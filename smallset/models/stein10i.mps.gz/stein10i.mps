NAME           
ROWS
 N  obj     
 G  c1      
 G  c2      
 G  c3      
 G  c4      
 G  c5      
 G  c6      
 G  c7      
 G  c8      
 G  c9      
 G  c10     
 G  c11     
 G  c12     
 L  c13     
 L  c14     
 L  c15     
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x1        obj                  1   c2                   1
    x1        c3                   1   c7                   1
    x1        c10                  1   c13                  1
    x2        obj                  1   c1                   1
    x2        c3                   1   c8                   1
    x2        c11                  1   c13                  1
    x3        obj                  1   c1                   1
    x3        c2                   1   c9                   1
    x3        c12                  1   c13                  1
    x4        obj                  1   c1                   1
    x4        c5                   1   c6                   1
    x4        c10                  1   c14                  1
    x5        obj                  1   c2                   1
    x5        c4                   1   c6                   1
    x5        c11                  1   c14                  1
    x6        obj                  1   c3                   1
    x6        c4                   1   c5                   1
    x6        c12                  1   c14                  1
    x7        obj                  1   c4                   1
    x7        c8                   1   c9                   1
    x7        c10                  1   c15                  1
    x8        obj                  1   c5                   1
    x8        c7                   1   c9                   1
    x8        c11                  1   c15                  1
    x9        obj                  1   c6                   1
    x9        c7                   1   c8                   1
    x9        c12                  1   c15                  1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       c1                   1   c2                   1
    rhs       c3                   1   c4                   1
    rhs       c5                   1   c6                   1
    rhs       c7                   1   c8                   1
    rhs       c9                   1   c10                  1
    rhs       c11                  1   c12                  1
    rhs       c13                1.5   c14                1.5
    rhs       c15                1.5
BOUNDS
 UP bnd       x1                   1
 UP bnd       x2                   1
 UP bnd       x3                   1
 UP bnd       x4                   1
 UP bnd       x5                   1
 UP bnd       x6                   1
 UP bnd       x7                   1
 UP bnd       x8                   1
 UP bnd       x9                   1
ENDATA
