NAME (null)
ROWS
 N  OBJ
 E  R0      
 G  R1      
 G  R2      
 G  R3      
 G  R4      
 G  R5      
 G  R6      
 G  R7      
 G  R8      
 G  R9      
 G  R10     
 G  R11     
 G  R12     
 G  R13     
 G  R14     
 G  R15     
 G  R16     
 G  R17     
 G  R18     
 G  R19     
 G  R20     
 G  R21     
 G  R22     
 G  R23     
 G  R24     
 G  R25     
 G  R26     
 G  R27     
 G  R28     
 G  R29     
 G  R30     
 G  R31     
 G  R32     
 G  R33     
 G  R34     
 G  R35     
 G  R36     
 G  R37     
 G  R38     
 G  R39     
 G  R40     
 G  R41     
 G  R42     
 G  R43     
 G  R44     
 G  R45     
 G  R46     
 G  R47     
 G  R48     
 G  R49     
 G  R50     
 G  R51     
 G  R52     
 G  R53     
 G  R54     
 G  R55     
 G  R56     
 G  R57     
 G  R58     
 G  R59     
 G  R60     
 G  R61     
 G  R62     
 G  R63     
 G  R64     
 G  R65     
 G  R66     
 G  R67     
 G  R68     
 G  R69     
 G  R70     
 G  R71     
 G  R72     
 G  R73     
 G  R74     
 G  R75     
 G  R76     
 G  R77     
 G  R78     
 G  R79     
 G  R80     
 G  R81     
 G  R82     
 G  R83     
 G  R84     
 G  R85     
 G  R86     
 G  R87     
 G  R88     
 G  R89     
 G  R90     
 G  R91     
 G  R92     
 G  R93     
 G  R94     
 G  R95     
 G  R96     
 G  R97     
 G  R98     
 G  R99     
 G  R100    
 G  R101    
 G  R102    
 G  R103    
 G  R104    
 G  R105    
 G  R106    
 G  R107    
 G  R108    
 G  R109    
 G  R110    
 G  R111    
 G  R112    
 G  R113    
 G  R114    
 G  R115    
 G  R116    
 G  R117    
 G  R118    
 G  R119    
 G  R120    
 G  R121    
 G  R122    
 G  R123    
 G  R124    
 G  R125    
 G  R126    
 G  R127    
 G  R128    
 G  R129    
 G  R130    
 G  R131    
 G  R132    
 G  R133    
 G  R134    
 G  R135    
 G  R136    
 G  R137    
 G  R138    
 G  R139    
 G  R140    
 G  R141    
 G  R142    
 G  R143    
 G  R144    
 G  R145    
 G  R146    
 G  R147    
 G  R148    
 G  R149    
 G  R150    
 G  R151    
 G  R152    
 G  R153    
 G  R154    
 G  R155    
 G  R156    
 G  R157    
 G  R158    
 G  R159    
 G  R160    
 G  R161    
 G  R162    
 G  R163    
 G  R164    
 G  R165    
 G  R166    
 G  R167    
 G  R168    
 G  R169    
 G  R170    
 G  R171    
 G  R172    
 G  R173    
 G  R174    
 G  R175    
 G  R176    
 G  R177    
 G  R178    
 G  R179    
 G  R180    
 G  R181    
 G  R182    
 G  R183    
 G  R184    
 G  R185    
 G  R186    
 G  R187    
 G  R188    
 G  R189    
 G  R190    
 G  R191    
 G  R192    
 G  R193    
 G  R194    
 G  R195    
 G  R196    
 G  R197    
 G  R198    
 G  R199    
 G  R200    
 G  R201    
 G  R202    
 G  R203    
 G  R204    
 G  R205    
 G  R206    
 G  R207    
 G  R208    
 G  R209    
 G  R210    
 G  R211    
 G  R212    
 G  R213    
 G  R214    
 G  R215    
 G  R216    
 G  R217    
 G  R218    
 G  R219    
 G  R220    
 G  R221    
 G  R222    
 G  R223    
 G  R224    
 G  R225    
 G  R226    
 G  R227    
 G  R228    
 G  R229    
 G  R230    
 G  R231    
 G  R232    
 G  R233    
 G  R234    
 G  R235    
 G  R236    
 G  R237    
 G  R238    
 G  R239    
 G  R240    
 G  R241    
 G  R242    
 G  R243    
 G  R244    
 G  R245    
 G  R246    
 G  R247    
 G  R248    
 G  R249    
 G  R250    
 G  R251    
 G  R252    
 G  R253    
 G  R254    
 G  R255    
 G  R256    
 G  R257    
 G  R258    
 G  R259    
 G  R260    
 G  R261    
 G  R262    
 G  R263    
 G  R264    
 G  R265    
 G  R266    
 G  R267    
 G  R268    
 G  R269    
 G  R270    
 G  R271    
 G  R272    
 G  R273    
 G  R274    
 G  R275    
 G  R276    
 G  R277    
 G  R278    
 G  R279    
 G  R280    
 G  R281    
 G  R282    
 G  R283    
 G  R284    
 G  R285    
 G  R286    
 G  R287    
 G  R288    
 G  R289    
 G  R290    
 G  R291    
 G  R292    
 G  R293    
 G  R294    
 G  R295    
 G  R296    
 G  R297    
 G  R298    
 G  R299    
 G  R300    
 G  R301    
 G  R302    
 G  R303    
 G  R304    
 G  R305    
 G  R306    
 G  R307    
 G  R308    
 G  R309    
 G  R310    
 G  R311    
 G  R312    
 G  R313    
 G  R314    
 G  R315    
 G  R316    
 G  R317    
 G  R318    
 G  R319    
 G  R320    
 G  R321    
 G  R322    
 G  R323    
 G  R324    
 G  R325    
 G  R326    
 G  R327    
 G  R328    
 G  R329    
 G  R330    
 G  R331    
 G  R332    
 G  R333    
 G  R334    
 G  R335    
 G  R336    
 G  R337    
 G  R338    
 G  R339    
 G  R340    
 G  R341    
 G  R342    
 G  R343    
 G  R344    
 G  R345    
 G  R346    
 G  R347    
 G  R348    
 G  R349    
 G  R350    
 G  R351    
 G  R352    
 G  R353    
 G  R354    
 G  R355    
 G  R356    
 G  R357    
 G  R358    
 G  R359    
 G  R360    
 G  R361    
 G  R362    
 G  R363    
 G  R364    
 G  R365    
 G  R366    
 G  R367    
 G  R368    
 G  R369    
 G  R370    
 G  R371    
 G  R372    
 G  R373    
 G  R374    
 G  R375    
 G  R376    
 G  R377    
 G  R378    
 G  R379    
 G  R380    
 G  R381    
 G  R382    
 G  R383    
 G  R384    
 G  R385    
 G  R386    
 G  R387    
 G  R388    
 G  R389    
 G  R390    
 G  R391    
 G  R392    
 G  R393    
 G  R394    
 G  R395    
 G  R396    
 G  R397    
 G  R398    
 G  R399    
 G  R400    
 G  R401    
 G  R402    
 G  R403    
 G  R404    
 G  R405    
 G  R406    
 G  R407    
 G  R408    
 G  R409    
 G  R410    
 G  R411    
 G  R412    
 G  R413    
 G  R414    
 G  R415    
 G  R416    
 G  R417    
 G  R418    
 G  R419    
 G  R420    
 G  R421    
 G  R422    
 G  R423    
 G  R424    
 G  R425    
 G  R426    
 G  R427    
 G  R428    
 G  R429    
 G  R430    
 G  R431    
 G  R432    
 G  R433    
 G  R434    
 G  R435    
 G  R436    
 G  R437    
 G  R438    
 G  R439    
 G  R440    
 G  R441    
 G  R442    
 G  R443    
 G  R444    
 G  R445    
 G  R446    
 G  R447    
 G  R448    
 G  R449    
 G  R450    
 G  R451    
 G  R452    
 G  R453    
 G  R454    
 G  R455    
 G  R456    
 G  R457    
 G  R458    
 G  R459    
 G  R460    
 G  R461    
 G  R462    
 G  R463    
 G  R464    
 G  R465    
 G  R466    
 G  R467    
 G  R468    
 G  R469    
 G  R470    
 G  R471    
 G  R472    
 G  R473    
 G  R474    
 G  R475    
 G  R476    
 G  R477    
 G  R478    
 G  R479    
 G  R480    
 G  R481    
 G  R482    
 G  R483    
 G  R484    
 G  R485    
 G  R486    
 G  R487    
 G  R488    
 G  R489    
 G  R490    
 G  R491    
 G  R492    
 G  R493    
 G  R494    
 G  R495    
 G  R496    
 G  R497    
 G  R498    
 G  R499    
 G  R500    
 G  R501    
 G  R502    
 G  R503    
 G  R504    
 G  R505    
 G  R506    
 G  R507    
 G  R508    
 G  R509    
 G  R510    
 G  R511    
 G  R512    
 G  R513    
 G  R514    
 G  R515    
 G  R516    
 G  R517    
 G  R518    
 G  R519    
 G  R520    
 G  R521    
 G  R522    
 G  R523    
 G  R524    
 G  R525    
 G  R526    
 G  R527    
 G  R528    
 G  R529    
 G  R530    
 G  R531    
 G  R532    
 G  R533    
 G  R534    
 G  R535    
 G  R536    
 G  R537    
 G  R538    
 G  R539    
 G  R540    
 G  R541    
 G  R542    
 G  R543    
 G  R544    
 G  R545    
 G  R546    
 G  R547    
 G  R548    
 G  R549    
 G  R550    
 G  R551    
 G  R552    
 G  R553    
 G  R554    
 G  R555    
 G  R556    
 G  R557    
 G  R558    
 G  R559    
 G  R560    
 G  R561    
 G  R562    
 G  R563    
 G  R564    
 G  R565    
 G  R566    
 G  R567    
 G  R568    
 G  R569    
 G  R570    
 G  R571    
 G  R572    
 G  R573    
 G  R574    
 G  R575    
 G  R576    
 G  R577    
 G  R578    
 G  R579    
 G  R580    
 G  R581    
 G  R582    
 G  R583    
 G  R584    
 G  R585    
 G  R586    
 G  R587    
 G  R588    
 G  R589    
 G  R590    
 G  R591    
 G  R592    
 G  R593    
 G  R594    
 G  R595    
 G  R596    
 G  R597    
 G  R598    
 G  R599    
 G  R600    
 G  R601    
 G  R602    
 G  R603    
 G  R604    
 G  R605    
 G  R606    
 G  R607    
 G  R608    
 G  R609    
 G  R610    
 G  R611    
 G  R612    
 G  R613    
 G  R614    
 G  R615    
 G  R616    
 G  R617    
 G  R618    
 G  R619    
 G  R620    
 G  R621    
 G  R622    
 G  R623    
 G  R624    
 G  R625    
 G  R626    
 G  R627    
 G  R628    
 G  R629    
 G  R630    
 G  R631    
 G  R632    
 G  R633    
 G  R634    
 G  R635    
 G  R636    
 G  R637    
 G  R638    
 G  R639    
 G  R640    
 G  R641    
 G  R642    
 G  R643    
 G  R644    
 G  R645    
 G  R646    
 G  R647    
 G  R648    
 G  R649    
 G  R650    
 G  R651    
 G  R652    
 G  R653    
 G  R654    
 G  R655    
 G  R656    
 G  R657    
 G  R658    
 G  R659    
 G  R660    
 G  R661    
 G  R662    
 G  R663    
 G  R664    
 G  R665    
 G  R666    
 G  R667    
 G  R668    
 G  R669    
 G  R670    
 G  R671    
 G  R672    
 G  R673    
 G  R674    
 G  R675    
 G  R676    
 G  R677    
 G  R678    
 G  R679    
 G  R680    
 G  R681    
 G  R682    
 G  R683    
 G  R684    
 G  R685    
 G  R686    
 G  R687    
 G  R688    
 G  R689    
 G  R690    
 G  R691    
 G  R692    
 G  R693    
 G  R694    
 G  R695    
 G  R696    
 G  R697    
 G  R698    
 G  R699    
 G  R700    
 G  R701    
 G  R702    
 G  R703    
 G  R704    
 G  R705    
 G  R706    
 G  R707    
 G  R708    
 G  R709    
 G  R710    
 G  R711    
 G  R712    
 G  R713    
 G  R714    
 G  R715    
 G  R716    
 G  R717    
 G  R718    
 G  R719    
 G  R720    
 G  R721    
 G  R722    
 G  R723    
 G  R724    
 G  R725    
 G  R726    
 G  R727    
 G  R728    
 G  R729    
 G  R730    
 G  R731    
 G  R732    
 G  R733    
 G  R734    
 G  R735    
 G  R736    
 G  R737    
 G  R738    
 G  R739    
 G  R740    
 G  R741    
 G  R742    
 G  R743    
 G  R744    
 G  R745    
 G  R746    
 G  R747    
 G  R748    
 G  R749    
 G  R750    
 G  R751    
 G  R752    
 G  R753    
 G  R754    
 G  R755    
 G  R756    
 G  R757    
 G  R758    
 G  R759    
 G  R760    
 G  R761    
 G  R762    
 G  R763    
 G  R764    
 G  R765    
 G  R766    
 G  R767    
 G  R768    
 G  R769    
 G  R770    
 G  R771    
 G  R772    
 G  R773    
 G  R774    
 G  R775    
 G  R776    
 G  R777    
 G  R778    
 G  R779    
 G  R780    
 G  R781    
 G  R782    
 G  R783    
 G  R784    
 G  R785    
 G  R786    
 G  R787    
 G  R788    
 G  R789    
 G  R790    
 G  R791    
 G  R792    
 G  R793    
 G  R794    
 G  R795    
 G  R796    
 G  R797    
 G  R798    
 G  R799    
 G  R800    
 G  R801    
 G  R802    
 G  R803    
 G  R804    
 G  R805    
 G  R806    
 G  R807    
 G  R808    
 G  R809    
 G  R810    
 G  R811    
 G  R812    
 G  R813    
 G  R814    
 G  R815    
 G  R816    
 G  R817    
 G  R818    
 G  R819    
 G  R820    
 G  R821    
 G  R822    
 G  R823    
 G  R824    
 G  R825    
 G  R826    
 G  R827    
 G  R828    
 G  R829    
 G  R830    
 G  R831    
 G  R832    
 G  R833    
 G  R834    
 G  R835    
 G  R836    
 G  R837    
 G  R838    
 G  R839    
 G  R840    
 G  R841    
 G  R842    
 G  R843    
 G  R844    
 G  R845    
 G  R846    
 G  R847    
 G  R848    
 G  R849    
 G  R850    
 G  R851    
 G  R852    
 G  R853    
 G  R854    
 G  R855    
 G  R856    
 G  R857    
 G  R858    
 G  R859    
 G  R860    
 G  R861    
 G  R862    
 G  R863    
 G  R864    
 G  R865    
 G  R866    
 G  R867    
 G  R868    
 G  R869    
 G  R870    
 G  R871    
 G  R872    
 G  R873    
 G  R874    
 G  R875    
 G  R876    
 G  R877    
 G  R878    
 G  R879    
 G  R880    
 G  R881    
 G  R882    
 G  R883    
 G  R884    
 G  R885    
 G  R886    
 G  R887    
 G  R888    
 G  R889    
 G  R890    
 G  R891    
 G  R892    
 G  R893    
 G  R894    
 G  R895    
 G  R896    
 G  R897    
 G  R898    
 G  R899    
 G  R900    
 G  R901    
 G  R902    
 G  R903    
 G  R904    
 G  R905    
 G  R906    
 G  R907    
 G  R908    
 G  R909    
 G  R910    
 G  R911    
 G  R912    
 G  R913    
 G  R914    
 G  R915    
 G  R916    
 G  R917    
 G  R918    
 G  R919    
 G  R920    
 G  R921    
 G  R922    
 G  R923    
 G  R924    
 G  R925    
 G  R926    
 G  R927    
 G  R928    
 G  R929    
 G  R930    
 G  R931    
 G  R932    
 G  R933    
 G  R934    
 G  R935    
 G  R936    
 G  R937    
 G  R938    
 G  R939    
 G  R940    
 G  R941    
 G  R942    
 G  R943    
 G  R944    
 G  R945    
 G  R946    
 G  R947    
 G  R948    
 G  R949    
 G  R950    
 G  R951    
 G  R952    
 G  R953    
 G  R954    
 G  R955    
 G  R956    
 G  R957    
 G  R958    
 G  R959    
 G  R960    
 G  R961    
 G  R962    
 G  R963    
 G  R964    
 G  R965    
 G  R966    
 G  R967    
 G  R968    
 G  R969    
 G  R970    
 G  R971    
 G  R972    
 G  R973    
 G  R974    
 G  R975    
 G  R976    
 G  R977    
 G  R978    
 G  R979    
 G  R980    
 G  R981    
 G  R982    
 G  R983    
 G  R984    
 G  R985    
 G  R986    
 G  R987    
 G  R988    
 G  R989    
 G  R990    
 G  R991    
 G  R992    
 G  R993    
 G  R994    
 G  R995    
 G  R996    
 G  R997    
 G  R998    
 G  R999    
 G  R1000   
 G  R1001   
 G  R1002   
 G  R1003   
 G  R1004   
 G  R1005   
 G  R1006   
 G  R1007   
 G  R1008   
 G  R1009   
 G  R1010   
 G  R1011   
 G  R1012   
 G  R1013   
 G  R1014   
 G  R1015   
 G  R1016   
 G  R1017   
 G  R1018   
 G  R1019   
 G  R1020   
 G  R1021   
 G  R1022   
 G  R1023   
 G  R1024   
 G  R1025   
 G  R1026   
 G  R1027   
 G  R1028   
 G  R1029   
 G  R1030   
 G  R1031   
 G  R1032   
 G  R1033   
 G  R1034   
 G  R1035   
 G  R1036   
 G  R1037   
 G  R1038   
 G  R1039   
 G  R1040   
 G  R1041   
 G  R1042   
 G  R1043   
 G  R1044   
 G  R1045   
 G  R1046   
 G  R1047   
 G  R1048   
 G  R1049   
 G  R1050   
 G  R1051   
 G  R1052   
 G  R1053   
 G  R1054   
 G  R1055   
 G  R1056   
 G  R1057   
 G  R1058   
 G  R1059   
 G  R1060   
 G  R1061   
 G  R1062   
 G  R1063   
 G  R1064   
 G  R1065   
 G  R1066   
 G  R1067   
 G  R1068   
 G  R1069   
 G  R1070   
 G  R1071   
 G  R1072   
 G  R1073   
 G  R1074   
 G  R1075   
 G  R1076   
 G  R1077   
 G  R1078   
 G  R1079   
 G  R1080   
 G  R1081   
 G  R1082   
 G  R1083   
 G  R1084   
 G  R1085   
 G  R1086   
 G  R1087   
 G  R1088   
 G  R1089   
 G  R1090   
 G  R1091   
 G  R1092   
 G  R1093   
 G  R1094   
 G  R1095   
 G  R1096   
 G  R1097   
 G  R1098   
 G  R1099   
 G  R1100   
 G  R1101   
 G  R1102   
 G  R1103   
 G  R1104   
 G  R1105   
 G  R1106   
 G  R1107   
 G  R1108   
 G  R1109   
 G  R1110   
 G  R1111   
 G  R1112   
 G  R1113   
 G  R1114   
 G  R1115   
 G  R1116   
 G  R1117   
 G  R1118   
 G  R1119   
 G  R1120   
 G  R1121   
 G  R1122   
 G  R1123   
 G  R1124   
 G  R1125   
 G  R1126   
 G  R1127   
 G  R1128   
 G  R1129   
 G  R1130   
 G  R1131   
 G  R1132   
 G  R1133   
 G  R1134   
 G  R1135   
 G  R1136   
 G  R1137   
 G  R1138   
 G  R1139   
 G  R1140   
 G  R1141   
 G  R1142   
 G  R1143   
 G  R1144   
 G  R1145   
 G  R1146   
 G  R1147   
 G  R1148   
 G  R1149   
 G  R1150   
 G  R1151   
 G  R1152   
 G  R1153   
 G  R1154   
 G  R1155   
 G  R1156   
 G  R1157   
 G  R1158   
 G  R1159   
 G  R1160   
 G  R1161   
 G  R1162   
 G  R1163   
 G  R1164   
 G  R1165   
 G  R1166   
 G  R1167   
 G  R1168   
 G  R1169   
 G  R1170   
 G  R1171   
 G  R1172   
 G  R1173   
 G  R1174   
 G  R1175   
 G  R1176   
 G  R1177   
 G  R1178   
 G  R1179   
 G  R1180   
 G  R1181   
 G  R1182   
 G  R1183   
 G  R1184   
 G  R1185   
 G  R1186   
 G  R1187   
 G  R1188   
 G  R1189   
 G  R1190   
 G  R1191   
 G  R1192   
 G  R1193   
 G  R1194   
 G  R1195   
 G  R1196   
 G  R1197   
 G  R1198   
 G  R1199   
 G  R1200   
 E  R1201   
 E  R1202   
 E  R1203   
 G  R1204   
 G  R1205   
 G  R1206   
 G  R1207   
 G  R1208   
 G  R1209   
 G  R1210   
 G  R1211   
 G  R1212   
 G  R1213   
 G  R1214   
 G  R1215   
 G  R1216   
 G  R1217   
 G  R1218   
 G  R1219   
 G  R1220   
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x1        R0        1
    x1        R241      1
    x1        R243      1
    x1        R245      1
    x1        R247      1
    x1        R249      1
    x1        R251      1
    x1        R253      1
    x1        R255      1
    x1        R257      1
    x1        R259      1
    x1        R261      1
    x1        R263      1
    x1        R265      1
    x1        R267      1
    x1        R269      1
    x1        R300      1
    x1        R328      1
    x1        R356      1
    x1        R384      1
    x1        R412      1
    x1        R440      1
    x1        R468      1
    x1        R496      1
    x1        R524      1
    x1        R552      1
    x1        R580      1
    x1        R608      1
    x1        R636      1
    x1        R664      1
    x1        R692      1
    x1        R1201     1
    x1        R1204     1
    x2        R0        1
    x2        R242      1
    x2        R271      1
    x2        R273      1
    x2        R275      1
    x2        R277      1
    x2        R279      1
    x2        R281      1
    x2        R283      1
    x2        R285      1
    x2        R287      1
    x2        R289      1
    x2        R291      1
    x2        R293      1
    x2        R295      1
    x2        R297      1
    x2        R299      1
    x2        R330      1
    x2        R358      1
    x2        R386      1
    x2        R414      1
    x2        R442      1
    x2        R470      1
    x2        R498      1
    x2        R526      1
    x2        R554      1
    x2        R582      1
    x2        R610      1
    x2        R638      1
    x2        R666      1
    x2        R694      1
    x2        R1205     1
    x3        R0        1
    x3        R244      1
    x3        R272      1
    x3        R301      1
    x3        R303      1
    x3        R305      1
    x3        R307      1
    x3        R309      1
    x3        R311      1
    x3        R313      1
    x3        R315      1
    x3        R317      1
    x3        R319      1
    x3        R321      1
    x3        R323      1
    x3        R325      1
    x3        R327      1
    x3        R329      1
    x3        R360      1
    x3        R388      1
    x3        R416      1
    x3        R444      1
    x3        R472      1
    x3        R500      1
    x3        R528      1
    x3        R556      1
    x3        R584      1
    x3        R612      1
    x3        R640      1
    x3        R668      1
    x3        R696      1
    x3        R1206     1
    x4        R0        1
    x4        R246      1
    x4        R274      1
    x4        R302      1
    x4        R331      1
    x4        R333      1
    x4        R335      1
    x4        R337      1
    x4        R339      1
    x4        R341      1
    x4        R343      1
    x4        R345      1
    x4        R347      1
    x4        R349      1
    x4        R351      1
    x4        R353      1
    x4        R355      1
    x4        R357      1
    x4        R359      1
    x4        R390      1
    x4        R418      1
    x4        R446      1
    x4        R474      1
    x4        R502      1
    x4        R530      1
    x4        R558      1
    x4        R586      1
    x4        R614      1
    x4        R642      1
    x4        R670      1
    x4        R698      1
    x4        R1207     1
    x5        R0        1
    x5        R248      1
    x5        R276      1
    x5        R304      1
    x5        R332      1
    x5        R361      1
    x5        R363      1
    x5        R365      1
    x5        R367      1
    x5        R369      1
    x5        R371      1
    x5        R373      1
    x5        R375      1
    x5        R377      1
    x5        R379      1
    x5        R381      1
    x5        R383      1
    x5        R385      1
    x5        R387      1
    x5        R389      1
    x5        R420      1
    x5        R448      1
    x5        R476      1
    x5        R504      1
    x5        R532      1
    x5        R560      1
    x5        R588      1
    x5        R616      1
    x5        R644      1
    x5        R672      1
    x5        R700      1
    x5        R1208     1
    x6        R0        1
    x6        R250      1
    x6        R278      1
    x6        R306      1
    x6        R334      1
    x6        R362      1
    x6        R391      1
    x6        R393      1
    x6        R395      1
    x6        R397      1
    x6        R399      1
    x6        R401      1
    x6        R403      1
    x6        R405      1
    x6        R407      1
    x6        R409      1
    x6        R411      1
    x6        R413      1
    x6        R415      1
    x6        R417      1
    x6        R419      1
    x6        R450      1
    x6        R478      1
    x6        R506      1
    x6        R534      1
    x6        R562      1
    x6        R590      1
    x6        R618      1
    x6        R646      1
    x6        R674      1
    x6        R702      1
    x6        R1209     1
    x7        R0        1
    x7        R252      1
    x7        R280      1
    x7        R308      1
    x7        R336      1
    x7        R364      1
    x7        R392      1
    x7        R421      1
    x7        R423      1
    x7        R425      1
    x7        R427      1
    x7        R429      1
    x7        R431      1
    x7        R433      1
    x7        R435      1
    x7        R437      1
    x7        R439      1
    x7        R441      1
    x7        R443      1
    x7        R445      1
    x7        R447      1
    x7        R449      1
    x7        R480      1
    x7        R508      1
    x7        R536      1
    x7        R564      1
    x7        R592      1
    x7        R620      1
    x7        R648      1
    x7        R676      1
    x7        R704      1
    x7        R1210     1
    x8        R0        1
    x8        R254      1
    x8        R282      1
    x8        R310      1
    x8        R338      1
    x8        R366      1
    x8        R394      1
    x8        R422      1
    x8        R451      1
    x8        R453      1
    x8        R455      1
    x8        R457      1
    x8        R459      1
    x8        R461      1
    x8        R463      1
    x8        R465      1
    x8        R467      1
    x8        R469      1
    x8        R471      1
    x8        R473      1
    x8        R475      1
    x8        R477      1
    x8        R479      1
    x8        R510      1
    x8        R538      1
    x8        R566      1
    x8        R594      1
    x8        R622      1
    x8        R650      1
    x8        R678      1
    x8        R706      1
    x8        R1211     1
    x9        R0        1
    x9        R256      1
    x9        R284      1
    x9        R312      1
    x9        R340      1
    x9        R368      1
    x9        R396      1
    x9        R424      1
    x9        R452      1
    x9        R481      1
    x9        R483      1
    x9        R485      1
    x9        R487      1
    x9        R489      1
    x9        R491      1
    x9        R493      1
    x9        R495      1
    x9        R497      1
    x9        R499      1
    x9        R501      1
    x9        R503      1
    x9        R505      1
    x9        R507      1
    x9        R509      1
    x9        R540      1
    x9        R568      1
    x9        R596      1
    x9        R624      1
    x9        R652      1
    x9        R680      1
    x9        R708      1
    x9        R1212     1
    x10       R0        1
    x10       R258      1
    x10       R286      1
    x10       R314      1
    x10       R342      1
    x10       R370      1
    x10       R398      1
    x10       R426      1
    x10       R454      1
    x10       R482      1
    x10       R511      1
    x10       R513      1
    x10       R515      1
    x10       R517      1
    x10       R519      1
    x10       R521      1
    x10       R523      1
    x10       R525      1
    x10       R527      1
    x10       R529      1
    x10       R531      1
    x10       R533      1
    x10       R535      1
    x10       R537      1
    x10       R539      1
    x10       R570      1
    x10       R598      1
    x10       R626      1
    x10       R654      1
    x10       R682      1
    x10       R710      1
    x10       R1213     1
    x11       R0        1
    x11       R260      1
    x11       R288      1
    x11       R316      1
    x11       R344      1
    x11       R372      1
    x11       R400      1
    x11       R428      1
    x11       R456      1
    x11       R484      1
    x11       R512      1
    x11       R541      1
    x11       R543      1
    x11       R545      1
    x11       R547      1
    x11       R549      1
    x11       R551      1
    x11       R553      1
    x11       R555      1
    x11       R557      1
    x11       R559      1
    x11       R561      1
    x11       R563      1
    x11       R565      1
    x11       R567      1
    x11       R569      1
    x11       R600      1
    x11       R628      1
    x11       R656      1
    x11       R684      1
    x11       R712      1
    x11       R1214     1
    x12       R0        1
    x12       R262      1
    x12       R290      1
    x12       R318      1
    x12       R346      1
    x12       R374      1
    x12       R402      1
    x12       R430      1
    x12       R458      1
    x12       R486      1
    x12       R514      1
    x12       R542      1
    x12       R571      1
    x12       R573      1
    x12       R575      1
    x12       R577      1
    x12       R579      1
    x12       R581      1
    x12       R583      1
    x12       R585      1
    x12       R587      1
    x12       R589      1
    x12       R591      1
    x12       R593      1
    x12       R595      1
    x12       R597      1
    x12       R599      1
    x12       R630      1
    x12       R658      1
    x12       R686      1
    x12       R714      1
    x12       R1215     1
    x13       R0        1
    x13       R264      1
    x13       R292      1
    x13       R320      1
    x13       R348      1
    x13       R376      1
    x13       R404      1
    x13       R432      1
    x13       R460      1
    x13       R488      1
    x13       R516      1
    x13       R544      1
    x13       R572      1
    x13       R601      1
    x13       R603      1
    x13       R605      1
    x13       R607      1
    x13       R609      1
    x13       R611      1
    x13       R613      1
    x13       R615      1
    x13       R617      1
    x13       R619      1
    x13       R621      1
    x13       R623      1
    x13       R625      1
    x13       R627      1
    x13       R629      1
    x13       R660      1
    x13       R688      1
    x13       R716      1
    x13       R1216     1
    x14       R0        1
    x14       R266      1
    x14       R294      1
    x14       R322      1
    x14       R350      1
    x14       R378      1
    x14       R406      1
    x14       R434      1
    x14       R462      1
    x14       R490      1
    x14       R518      1
    x14       R546      1
    x14       R574      1
    x14       R602      1
    x14       R631      1
    x14       R633      1
    x14       R635      1
    x14       R637      1
    x14       R639      1
    x14       R641      1
    x14       R643      1
    x14       R645      1
    x14       R647      1
    x14       R649      1
    x14       R651      1
    x14       R653      1
    x14       R655      1
    x14       R657      1
    x14       R659      1
    x14       R690      1
    x14       R718      1
    x14       R1217     1
    x15       R0        1
    x15       R268      1
    x15       R296      1
    x15       R324      1
    x15       R352      1
    x15       R380      1
    x15       R408      1
    x15       R436      1
    x15       R464      1
    x15       R492      1
    x15       R520      1
    x15       R548      1
    x15       R576      1
    x15       R604      1
    x15       R632      1
    x15       R661      1
    x15       R663      1
    x15       R665      1
    x15       R667      1
    x15       R669      1
    x15       R671      1
    x15       R673      1
    x15       R675      1
    x15       R677      1
    x15       R679      1
    x15       R681      1
    x15       R683      1
    x15       R685      1
    x15       R687      1
    x15       R689      1
    x15       R720      1
    x15       R1218     1
    x16       R0        1
    x16       R270      1
    x16       R298      1
    x16       R326      1
    x16       R354      1
    x16       R382      1
    x16       R410      1
    x16       R438      1
    x16       R466      1
    x16       R494      1
    x16       R522      1
    x16       R550      1
    x16       R578      1
    x16       R606      1
    x16       R634      1
    x16       R662      1
    x16       R691      1
    x16       R693      1
    x16       R695      1
    x16       R697      1
    x16       R699      1
    x16       R701      1
    x16       R703      1
    x16       R705      1
    x16       R707      1
    x16       R709      1
    x16       R711      1
    x16       R713      1
    x16       R715      1
    x16       R717      1
    x16       R719      1
    x16       R1219     1
    x33       R1        1
    x33       R196      1
    x33       R211      1
    x33       R226      1
    x33       R241      -1
    x33       R242      -1
    x33       R721      -1
    x33       R722      -1
    x33       R1203     1
    x48       R1        1
    x48       R16       1
    x48       R211      1
    x48       R226      1
    x48       R271      -1
    x48       R272      -1
    x48       R751      -1
    x48       R752      -1
    x63       R1        1
    x63       R16       1
    x63       R31       1
    x63       R226      1
    x63       R301      -1
    x63       R302      -1
    x63       R781      -1
    x63       R782      -1
    x78       R1        1
    x78       R16       1
    x78       R31       1
    x78       R46       1
    x78       R331      -1
    x78       R332      -1
    x78       R811      -1
    x78       R812      -1
    x34       R2        1
    x34       R197      1
    x34       R212      1
    x34       R227      1
    x34       R243      -1
    x34       R244      -1
    x34       R723      -1
    x34       R724      -1
    x49       R2        1
    x49       R17       1
    x49       R212      1
    x49       R227      1
    x49       R273      -1
    x49       R274      -1
    x49       R753      -1
    x49       R754      -1
    x64       R2        1
    x64       R17       1
    x64       R32       1
    x64       R227      1
    x64       R303      -1
    x64       R304      -1
    x64       R783      -1
    x64       R784      -1
    x79       R2        1
    x79       R17       1
    x79       R32       1
    x79       R47       1
    x79       R333      -1
    x79       R334      -1
    x79       R813      -1
    x79       R814      -1
    x35       R3        1
    x35       R198      1
    x35       R213      1
    x35       R228      1
    x35       R245      -1
    x35       R246      -1
    x35       R725      -1
    x35       R726      -1
    x50       R3        1
    x50       R18       1
    x50       R213      1
    x50       R228      1
    x50       R275      -1
    x50       R276      -1
    x50       R755      -1
    x50       R756      -1
    x65       R3        1
    x65       R18       1
    x65       R33       1
    x65       R228      1
    x65       R305      -1
    x65       R306      -1
    x65       R785      -1
    x65       R786      -1
    x80       R3        1
    x80       R18       1
    x80       R33       1
    x80       R48       1
    x80       R335      -1
    x80       R336      -1
    x80       R815      -1
    x80       R816      -1
    x36       R4        1
    x36       R199      1
    x36       R214      1
    x36       R229      1
    x36       R247      -1
    x36       R248      -1
    x36       R727      -1
    x36       R728      -1
    x51       R4        1
    x51       R19       1
    x51       R214      1
    x51       R229      1
    x51       R277      -1
    x51       R278      -1
    x51       R757      -1
    x51       R758      -1
    x66       R4        1
    x66       R19       1
    x66       R34       1
    x66       R229      1
    x66       R307      -1
    x66       R308      -1
    x66       R787      -1
    x66       R788      -1
    x81       R4        1
    x81       R19       1
    x81       R34       1
    x81       R49       1
    x81       R337      -1
    x81       R338      -1
    x81       R817      -1
    x81       R818      -1
    x37       R5        1
    x37       R200      1
    x37       R215      1
    x37       R230      1
    x37       R249      -1
    x37       R250      -1
    x37       R729      -1
    x37       R730      -1
    x52       R5        1
    x52       R20       1
    x52       R215      1
    x52       R230      1
    x52       R279      -1
    x52       R280      -1
    x52       R759      -1
    x52       R760      -1
    x67       R5        1
    x67       R20       1
    x67       R35       1
    x67       R230      1
    x67       R309      -1
    x67       R310      -1
    x67       R789      -1
    x67       R790      -1
    x82       R5        1
    x82       R20       1
    x82       R35       1
    x82       R50       1
    x82       R339      -1
    x82       R340      -1
    x82       R819      -1
    x82       R820      -1
    x38       R6        1
    x38       R201      1
    x38       R216      1
    x38       R231      1
    x38       R251      -1
    x38       R252      -1
    x38       R731      -1
    x38       R732      -1
    x53       R6        1
    x53       R21       1
    x53       R216      1
    x53       R231      1
    x53       R281      -1
    x53       R282      -1
    x53       R761      -1
    x53       R762      -1
    x68       R6        1
    x68       R21       1
    x68       R36       1
    x68       R231      1
    x68       R311      -1
    x68       R312      -1
    x68       R791      -1
    x68       R792      -1
    x83       R6        1
    x83       R21       1
    x83       R36       1
    x83       R51       1
    x83       R341      -1
    x83       R342      -1
    x83       R821      -1
    x83       R822      -1
    x39       R7        1
    x39       R202      1
    x39       R217      1
    x39       R232      1
    x39       R253      -1
    x39       R254      -1
    x39       R733      -1
    x39       R734      -1
    x54       R7        1
    x54       R22       1
    x54       R217      1
    x54       R232      1
    x54       R283      -1
    x54       R284      -1
    x54       R763      -1
    x54       R764      -1
    x69       R7        1
    x69       R22       1
    x69       R37       1
    x69       R232      1
    x69       R313      -1
    x69       R314      -1
    x69       R793      -1
    x69       R794      -1
    x84       R7        1
    x84       R22       1
    x84       R37       1
    x84       R52       1
    x84       R343      -1
    x84       R344      -1
    x84       R823      -1
    x84       R824      -1
    x40       R8        1
    x40       R203      1
    x40       R218      1
    x40       R233      1
    x40       R255      -1
    x40       R256      -1
    x40       R735      -1
    x40       R736      -1
    x55       R8        1
    x55       R23       1
    x55       R218      1
    x55       R233      1
    x55       R285      -1
    x55       R286      -1
    x55       R765      -1
    x55       R766      -1
    x70       R8        1
    x70       R23       1
    x70       R38       1
    x70       R233      1
    x70       R315      -1
    x70       R316      -1
    x70       R795      -1
    x70       R796      -1
    x85       R8        1
    x85       R23       1
    x85       R38       1
    x85       R53       1
    x85       R345      -1
    x85       R346      -1
    x85       R825      -1
    x85       R826      -1
    x41       R9        1
    x41       R204      1
    x41       R219      1
    x41       R234      1
    x41       R257      -1
    x41       R258      -1
    x41       R737      -1
    x41       R738      -1
    x56       R9        1
    x56       R24       1
    x56       R219      1
    x56       R234      1
    x56       R287      -1
    x56       R288      -1
    x56       R767      -1
    x56       R768      -1
    x71       R9        1
    x71       R24       1
    x71       R39       1
    x71       R234      1
    x71       R317      -1
    x71       R318      -1
    x71       R797      -1
    x71       R798      -1
    x86       R9        1
    x86       R24       1
    x86       R39       1
    x86       R54       1
    x86       R347      -1
    x86       R348      -1
    x86       R827      -1
    x86       R828      -1
    x42       R10       1
    x42       R205      1
    x42       R220      1
    x42       R235      1
    x42       R259      -1
    x42       R260      -1
    x42       R739      -1
    x42       R740      -1
    x57       R10       1
    x57       R25       1
    x57       R220      1
    x57       R235      1
    x57       R289      -1
    x57       R290      -1
    x57       R769      -1
    x57       R770      -1
    x72       R10       1
    x72       R25       1
    x72       R40       1
    x72       R235      1
    x72       R319      -1
    x72       R320      -1
    x72       R799      -1
    x72       R800      -1
    x87       R10       1
    x87       R25       1
    x87       R40       1
    x87       R55       1
    x87       R349      -1
    x87       R350      -1
    x87       R829      -1
    x87       R830      -1
    x43       R11       1
    x43       R206      1
    x43       R221      1
    x43       R236      1
    x43       R261      -1
    x43       R262      -1
    x43       R741      -1
    x43       R742      -1
    x58       R11       1
    x58       R26       1
    x58       R221      1
    x58       R236      1
    x58       R291      -1
    x58       R292      -1
    x58       R771      -1
    x58       R772      -1
    x73       R11       1
    x73       R26       1
    x73       R41       1
    x73       R236      1
    x73       R321      -1
    x73       R322      -1
    x73       R801      -1
    x73       R802      -1
    x88       R11       1
    x88       R26       1
    x88       R41       1
    x88       R56       1
    x88       R351      -1
    x88       R352      -1
    x88       R831      -1
    x88       R832      -1
    x44       R12       1
    x44       R207      1
    x44       R222      1
    x44       R237      1
    x44       R263      -1
    x44       R264      -1
    x44       R743      -1
    x44       R744      -1
    x59       R12       1
    x59       R27       1
    x59       R222      1
    x59       R237      1
    x59       R293      -1
    x59       R294      -1
    x59       R773      -1
    x59       R774      -1
    x74       R12       1
    x74       R27       1
    x74       R42       1
    x74       R237      1
    x74       R323      -1
    x74       R324      -1
    x74       R803      -1
    x74       R804      -1
    x89       R12       1
    x89       R27       1
    x89       R42       1
    x89       R57       1
    x89       R353      -1
    x89       R354      -1
    x89       R833      -1
    x89       R834      -1
    x45       R13       1
    x45       R208      1
    x45       R223      1
    x45       R238      1
    x45       R265      -1
    x45       R266      -1
    x45       R745      -1
    x45       R746      -1
    x60       R13       1
    x60       R28       1
    x60       R223      1
    x60       R238      1
    x60       R295      -1
    x60       R296      -1
    x60       R775      -1
    x60       R776      -1
    x75       R13       1
    x75       R28       1
    x75       R43       1
    x75       R238      1
    x75       R325      -1
    x75       R326      -1
    x75       R805      -1
    x75       R806      -1
    x90       R13       1
    x90       R28       1
    x90       R43       1
    x90       R58       1
    x90       R355      -1
    x90       R356      -1
    x90       R835      -1
    x90       R836      -1
    x46       R14       1
    x46       R209      1
    x46       R224      1
    x46       R239      1
    x46       R267      -1
    x46       R268      -1
    x46       R747      -1
    x46       R748      -1
    x61       R14       1
    x61       R29       1
    x61       R224      1
    x61       R239      1
    x61       R297      -1
    x61       R298      -1
    x61       R777      -1
    x61       R778      -1
    x76       R14       1
    x76       R29       1
    x76       R44       1
    x76       R239      1
    x76       R327      -1
    x76       R328      -1
    x76       R807      -1
    x76       R808      -1
    x91       R14       1
    x91       R29       1
    x91       R44       1
    x91       R59       1
    x91       R357      -1
    x91       R358      -1
    x91       R837      -1
    x91       R838      -1
    x47       R15       1
    x47       R210      1
    x47       R225      1
    x47       R240      1
    x47       R269      -1
    x47       R270      -1
    x47       R749      -1
    x47       R750      -1
    x62       R15       1
    x62       R30       1
    x62       R225      1
    x62       R240      1
    x62       R299      -1
    x62       R300      -1
    x62       R779      -1
    x62       R780      -1
    x77       R15       1
    x77       R30       1
    x77       R45       1
    x77       R240      1
    x77       R329      -1
    x77       R330      -1
    x77       R809      -1
    x77       R810      -1
    x92       R15       1
    x92       R30       1
    x92       R45       1
    x92       R60       1
    x92       R359      -1
    x92       R360      -1
    x92       R839      -1
    x92       R840      -1
    x93       R16       1
    x93       R31       1
    x93       R46       1
    x93       R61       1
    x93       R361      -1
    x93       R362      -1
    x93       R841      -1
    x93       R842      -1
    x94       R17       1
    x94       R32       1
    x94       R47       1
    x94       R62       1
    x94       R363      -1
    x94       R364      -1
    x94       R843      -1
    x94       R844      -1
    x95       R18       1
    x95       R33       1
    x95       R48       1
    x95       R63       1
    x95       R365      -1
    x95       R366      -1
    x95       R845      -1
    x95       R846      -1
    x96       R19       1
    x96       R34       1
    x96       R49       1
    x96       R64       1
    x96       R367      -1
    x96       R368      -1
    x96       R847      -1
    x96       R848      -1
    x97       R20       1
    x97       R35       1
    x97       R50       1
    x97       R65       1
    x97       R369      -1
    x97       R370      -1
    x97       R849      -1
    x97       R850      -1
    x98       R21       1
    x98       R36       1
    x98       R51       1
    x98       R66       1
    x98       R371      -1
    x98       R372      -1
    x98       R851      -1
    x98       R852      -1
    x99       R22       1
    x99       R37       1
    x99       R52       1
    x99       R67       1
    x99       R373      -1
    x99       R374      -1
    x99       R853      -1
    x99       R854      -1
    x100      R23       1
    x100      R38       1
    x100      R53       1
    x100      R68       1
    x100      R375      -1
    x100      R376      -1
    x100      R855      -1
    x100      R856      -1
    x101      R24       1
    x101      R39       1
    x101      R54       1
    x101      R69       1
    x101      R377      -1
    x101      R378      -1
    x101      R857      -1
    x101      R858      -1
    x102      R25       1
    x102      R40       1
    x102      R55       1
    x102      R70       1
    x102      R379      -1
    x102      R380      -1
    x102      R859      -1
    x102      R860      -1
    x103      R26       1
    x103      R41       1
    x103      R56       1
    x103      R71       1
    x103      R381      -1
    x103      R382      -1
    x103      R861      -1
    x103      R862      -1
    x104      R27       1
    x104      R42       1
    x104      R57       1
    x104      R72       1
    x104      R383      -1
    x104      R384      -1
    x104      R863      -1
    x104      R864      -1
    x105      R28       1
    x105      R43       1
    x105      R58       1
    x105      R73       1
    x105      R385      -1
    x105      R386      -1
    x105      R865      -1
    x105      R866      -1
    x106      R29       1
    x106      R44       1
    x106      R59       1
    x106      R74       1
    x106      R387      -1
    x106      R388      -1
    x106      R867      -1
    x106      R868      -1
    x107      R30       1
    x107      R45       1
    x107      R60       1
    x107      R75       1
    x107      R389      -1
    x107      R390      -1
    x107      R869      -1
    x107      R870      -1
    x108      R31       1
    x108      R46       1
    x108      R61       1
    x108      R76       1
    x108      R391      -1
    x108      R392      -1
    x108      R871      -1
    x108      R872      -1
    x109      R32       1
    x109      R47       1
    x109      R62       1
    x109      R77       1
    x109      R393      -1
    x109      R394      -1
    x109      R873      -1
    x109      R874      -1
    x110      R33       1
    x110      R48       1
    x110      R63       1
    x110      R78       1
    x110      R395      -1
    x110      R396      -1
    x110      R875      -1
    x110      R876      -1
    x111      R34       1
    x111      R49       1
    x111      R64       1
    x111      R79       1
    x111      R397      -1
    x111      R398      -1
    x111      R877      -1
    x111      R878      -1
    x112      R35       1
    x112      R50       1
    x112      R65       1
    x112      R80       1
    x112      R399      -1
    x112      R400      -1
    x112      R879      -1
    x112      R880      -1
    x113      R36       1
    x113      R51       1
    x113      R66       1
    x113      R81       1
    x113      R401      -1
    x113      R402      -1
    x113      R881      -1
    x113      R882      -1
    x114      R37       1
    x114      R52       1
    x114      R67       1
    x114      R82       1
    x114      R403      -1
    x114      R404      -1
    x114      R883      -1
    x114      R884      -1
    x115      R38       1
    x115      R53       1
    x115      R68       1
    x115      R83       1
    x115      R405      -1
    x115      R406      -1
    x115      R885      -1
    x115      R886      -1
    x116      R39       1
    x116      R54       1
    x116      R69       1
    x116      R84       1
    x116      R407      -1
    x116      R408      -1
    x116      R887      -1
    x116      R888      -1
    x117      R40       1
    x117      R55       1
    x117      R70       1
    x117      R85       1
    x117      R409      -1
    x117      R410      -1
    x117      R889      -1
    x117      R890      -1
    x118      R41       1
    x118      R56       1
    x118      R71       1
    x118      R86       1
    x118      R411      -1
    x118      R412      -1
    x118      R891      -1
    x118      R892      -1
    x119      R42       1
    x119      R57       1
    x119      R72       1
    x119      R87       1
    x119      R413      -1
    x119      R414      -1
    x119      R893      -1
    x119      R894      -1
    x120      R43       1
    x120      R58       1
    x120      R73       1
    x120      R88       1
    x120      R415      -1
    x120      R416      -1
    x120      R895      -1
    x120      R896      -1
    x121      R44       1
    x121      R59       1
    x121      R74       1
    x121      R89       1
    x121      R417      -1
    x121      R418      -1
    x121      R897      -1
    x121      R898      -1
    x122      R45       1
    x122      R60       1
    x122      R75       1
    x122      R90       1
    x122      R419      -1
    x122      R420      -1
    x122      R899      -1
    x122      R900      -1
    x123      R46       1
    x123      R61       1
    x123      R76       1
    x123      R91       1
    x123      R421      -1
    x123      R422      -1
    x123      R901      -1
    x123      R902      -1
    x124      R47       1
    x124      R62       1
    x124      R77       1
    x124      R92       1
    x124      R423      -1
    x124      R424      -1
    x124      R903      -1
    x124      R904      -1
    x125      R48       1
    x125      R63       1
    x125      R78       1
    x125      R93       1
    x125      R425      -1
    x125      R426      -1
    x125      R905      -1
    x125      R906      -1
    x126      R49       1
    x126      R64       1
    x126      R79       1
    x126      R94       1
    x126      R427      -1
    x126      R428      -1
    x126      R907      -1
    x126      R908      -1
    x127      R50       1
    x127      R65       1
    x127      R80       1
    x127      R95       1
    x127      R429      -1
    x127      R430      -1
    x127      R909      -1
    x127      R910      -1
    x128      R51       1
    x128      R66       1
    x128      R81       1
    x128      R96       1
    x128      R431      -1
    x128      R432      -1
    x128      R911      -1
    x128      R912      -1
    x129      R52       1
    x129      R67       1
    x129      R82       1
    x129      R97       1
    x129      R433      -1
    x129      R434      -1
    x129      R913      -1
    x129      R914      -1
    x130      R53       1
    x130      R68       1
    x130      R83       1
    x130      R98       1
    x130      R435      -1
    x130      R436      -1
    x130      R915      -1
    x130      R916      -1
    x131      R54       1
    x131      R69       1
    x131      R84       1
    x131      R99       1
    x131      R437      -1
    x131      R438      -1
    x131      R917      -1
    x131      R918      -1
    x132      R55       1
    x132      R70       1
    x132      R85       1
    x132      R100      1
    x132      R439      -1
    x132      R440      -1
    x132      R919      -1
    x132      R920      -1
    x133      R56       1
    x133      R71       1
    x133      R86       1
    x133      R101      1
    x133      R441      -1
    x133      R442      -1
    x133      R921      -1
    x133      R922      -1
    x134      R57       1
    x134      R72       1
    x134      R87       1
    x134      R102      1
    x134      R443      -1
    x134      R444      -1
    x134      R923      -1
    x134      R924      -1
    x135      R58       1
    x135      R73       1
    x135      R88       1
    x135      R103      1
    x135      R445      -1
    x135      R446      -1
    x135      R925      -1
    x135      R926      -1
    x136      R59       1
    x136      R74       1
    x136      R89       1
    x136      R104      1
    x136      R447      -1
    x136      R448      -1
    x136      R927      -1
    x136      R928      -1
    x137      R60       1
    x137      R75       1
    x137      R90       1
    x137      R105      1
    x137      R449      -1
    x137      R450      -1
    x137      R929      -1
    x137      R930      -1
    x138      R61       1
    x138      R76       1
    x138      R91       1
    x138      R106      1
    x138      R451      -1
    x138      R452      -1
    x138      R931      -1
    x138      R932      -1
    x139      R62       1
    x139      R77       1
    x139      R92       1
    x139      R107      1
    x139      R453      -1
    x139      R454      -1
    x139      R933      -1
    x139      R934      -1
    x140      R63       1
    x140      R78       1
    x140      R93       1
    x140      R108      1
    x140      R455      -1
    x140      R456      -1
    x140      R935      -1
    x140      R936      -1
    x141      R64       1
    x141      R79       1
    x141      R94       1
    x141      R109      1
    x141      R457      -1
    x141      R458      -1
    x141      R937      -1
    x141      R938      -1
    x142      R65       1
    x142      R80       1
    x142      R95       1
    x142      R110      1
    x142      R459      -1
    x142      R460      -1
    x142      R939      -1
    x142      R940      -1
    x143      R66       1
    x143      R81       1
    x143      R96       1
    x143      R111      1
    x143      R461      -1
    x143      R462      -1
    x143      R941      -1
    x143      R942      -1
    x144      R67       1
    x144      R82       1
    x144      R97       1
    x144      R112      1
    x144      R463      -1
    x144      R464      -1
    x144      R943      -1
    x144      R944      -1
    x145      R68       1
    x145      R83       1
    x145      R98       1
    x145      R113      1
    x145      R465      -1
    x145      R466      -1
    x145      R945      -1
    x145      R946      -1
    x146      R69       1
    x146      R84       1
    x146      R99       1
    x146      R114      1
    x146      R467      -1
    x146      R468      -1
    x146      R947      -1
    x146      R948      -1
    x147      R70       1
    x147      R85       1
    x147      R100      1
    x147      R115      1
    x147      R469      -1
    x147      R470      -1
    x147      R949      -1
    x147      R950      -1
    x148      R71       1
    x148      R86       1
    x148      R101      1
    x148      R116      1
    x148      R471      -1
    x148      R472      -1
    x148      R951      -1
    x148      R952      -1
    x149      R72       1
    x149      R87       1
    x149      R102      1
    x149      R117      1
    x149      R473      -1
    x149      R474      -1
    x149      R953      -1
    x149      R954      -1
    x150      R73       1
    x150      R88       1
    x150      R103      1
    x150      R118      1
    x150      R475      -1
    x150      R476      -1
    x150      R955      -1
    x150      R956      -1
    x151      R74       1
    x151      R89       1
    x151      R104      1
    x151      R119      1
    x151      R477      -1
    x151      R478      -1
    x151      R957      -1
    x151      R958      -1
    x152      R75       1
    x152      R90       1
    x152      R105      1
    x152      R120      1
    x152      R479      -1
    x152      R480      -1
    x152      R959      -1
    x152      R960      -1
    x153      R76       1
    x153      R91       1
    x153      R106      1
    x153      R121      1
    x153      R481      -1
    x153      R482      -1
    x153      R961      -1
    x153      R962      -1
    x154      R77       1
    x154      R92       1
    x154      R107      1
    x154      R122      1
    x154      R483      -1
    x154      R484      -1
    x154      R963      -1
    x154      R964      -1
    x155      R78       1
    x155      R93       1
    x155      R108      1
    x155      R123      1
    x155      R485      -1
    x155      R486      -1
    x155      R965      -1
    x155      R966      -1
    x156      R79       1
    x156      R94       1
    x156      R109      1
    x156      R124      1
    x156      R487      -1
    x156      R488      -1
    x156      R967      -1
    x156      R968      -1
    x157      R80       1
    x157      R95       1
    x157      R110      1
    x157      R125      1
    x157      R489      -1
    x157      R490      -1
    x157      R969      -1
    x157      R970      -1
    x158      R81       1
    x158      R96       1
    x158      R111      1
    x158      R126      1
    x158      R491      -1
    x158      R492      -1
    x158      R971      -1
    x158      R972      -1
    x159      R82       1
    x159      R97       1
    x159      R112      1
    x159      R127      1
    x159      R493      -1
    x159      R494      -1
    x159      R973      -1
    x159      R974      -1
    x160      R83       1
    x160      R98       1
    x160      R113      1
    x160      R128      1
    x160      R495      -1
    x160      R496      -1
    x160      R975      -1
    x160      R976      -1
    x161      R84       1
    x161      R99       1
    x161      R114      1
    x161      R129      1
    x161      R497      -1
    x161      R498      -1
    x161      R977      -1
    x161      R978      -1
    x162      R85       1
    x162      R100      1
    x162      R115      1
    x162      R130      1
    x162      R499      -1
    x162      R500      -1
    x162      R979      -1
    x162      R980      -1
    x163      R86       1
    x163      R101      1
    x163      R116      1
    x163      R131      1
    x163      R501      -1
    x163      R502      -1
    x163      R981      -1
    x163      R982      -1
    x164      R87       1
    x164      R102      1
    x164      R117      1
    x164      R132      1
    x164      R503      -1
    x164      R504      -1
    x164      R983      -1
    x164      R984      -1
    x165      R88       1
    x165      R103      1
    x165      R118      1
    x165      R133      1
    x165      R505      -1
    x165      R506      -1
    x165      R985      -1
    x165      R986      -1
    x166      R89       1
    x166      R104      1
    x166      R119      1
    x166      R134      1
    x166      R507      -1
    x166      R508      -1
    x166      R987      -1
    x166      R988      -1
    x167      R90       1
    x167      R105      1
    x167      R120      1
    x167      R135      1
    x167      R509      -1
    x167      R510      -1
    x167      R989      -1
    x167      R990      -1
    x168      R91       1
    x168      R106      1
    x168      R121      1
    x168      R136      1
    x168      R511      -1
    x168      R512      -1
    x168      R991      -1
    x168      R992      -1
    x169      R92       1
    x169      R107      1
    x169      R122      1
    x169      R137      1
    x169      R513      -1
    x169      R514      -1
    x169      R993      -1
    x169      R994      -1
    x170      R93       1
    x170      R108      1
    x170      R123      1
    x170      R138      1
    x170      R515      -1
    x170      R516      -1
    x170      R995      -1
    x170      R996      -1
    x171      R94       1
    x171      R109      1
    x171      R124      1
    x171      R139      1
    x171      R517      -1
    x171      R518      -1
    x171      R997      -1
    x171      R998      -1
    x172      R95       1
    x172      R110      1
    x172      R125      1
    x172      R140      1
    x172      R519      -1
    x172      R520      -1
    x172      R999      -1
    x172      R1000     -1
    x173      R96       1
    x173      R111      1
    x173      R126      1
    x173      R141      1
    x173      R521      -1
    x173      R522      -1
    x173      R1001     -1
    x173      R1002     -1
    x174      R97       1
    x174      R112      1
    x174      R127      1
    x174      R142      1
    x174      R523      -1
    x174      R524      -1
    x174      R1003     -1
    x174      R1004     -1
    x175      R98       1
    x175      R113      1
    x175      R128      1
    x175      R143      1
    x175      R525      -1
    x175      R526      -1
    x175      R1005     -1
    x175      R1006     -1
    x176      R99       1
    x176      R114      1
    x176      R129      1
    x176      R144      1
    x176      R527      -1
    x176      R528      -1
    x176      R1007     -1
    x176      R1008     -1
    x177      R100      1
    x177      R115      1
    x177      R130      1
    x177      R145      1
    x177      R529      -1
    x177      R530      -1
    x177      R1009     -1
    x177      R1010     -1
    x178      R101      1
    x178      R116      1
    x178      R131      1
    x178      R146      1
    x178      R531      -1
    x178      R532      -1
    x178      R1011     -1
    x178      R1012     -1
    x179      R102      1
    x179      R117      1
    x179      R132      1
    x179      R147      1
    x179      R533      -1
    x179      R534      -1
    x179      R1013     -1
    x179      R1014     -1
    x180      R103      1
    x180      R118      1
    x180      R133      1
    x180      R148      1
    x180      R535      -1
    x180      R536      -1
    x180      R1015     -1
    x180      R1016     -1
    x181      R104      1
    x181      R119      1
    x181      R134      1
    x181      R149      1
    x181      R537      -1
    x181      R538      -1
    x181      R1017     -1
    x181      R1018     -1
    x182      R105      1
    x182      R120      1
    x182      R135      1
    x182      R150      1
    x182      R539      -1
    x182      R540      -1
    x182      R1019     -1
    x182      R1020     -1
    x183      R106      1
    x183      R121      1
    x183      R136      1
    x183      R151      1
    x183      R541      -1
    x183      R542      -1
    x183      R1021     -1
    x183      R1022     -1
    x184      R107      1
    x184      R122      1
    x184      R137      1
    x184      R152      1
    x184      R543      -1
    x184      R544      -1
    x184      R1023     -1
    x184      R1024     -1
    x185      R108      1
    x185      R123      1
    x185      R138      1
    x185      R153      1
    x185      R545      -1
    x185      R546      -1
    x185      R1025     -1
    x185      R1026     -1
    x186      R109      1
    x186      R124      1
    x186      R139      1
    x186      R154      1
    x186      R547      -1
    x186      R548      -1
    x186      R1027     -1
    x186      R1028     -1
    x187      R110      1
    x187      R125      1
    x187      R140      1
    x187      R155      1
    x187      R549      -1
    x187      R550      -1
    x187      R1029     -1
    x187      R1030     -1
    x188      R111      1
    x188      R126      1
    x188      R141      1
    x188      R156      1
    x188      R551      -1
    x188      R552      -1
    x188      R1031     -1
    x188      R1032     -1
    x189      R112      1
    x189      R127      1
    x189      R142      1
    x189      R157      1
    x189      R553      -1
    x189      R554      -1
    x189      R1033     -1
    x189      R1034     -1
    x190      R113      1
    x190      R128      1
    x190      R143      1
    x190      R158      1
    x190      R555      -1
    x190      R556      -1
    x190      R1035     -1
    x190      R1036     -1
    x191      R114      1
    x191      R129      1
    x191      R144      1
    x191      R159      1
    x191      R557      -1
    x191      R558      -1
    x191      R1037     -1
    x191      R1038     -1
    x192      R115      1
    x192      R130      1
    x192      R145      1
    x192      R160      1
    x192      R559      -1
    x192      R560      -1
    x192      R1039     -1
    x192      R1040     -1
    x193      R116      1
    x193      R131      1
    x193      R146      1
    x193      R161      1
    x193      R561      -1
    x193      R562      -1
    x193      R1041     -1
    x193      R1042     -1
    x194      R117      1
    x194      R132      1
    x194      R147      1
    x194      R162      1
    x194      R563      -1
    x194      R564      -1
    x194      R1043     -1
    x194      R1044     -1
    x195      R118      1
    x195      R133      1
    x195      R148      1
    x195      R163      1
    x195      R565      -1
    x195      R566      -1
    x195      R1045     -1
    x195      R1046     -1
    x196      R119      1
    x196      R134      1
    x196      R149      1
    x196      R164      1
    x196      R567      -1
    x196      R568      -1
    x196      R1047     -1
    x196      R1048     -1
    x197      R120      1
    x197      R135      1
    x197      R150      1
    x197      R165      1
    x197      R569      -1
    x197      R570      -1
    x197      R1049     -1
    x197      R1050     -1
    x198      R121      1
    x198      R136      1
    x198      R151      1
    x198      R166      1
    x198      R571      -1
    x198      R572      -1
    x198      R1051     -1
    x198      R1052     -1
    x199      R122      1
    x199      R137      1
    x199      R152      1
    x199      R167      1
    x199      R573      -1
    x199      R574      -1
    x199      R1053     -1
    x199      R1054     -1
    x200      R123      1
    x200      R138      1
    x200      R153      1
    x200      R168      1
    x200      R575      -1
    x200      R576      -1
    x200      R1055     -1
    x200      R1056     -1
    x201      R124      1
    x201      R139      1
    x201      R154      1
    x201      R169      1
    x201      R577      -1
    x201      R578      -1
    x201      R1057     -1
    x201      R1058     -1
    x202      R125      1
    x202      R140      1
    x202      R155      1
    x202      R170      1
    x202      R579      -1
    x202      R580      -1
    x202      R1059     -1
    x202      R1060     -1
    x203      R126      1
    x203      R141      1
    x203      R156      1
    x203      R171      1
    x203      R581      -1
    x203      R582      -1
    x203      R1061     -1
    x203      R1062     -1
    x204      R127      1
    x204      R142      1
    x204      R157      1
    x204      R172      1
    x204      R583      -1
    x204      R584      -1
    x204      R1063     -1
    x204      R1064     -1
    x205      R128      1
    x205      R143      1
    x205      R158      1
    x205      R173      1
    x205      R585      -1
    x205      R586      -1
    x205      R1065     -1
    x205      R1066     -1
    x206      R129      1
    x206      R144      1
    x206      R159      1
    x206      R174      1
    x206      R587      -1
    x206      R588      -1
    x206      R1067     -1
    x206      R1068     -1
    x207      R130      1
    x207      R145      1
    x207      R160      1
    x207      R175      1
    x207      R589      -1
    x207      R590      -1
    x207      R1069     -1
    x207      R1070     -1
    x208      R131      1
    x208      R146      1
    x208      R161      1
    x208      R176      1
    x208      R591      -1
    x208      R592      -1
    x208      R1071     -1
    x208      R1072     -1
    x209      R132      1
    x209      R147      1
    x209      R162      1
    x209      R177      1
    x209      R593      -1
    x209      R594      -1
    x209      R1073     -1
    x209      R1074     -1
    x210      R133      1
    x210      R148      1
    x210      R163      1
    x210      R178      1
    x210      R595      -1
    x210      R596      -1
    x210      R1075     -1
    x210      R1076     -1
    x211      R134      1
    x211      R149      1
    x211      R164      1
    x211      R179      1
    x211      R597      -1
    x211      R598      -1
    x211      R1077     -1
    x211      R1078     -1
    x212      R135      1
    x212      R150      1
    x212      R165      1
    x212      R180      1
    x212      R599      -1
    x212      R600      -1
    x212      R1079     -1
    x212      R1080     -1
    x213      R136      1
    x213      R151      1
    x213      R166      1
    x213      R181      1
    x213      R601      -1
    x213      R602      -1
    x213      R1081     -1
    x213      R1082     -1
    x214      R137      1
    x214      R152      1
    x214      R167      1
    x214      R182      1
    x214      R603      -1
    x214      R604      -1
    x214      R1083     -1
    x214      R1084     -1
    x215      R138      1
    x215      R153      1
    x215      R168      1
    x215      R183      1
    x215      R605      -1
    x215      R606      -1
    x215      R1085     -1
    x215      R1086     -1
    x216      R139      1
    x216      R154      1
    x216      R169      1
    x216      R184      1
    x216      R607      -1
    x216      R608      -1
    x216      R1087     -1
    x216      R1088     -1
    x217      R140      1
    x217      R155      1
    x217      R170      1
    x217      R185      1
    x217      R609      -1
    x217      R610      -1
    x217      R1089     -1
    x217      R1090     -1
    x218      R141      1
    x218      R156      1
    x218      R171      1
    x218      R186      1
    x218      R611      -1
    x218      R612      -1
    x218      R1091     -1
    x218      R1092     -1
    x219      R142      1
    x219      R157      1
    x219      R172      1
    x219      R187      1
    x219      R613      -1
    x219      R614      -1
    x219      R1093     -1
    x219      R1094     -1
    x220      R143      1
    x220      R158      1
    x220      R173      1
    x220      R188      1
    x220      R615      -1
    x220      R616      -1
    x220      R1095     -1
    x220      R1096     -1
    x221      R144      1
    x221      R159      1
    x221      R174      1
    x221      R189      1
    x221      R617      -1
    x221      R618      -1
    x221      R1097     -1
    x221      R1098     -1
    x222      R145      1
    x222      R160      1
    x222      R175      1
    x222      R190      1
    x222      R619      -1
    x222      R620      -1
    x222      R1099     -1
    x222      R1100     -1
    x223      R146      1
    x223      R161      1
    x223      R176      1
    x223      R191      1
    x223      R621      -1
    x223      R622      -1
    x223      R1101     -1
    x223      R1102     -1
    x224      R147      1
    x224      R162      1
    x224      R177      1
    x224      R192      1
    x224      R623      -1
    x224      R624      -1
    x224      R1103     -1
    x224      R1104     -1
    x225      R148      1
    x225      R163      1
    x225      R178      1
    x225      R193      1
    x225      R625      -1
    x225      R626      -1
    x225      R1105     -1
    x225      R1106     -1
    x226      R149      1
    x226      R164      1
    x226      R179      1
    x226      R194      1
    x226      R627      -1
    x226      R628      -1
    x226      R1107     -1
    x226      R1108     -1
    x227      R150      1
    x227      R165      1
    x227      R180      1
    x227      R195      1
    x227      R629      -1
    x227      R630      -1
    x227      R1109     -1
    x227      R1110     -1
    x228      R151      1
    x228      R166      1
    x228      R181      1
    x228      R196      1
    x228      R631      -1
    x228      R632      -1
    x228      R1111     -1
    x228      R1112     -1
    x229      R152      1
    x229      R167      1
    x229      R182      1
    x229      R197      1
    x229      R633      -1
    x229      R634      -1
    x229      R1113     -1
    x229      R1114     -1
    x230      R153      1
    x230      R168      1
    x230      R183      1
    x230      R198      1
    x230      R635      -1
    x230      R636      -1
    x230      R1115     -1
    x230      R1116     -1
    x231      R154      1
    x231      R169      1
    x231      R184      1
    x231      R199      1
    x231      R637      -1
    x231      R638      -1
    x231      R1117     -1
    x231      R1118     -1
    x232      R155      1
    x232      R170      1
    x232      R185      1
    x232      R200      1
    x232      R639      -1
    x232      R640      -1
    x232      R1119     -1
    x232      R1120     -1
    x233      R156      1
    x233      R171      1
    x233      R186      1
    x233      R201      1
    x233      R641      -1
    x233      R642      -1
    x233      R1121     -1
    x233      R1122     -1
    x234      R157      1
    x234      R172      1
    x234      R187      1
    x234      R202      1
    x234      R643      -1
    x234      R644      -1
    x234      R1123     -1
    x234      R1124     -1
    x235      R158      1
    x235      R173      1
    x235      R188      1
    x235      R203      1
    x235      R645      -1
    x235      R646      -1
    x235      R1125     -1
    x235      R1126     -1
    x236      R159      1
    x236      R174      1
    x236      R189      1
    x236      R204      1
    x236      R647      -1
    x236      R648      -1
    x236      R1127     -1
    x236      R1128     -1
    x237      R160      1
    x237      R175      1
    x237      R190      1
    x237      R205      1
    x237      R649      -1
    x237      R650      -1
    x237      R1129     -1
    x237      R1130     -1
    x238      R161      1
    x238      R176      1
    x238      R191      1
    x238      R206      1
    x238      R651      -1
    x238      R652      -1
    x238      R1131     -1
    x238      R1132     -1
    x239      R162      1
    x239      R177      1
    x239      R192      1
    x239      R207      1
    x239      R653      -1
    x239      R654      -1
    x239      R1133     -1
    x239      R1134     -1
    x240      R163      1
    x240      R178      1
    x240      R193      1
    x240      R208      1
    x240      R655      -1
    x240      R656      -1
    x240      R1135     -1
    x240      R1136     -1
    x241      R164      1
    x241      R179      1
    x241      R194      1
    x241      R209      1
    x241      R657      -1
    x241      R658      -1
    x241      R1137     -1
    x241      R1138     -1
    x242      R165      1
    x242      R180      1
    x242      R195      1
    x242      R210      1
    x242      R659      -1
    x242      R660      -1
    x242      R1139     -1
    x242      R1140     -1
    x243      R166      1
    x243      R181      1
    x243      R196      1
    x243      R211      1
    x243      R661      -1
    x243      R662      -1
    x243      R1141     -1
    x243      R1142     -1
    x244      R167      1
    x244      R182      1
    x244      R197      1
    x244      R212      1
    x244      R663      -1
    x244      R664      -1
    x244      R1143     -1
    x244      R1144     -1
    x245      R168      1
    x245      R183      1
    x245      R198      1
    x245      R213      1
    x245      R665      -1
    x245      R666      -1
    x245      R1145     -1
    x245      R1146     -1
    x246      R169      1
    x246      R184      1
    x246      R199      1
    x246      R214      1
    x246      R667      -1
    x246      R668      -1
    x246      R1147     -1
    x246      R1148     -1
    x247      R170      1
    x247      R185      1
    x247      R200      1
    x247      R215      1
    x247      R669      -1
    x247      R670      -1
    x247      R1149     -1
    x247      R1150     -1
    x248      R171      1
    x248      R186      1
    x248      R201      1
    x248      R216      1
    x248      R671      -1
    x248      R672      -1
    x248      R1151     -1
    x248      R1152     -1
    x249      R172      1
    x249      R187      1
    x249      R202      1
    x249      R217      1
    x249      R673      -1
    x249      R674      -1
    x249      R1153     -1
    x249      R1154     -1
    x250      R173      1
    x250      R188      1
    x250      R203      1
    x250      R218      1
    x250      R675      -1
    x250      R676      -1
    x250      R1155     -1
    x250      R1156     -1
    x251      R174      1
    x251      R189      1
    x251      R204      1
    x251      R219      1
    x251      R677      -1
    x251      R678      -1
    x251      R1157     -1
    x251      R1158     -1
    x252      R175      1
    x252      R190      1
    x252      R205      1
    x252      R220      1
    x252      R679      -1
    x252      R680      -1
    x252      R1159     -1
    x252      R1160     -1
    x253      R176      1
    x253      R191      1
    x253      R206      1
    x253      R221      1
    x253      R681      -1
    x253      R682      -1
    x253      R1161     -1
    x253      R1162     -1
    x254      R177      1
    x254      R192      1
    x254      R207      1
    x254      R222      1
    x254      R683      -1
    x254      R684      -1
    x254      R1163     -1
    x254      R1164     -1
    x255      R178      1
    x255      R193      1
    x255      R208      1
    x255      R223      1
    x255      R685      -1
    x255      R686      -1
    x255      R1165     -1
    x255      R1166     -1
    x256      R179      1
    x256      R194      1
    x256      R209      1
    x256      R224      1
    x256      R687      -1
    x256      R688      -1
    x256      R1167     -1
    x256      R1168     -1
    x257      R180      1
    x257      R195      1
    x257      R210      1
    x257      R225      1
    x257      R689      -1
    x257      R690      -1
    x257      R1169     -1
    x257      R1170     -1
    x258      R181      1
    x258      R196      1
    x258      R211      1
    x258      R226      1
    x258      R691      -1
    x258      R692      -1
    x258      R1171     -1
    x258      R1172     -1
    x259      R182      1
    x259      R197      1
    x259      R212      1
    x259      R227      1
    x259      R693      -1
    x259      R694      -1
    x259      R1173     -1
    x259      R1174     -1
    x260      R183      1
    x260      R198      1
    x260      R213      1
    x260      R228      1
    x260      R695      -1
    x260      R696      -1
    x260      R1175     -1
    x260      R1176     -1
    x261      R184      1
    x261      R199      1
    x261      R214      1
    x261      R229      1
    x261      R697      -1
    x261      R698      -1
    x261      R1177     -1
    x261      R1178     -1
    x262      R185      1
    x262      R200      1
    x262      R215      1
    x262      R230      1
    x262      R699      -1
    x262      R700      -1
    x262      R1179     -1
    x262      R1180     -1
    x263      R186      1
    x263      R201      1
    x263      R216      1
    x263      R231      1
    x263      R701      -1
    x263      R702      -1
    x263      R1181     -1
    x263      R1182     -1
    x264      R187      1
    x264      R202      1
    x264      R217      1
    x264      R232      1
    x264      R703      -1
    x264      R704      -1
    x264      R1183     -1
    x264      R1184     -1
    x265      R188      1
    x265      R203      1
    x265      R218      1
    x265      R233      1
    x265      R705      -1
    x265      R706      -1
    x265      R1185     -1
    x265      R1186     -1
    x266      R189      1
    x266      R204      1
    x266      R219      1
    x266      R234      1
    x266      R707      -1
    x266      R708      -1
    x266      R1187     -1
    x266      R1188     -1
    x267      R190      1
    x267      R205      1
    x267      R220      1
    x267      R235      1
    x267      R709      -1
    x267      R710      -1
    x267      R1189     -1
    x267      R1190     -1
    x268      R191      1
    x268      R206      1
    x268      R221      1
    x268      R236      1
    x268      R711      -1
    x268      R712      -1
    x268      R1191     -1
    x268      R1192     -1
    x269      R192      1
    x269      R207      1
    x269      R222      1
    x269      R237      1
    x269      R713      -1
    x269      R714      -1
    x269      R1193     -1
    x269      R1194     -1
    x270      R193      1
    x270      R208      1
    x270      R223      1
    x270      R238      1
    x270      R715      -1
    x270      R716      -1
    x270      R1195     -1
    x270      R1196     -1
    x271      R194      1
    x271      R209      1
    x271      R224      1
    x271      R239      1
    x271      R717      -1
    x271      R718      -1
    x271      R1197     -1
    x271      R1198     -1
    x272      R195      1
    x272      R210      1
    x272      R225      1
    x272      R240      1
    x272      R719      -1
    x272      R720      -1
    x272      R1199     -1
    x272      R1200     -1
    x17       R721      -1
    x17       R722      1
    x17       R723      -1
    x17       R724      1
    x17       R725      -1
    x17       R726      1
    x17       R727      -1
    x17       R728      1
    x17       R729      -1
    x17       R730      1
    x17       R731      -1
    x17       R732      1
    x17       R733      -1
    x17       R734      1
    x17       R735      -1
    x17       R736      1
    x17       R737      -1
    x17       R738      1
    x17       R739      -1
    x17       R740      1
    x17       R741      -1
    x17       R742      1
    x17       R743      -1
    x17       R744      1
    x17       R745      -1
    x17       R746      1
    x17       R747      -1
    x17       R748      1
    x17       R749      -1
    x17       R750      1
    x17       R779      -1
    x17       R780      1
    x17       R807      -1
    x17       R808      1
    x17       R835      -1
    x17       R836      1
    x17       R863      -1
    x17       R864      1
    x17       R891      -1
    x17       R892      1
    x17       R919      -1
    x17       R920      1
    x17       R947      -1
    x17       R948      1
    x17       R975      -1
    x17       R976      1
    x17       R1003     -1
    x17       R1004     1
    x17       R1031     -1
    x17       R1032     1
    x17       R1059     -1
    x17       R1060     1
    x17       R1087     -1
    x17       R1088     1
    x17       R1115     -1
    x17       R1116     1
    x17       R1143     -1
    x17       R1144     1
    x17       R1171     -1
    x17       R1172     1
    x17       R1202     1
    x17       R1204     -1
    x17       R1220     -1
    x18       R721      -1
    x18       R722      1
    x18       R751      -1
    x18       R752      1
    x18       R753      -1
    x18       R754      1
    x18       R755      -1
    x18       R756      1
    x18       R757      -1
    x18       R758      1
    x18       R759      -1
    x18       R760      1
    x18       R761      -1
    x18       R762      1
    x18       R763      -1
    x18       R764      1
    x18       R765      -1
    x18       R766      1
    x18       R767      -1
    x18       R768      1
    x18       R769      -1
    x18       R770      1
    x18       R771      -1
    x18       R772      1
    x18       R773      -1
    x18       R774      1
    x18       R775      -1
    x18       R776      1
    x18       R777      -1
    x18       R778      1
    x18       R779      -1
    x18       R780      1
    x18       R809      -1
    x18       R810      1
    x18       R837      -1
    x18       R838      1
    x18       R865      -1
    x18       R866      1
    x18       R893      -1
    x18       R894      1
    x18       R921      -1
    x18       R922      1
    x18       R949      -1
    x18       R950      1
    x18       R977      -1
    x18       R978      1
    x18       R1005     -1
    x18       R1006     1
    x18       R1033     -1
    x18       R1034     1
    x18       R1061     -1
    x18       R1062     1
    x18       R1089     -1
    x18       R1090     1
    x18       R1117     -1
    x18       R1118     1
    x18       R1145     -1
    x18       R1146     1
    x18       R1173     -1
    x18       R1174     1
    x18       R1205     -1
    x18       R1220     -1
    x19       R723      -1
    x19       R724      1
    x19       R751      -1
    x19       R752      1
    x19       R781      -1
    x19       R782      1
    x19       R783      -1
    x19       R784      1
    x19       R785      -1
    x19       R786      1
    x19       R787      -1
    x19       R788      1
    x19       R789      -1
    x19       R790      1
    x19       R791      -1
    x19       R792      1
    x19       R793      -1
    x19       R794      1
    x19       R795      -1
    x19       R796      1
    x19       R797      -1
    x19       R798      1
    x19       R799      -1
    x19       R800      1
    x19       R801      -1
    x19       R802      1
    x19       R803      -1
    x19       R804      1
    x19       R805      -1
    x19       R806      1
    x19       R807      -1
    x19       R808      1
    x19       R809      -1
    x19       R810      1
    x19       R839      -1
    x19       R840      1
    x19       R867      -1
    x19       R868      1
    x19       R895      -1
    x19       R896      1
    x19       R923      -1
    x19       R924      1
    x19       R951      -1
    x19       R952      1
    x19       R979      -1
    x19       R980      1
    x19       R1007     -1
    x19       R1008     1
    x19       R1035     -1
    x19       R1036     1
    x19       R1063     -1
    x19       R1064     1
    x19       R1091     -1
    x19       R1092     1
    x19       R1119     -1
    x19       R1120     1
    x19       R1147     -1
    x19       R1148     1
    x19       R1175     -1
    x19       R1176     1
    x19       R1206     -1
    x19       R1220     -1
    x20       R725      -1
    x20       R726      1
    x20       R753      -1
    x20       R754      1
    x20       R781      -1
    x20       R782      1
    x20       R811      -1
    x20       R812      1
    x20       R813      -1
    x20       R814      1
    x20       R815      -1
    x20       R816      1
    x20       R817      -1
    x20       R818      1
    x20       R819      -1
    x20       R820      1
    x20       R821      -1
    x20       R822      1
    x20       R823      -1
    x20       R824      1
    x20       R825      -1
    x20       R826      1
    x20       R827      -1
    x20       R828      1
    x20       R829      -1
    x20       R830      1
    x20       R831      -1
    x20       R832      1
    x20       R833      -1
    x20       R834      1
    x20       R835      -1
    x20       R836      1
    x20       R837      -1
    x20       R838      1
    x20       R839      -1
    x20       R840      1
    x20       R869      -1
    x20       R870      1
    x20       R897      -1
    x20       R898      1
    x20       R925      -1
    x20       R926      1
    x20       R953      -1
    x20       R954      1
    x20       R981      -1
    x20       R982      1
    x20       R1009     -1
    x20       R1010     1
    x20       R1037     -1
    x20       R1038     1
    x20       R1065     -1
    x20       R1066     1
    x20       R1093     -1
    x20       R1094     1
    x20       R1121     -1
    x20       R1122     1
    x20       R1149     -1
    x20       R1150     1
    x20       R1177     -1
    x20       R1178     1
    x20       R1207     -1
    x20       R1220     -1
    x21       R727      -1
    x21       R728      1
    x21       R755      -1
    x21       R756      1
    x21       R783      -1
    x21       R784      1
    x21       R811      -1
    x21       R812      1
    x21       R841      -1
    x21       R842      1
    x21       R843      -1
    x21       R844      1
    x21       R845      -1
    x21       R846      1
    x21       R847      -1
    x21       R848      1
    x21       R849      -1
    x21       R850      1
    x21       R851      -1
    x21       R852      1
    x21       R853      -1
    x21       R854      1
    x21       R855      -1
    x21       R856      1
    x21       R857      -1
    x21       R858      1
    x21       R859      -1
    x21       R860      1
    x21       R861      -1
    x21       R862      1
    x21       R863      -1
    x21       R864      1
    x21       R865      -1
    x21       R866      1
    x21       R867      -1
    x21       R868      1
    x21       R869      -1
    x21       R870      1
    x21       R899      -1
    x21       R900      1
    x21       R927      -1
    x21       R928      1
    x21       R955      -1
    x21       R956      1
    x21       R983      -1
    x21       R984      1
    x21       R1011     -1
    x21       R1012     1
    x21       R1039     -1
    x21       R1040     1
    x21       R1067     -1
    x21       R1068     1
    x21       R1095     -1
    x21       R1096     1
    x21       R1123     -1
    x21       R1124     1
    x21       R1151     -1
    x21       R1152     1
    x21       R1179     -1
    x21       R1180     1
    x21       R1208     -1
    x21       R1220     -1
    x22       R729      -1
    x22       R730      1
    x22       R757      -1
    x22       R758      1
    x22       R785      -1
    x22       R786      1
    x22       R813      -1
    x22       R814      1
    x22       R841      -1
    x22       R842      1
    x22       R871      -1
    x22       R872      1
    x22       R873      -1
    x22       R874      1
    x22       R875      -1
    x22       R876      1
    x22       R877      -1
    x22       R878      1
    x22       R879      -1
    x22       R880      1
    x22       R881      -1
    x22       R882      1
    x22       R883      -1
    x22       R884      1
    x22       R885      -1
    x22       R886      1
    x22       R887      -1
    x22       R888      1
    x22       R889      -1
    x22       R890      1
    x22       R891      -1
    x22       R892      1
    x22       R893      -1
    x22       R894      1
    x22       R895      -1
    x22       R896      1
    x22       R897      -1
    x22       R898      1
    x22       R899      -1
    x22       R900      1
    x22       R929      -1
    x22       R930      1
    x22       R957      -1
    x22       R958      1
    x22       R985      -1
    x22       R986      1
    x22       R1013     -1
    x22       R1014     1
    x22       R1041     -1
    x22       R1042     1
    x22       R1069     -1
    x22       R1070     1
    x22       R1097     -1
    x22       R1098     1
    x22       R1125     -1
    x22       R1126     1
    x22       R1153     -1
    x22       R1154     1
    x22       R1181     -1
    x22       R1182     1
    x22       R1209     -1
    x22       R1220     -1
    x23       R731      -1
    x23       R732      1
    x23       R759      -1
    x23       R760      1
    x23       R787      -1
    x23       R788      1
    x23       R815      -1
    x23       R816      1
    x23       R843      -1
    x23       R844      1
    x23       R871      -1
    x23       R872      1
    x23       R901      -1
    x23       R902      1
    x23       R903      -1
    x23       R904      1
    x23       R905      -1
    x23       R906      1
    x23       R907      -1
    x23       R908      1
    x23       R909      -1
    x23       R910      1
    x23       R911      -1
    x23       R912      1
    x23       R913      -1
    x23       R914      1
    x23       R915      -1
    x23       R916      1
    x23       R917      -1
    x23       R918      1
    x23       R919      -1
    x23       R920      1
    x23       R921      -1
    x23       R922      1
    x23       R923      -1
    x23       R924      1
    x23       R925      -1
    x23       R926      1
    x23       R927      -1
    x23       R928      1
    x23       R929      -1
    x23       R930      1
    x23       R959      -1
    x23       R960      1
    x23       R987      -1
    x23       R988      1
    x23       R1015     -1
    x23       R1016     1
    x23       R1043     -1
    x23       R1044     1
    x23       R1071     -1
    x23       R1072     1
    x23       R1099     -1
    x23       R1100     1
    x23       R1127     -1
    x23       R1128     1
    x23       R1155     -1
    x23       R1156     1
    x23       R1183     -1
    x23       R1184     1
    x23       R1210     -1
    x23       R1220     -1
    x24       R733      -1
    x24       R734      1
    x24       R761      -1
    x24       R762      1
    x24       R789      -1
    x24       R790      1
    x24       R817      -1
    x24       R818      1
    x24       R845      -1
    x24       R846      1
    x24       R873      -1
    x24       R874      1
    x24       R901      -1
    x24       R902      1
    x24       R931      -1
    x24       R932      1
    x24       R933      -1
    x24       R934      1
    x24       R935      -1
    x24       R936      1
    x24       R937      -1
    x24       R938      1
    x24       R939      -1
    x24       R940      1
    x24       R941      -1
    x24       R942      1
    x24       R943      -1
    x24       R944      1
    x24       R945      -1
    x24       R946      1
    x24       R947      -1
    x24       R948      1
    x24       R949      -1
    x24       R950      1
    x24       R951      -1
    x24       R952      1
    x24       R953      -1
    x24       R954      1
    x24       R955      -1
    x24       R956      1
    x24       R957      -1
    x24       R958      1
    x24       R959      -1
    x24       R960      1
    x24       R989      -1
    x24       R990      1
    x24       R1017     -1
    x24       R1018     1
    x24       R1045     -1
    x24       R1046     1
    x24       R1073     -1
    x24       R1074     1
    x24       R1101     -1
    x24       R1102     1
    x24       R1129     -1
    x24       R1130     1
    x24       R1157     -1
    x24       R1158     1
    x24       R1185     -1
    x24       R1186     1
    x24       R1211     -1
    x24       R1220     -1
    x25       R735      -1
    x25       R736      1
    x25       R763      -1
    x25       R764      1
    x25       R791      -1
    x25       R792      1
    x25       R819      -1
    x25       R820      1
    x25       R847      -1
    x25       R848      1
    x25       R875      -1
    x25       R876      1
    x25       R903      -1
    x25       R904      1
    x25       R931      -1
    x25       R932      1
    x25       R961      -1
    x25       R962      1
    x25       R963      -1
    x25       R964      1
    x25       R965      -1
    x25       R966      1
    x25       R967      -1
    x25       R968      1
    x25       R969      -1
    x25       R970      1
    x25       R971      -1
    x25       R972      1
    x25       R973      -1
    x25       R974      1
    x25       R975      -1
    x25       R976      1
    x25       R977      -1
    x25       R978      1
    x25       R979      -1
    x25       R980      1
    x25       R981      -1
    x25       R982      1
    x25       R983      -1
    x25       R984      1
    x25       R985      -1
    x25       R986      1
    x25       R987      -1
    x25       R988      1
    x25       R989      -1
    x25       R990      1
    x25       R1019     -1
    x25       R1020     1
    x25       R1047     -1
    x25       R1048     1
    x25       R1075     -1
    x25       R1076     1
    x25       R1103     -1
    x25       R1104     1
    x25       R1131     -1
    x25       R1132     1
    x25       R1159     -1
    x25       R1160     1
    x25       R1187     -1
    x25       R1188     1
    x25       R1212     -1
    x25       R1220     -1
    x26       R737      -1
    x26       R738      1
    x26       R765      -1
    x26       R766      1
    x26       R793      -1
    x26       R794      1
    x26       R821      -1
    x26       R822      1
    x26       R849      -1
    x26       R850      1
    x26       R877      -1
    x26       R878      1
    x26       R905      -1
    x26       R906      1
    x26       R933      -1
    x26       R934      1
    x26       R961      -1
    x26       R962      1
    x26       R991      -1
    x26       R992      1
    x26       R993      -1
    x26       R994      1
    x26       R995      -1
    x26       R996      1
    x26       R997      -1
    x26       R998      1
    x26       R999      -1
    x26       R1000     1
    x26       R1001     -1
    x26       R1002     1
    x26       R1003     -1
    x26       R1004     1
    x26       R1005     -1
    x26       R1006     1
    x26       R1007     -1
    x26       R1008     1
    x26       R1009     -1
    x26       R1010     1
    x26       R1011     -1
    x26       R1012     1
    x26       R1013     -1
    x26       R1014     1
    x26       R1015     -1
    x26       R1016     1
    x26       R1017     -1
    x26       R1018     1
    x26       R1019     -1
    x26       R1020     1
    x26       R1049     -1
    x26       R1050     1
    x26       R1077     -1
    x26       R1078     1
    x26       R1105     -1
    x26       R1106     1
    x26       R1133     -1
    x26       R1134     1
    x26       R1161     -1
    x26       R1162     1
    x26       R1189     -1
    x26       R1190     1
    x26       R1213     -1
    x26       R1220     -1
    x27       R739      -1
    x27       R740      1
    x27       R767      -1
    x27       R768      1
    x27       R795      -1
    x27       R796      1
    x27       R823      -1
    x27       R824      1
    x27       R851      -1
    x27       R852      1
    x27       R879      -1
    x27       R880      1
    x27       R907      -1
    x27       R908      1
    x27       R935      -1
    x27       R936      1
    x27       R963      -1
    x27       R964      1
    x27       R991      -1
    x27       R992      1
    x27       R1021     -1
    x27       R1022     1
    x27       R1023     -1
    x27       R1024     1
    x27       R1025     -1
    x27       R1026     1
    x27       R1027     -1
    x27       R1028     1
    x27       R1029     -1
    x27       R1030     1
    x27       R1031     -1
    x27       R1032     1
    x27       R1033     -1
    x27       R1034     1
    x27       R1035     -1
    x27       R1036     1
    x27       R1037     -1
    x27       R1038     1
    x27       R1039     -1
    x27       R1040     1
    x27       R1041     -1
    x27       R1042     1
    x27       R1043     -1
    x27       R1044     1
    x27       R1045     -1
    x27       R1046     1
    x27       R1047     -1
    x27       R1048     1
    x27       R1049     -1
    x27       R1050     1
    x27       R1079     -1
    x27       R1080     1
    x27       R1107     -1
    x27       R1108     1
    x27       R1135     -1
    x27       R1136     1
    x27       R1163     -1
    x27       R1164     1
    x27       R1191     -1
    x27       R1192     1
    x27       R1214     -1
    x27       R1220     -1
    x28       R741      -1
    x28       R742      1
    x28       R769      -1
    x28       R770      1
    x28       R797      -1
    x28       R798      1
    x28       R825      -1
    x28       R826      1
    x28       R853      -1
    x28       R854      1
    x28       R881      -1
    x28       R882      1
    x28       R909      -1
    x28       R910      1
    x28       R937      -1
    x28       R938      1
    x28       R965      -1
    x28       R966      1
    x28       R993      -1
    x28       R994      1
    x28       R1021     -1
    x28       R1022     1
    x28       R1051     -1
    x28       R1052     1
    x28       R1053     -1
    x28       R1054     1
    x28       R1055     -1
    x28       R1056     1
    x28       R1057     -1
    x28       R1058     1
    x28       R1059     -1
    x28       R1060     1
    x28       R1061     -1
    x28       R1062     1
    x28       R1063     -1
    x28       R1064     1
    x28       R1065     -1
    x28       R1066     1
    x28       R1067     -1
    x28       R1068     1
    x28       R1069     -1
    x28       R1070     1
    x28       R1071     -1
    x28       R1072     1
    x28       R1073     -1
    x28       R1074     1
    x28       R1075     -1
    x28       R1076     1
    x28       R1077     -1
    x28       R1078     1
    x28       R1079     -1
    x28       R1080     1
    x28       R1109     -1
    x28       R1110     1
    x28       R1137     -1
    x28       R1138     1
    x28       R1165     -1
    x28       R1166     1
    x28       R1193     -1
    x28       R1194     1
    x28       R1215     -1
    x28       R1220     -1
    x29       R743      -1
    x29       R744      1
    x29       R771      -1
    x29       R772      1
    x29       R799      -1
    x29       R800      1
    x29       R827      -1
    x29       R828      1
    x29       R855      -1
    x29       R856      1
    x29       R883      -1
    x29       R884      1
    x29       R911      -1
    x29       R912      1
    x29       R939      -1
    x29       R940      1
    x29       R967      -1
    x29       R968      1
    x29       R995      -1
    x29       R996      1
    x29       R1023     -1
    x29       R1024     1
    x29       R1051     -1
    x29       R1052     1
    x29       R1081     -1
    x29       R1082     1
    x29       R1083     -1
    x29       R1084     1
    x29       R1085     -1
    x29       R1086     1
    x29       R1087     -1
    x29       R1088     1
    x29       R1089     -1
    x29       R1090     1
    x29       R1091     -1
    x29       R1092     1
    x29       R1093     -1
    x29       R1094     1
    x29       R1095     -1
    x29       R1096     1
    x29       R1097     -1
    x29       R1098     1
    x29       R1099     -1
    x29       R1100     1
    x29       R1101     -1
    x29       R1102     1
    x29       R1103     -1
    x29       R1104     1
    x29       R1105     -1
    x29       R1106     1
    x29       R1107     -1
    x29       R1108     1
    x29       R1109     -1
    x29       R1110     1
    x29       R1139     -1
    x29       R1140     1
    x29       R1167     -1
    x29       R1168     1
    x29       R1195     -1
    x29       R1196     1
    x29       R1216     -1
    x29       R1220     -1
    x30       R745      -1
    x30       R746      1
    x30       R773      -1
    x30       R774      1
    x30       R801      -1
    x30       R802      1
    x30       R829      -1
    x30       R830      1
    x30       R857      -1
    x30       R858      1
    x30       R885      -1
    x30       R886      1
    x30       R913      -1
    x30       R914      1
    x30       R941      -1
    x30       R942      1
    x30       R969      -1
    x30       R970      1
    x30       R997      -1
    x30       R998      1
    x30       R1025     -1
    x30       R1026     1
    x30       R1053     -1
    x30       R1054     1
    x30       R1081     -1
    x30       R1082     1
    x30       R1111     -1
    x30       R1112     1
    x30       R1113     -1
    x30       R1114     1
    x30       R1115     -1
    x30       R1116     1
    x30       R1117     -1
    x30       R1118     1
    x30       R1119     -1
    x30       R1120     1
    x30       R1121     -1
    x30       R1122     1
    x30       R1123     -1
    x30       R1124     1
    x30       R1125     -1
    x30       R1126     1
    x30       R1127     -1
    x30       R1128     1
    x30       R1129     -1
    x30       R1130     1
    x30       R1131     -1
    x30       R1132     1
    x30       R1133     -1
    x30       R1134     1
    x30       R1135     -1
    x30       R1136     1
    x30       R1137     -1
    x30       R1138     1
    x30       R1139     -1
    x30       R1140     1
    x30       R1169     -1
    x30       R1170     1
    x30       R1197     -1
    x30       R1198     1
    x30       R1217     -1
    x30       R1220     -1
    x31       R747      -1
    x31       R748      1
    x31       R775      -1
    x31       R776      1
    x31       R803      -1
    x31       R804      1
    x31       R831      -1
    x31       R832      1
    x31       R859      -1
    x31       R860      1
    x31       R887      -1
    x31       R888      1
    x31       R915      -1
    x31       R916      1
    x31       R943      -1
    x31       R944      1
    x31       R971      -1
    x31       R972      1
    x31       R999      -1
    x31       R1000     1
    x31       R1027     -1
    x31       R1028     1
    x31       R1055     -1
    x31       R1056     1
    x31       R1083     -1
    x31       R1084     1
    x31       R1111     -1
    x31       R1112     1
    x31       R1141     -1
    x31       R1142     1
    x31       R1143     -1
    x31       R1144     1
    x31       R1145     -1
    x31       R1146     1
    x31       R1147     -1
    x31       R1148     1
    x31       R1149     -1
    x31       R1150     1
    x31       R1151     -1
    x31       R1152     1
    x31       R1153     -1
    x31       R1154     1
    x31       R1155     -1
    x31       R1156     1
    x31       R1157     -1
    x31       R1158     1
    x31       R1159     -1
    x31       R1160     1
    x31       R1161     -1
    x31       R1162     1
    x31       R1163     -1
    x31       R1164     1
    x31       R1165     -1
    x31       R1166     1
    x31       R1167     -1
    x31       R1168     1
    x31       R1169     -1
    x31       R1170     1
    x31       R1199     -1
    x31       R1200     1
    x31       R1218     -1
    x31       R1220     -1
    x32       R749      -1
    x32       R750      1
    x32       R777      -1
    x32       R778      1
    x32       R805      -1
    x32       R806      1
    x32       R833      -1
    x32       R834      1
    x32       R861      -1
    x32       R862      1
    x32       R889      -1
    x32       R890      1
    x32       R917      -1
    x32       R918      1
    x32       R945      -1
    x32       R946      1
    x32       R973      -1
    x32       R974      1
    x32       R1001     -1
    x32       R1002     1
    x32       R1029     -1
    x32       R1030     1
    x32       R1057     -1
    x32       R1058     1
    x32       R1085     -1
    x32       R1086     1
    x32       R1113     -1
    x32       R1114     1
    x32       R1141     -1
    x32       R1142     1
    x32       R1171     -1
    x32       R1172     1
    x32       R1173     -1
    x32       R1174     1
    x32       R1175     -1
    x32       R1176     1
    x32       R1177     -1
    x32       R1178     1
    x32       R1179     -1
    x32       R1180     1
    x32       R1181     -1
    x32       R1182     1
    x32       R1183     -1
    x32       R1184     1
    x32       R1185     -1
    x32       R1186     1
    x32       R1187     -1
    x32       R1188     1
    x32       R1189     -1
    x32       R1190     1
    x32       R1191     -1
    x32       R1192     1
    x32       R1193     -1
    x32       R1194     1
    x32       R1195     -1
    x32       R1196     1
    x32       R1197     -1
    x32       R1198     1
    x32       R1199     -1
    x32       R1200     1
    x32       R1219     -1
    x32       R1220     -1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      R0        13
    RHS1      R1        1
    RHS1      R2        1
    RHS1      R3        1
    RHS1      R4        1
    RHS1      R5        1
    RHS1      R6        1
    RHS1      R7        1
    RHS1      R8        1
    RHS1      R9        1
    RHS1      R10       1
    RHS1      R11       1
    RHS1      R12       1
    RHS1      R13       1
    RHS1      R14       1
    RHS1      R15       1
    RHS1      R16       1
    RHS1      R17       1
    RHS1      R18       1
    RHS1      R19       1
    RHS1      R20       1
    RHS1      R21       1
    RHS1      R22       1
    RHS1      R23       1
    RHS1      R24       1
    RHS1      R25       1
    RHS1      R26       1
    RHS1      R27       1
    RHS1      R28       1
    RHS1      R29       1
    RHS1      R30       1
    RHS1      R31       1
    RHS1      R32       1
    RHS1      R33       1
    RHS1      R34       1
    RHS1      R35       1
    RHS1      R36       1
    RHS1      R37       1
    RHS1      R38       1
    RHS1      R39       1
    RHS1      R40       1
    RHS1      R41       1
    RHS1      R42       1
    RHS1      R43       1
    RHS1      R44       1
    RHS1      R45       1
    RHS1      R46       1
    RHS1      R47       1
    RHS1      R48       1
    RHS1      R49       1
    RHS1      R50       1
    RHS1      R51       1
    RHS1      R52       1
    RHS1      R53       1
    RHS1      R54       1
    RHS1      R55       1
    RHS1      R56       1
    RHS1      R57       1
    RHS1      R58       1
    RHS1      R59       1
    RHS1      R60       1
    RHS1      R61       1
    RHS1      R62       1
    RHS1      R63       1
    RHS1      R64       1
    RHS1      R65       1
    RHS1      R66       1
    RHS1      R67       1
    RHS1      R68       1
    RHS1      R69       1
    RHS1      R70       1
    RHS1      R71       1
    RHS1      R72       1
    RHS1      R73       1
    RHS1      R74       1
    RHS1      R75       1
    RHS1      R76       1
    RHS1      R77       1
    RHS1      R78       1
    RHS1      R79       1
    RHS1      R80       1
    RHS1      R81       1
    RHS1      R82       1
    RHS1      R83       1
    RHS1      R84       1
    RHS1      R85       1
    RHS1      R86       1
    RHS1      R87       1
    RHS1      R88       1
    RHS1      R89       1
    RHS1      R90       1
    RHS1      R91       1
    RHS1      R92       1
    RHS1      R93       1
    RHS1      R94       1
    RHS1      R95       1
    RHS1      R96       1
    RHS1      R97       1
    RHS1      R98       1
    RHS1      R99       1
    RHS1      R100      1
    RHS1      R101      1
    RHS1      R102      1
    RHS1      R103      1
    RHS1      R104      1
    RHS1      R105      1
    RHS1      R106      1
    RHS1      R107      1
    RHS1      R108      1
    RHS1      R109      1
    RHS1      R110      1
    RHS1      R111      1
    RHS1      R112      1
    RHS1      R113      1
    RHS1      R114      1
    RHS1      R115      1
    RHS1      R116      1
    RHS1      R117      1
    RHS1      R118      1
    RHS1      R119      1
    RHS1      R120      1
    RHS1      R121      1
    RHS1      R122      1
    RHS1      R123      1
    RHS1      R124      1
    RHS1      R125      1
    RHS1      R126      1
    RHS1      R127      1
    RHS1      R128      1
    RHS1      R129      1
    RHS1      R130      1
    RHS1      R131      1
    RHS1      R132      1
    RHS1      R133      1
    RHS1      R134      1
    RHS1      R135      1
    RHS1      R136      1
    RHS1      R137      1
    RHS1      R138      1
    RHS1      R139      1
    RHS1      R140      1
    RHS1      R141      1
    RHS1      R142      1
    RHS1      R143      1
    RHS1      R144      1
    RHS1      R145      1
    RHS1      R146      1
    RHS1      R147      1
    RHS1      R148      1
    RHS1      R149      1
    RHS1      R150      1
    RHS1      R151      1
    RHS1      R152      1
    RHS1      R153      1
    RHS1      R154      1
    RHS1      R155      1
    RHS1      R156      1
    RHS1      R157      1
    RHS1      R158      1
    RHS1      R159      1
    RHS1      R160      1
    RHS1      R161      1
    RHS1      R162      1
    RHS1      R163      1
    RHS1      R164      1
    RHS1      R165      1
    RHS1      R166      1
    RHS1      R167      1
    RHS1      R168      1
    RHS1      R169      1
    RHS1      R170      1
    RHS1      R171      1
    RHS1      R172      1
    RHS1      R173      1
    RHS1      R174      1
    RHS1      R175      1
    RHS1      R176      1
    RHS1      R177      1
    RHS1      R178      1
    RHS1      R179      1
    RHS1      R180      1
    RHS1      R181      1
    RHS1      R182      1
    RHS1      R183      1
    RHS1      R184      1
    RHS1      R185      1
    RHS1      R186      1
    RHS1      R187      1
    RHS1      R188      1
    RHS1      R189      1
    RHS1      R190      1
    RHS1      R191      1
    RHS1      R192      1
    RHS1      R193      1
    RHS1      R194      1
    RHS1      R195      1
    RHS1      R196      1
    RHS1      R197      1
    RHS1      R198      1
    RHS1      R199      1
    RHS1      R200      1
    RHS1      R201      1
    RHS1      R202      1
    RHS1      R203      1
    RHS1      R204      1
    RHS1      R205      1
    RHS1      R206      1
    RHS1      R207      1
    RHS1      R208      1
    RHS1      R209      1
    RHS1      R210      1
    RHS1      R211      1
    RHS1      R212      1
    RHS1      R213      1
    RHS1      R214      1
    RHS1      R215      1
    RHS1      R216      1
    RHS1      R217      1
    RHS1      R218      1
    RHS1      R219      1
    RHS1      R220      1
    RHS1      R221      1
    RHS1      R222      1
    RHS1      R223      1
    RHS1      R224      1
    RHS1      R225      1
    RHS1      R226      1
    RHS1      R227      1
    RHS1      R228      1
    RHS1      R229      1
    RHS1      R230      1
    RHS1      R231      1
    RHS1      R232      1
    RHS1      R233      1
    RHS1      R234      1
    RHS1      R235      1
    RHS1      R236      1
    RHS1      R237      1
    RHS1      R238      1
    RHS1      R239      1
    RHS1      R240      1
    RHS1      R721      -2
    RHS1      R723      -2
    RHS1      R725      -2
    RHS1      R727      -2
    RHS1      R729      -2
    RHS1      R731      -2
    RHS1      R733      -2
    RHS1      R735      -2
    RHS1      R737      -2
    RHS1      R739      -2
    RHS1      R741      -2
    RHS1      R743      -2
    RHS1      R745      -2
    RHS1      R747      -2
    RHS1      R749      -2
    RHS1      R751      -2
    RHS1      R753      -2
    RHS1      R755      -2
    RHS1      R757      -2
    RHS1      R759      -2
    RHS1      R761      -2
    RHS1      R763      -2
    RHS1      R765      -2
    RHS1      R767      -2
    RHS1      R769      -2
    RHS1      R771      -2
    RHS1      R773      -2
    RHS1      R775      -2
    RHS1      R777      -2
    RHS1      R779      -2
    RHS1      R781      -2
    RHS1      R783      -2
    RHS1      R785      -2
    RHS1      R787      -2
    RHS1      R789      -2
    RHS1      R791      -2
    RHS1      R793      -2
    RHS1      R795      -2
    RHS1      R797      -2
    RHS1      R799      -2
    RHS1      R801      -2
    RHS1      R803      -2
    RHS1      R805      -2
    RHS1      R807      -2
    RHS1      R809      -2
    RHS1      R811      -2
    RHS1      R813      -2
    RHS1      R815      -2
    RHS1      R817      -2
    RHS1      R819      -2
    RHS1      R821      -2
    RHS1      R823      -2
    RHS1      R825      -2
    RHS1      R827      -2
    RHS1      R829      -2
    RHS1      R831      -2
    RHS1      R833      -2
    RHS1      R835      -2
    RHS1      R837      -2
    RHS1      R839      -2
    RHS1      R841      -2
    RHS1      R843      -2
    RHS1      R845      -2
    RHS1      R847      -2
    RHS1      R849      -2
    RHS1      R851      -2
    RHS1      R853      -2
    RHS1      R855      -2
    RHS1      R857      -2
    RHS1      R859      -2
    RHS1      R861      -2
    RHS1      R863      -2
    RHS1      R865      -2
    RHS1      R867      -2
    RHS1      R869      -2
    RHS1      R871      -2
    RHS1      R873      -2
    RHS1      R875      -2
    RHS1      R877      -2
    RHS1      R879      -2
    RHS1      R881      -2
    RHS1      R883      -2
    RHS1      R885      -2
    RHS1      R887      -2
    RHS1      R889      -2
    RHS1      R891      -2
    RHS1      R893      -2
    RHS1      R895      -2
    RHS1      R897      -2
    RHS1      R899      -2
    RHS1      R901      -2
    RHS1      R903      -2
    RHS1      R905      -2
    RHS1      R907      -2
    RHS1      R909      -2
    RHS1      R911      -2
    RHS1      R913      -2
    RHS1      R915      -2
    RHS1      R917      -2
    RHS1      R919      -2
    RHS1      R921      -2
    RHS1      R923      -2
    RHS1      R925      -2
    RHS1      R927      -2
    RHS1      R929      -2
    RHS1      R931      -2
    RHS1      R933      -2
    RHS1      R935      -2
    RHS1      R937      -2
    RHS1      R939      -2
    RHS1      R941      -2
    RHS1      R943      -2
    RHS1      R945      -2
    RHS1      R947      -2
    RHS1      R949      -2
    RHS1      R951      -2
    RHS1      R953      -2
    RHS1      R955      -2
    RHS1      R957      -2
    RHS1      R959      -2
    RHS1      R961      -2
    RHS1      R963      -2
    RHS1      R965      -2
    RHS1      R967      -2
    RHS1      R969      -2
    RHS1      R971      -2
    RHS1      R973      -2
    RHS1      R975      -2
    RHS1      R977      -2
    RHS1      R979      -2
    RHS1      R981      -2
    RHS1      R983      -2
    RHS1      R985      -2
    RHS1      R987      -2
    RHS1      R989      -2
    RHS1      R991      -2
    RHS1      R993      -2
    RHS1      R995      -2
    RHS1      R997      -2
    RHS1      R999      -2
    RHS1      R1001     -2
    RHS1      R1003     -2
    RHS1      R1005     -2
    RHS1      R1007     -2
    RHS1      R1009     -2
    RHS1      R1011     -2
    RHS1      R1013     -2
    RHS1      R1015     -2
    RHS1      R1017     -2
    RHS1      R1019     -2
    RHS1      R1021     -2
    RHS1      R1023     -2
    RHS1      R1025     -2
    RHS1      R1027     -2
    RHS1      R1029     -2
    RHS1      R1031     -2
    RHS1      R1033     -2
    RHS1      R1035     -2
    RHS1      R1037     -2
    RHS1      R1039     -2
    RHS1      R1041     -2
    RHS1      R1043     -2
    RHS1      R1045     -2
    RHS1      R1047     -2
    RHS1      R1049     -2
    RHS1      R1051     -2
    RHS1      R1053     -2
    RHS1      R1055     -2
    RHS1      R1057     -2
    RHS1      R1059     -2
    RHS1      R1061     -2
    RHS1      R1063     -2
    RHS1      R1065     -2
    RHS1      R1067     -2
    RHS1      R1069     -2
    RHS1      R1071     -2
    RHS1      R1073     -2
    RHS1      R1075     -2
    RHS1      R1077     -2
    RHS1      R1079     -2
    RHS1      R1081     -2
    RHS1      R1083     -2
    RHS1      R1085     -2
    RHS1      R1087     -2
    RHS1      R1089     -2
    RHS1      R1091     -2
    RHS1      R1093     -2
    RHS1      R1095     -2
    RHS1      R1097     -2
    RHS1      R1099     -2
    RHS1      R1101     -2
    RHS1      R1103     -2
    RHS1      R1105     -2
    RHS1      R1107     -2
    RHS1      R1109     -2
    RHS1      R1111     -2
    RHS1      R1113     -2
    RHS1      R1115     -2
    RHS1      R1117     -2
    RHS1      R1119     -2
    RHS1      R1121     -2
    RHS1      R1123     -2
    RHS1      R1125     -2
    RHS1      R1127     -2
    RHS1      R1129     -2
    RHS1      R1131     -2
    RHS1      R1133     -2
    RHS1      R1135     -2
    RHS1      R1137     -2
    RHS1      R1139     -2
    RHS1      R1141     -2
    RHS1      R1143     -2
    RHS1      R1145     -2
    RHS1      R1147     -2
    RHS1      R1149     -2
    RHS1      R1151     -2
    RHS1      R1153     -2
    RHS1      R1155     -2
    RHS1      R1157     -2
    RHS1      R1159     -2
    RHS1      R1161     -2
    RHS1      R1163     -2
    RHS1      R1165     -2
    RHS1      R1167     -2
    RHS1      R1169     -2
    RHS1      R1171     -2
    RHS1      R1173     -2
    RHS1      R1175     -2
    RHS1      R1177     -2
    RHS1      R1179     -2
    RHS1      R1181     -2
    RHS1      R1183     -2
    RHS1      R1185     -2
    RHS1      R1187     -2
    RHS1      R1189     -2
    RHS1      R1191     -2
    RHS1      R1193     -2
    RHS1      R1195     -2
    RHS1      R1197     -2
    RHS1      R1199     -2
    RHS1      R1201     1
    RHS1      R1202     1
    RHS1      R1203     1
    RHS1      R1220     -6
BOUNDS
* Note: variable lower bounds are 0 unless specified otherwise
 BV BND1      x1      
 BV BND1      x2      
 BV BND1      x3      
 BV BND1      x4      
 BV BND1      x5      
 BV BND1      x6      
 BV BND1      x7      
 BV BND1      x8      
 BV BND1      x9      
 BV BND1      x10     
 BV BND1      x11     
 BV BND1      x12     
 BV BND1      x13     
 BV BND1      x14     
 BV BND1      x15     
 BV BND1      x16     
 BV BND1      x33     
 BV BND1      x48     
 BV BND1      x63     
 BV BND1      x78     
 BV BND1      x34     
 BV BND1      x49     
 BV BND1      x64     
 BV BND1      x79     
 BV BND1      x35     
 BV BND1      x50     
 BV BND1      x65     
 BV BND1      x80     
 BV BND1      x36     
 BV BND1      x51     
 BV BND1      x66     
 BV BND1      x81     
 BV BND1      x37     
 BV BND1      x52     
 BV BND1      x67     
 BV BND1      x82     
 BV BND1      x38     
 BV BND1      x53     
 BV BND1      x68     
 BV BND1      x83     
 BV BND1      x39     
 BV BND1      x54     
 BV BND1      x69     
 BV BND1      x84     
 BV BND1      x40     
 BV BND1      x55     
 BV BND1      x70     
 BV BND1      x85     
 BV BND1      x41     
 BV BND1      x56     
 BV BND1      x71     
 BV BND1      x86     
 BV BND1      x42     
 BV BND1      x57     
 BV BND1      x72     
 BV BND1      x87     
 BV BND1      x43     
 BV BND1      x58     
 BV BND1      x73     
 BV BND1      x88     
 BV BND1      x44     
 BV BND1      x59     
 BV BND1      x74     
 BV BND1      x89     
 BV BND1      x45     
 BV BND1      x60     
 BV BND1      x75     
 BV BND1      x90     
 BV BND1      x46     
 BV BND1      x61     
 BV BND1      x76     
 BV BND1      x91     
 BV BND1      x47     
 BV BND1      x62     
 BV BND1      x77     
 BV BND1      x92     
 BV BND1      x93     
 BV BND1      x94     
 BV BND1      x95     
 BV BND1      x96     
 BV BND1      x97     
 BV BND1      x98     
 BV BND1      x99     
 BV BND1      x100    
 BV BND1      x101    
 BV BND1      x102    
 BV BND1      x103    
 BV BND1      x104    
 BV BND1      x105    
 BV BND1      x106    
 BV BND1      x107    
 BV BND1      x108    
 BV BND1      x109    
 BV BND1      x110    
 BV BND1      x111    
 BV BND1      x112    
 BV BND1      x113    
 BV BND1      x114    
 BV BND1      x115    
 BV BND1      x116    
 BV BND1      x117    
 BV BND1      x118    
 BV BND1      x119    
 BV BND1      x120    
 BV BND1      x121    
 BV BND1      x122    
 BV BND1      x123    
 BV BND1      x124    
 BV BND1      x125    
 BV BND1      x126    
 BV BND1      x127    
 BV BND1      x128    
 BV BND1      x129    
 BV BND1      x130    
 BV BND1      x131    
 BV BND1      x132    
 BV BND1      x133    
 BV BND1      x134    
 BV BND1      x135    
 BV BND1      x136    
 BV BND1      x137    
 BV BND1      x138    
 BV BND1      x139    
 BV BND1      x140    
 BV BND1      x141    
 BV BND1      x142    
 BV BND1      x143    
 BV BND1      x144    
 BV BND1      x145    
 BV BND1      x146    
 BV BND1      x147    
 BV BND1      x148    
 BV BND1      x149    
 BV BND1      x150    
 BV BND1      x151    
 BV BND1      x152    
 BV BND1      x153    
 BV BND1      x154    
 BV BND1      x155    
 BV BND1      x156    
 BV BND1      x157    
 BV BND1      x158    
 BV BND1      x159    
 BV BND1      x160    
 BV BND1      x161    
 BV BND1      x162    
 BV BND1      x163    
 BV BND1      x164    
 BV BND1      x165    
 BV BND1      x166    
 BV BND1      x167    
 BV BND1      x168    
 BV BND1      x169    
 BV BND1      x170    
 BV BND1      x171    
 BV BND1      x172    
 BV BND1      x173    
 BV BND1      x174    
 BV BND1      x175    
 BV BND1      x176    
 BV BND1      x177    
 BV BND1      x178    
 BV BND1      x179    
 BV BND1      x180    
 BV BND1      x181    
 BV BND1      x182    
 BV BND1      x183    
 BV BND1      x184    
 BV BND1      x185    
 BV BND1      x186    
 BV BND1      x187    
 BV BND1      x188    
 BV BND1      x189    
 BV BND1      x190    
 BV BND1      x191    
 BV BND1      x192    
 BV BND1      x193    
 BV BND1      x194    
 BV BND1      x195    
 BV BND1      x196    
 BV BND1      x197    
 BV BND1      x198    
 BV BND1      x199    
 BV BND1      x200    
 BV BND1      x201    
 BV BND1      x202    
 BV BND1      x203    
 BV BND1      x204    
 BV BND1      x205    
 BV BND1      x206    
 BV BND1      x207    
 BV BND1      x208    
 BV BND1      x209    
 BV BND1      x210    
 BV BND1      x211    
 BV BND1      x212    
 BV BND1      x213    
 BV BND1      x214    
 BV BND1      x215    
 BV BND1      x216    
 BV BND1      x217    
 BV BND1      x218    
 BV BND1      x219    
 BV BND1      x220    
 BV BND1      x221    
 BV BND1      x222    
 BV BND1      x223    
 BV BND1      x224    
 BV BND1      x225    
 BV BND1      x226    
 BV BND1      x227    
 BV BND1      x228    
 BV BND1      x229    
 BV BND1      x230    
 BV BND1      x231    
 BV BND1      x232    
 BV BND1      x233    
 BV BND1      x234    
 BV BND1      x235    
 BV BND1      x236    
 BV BND1      x237    
 BV BND1      x238    
 BV BND1      x239    
 BV BND1      x240    
 BV BND1      x241    
 BV BND1      x242    
 BV BND1      x243    
 BV BND1      x244    
 BV BND1      x245    
 BV BND1      x246    
 BV BND1      x247    
 BV BND1      x248    
 BV BND1      x249    
 BV BND1      x250    
 BV BND1      x251    
 BV BND1      x252    
 BV BND1      x253    
 BV BND1      x254    
 BV BND1      x255    
 BV BND1      x256    
 BV BND1      x257    
 BV BND1      x258    
 BV BND1      x259    
 BV BND1      x260    
 BV BND1      x261    
 BV BND1      x262    
 BV BND1      x263    
 BV BND1      x264    
 BV BND1      x265    
 BV BND1      x266    
 BV BND1      x267    
 BV BND1      x268    
 BV BND1      x269    
 BV BND1      x270    
 BV BND1      x271    
 BV BND1      x272    
 BV BND1      x17     
 BV BND1      x18     
 BV BND1      x19     
 BV BND1      x20     
 BV BND1      x21     
 BV BND1      x22     
 BV BND1      x23     
 BV BND1      x24     
 BV BND1      x25     
 BV BND1      x26     
 BV BND1      x27     
 BV BND1      x28     
 BV BND1      x29     
 BV BND1      x30     
 BV BND1      x31     
 BV BND1      x32     
ENDATA
