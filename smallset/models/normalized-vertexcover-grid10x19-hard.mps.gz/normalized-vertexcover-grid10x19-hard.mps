NAME (null)
ROWS
 N  OBJ
 G  R0      
 G  R1      
 G  R2      
 G  R3      
 G  R4      
 G  R5      
 G  R6      
 G  R7      
 G  R8      
 G  R9      
 G  R10     
 G  R11     
 G  R12     
 G  R13     
 G  R14     
 G  R15     
 G  R16     
 G  R17     
 G  R18     
 G  R19     
 G  R20     
 G  R21     
 G  R22     
 G  R23     
 G  R24     
 G  R25     
 G  R26     
 G  R27     
 G  R28     
 G  R29     
 G  R30     
 G  R31     
 G  R32     
 G  R33     
 G  R34     
 G  R35     
 G  R36     
 G  R37     
 G  R38     
 G  R39     
 G  R40     
 G  R41     
 G  R42     
 G  R43     
 G  R44     
 G  R45     
 G  R46     
 G  R47     
 G  R48     
 G  R49     
 G  R50     
 G  R51     
 G  R52     
 G  R53     
 G  R54     
 G  R55     
 G  R56     
 G  R57     
 G  R58     
 G  R59     
 G  R60     
 G  R61     
 G  R62     
 G  R63     
 G  R64     
 G  R65     
 G  R66     
 G  R67     
 G  R68     
 G  R69     
 G  R70     
 G  R71     
 G  R72     
 G  R73     
 G  R74     
 G  R75     
 G  R76     
 G  R77     
 G  R78     
 G  R79     
 G  R80     
 G  R81     
 G  R82     
 G  R83     
 G  R84     
 G  R85     
 G  R86     
 G  R87     
 G  R88     
 G  R89     
 G  R90     
 G  R91     
 G  R92     
 G  R93     
 G  R94     
 G  R95     
 G  R96     
 G  R97     
 G  R98     
 G  R99     
 G  R100    
 G  R101    
 G  R102    
 G  R103    
 G  R104    
 G  R105    
 G  R106    
 G  R107    
 G  R108    
 G  R109    
 G  R110    
 G  R111    
 G  R112    
 G  R113    
 G  R114    
 G  R115    
 G  R116    
 G  R117    
 G  R118    
 G  R119    
 G  R120    
 G  R121    
 G  R122    
 G  R123    
 G  R124    
 G  R125    
 G  R126    
 G  R127    
 G  R128    
 G  R129    
 G  R130    
 G  R131    
 G  R132    
 G  R133    
 G  R134    
 G  R135    
 G  R136    
 G  R137    
 G  R138    
 G  R139    
 G  R140    
 G  R141    
 G  R142    
 G  R143    
 G  R144    
 G  R145    
 G  R146    
 G  R147    
 G  R148    
 G  R149    
 G  R150    
 G  R151    
 G  R152    
 G  R153    
 G  R154    
 G  R155    
 G  R156    
 G  R157    
 G  R158    
 G  R159    
 G  R160    
 G  R161    
 G  R162    
 G  R163    
 G  R164    
 G  R165    
 G  R166    
 G  R167    
 G  R168    
 G  R169    
 G  R170    
 G  R171    
 G  R172    
 G  R173    
 G  R174    
 G  R175    
 G  R176    
 G  R177    
 G  R178    
 G  R179    
 G  R180    
 G  R181    
 G  R182    
 G  R183    
 G  R184    
 G  R185    
 G  R186    
 G  R187    
 G  R188    
 G  R189    
 G  R190    
 G  R191    
 G  R192    
 G  R193    
 G  R194    
 G  R195    
 G  R196    
 G  R197    
 G  R198    
 G  R199    
 G  R200    
 G  R201    
 G  R202    
 G  R203    
 G  R204    
 G  R205    
 G  R206    
 G  R207    
 G  R208    
 G  R209    
 G  R210    
 G  R211    
 G  R212    
 G  R213    
 G  R214    
 G  R215    
 G  R216    
 G  R217    
 G  R218    
 G  R219    
 G  R220    
 G  R221    
 G  R222    
 G  R223    
 G  R224    
 G  R225    
 G  R226    
 G  R227    
 G  R228    
 G  R229    
 G  R230    
 G  R231    
 G  R232    
 G  R233    
 G  R234    
 G  R235    
 G  R236    
 G  R237    
 G  R238    
 G  R239    
 G  R240    
 G  R241    
 G  R242    
 G  R243    
 G  R244    
 G  R245    
 G  R246    
 G  R247    
 G  R248    
 G  R249    
 G  R250    
 G  R251    
 G  R252    
 G  R253    
 G  R254    
 G  R255    
 G  R256    
 G  R257    
 G  R258    
 G  R259    
 G  R260    
 G  R261    
 G  R262    
 G  R263    
 G  R264    
 G  R265    
 G  R266    
 G  R267    
 G  R268    
 G  R269    
 G  R270    
 G  R271    
 G  R272    
 G  R273    
 G  R274    
 G  R275    
 G  R276    
 G  R277    
 G  R278    
 G  R279    
 G  R280    
 G  R281    
 G  R282    
 G  R283    
 G  R284    
 G  R285    
 G  R286    
 G  R287    
 G  R288    
 G  R289    
 G  R290    
 G  R291    
 G  R292    
 G  R293    
 G  R294    
 G  R295    
 G  R296    
 G  R297    
 G  R298    
 G  R299    
 G  R300    
 G  R301    
 G  R302    
 G  R303    
 G  R304    
 G  R305    
 G  R306    
 G  R307    
 G  R308    
 G  R309    
 G  R310    
 G  R311    
 G  R312    
 G  R313    
 G  R314    
 G  R315    
 G  R316    
 G  R317    
 G  R318    
 G  R319    
 G  R320    
 G  R321    
 G  R322    
 G  R323    
 G  R324    
 G  R325    
 G  R326    
 G  R327    
 G  R328    
 G  R329    
 G  R330    
 G  R331    
 G  R332    
 G  R333    
 G  R334    
 G  R335    
 G  R336    
 G  R337    
 G  R338    
 G  R339    
 G  R340    
 G  R341    
 G  R342    
 G  R343    
 G  R344    
 G  R345    
 G  R346    
 G  R347    
 G  R348    
 G  R349    
 G  R350    
 G  R351    
 G  R352    
 G  R353    
 G  R354    
 G  R355    
 G  R356    
 G  R357    
 G  R358    
 G  R359    
 G  R360    
 G  R361    
 G  R362    
 G  R363    
 G  R364    
 G  R365    
 G  R366    
 G  R367    
 G  R368    
 G  R369    
 G  R370    
 G  R371    
 G  R372    
 G  R373    
 G  R374    
 G  R375    
 G  R376    
 G  R377    
 G  R378    
 G  R379    
 G  R380    
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x1        R0        1
    x1        R1        1
    x1        R18       1
    x1        R361      1
    x1        R380      -1
    x2        R0        1
    x2        R2        1
    x2        R3        1
    x2        R363      1
    x2        R380      -1
    x11       R1        1
    x11       R20       1
    x11       R21       1
    x11       R38       1
    x11       R380      -1
    x3        R2        1
    x3        R4        1
    x3        R5        1
    x3        R365      1
    x3        R380      -1
    x12       R3        1
    x12       R20       1
    x12       R22       1
    x12       R23       1
    x12       R380      -1
    x4        R4        1
    x4        R6        1
    x4        R7        1
    x4        R367      1
    x4        R380      -1
    x13       R5        1
    x13       R22       1
    x13       R24       1
    x13       R25       1
    x13       R380      -1
    x5        R6        1
    x5        R8        1
    x5        R9        1
    x5        R369      1
    x5        R380      -1
    x14       R7        1
    x14       R24       1
    x14       R26       1
    x14       R27       1
    x14       R380      -1
    x6        R8        1
    x6        R10       1
    x6        R11       1
    x6        R371      1
    x6        R380      -1
    x15       R9        1
    x15       R26       1
    x15       R28       1
    x15       R29       1
    x15       R380      -1
    x7        R10       1
    x7        R12       1
    x7        R13       1
    x7        R373      1
    x7        R380      -1
    x16       R11       1
    x16       R28       1
    x16       R30       1
    x16       R31       1
    x16       R380      -1
    x8        R12       1
    x8        R14       1
    x8        R15       1
    x8        R375      1
    x8        R380      -1
    x17       R13       1
    x17       R30       1
    x17       R32       1
    x17       R33       1
    x17       R380      -1
    x9        R14       1
    x9        R16       1
    x9        R17       1
    x9        R377      1
    x9        R380      -1
    x18       R15       1
    x18       R32       1
    x18       R34       1
    x18       R35       1
    x18       R380      -1
    x10       R16       1
    x10       R18       1
    x10       R19       1
    x10       R379      1
    x10       R380      -1
    x19       R17       1
    x19       R34       1
    x19       R36       1
    x19       R37       1
    x19       R380      -1
    x20       R19       1
    x20       R36       1
    x20       R38       1
    x20       R39       1
    x20       R380      -1
    x21       R21       1
    x21       R40       1
    x21       R41       1
    x21       R58       1
    x21       R380      -1
    x22       R23       1
    x22       R40       1
    x22       R42       1
    x22       R43       1
    x22       R380      -1
    x23       R25       1
    x23       R42       1
    x23       R44       1
    x23       R45       1
    x23       R380      -1
    x24       R27       1
    x24       R44       1
    x24       R46       1
    x24       R47       1
    x24       R380      -1
    x25       R29       1
    x25       R46       1
    x25       R48       1
    x25       R49       1
    x25       R380      -1
    x26       R31       1
    x26       R48       1
    x26       R50       1
    x26       R51       1
    x26       R380      -1
    x27       R33       1
    x27       R50       1
    x27       R52       1
    x27       R53       1
    x27       R380      -1
    x28       R35       1
    x28       R52       1
    x28       R54       1
    x28       R55       1
    x28       R380      -1
    x29       R37       1
    x29       R54       1
    x29       R56       1
    x29       R57       1
    x29       R380      -1
    x30       R39       1
    x30       R56       1
    x30       R58       1
    x30       R59       1
    x30       R380      -1
    x31       R41       1
    x31       R60       1
    x31       R61       1
    x31       R78       1
    x31       R380      -1
    x32       R43       1
    x32       R60       1
    x32       R62       1
    x32       R63       1
    x32       R380      -1
    x33       R45       1
    x33       R62       1
    x33       R64       1
    x33       R65       1
    x33       R380      -1
    x34       R47       1
    x34       R64       1
    x34       R66       1
    x34       R67       1
    x34       R380      -1
    x35       R49       1
    x35       R66       1
    x35       R68       1
    x35       R69       1
    x35       R380      -1
    x36       R51       1
    x36       R68       1
    x36       R70       1
    x36       R71       1
    x36       R380      -1
    x37       R53       1
    x37       R70       1
    x37       R72       1
    x37       R73       1
    x37       R380      -1
    x38       R55       1
    x38       R72       1
    x38       R74       1
    x38       R75       1
    x38       R380      -1
    x39       R57       1
    x39       R74       1
    x39       R76       1
    x39       R77       1
    x39       R380      -1
    x40       R59       1
    x40       R76       1
    x40       R78       1
    x40       R79       1
    x40       R380      -1
    x41       R61       1
    x41       R80       1
    x41       R81       1
    x41       R98       1
    x41       R380      -1
    x42       R63       1
    x42       R80       1
    x42       R82       1
    x42       R83       1
    x42       R380      -1
    x43       R65       1
    x43       R82       1
    x43       R84       1
    x43       R85       1
    x43       R380      -1
    x44       R67       1
    x44       R84       1
    x44       R86       1
    x44       R87       1
    x44       R380      -1
    x45       R69       1
    x45       R86       1
    x45       R88       1
    x45       R89       1
    x45       R380      -1
    x46       R71       1
    x46       R88       1
    x46       R90       1
    x46       R91       1
    x46       R380      -1
    x47       R73       1
    x47       R90       1
    x47       R92       1
    x47       R93       1
    x47       R380      -1
    x48       R75       1
    x48       R92       1
    x48       R94       1
    x48       R95       1
    x48       R380      -1
    x49       R77       1
    x49       R94       1
    x49       R96       1
    x49       R97       1
    x49       R380      -1
    x50       R79       1
    x50       R96       1
    x50       R98       1
    x50       R99       1
    x50       R380      -1
    x51       R81       1
    x51       R100      1
    x51       R101      1
    x51       R118      1
    x51       R380      -1
    x52       R83       1
    x52       R100      1
    x52       R102      1
    x52       R103      1
    x52       R380      -1
    x53       R85       1
    x53       R102      1
    x53       R104      1
    x53       R105      1
    x53       R380      -1
    x54       R87       1
    x54       R104      1
    x54       R106      1
    x54       R107      1
    x54       R380      -1
    x55       R89       1
    x55       R106      1
    x55       R108      1
    x55       R109      1
    x55       R380      -1
    x56       R91       1
    x56       R108      1
    x56       R110      1
    x56       R111      1
    x56       R380      -1
    x57       R93       1
    x57       R110      1
    x57       R112      1
    x57       R113      1
    x57       R380      -1
    x58       R95       1
    x58       R112      1
    x58       R114      1
    x58       R115      1
    x58       R380      -1
    x59       R97       1
    x59       R114      1
    x59       R116      1
    x59       R117      1
    x59       R380      -1
    x60       R99       1
    x60       R116      1
    x60       R118      1
    x60       R119      1
    x60       R380      -1
    x61       R101      1
    x61       R120      1
    x61       R121      1
    x61       R138      1
    x61       R380      -1
    x62       R103      1
    x62       R120      1
    x62       R122      1
    x62       R123      1
    x62       R380      -1
    x63       R105      1
    x63       R122      1
    x63       R124      1
    x63       R125      1
    x63       R380      -1
    x64       R107      1
    x64       R124      1
    x64       R126      1
    x64       R127      1
    x64       R380      -1
    x65       R109      1
    x65       R126      1
    x65       R128      1
    x65       R129      1
    x65       R380      -1
    x66       R111      1
    x66       R128      1
    x66       R130      1
    x66       R131      1
    x66       R380      -1
    x67       R113      1
    x67       R130      1
    x67       R132      1
    x67       R133      1
    x67       R380      -1
    x68       R115      1
    x68       R132      1
    x68       R134      1
    x68       R135      1
    x68       R380      -1
    x69       R117      1
    x69       R134      1
    x69       R136      1
    x69       R137      1
    x69       R380      -1
    x70       R119      1
    x70       R136      1
    x70       R138      1
    x70       R139      1
    x70       R380      -1
    x71       R121      1
    x71       R140      1
    x71       R141      1
    x71       R158      1
    x71       R380      -1
    x72       R123      1
    x72       R140      1
    x72       R142      1
    x72       R143      1
    x72       R380      -1
    x73       R125      1
    x73       R142      1
    x73       R144      1
    x73       R145      1
    x73       R380      -1
    x74       R127      1
    x74       R144      1
    x74       R146      1
    x74       R147      1
    x74       R380      -1
    x75       R129      1
    x75       R146      1
    x75       R148      1
    x75       R149      1
    x75       R380      -1
    x76       R131      1
    x76       R148      1
    x76       R150      1
    x76       R151      1
    x76       R380      -1
    x77       R133      1
    x77       R150      1
    x77       R152      1
    x77       R153      1
    x77       R380      -1
    x78       R135      1
    x78       R152      1
    x78       R154      1
    x78       R155      1
    x78       R380      -1
    x79       R137      1
    x79       R154      1
    x79       R156      1
    x79       R157      1
    x79       R380      -1
    x80       R139      1
    x80       R156      1
    x80       R158      1
    x80       R159      1
    x80       R380      -1
    x81       R141      1
    x81       R160      1
    x81       R161      1
    x81       R178      1
    x81       R380      -1
    x82       R143      1
    x82       R160      1
    x82       R162      1
    x82       R163      1
    x82       R380      -1
    x83       R145      1
    x83       R162      1
    x83       R164      1
    x83       R165      1
    x83       R380      -1
    x84       R147      1
    x84       R164      1
    x84       R166      1
    x84       R167      1
    x84       R380      -1
    x85       R149      1
    x85       R166      1
    x85       R168      1
    x85       R169      1
    x85       R380      -1
    x86       R151      1
    x86       R168      1
    x86       R170      1
    x86       R171      1
    x86       R380      -1
    x87       R153      1
    x87       R170      1
    x87       R172      1
    x87       R173      1
    x87       R380      -1
    x88       R155      1
    x88       R172      1
    x88       R174      1
    x88       R175      1
    x88       R380      -1
    x89       R157      1
    x89       R174      1
    x89       R176      1
    x89       R177      1
    x89       R380      -1
    x90       R159      1
    x90       R176      1
    x90       R178      1
    x90       R179      1
    x90       R380      -1
    x91       R161      1
    x91       R180      1
    x91       R181      1
    x91       R198      1
    x91       R380      -1
    x92       R163      1
    x92       R180      1
    x92       R182      1
    x92       R183      1
    x92       R380      -1
    x93       R165      1
    x93       R182      1
    x93       R184      1
    x93       R185      1
    x93       R380      -1
    x94       R167      1
    x94       R184      1
    x94       R186      1
    x94       R187      1
    x94       R380      -1
    x95       R169      1
    x95       R186      1
    x95       R188      1
    x95       R189      1
    x95       R380      -1
    x96       R171      1
    x96       R188      1
    x96       R190      1
    x96       R191      1
    x96       R380      -1
    x97       R173      1
    x97       R190      1
    x97       R192      1
    x97       R193      1
    x97       R380      -1
    x98       R175      1
    x98       R192      1
    x98       R194      1
    x98       R195      1
    x98       R380      -1
    x99       R177      1
    x99       R194      1
    x99       R196      1
    x99       R197      1
    x99       R380      -1
    x100      R179      1
    x100      R196      1
    x100      R198      1
    x100      R199      1
    x100      R380      -1
    x101      R181      1
    x101      R200      1
    x101      R201      1
    x101      R218      1
    x101      R380      -1
    x102      R183      1
    x102      R200      1
    x102      R202      1
    x102      R203      1
    x102      R380      -1
    x103      R185      1
    x103      R202      1
    x103      R204      1
    x103      R205      1
    x103      R380      -1
    x104      R187      1
    x104      R204      1
    x104      R206      1
    x104      R207      1
    x104      R380      -1
    x105      R189      1
    x105      R206      1
    x105      R208      1
    x105      R209      1
    x105      R380      -1
    x106      R191      1
    x106      R208      1
    x106      R210      1
    x106      R211      1
    x106      R380      -1
    x107      R193      1
    x107      R210      1
    x107      R212      1
    x107      R213      1
    x107      R380      -1
    x108      R195      1
    x108      R212      1
    x108      R214      1
    x108      R215      1
    x108      R380      -1
    x109      R197      1
    x109      R214      1
    x109      R216      1
    x109      R217      1
    x109      R380      -1
    x110      R199      1
    x110      R216      1
    x110      R218      1
    x110      R219      1
    x110      R380      -1
    x111      R201      1
    x111      R220      1
    x111      R221      1
    x111      R238      1
    x111      R380      -1
    x112      R203      1
    x112      R220      1
    x112      R222      1
    x112      R223      1
    x112      R380      -1
    x113      R205      1
    x113      R222      1
    x113      R224      1
    x113      R225      1
    x113      R380      -1
    x114      R207      1
    x114      R224      1
    x114      R226      1
    x114      R227      1
    x114      R380      -1
    x115      R209      1
    x115      R226      1
    x115      R228      1
    x115      R229      1
    x115      R380      -1
    x116      R211      1
    x116      R228      1
    x116      R230      1
    x116      R231      1
    x116      R380      -1
    x117      R213      1
    x117      R230      1
    x117      R232      1
    x117      R233      1
    x117      R380      -1
    x118      R215      1
    x118      R232      1
    x118      R234      1
    x118      R235      1
    x118      R380      -1
    x119      R217      1
    x119      R234      1
    x119      R236      1
    x119      R237      1
    x119      R380      -1
    x120      R219      1
    x120      R236      1
    x120      R238      1
    x120      R239      1
    x120      R380      -1
    x121      R221      1
    x121      R240      1
    x121      R241      1
    x121      R258      1
    x121      R380      -1
    x122      R223      1
    x122      R240      1
    x122      R242      1
    x122      R243      1
    x122      R380      -1
    x123      R225      1
    x123      R242      1
    x123      R244      1
    x123      R245      1
    x123      R380      -1
    x124      R227      1
    x124      R244      1
    x124      R246      1
    x124      R247      1
    x124      R380      -1
    x125      R229      1
    x125      R246      1
    x125      R248      1
    x125      R249      1
    x125      R380      -1
    x126      R231      1
    x126      R248      1
    x126      R250      1
    x126      R251      1
    x126      R380      -1
    x127      R233      1
    x127      R250      1
    x127      R252      1
    x127      R253      1
    x127      R380      -1
    x128      R235      1
    x128      R252      1
    x128      R254      1
    x128      R255      1
    x128      R380      -1
    x129      R237      1
    x129      R254      1
    x129      R256      1
    x129      R257      1
    x129      R380      -1
    x130      R239      1
    x130      R256      1
    x130      R258      1
    x130      R259      1
    x130      R380      -1
    x131      R241      1
    x131      R260      1
    x131      R261      1
    x131      R278      1
    x131      R380      -1
    x132      R243      1
    x132      R260      1
    x132      R262      1
    x132      R263      1
    x132      R380      -1
    x133      R245      1
    x133      R262      1
    x133      R264      1
    x133      R265      1
    x133      R380      -1
    x134      R247      1
    x134      R264      1
    x134      R266      1
    x134      R267      1
    x134      R380      -1
    x135      R249      1
    x135      R266      1
    x135      R268      1
    x135      R269      1
    x135      R380      -1
    x136      R251      1
    x136      R268      1
    x136      R270      1
    x136      R271      1
    x136      R380      -1
    x137      R253      1
    x137      R270      1
    x137      R272      1
    x137      R273      1
    x137      R380      -1
    x138      R255      1
    x138      R272      1
    x138      R274      1
    x138      R275      1
    x138      R380      -1
    x139      R257      1
    x139      R274      1
    x139      R276      1
    x139      R277      1
    x139      R380      -1
    x140      R259      1
    x140      R276      1
    x140      R278      1
    x140      R279      1
    x140      R380      -1
    x141      R261      1
    x141      R280      1
    x141      R281      1
    x141      R298      1
    x141      R380      -1
    x142      R263      1
    x142      R280      1
    x142      R282      1
    x142      R283      1
    x142      R380      -1
    x143      R265      1
    x143      R282      1
    x143      R284      1
    x143      R285      1
    x143      R380      -1
    x144      R267      1
    x144      R284      1
    x144      R286      1
    x144      R287      1
    x144      R380      -1
    x145      R269      1
    x145      R286      1
    x145      R288      1
    x145      R289      1
    x145      R380      -1
    x146      R271      1
    x146      R288      1
    x146      R290      1
    x146      R291      1
    x146      R380      -1
    x147      R273      1
    x147      R290      1
    x147      R292      1
    x147      R293      1
    x147      R380      -1
    x148      R275      1
    x148      R292      1
    x148      R294      1
    x148      R295      1
    x148      R380      -1
    x149      R277      1
    x149      R294      1
    x149      R296      1
    x149      R297      1
    x149      R380      -1
    x150      R279      1
    x150      R296      1
    x150      R298      1
    x150      R299      1
    x150      R380      -1
    x151      R281      1
    x151      R300      1
    x151      R301      1
    x151      R318      1
    x151      R380      -1
    x152      R283      1
    x152      R300      1
    x152      R302      1
    x152      R303      1
    x152      R380      -1
    x153      R285      1
    x153      R302      1
    x153      R304      1
    x153      R305      1
    x153      R380      -1
    x154      R287      1
    x154      R304      1
    x154      R306      1
    x154      R307      1
    x154      R380      -1
    x155      R289      1
    x155      R306      1
    x155      R308      1
    x155      R309      1
    x155      R380      -1
    x156      R291      1
    x156      R308      1
    x156      R310      1
    x156      R311      1
    x156      R380      -1
    x157      R293      1
    x157      R310      1
    x157      R312      1
    x157      R313      1
    x157      R380      -1
    x158      R295      1
    x158      R312      1
    x158      R314      1
    x158      R315      1
    x158      R380      -1
    x159      R297      1
    x159      R314      1
    x159      R316      1
    x159      R317      1
    x159      R380      -1
    x160      R299      1
    x160      R316      1
    x160      R318      1
    x160      R319      1
    x160      R380      -1
    x161      R301      1
    x161      R320      1
    x161      R321      1
    x161      R338      1
    x161      R380      -1
    x162      R303      1
    x162      R320      1
    x162      R322      1
    x162      R323      1
    x162      R380      -1
    x163      R305      1
    x163      R322      1
    x163      R324      1
    x163      R325      1
    x163      R380      -1
    x164      R307      1
    x164      R324      1
    x164      R326      1
    x164      R327      1
    x164      R380      -1
    x165      R309      1
    x165      R326      1
    x165      R328      1
    x165      R329      1
    x165      R380      -1
    x166      R311      1
    x166      R328      1
    x166      R330      1
    x166      R331      1
    x166      R380      -1
    x167      R313      1
    x167      R330      1
    x167      R332      1
    x167      R333      1
    x167      R380      -1
    x168      R315      1
    x168      R332      1
    x168      R334      1
    x168      R335      1
    x168      R380      -1
    x169      R317      1
    x169      R334      1
    x169      R336      1
    x169      R337      1
    x169      R380      -1
    x170      R319      1
    x170      R336      1
    x170      R338      1
    x170      R339      1
    x170      R380      -1
    x171      R321      1
    x171      R340      1
    x171      R341      1
    x171      R358      1
    x171      R380      -1
    x172      R323      1
    x172      R340      1
    x172      R342      1
    x172      R343      1
    x172      R380      -1
    x173      R325      1
    x173      R342      1
    x173      R344      1
    x173      R345      1
    x173      R380      -1
    x174      R327      1
    x174      R344      1
    x174      R346      1
    x174      R347      1
    x174      R380      -1
    x175      R329      1
    x175      R346      1
    x175      R348      1
    x175      R349      1
    x175      R380      -1
    x176      R331      1
    x176      R348      1
    x176      R350      1
    x176      R351      1
    x176      R380      -1
    x177      R333      1
    x177      R350      1
    x177      R352      1
    x177      R353      1
    x177      R380      -1
    x178      R335      1
    x178      R352      1
    x178      R354      1
    x178      R355      1
    x178      R380      -1
    x179      R337      1
    x179      R354      1
    x179      R356      1
    x179      R357      1
    x179      R380      -1
    x180      R339      1
    x180      R356      1
    x180      R358      1
    x180      R359      1
    x180      R380      -1
    x181      R341      1
    x181      R360      1
    x181      R361      1
    x181      R378      1
    x181      R380      -1
    x182      R343      1
    x182      R360      1
    x182      R362      1
    x182      R363      1
    x182      R380      -1
    x183      R345      1
    x183      R362      1
    x183      R364      1
    x183      R365      1
    x183      R380      -1
    x184      R347      1
    x184      R364      1
    x184      R366      1
    x184      R367      1
    x184      R380      -1
    x185      R349      1
    x185      R366      1
    x185      R368      1
    x185      R369      1
    x185      R380      -1
    x186      R351      1
    x186      R368      1
    x186      R370      1
    x186      R371      1
    x186      R380      -1
    x187      R353      1
    x187      R370      1
    x187      R372      1
    x187      R373      1
    x187      R380      -1
    x188      R355      1
    x188      R372      1
    x188      R374      1
    x188      R375      1
    x188      R380      -1
    x189      R357      1
    x189      R374      1
    x189      R376      1
    x189      R377      1
    x189      R380      -1
    x190      R359      1
    x190      R376      1
    x190      R378      1
    x190      R379      1
    x190      R380      -1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      R0        1
    RHS1      R1        1
    RHS1      R2        1
    RHS1      R3        1
    RHS1      R4        1
    RHS1      R5        1
    RHS1      R6        1
    RHS1      R7        1
    RHS1      R8        1
    RHS1      R9        1
    RHS1      R10       1
    RHS1      R11       1
    RHS1      R12       1
    RHS1      R13       1
    RHS1      R14       1
    RHS1      R15       1
    RHS1      R16       1
    RHS1      R17       1
    RHS1      R18       1
    RHS1      R19       1
    RHS1      R20       1
    RHS1      R21       1
    RHS1      R22       1
    RHS1      R23       1
    RHS1      R24       1
    RHS1      R25       1
    RHS1      R26       1
    RHS1      R27       1
    RHS1      R28       1
    RHS1      R29       1
    RHS1      R30       1
    RHS1      R31       1
    RHS1      R32       1
    RHS1      R33       1
    RHS1      R34       1
    RHS1      R35       1
    RHS1      R36       1
    RHS1      R37       1
    RHS1      R38       1
    RHS1      R39       1
    RHS1      R40       1
    RHS1      R41       1
    RHS1      R42       1
    RHS1      R43       1
    RHS1      R44       1
    RHS1      R45       1
    RHS1      R46       1
    RHS1      R47       1
    RHS1      R48       1
    RHS1      R49       1
    RHS1      R50       1
    RHS1      R51       1
    RHS1      R52       1
    RHS1      R53       1
    RHS1      R54       1
    RHS1      R55       1
    RHS1      R56       1
    RHS1      R57       1
    RHS1      R58       1
    RHS1      R59       1
    RHS1      R60       1
    RHS1      R61       1
    RHS1      R62       1
    RHS1      R63       1
    RHS1      R64       1
    RHS1      R65       1
    RHS1      R66       1
    RHS1      R67       1
    RHS1      R68       1
    RHS1      R69       1
    RHS1      R70       1
    RHS1      R71       1
    RHS1      R72       1
    RHS1      R73       1
    RHS1      R74       1
    RHS1      R75       1
    RHS1      R76       1
    RHS1      R77       1
    RHS1      R78       1
    RHS1      R79       1
    RHS1      R80       1
    RHS1      R81       1
    RHS1      R82       1
    RHS1      R83       1
    RHS1      R84       1
    RHS1      R85       1
    RHS1      R86       1
    RHS1      R87       1
    RHS1      R88       1
    RHS1      R89       1
    RHS1      R90       1
    RHS1      R91       1
    RHS1      R92       1
    RHS1      R93       1
    RHS1      R94       1
    RHS1      R95       1
    RHS1      R96       1
    RHS1      R97       1
    RHS1      R98       1
    RHS1      R99       1
    RHS1      R100      1
    RHS1      R101      1
    RHS1      R102      1
    RHS1      R103      1
    RHS1      R104      1
    RHS1      R105      1
    RHS1      R106      1
    RHS1      R107      1
    RHS1      R108      1
    RHS1      R109      1
    RHS1      R110      1
    RHS1      R111      1
    RHS1      R112      1
    RHS1      R113      1
    RHS1      R114      1
    RHS1      R115      1
    RHS1      R116      1
    RHS1      R117      1
    RHS1      R118      1
    RHS1      R119      1
    RHS1      R120      1
    RHS1      R121      1
    RHS1      R122      1
    RHS1      R123      1
    RHS1      R124      1
    RHS1      R125      1
    RHS1      R126      1
    RHS1      R127      1
    RHS1      R128      1
    RHS1      R129      1
    RHS1      R130      1
    RHS1      R131      1
    RHS1      R132      1
    RHS1      R133      1
    RHS1      R134      1
    RHS1      R135      1
    RHS1      R136      1
    RHS1      R137      1
    RHS1      R138      1
    RHS1      R139      1
    RHS1      R140      1
    RHS1      R141      1
    RHS1      R142      1
    RHS1      R143      1
    RHS1      R144      1
    RHS1      R145      1
    RHS1      R146      1
    RHS1      R147      1
    RHS1      R148      1
    RHS1      R149      1
    RHS1      R150      1
    RHS1      R151      1
    RHS1      R152      1
    RHS1      R153      1
    RHS1      R154      1
    RHS1      R155      1
    RHS1      R156      1
    RHS1      R157      1
    RHS1      R158      1
    RHS1      R159      1
    RHS1      R160      1
    RHS1      R161      1
    RHS1      R162      1
    RHS1      R163      1
    RHS1      R164      1
    RHS1      R165      1
    RHS1      R166      1
    RHS1      R167      1
    RHS1      R168      1
    RHS1      R169      1
    RHS1      R170      1
    RHS1      R171      1
    RHS1      R172      1
    RHS1      R173      1
    RHS1      R174      1
    RHS1      R175      1
    RHS1      R176      1
    RHS1      R177      1
    RHS1      R178      1
    RHS1      R179      1
    RHS1      R180      1
    RHS1      R181      1
    RHS1      R182      1
    RHS1      R183      1
    RHS1      R184      1
    RHS1      R185      1
    RHS1      R186      1
    RHS1      R187      1
    RHS1      R188      1
    RHS1      R189      1
    RHS1      R190      1
    RHS1      R191      1
    RHS1      R192      1
    RHS1      R193      1
    RHS1      R194      1
    RHS1      R195      1
    RHS1      R196      1
    RHS1      R197      1
    RHS1      R198      1
    RHS1      R199      1
    RHS1      R200      1
    RHS1      R201      1
    RHS1      R202      1
    RHS1      R203      1
    RHS1      R204      1
    RHS1      R205      1
    RHS1      R206      1
    RHS1      R207      1
    RHS1      R208      1
    RHS1      R209      1
    RHS1      R210      1
    RHS1      R211      1
    RHS1      R212      1
    RHS1      R213      1
    RHS1      R214      1
    RHS1      R215      1
    RHS1      R216      1
    RHS1      R217      1
    RHS1      R218      1
    RHS1      R219      1
    RHS1      R220      1
    RHS1      R221      1
    RHS1      R222      1
    RHS1      R223      1
    RHS1      R224      1
    RHS1      R225      1
    RHS1      R226      1
    RHS1      R227      1
    RHS1      R228      1
    RHS1      R229      1
    RHS1      R230      1
    RHS1      R231      1
    RHS1      R232      1
    RHS1      R233      1
    RHS1      R234      1
    RHS1      R235      1
    RHS1      R236      1
    RHS1      R237      1
    RHS1      R238      1
    RHS1      R239      1
    RHS1      R240      1
    RHS1      R241      1
    RHS1      R242      1
    RHS1      R243      1
    RHS1      R244      1
    RHS1      R245      1
    RHS1      R246      1
    RHS1      R247      1
    RHS1      R248      1
    RHS1      R249      1
    RHS1      R250      1
    RHS1      R251      1
    RHS1      R252      1
    RHS1      R253      1
    RHS1      R254      1
    RHS1      R255      1
    RHS1      R256      1
    RHS1      R257      1
    RHS1      R258      1
    RHS1      R259      1
    RHS1      R260      1
    RHS1      R261      1
    RHS1      R262      1
    RHS1      R263      1
    RHS1      R264      1
    RHS1      R265      1
    RHS1      R266      1
    RHS1      R267      1
    RHS1      R268      1
    RHS1      R269      1
    RHS1      R270      1
    RHS1      R271      1
    RHS1      R272      1
    RHS1      R273      1
    RHS1      R274      1
    RHS1      R275      1
    RHS1      R276      1
    RHS1      R277      1
    RHS1      R278      1
    RHS1      R279      1
    RHS1      R280      1
    RHS1      R281      1
    RHS1      R282      1
    RHS1      R283      1
    RHS1      R284      1
    RHS1      R285      1
    RHS1      R286      1
    RHS1      R287      1
    RHS1      R288      1
    RHS1      R289      1
    RHS1      R290      1
    RHS1      R291      1
    RHS1      R292      1
    RHS1      R293      1
    RHS1      R294      1
    RHS1      R295      1
    RHS1      R296      1
    RHS1      R297      1
    RHS1      R298      1
    RHS1      R299      1
    RHS1      R300      1
    RHS1      R301      1
    RHS1      R302      1
    RHS1      R303      1
    RHS1      R304      1
    RHS1      R305      1
    RHS1      R306      1
    RHS1      R307      1
    RHS1      R308      1
    RHS1      R309      1
    RHS1      R310      1
    RHS1      R311      1
    RHS1      R312      1
    RHS1      R313      1
    RHS1      R314      1
    RHS1      R315      1
    RHS1      R316      1
    RHS1      R317      1
    RHS1      R318      1
    RHS1      R319      1
    RHS1      R320      1
    RHS1      R321      1
    RHS1      R322      1
    RHS1      R323      1
    RHS1      R324      1
    RHS1      R325      1
    RHS1      R326      1
    RHS1      R327      1
    RHS1      R328      1
    RHS1      R329      1
    RHS1      R330      1
    RHS1      R331      1
    RHS1      R332      1
    RHS1      R333      1
    RHS1      R334      1
    RHS1      R335      1
    RHS1      R336      1
    RHS1      R337      1
    RHS1      R338      1
    RHS1      R339      1
    RHS1      R340      1
    RHS1      R341      1
    RHS1      R342      1
    RHS1      R343      1
    RHS1      R344      1
    RHS1      R345      1
    RHS1      R346      1
    RHS1      R347      1
    RHS1      R348      1
    RHS1      R349      1
    RHS1      R350      1
    RHS1      R351      1
    RHS1      R352      1
    RHS1      R353      1
    RHS1      R354      1
    RHS1      R355      1
    RHS1      R356      1
    RHS1      R357      1
    RHS1      R358      1
    RHS1      R359      1
    RHS1      R360      1
    RHS1      R361      1
    RHS1      R362      1
    RHS1      R363      1
    RHS1      R364      1
    RHS1      R365      1
    RHS1      R366      1
    RHS1      R367      1
    RHS1      R368      1
    RHS1      R369      1
    RHS1      R370      1
    RHS1      R371      1
    RHS1      R372      1
    RHS1      R373      1
    RHS1      R374      1
    RHS1      R375      1
    RHS1      R376      1
    RHS1      R377      1
    RHS1      R378      1
    RHS1      R379      1
    RHS1      R380      -99
BOUNDS
* Note: variable lower bounds are 0 unless specified otherwise
 BV BND1      x1      
 BV BND1      x2      
 BV BND1      x11     
 BV BND1      x3      
 BV BND1      x12     
 BV BND1      x4      
 BV BND1      x13     
 BV BND1      x5      
 BV BND1      x14     
 BV BND1      x6      
 BV BND1      x15     
 BV BND1      x7      
 BV BND1      x16     
 BV BND1      x8      
 BV BND1      x17     
 BV BND1      x9      
 BV BND1      x18     
 BV BND1      x10     
 BV BND1      x19     
 BV BND1      x20     
 BV BND1      x21     
 BV BND1      x22     
 BV BND1      x23     
 BV BND1      x24     
 BV BND1      x25     
 BV BND1      x26     
 BV BND1      x27     
 BV BND1      x28     
 BV BND1      x29     
 BV BND1      x30     
 BV BND1      x31     
 BV BND1      x32     
 BV BND1      x33     
 BV BND1      x34     
 BV BND1      x35     
 BV BND1      x36     
 BV BND1      x37     
 BV BND1      x38     
 BV BND1      x39     
 BV BND1      x40     
 BV BND1      x41     
 BV BND1      x42     
 BV BND1      x43     
 BV BND1      x44     
 BV BND1      x45     
 BV BND1      x46     
 BV BND1      x47     
 BV BND1      x48     
 BV BND1      x49     
 BV BND1      x50     
 BV BND1      x51     
 BV BND1      x52     
 BV BND1      x53     
 BV BND1      x54     
 BV BND1      x55     
 BV BND1      x56     
 BV BND1      x57     
 BV BND1      x58     
 BV BND1      x59     
 BV BND1      x60     
 BV BND1      x61     
 BV BND1      x62     
 BV BND1      x63     
 BV BND1      x64     
 BV BND1      x65     
 BV BND1      x66     
 BV BND1      x67     
 BV BND1      x68     
 BV BND1      x69     
 BV BND1      x70     
 BV BND1      x71     
 BV BND1      x72     
 BV BND1      x73     
 BV BND1      x74     
 BV BND1      x75     
 BV BND1      x76     
 BV BND1      x77     
 BV BND1      x78     
 BV BND1      x79     
 BV BND1      x80     
 BV BND1      x81     
 BV BND1      x82     
 BV BND1      x83     
 BV BND1      x84     
 BV BND1      x85     
 BV BND1      x86     
 BV BND1      x87     
 BV BND1      x88     
 BV BND1      x89     
 BV BND1      x90     
 BV BND1      x91     
 BV BND1      x92     
 BV BND1      x93     
 BV BND1      x94     
 BV BND1      x95     
 BV BND1      x96     
 BV BND1      x97     
 BV BND1      x98     
 BV BND1      x99     
 BV BND1      x100    
 BV BND1      x101    
 BV BND1      x102    
 BV BND1      x103    
 BV BND1      x104    
 BV BND1      x105    
 BV BND1      x106    
 BV BND1      x107    
 BV BND1      x108    
 BV BND1      x109    
 BV BND1      x110    
 BV BND1      x111    
 BV BND1      x112    
 BV BND1      x113    
 BV BND1      x114    
 BV BND1      x115    
 BV BND1      x116    
 BV BND1      x117    
 BV BND1      x118    
 BV BND1      x119    
 BV BND1      x120    
 BV BND1      x121    
 BV BND1      x122    
 BV BND1      x123    
 BV BND1      x124    
 BV BND1      x125    
 BV BND1      x126    
 BV BND1      x127    
 BV BND1      x128    
 BV BND1      x129    
 BV BND1      x130    
 BV BND1      x131    
 BV BND1      x132    
 BV BND1      x133    
 BV BND1      x134    
 BV BND1      x135    
 BV BND1      x136    
 BV BND1      x137    
 BV BND1      x138    
 BV BND1      x139    
 BV BND1      x140    
 BV BND1      x141    
 BV BND1      x142    
 BV BND1      x143    
 BV BND1      x144    
 BV BND1      x145    
 BV BND1      x146    
 BV BND1      x147    
 BV BND1      x148    
 BV BND1      x149    
 BV BND1      x150    
 BV BND1      x151    
 BV BND1      x152    
 BV BND1      x153    
 BV BND1      x154    
 BV BND1      x155    
 BV BND1      x156    
 BV BND1      x157    
 BV BND1      x158    
 BV BND1      x159    
 BV BND1      x160    
 BV BND1      x161    
 BV BND1      x162    
 BV BND1      x163    
 BV BND1      x164    
 BV BND1      x165    
 BV BND1      x166    
 BV BND1      x167    
 BV BND1      x168    
 BV BND1      x169    
 BV BND1      x170    
 BV BND1      x171    
 BV BND1      x172    
 BV BND1      x173    
 BV BND1      x174    
 BV BND1      x175    
 BV BND1      x176    
 BV BND1      x177    
 BV BND1      x178    
 BV BND1      x179    
 BV BND1      x180    
 BV BND1      x181    
 BV BND1      x182    
 BV BND1      x183    
 BV BND1      x184    
 BV BND1      x185    
 BV BND1      x186    
 BV BND1      x187    
 BV BND1      x188    
 BV BND1      x189    
 BV BND1      x190    
ENDATA
