NAME           
ROWS
 N  obj     
 G  c1      
 G  c2      
 G  c3      
 G  c4      
 G  c5      
 G  c6      
 G  c7      
 G  c8      
 G  c9      
 G  c10     
 G  c11     
 G  c12     
 G  c13     
 G  c14     
 G  c15     
 G  c16     
 G  c17     
 G  c18     
 G  c19     
 G  c20     
 G  c21     
 G  c22     
 G  c23     
 G  c24     
 G  c25     
 G  c26     
 G  c27     
 G  c28     
 G  c29     
 G  c30     
 G  c31     
 G  c32     
 G  c33     
 G  c34     
 G  c35     
 G  c36     
 G  c37     
 G  c38     
 G  c39     
 G  c40     
 G  c41     
 G  c42     
 G  c43     
 G  c44     
 G  c45     
 G  c46     
 G  c47     
 G  c48     
 G  c49     
 G  c50     
 G  c51     
 G  c52     
 G  c53     
 G  c54     
 G  c55     
 G  c56     
 G  c57     
 G  c58     
 G  c59     
 G  c60     
 G  c61     
 G  c62     
 G  c63     
 G  c64     
 G  c65     
 G  c66     
 G  c67     
 G  c68     
 G  c69     
 G  c70     
 G  c71     
 G  c72     
 G  c73     
 G  c74     
 G  c75     
 G  c76     
 G  c77     
 G  c78     
 G  c79     
 G  c80     
 G  c81     
 G  c82     
 G  c83     
 G  c84     
 G  c85     
 G  c86     
 G  c87     
 G  c88     
 G  c89     
 G  c90     
 G  c91     
 G  c92     
 G  c93     
 G  c94     
 G  c95     
 G  c96     
 G  c97     
 G  c98     
 G  c99     
 G  c100    
 G  c101    
 G  c102    
 G  c103    
 G  c104    
 G  c105    
 G  c106    
 G  c107    
 G  c108    
 G  c109    
 G  c110    
 G  c111    
 G  c112    
 G  c113    
 G  c114    
 G  c115    
 G  c116    
 G  c117    
 G  c118    
 G  c119    
 G  c120    
 G  c121    
 G  c122    
 G  c123    
 G  c124    
 G  c125    
 G  c126    
 G  c127    
 G  c128    
 G  c129    
 G  c130    
 G  c131    
 G  c132    
 G  c133    
 G  c134    
 G  c135    
 G  c136    
 G  c137    
 G  c138    
 G  c139    
 G  c140    
 G  c141    
 G  c142    
 G  c143    
 G  c144    
 G  c145    
 G  c146    
 G  c147    
 G  c148    
 G  c149    
 G  c150    
 G  c151    
 G  c152    
 G  c153    
 G  c154    
 G  c155    
 G  c156    
 G  c157    
 G  c158    
 G  c159    
 G  c160    
 G  c161    
 G  c162    
 G  c163    
 G  c164    
 G  c165    
 G  c166    
 G  c167    
 G  c168    
 G  c169    
 G  c170    
 G  c171    
 G  c172    
 G  c173    
 G  c174    
 G  c175    
 G  c176    
 G  c177    
 G  c178    
 G  c179    
 G  c180    
 G  c181    
 G  c182    
 G  c183    
 G  c184    
 G  c185    
 G  c186    
 G  c187    
 G  c188    
 G  c189    
 G  c190    
 G  c191    
 G  c192    
 G  c193    
 G  c194    
 G  c195    
 G  c196    
 G  c197    
 G  c198    
 G  c199    
 G  c200    
 G  c201    
 G  c202    
 G  c203    
 G  c204    
 G  c205    
 G  c206    
 G  c207    
 G  c208    
 G  c209    
 G  c210    
 G  c211    
 G  c212    
 G  c213    
 G  c214    
 G  c215    
 G  c216    
 G  c217    
 G  c218    
 G  c219    
 G  c220    
 G  c221    
 G  c222    
 G  c223    
 G  c224    
 G  c225    
 G  c226    
 G  c227    
 G  c228    
 G  c229    
 G  c230    
 G  c231    
 G  c232    
 G  c233    
 G  c234    
 G  c235    
 G  c236    
 G  c237    
 G  c238    
 G  c239    
 G  c240    
 G  c241    
 G  c242    
 G  c243    
 G  c244    
 G  c245    
 G  c246    
 G  c247    
 G  c248    
 G  c249    
 G  c250    
 G  c251    
 G  c252    
 G  c253    
 G  c254    
 G  c255    
 G  c256    
 G  c257    
 G  c258    
 G  c259    
 G  c260    
 G  c261    
 G  c262    
 G  c263    
 G  c264    
 G  c265    
 G  c266    
 G  c267    
 G  c268    
 G  c269    
 G  c270    
 G  c271    
 G  c272    
 G  c273    
 G  c274    
 G  c275    
 G  c276    
 G  c277    
 G  c278    
 G  c279    
 G  c280    
 G  c281    
 G  c282    
 G  c283    
 G  c284    
 G  c285    
 G  c286    
 G  c287    
 G  c288    
 G  c289    
 G  c290    
 G  c291    
 G  c292    
 G  c293    
 G  c294    
 G  c295    
 G  c296    
 G  c297    
 G  c298    
 G  c299    
 G  c300    
 G  c301    
 G  c302    
 G  c303    
 G  c304    
 G  c305    
 G  c306    
 G  c307    
 G  c308    
 G  c309    
 G  c310    
 G  c311    
 G  c312    
 G  c313    
 G  c314    
 G  c315    
 G  c316    
 G  c317    
 G  c318    
 G  c319    
 G  c320    
 G  c321    
 G  c322    
 G  c323    
 G  c324    
 G  c325    
 G  c326    
 G  c327    
 G  c328    
 G  c329    
 G  c330    
 G  c331    
 G  c332    
 G  c333    
 G  c334    
 G  c335    
 G  c336    
 G  c337    
 G  c338    
 G  c339    
 G  c340    
 G  c341    
 G  c342    
 G  c343    
 G  c344    
 G  c345    
 G  c346    
 G  c347    
 G  c348    
 G  c349    
 G  c350    
 G  c351    
 G  c352    
 G  c353    
 G  c354    
 G  c355    
 G  c356    
 G  c357    
 G  c358    
 G  c359    
 G  c360    
 G  c361    
 G  c362    
 G  c363    
 G  c364    
 G  c365    
 G  c366    
 G  c367    
 G  c368    
 G  c369    
 G  c370    
 G  c371    
 G  c372    
 G  c373    
 G  c374    
 G  c375    
 G  c376    
 G  c377    
 G  c378    
 G  c379    
 G  c380    
 G  c381    
 G  c382    
 G  c383    
 G  c384    
 G  c385    
 G  c386    
 G  c387    
 G  c388    
 G  c389    
 G  c390    
 G  c391    
 G  c392    
 G  c393    
 G  c394    
 G  c395    
 G  c396    
 G  c397    
 G  c398    
 G  c399    
 G  c400    
 G  c401    
 G  c402    
 G  c403    
 G  c404    
 G  c405    
 G  c406    
 G  c407    
 G  c408    
 G  c409    
 G  c410    
 G  c411    
 G  c412    
 G  c413    
 G  c414    
 G  c415    
 G  c416    
 G  c417    
 G  c418    
 G  c419    
 G  c420    
 G  c421    
 G  c422    
 G  c423    
 G  c424    
 G  c425    
 G  c426    
 G  c427    
 G  c428    
 G  c429    
 G  c430    
 G  c431    
 G  c432    
 G  c433    
 G  c434    
 G  c435    
 G  c436    
 G  c437    
 G  c438    
 G  c439    
 G  c440    
 G  c441    
 G  c442    
 G  c443    
 G  c444    
 G  c445    
 G  c446    
 G  c447    
 G  c448    
 G  c449    
 G  c450    
 G  c451    
 G  c452    
 G  c453    
 G  c454    
 G  c455    
 G  c456    
 G  c457    
 G  c458    
 G  c459    
 G  c460    
 G  c461    
 G  c462    
 G  c463    
 G  c464    
 G  c465    
 G  c466    
 G  c467    
 G  c468    
 G  c469    
 G  c470    
 G  c471    
 G  c472    
 G  c473    
 G  c474    
 G  c475    
 G  c476    
 G  c477    
 G  c478    
 G  c479    
 G  c480    
 G  c481    
 G  c482    
 G  c483    
 G  c484    
 G  c485    
 G  c486    
 G  c487    
 G  c488    
 G  c489    
 G  c490    
 G  c491    
 G  c492    
 G  c493    
 G  c494    
 G  c495    
 G  c496    
 G  c497    
 G  c498    
 G  c499    
 G  c500    
 G  c501    
 G  c502    
 G  c503    
 G  c504    
 G  c505    
 G  c506    
 G  c507    
 G  c508    
 G  c509    
 G  c510    
 G  c511    
 G  c512    
 G  c513    
 G  c514    
 G  c515    
 G  c516    
 G  c517    
 G  c518    
 G  c519    
 G  c520    
 G  c521    
 G  c522    
 G  c523    
 G  c524    
 G  c525    
 G  c526    
 G  c527    
 G  c528    
 G  c529    
 G  c530    
 G  c531    
 G  c532    
 G  c533    
 G  c534    
 G  c535    
 G  c536    
 G  c537    
 G  c538    
 G  c539    
 G  c540    
 G  c541    
 G  c542    
 G  c543    
 G  c544    
 G  c545    
 G  c546    
 G  c547    
 G  c548    
 G  c549    
 G  c550    
 G  c551    
 G  c552    
 G  c553    
 G  c554    
 G  c555    
 G  c556    
 G  c557    
 G  c558    
 G  c559    
 G  c560    
 G  c561    
 G  c562    
 G  c563    
 G  c564    
 G  c565    
 G  c566    
 G  c567    
 G  c568    
 G  c569    
 G  c570    
 G  c571    
 G  c572    
 G  c573    
 G  c574    
 G  c575    
 G  c576    
 G  c577    
 G  c578    
 G  c579    
 G  c580    
 G  c581    
 G  c582    
 G  c583    
 G  c584    
 G  c585    
 G  c586    
 G  c587    
 G  c588    
 G  c589    
 G  c590    
 G  c591    
 G  c592    
 G  c593    
 G  c594    
 G  c595    
 G  c596    
 G  c597    
 G  c598    
 G  c599    
 G  c600    
 G  c601    
 G  c602    
 G  c603    
 G  c604    
 G  c605    
 G  c606    
 G  c607    
 G  c608    
 G  c609    
 G  c610    
 G  c611    
 G  c612    
 G  c613    
 G  c614    
 G  c615    
 G  c616    
 G  c617    
 G  c618    
 G  c619    
 G  c620    
 G  c621    
 G  c622    
 G  c623    
 G  c624    
 G  c625    
 G  c626    
 G  c627    
 G  c628    
 G  c629    
 G  c630    
 G  c631    
 G  c632    
 G  c633    
 G  c634    
 G  c635    
 G  c636    
 G  c637    
 G  c638    
 G  c639    
 G  c640    
 G  c641    
 G  c642    
 G  c643    
 G  c644    
 G  c645    
 G  c646    
 G  c647    
 G  c648    
 G  c649    
 G  c650    
 G  c651    
 G  c652    
 G  c653    
 G  c654    
 G  c655    
 G  c656    
 G  c657    
 G  c658    
 G  c659    
 G  c660    
 G  c661    
 G  c662    
 G  c663    
 G  c664    
 G  c665    
 G  c666    
 G  c667    
 G  c668    
 G  c669    
 G  c670    
 G  c671    
 G  c672    
 G  c673    
 G  c674    
 G  c675    
 G  c676    
 G  c677    
 G  c678    
 G  c679    
 G  c680    
 G  c681    
 G  c682    
 G  c683    
 G  c684    
 G  c685    
 G  c686    
 G  c687    
 G  c688    
 G  c689    
 G  c690    
 G  c691    
 G  c692    
 G  c693    
 G  c694    
 G  c695    
 G  c696    
 G  c697    
 G  c698    
 G  c699    
 G  c700    
 G  c701    
 G  c702    
 G  c703    
 G  c704    
 G  c705    
 G  c706    
 G  c707    
 G  c708    
 G  c709    
 G  c710    
 G  c711    
 G  c712    
 G  c713    
 G  c714    
 G  c715    
 G  c716    
 G  c717    
 G  c718    
 G  c719    
 G  c720    
 G  c721    
 G  c722    
 G  c723    
 G  c724    
 G  c725    
 G  c726    
 G  c727    
 G  c728    
 G  c729    
 G  c730    
 G  c731    
 G  c732    
 G  c733    
 G  c734    
 G  c735    
 G  c736    
 G  c737    
 G  c738    
 G  c739    
 G  c740    
 G  c741    
 G  c742    
 G  c743    
 G  c744    
 G  c745    
 G  c746    
 G  c747    
 G  c748    
 G  c749    
 G  c750    
 G  c751    
 G  c752    
 G  c753    
 G  c754    
 G  c755    
 G  c756    
 G  c757    
 G  c758    
 G  c759    
 G  c760    
 G  c761    
 G  c762    
 G  c763    
 G  c764    
 G  c765    
 G  c766    
 G  c767    
 G  c768    
 G  c769    
 G  c770    
 G  c771    
 G  c772    
 G  c773    
 G  c774    
 G  c775    
 G  c776    
 G  c777    
 G  c778    
 G  c779    
 G  c780    
 G  c781    
 G  c782    
 G  c783    
 G  c784    
 G  c785    
 G  c786    
 G  c787    
 G  c788    
 G  c789    
 G  c790    
 G  c791    
 G  c792    
 G  c793    
 G  c794    
 G  c795    
 G  c796    
 G  c797    
 G  c798    
 G  c799    
 G  c800    
 G  c801    
 G  c802    
 G  c803    
 G  c804    
 G  c805    
 G  c806    
 G  c807    
 G  c808    
 G  c809    
 G  c810    
 G  c811    
 G  c812    
 G  c813    
 G  c814    
 G  c815    
 G  c816    
 G  c817    
 G  c818    
 G  c819    
 G  c820    
 G  c821    
 G  c822    
 G  c823    
 G  c824    
 G  c825    
 G  c826    
 G  c827    
 G  c828    
 G  c829    
 G  c830    
 G  c831    
 G  c832    
 G  c833    
 G  c834    
 G  c835    
 G  c836    
 G  c837    
 G  c838    
 G  c839    
 G  c840    
 G  c841    
 G  c842    
 G  c843    
 G  c844    
 G  c845    
 G  c846    
 G  c847    
 G  c848    
 G  c849    
 G  c850    
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x1        c1                   1   c26                  1
    x1        c29                  1   c57                 -1
    x1        c89                  1   c101                -1
    x1        c104                 1   c109                -1
    x1        c152                 1   c168                 1
    x1        c200                -1   c233                -1
    x1        c306                -1   c320                -1
    x1        c332                 1   c361                 1
    x1        c365                 1   c436                 1
    x1        c437                -1   c484                -1
    x1        c512                 1   c593                -1
    x1        c601                -1   c606                -1
    x1        c674                -1   c700                -1
    x1        c735                -1   c739                -1
    x1        c782                 1   c784                -1
    x1        c794                -1   c820                 1
    x1        c828                 1   c835                -1
    x1        c839                -1   c850                 1
    x2        c1                  -1   c58                 -1
    x2        c71                  1   c76                 -1
    x2        c79                  1   c83                  1
    x2        c97                  1   c108                 1
    x2        c125                 1   c133                 1
    x2        c174                -1   c208                 1
    x2        c210                -1   c229                 1
    x2        c235                 1   c260                 1
    x2        c311                -1   c326                 1
    x2        c345                -1   c356                 1
    x2        c366                -1   c402                -1
    x2        c423                 1   c436                 1
    x2        c438                 1   c454                -1
    x2        c501                 1   c507                -1
    x2        c508                 1   c513                -1
    x2        c519                 1   c532                 1
    x2        c563                -1   c592                -1
    x2        c594                -1   c615                -1
    x2        c628                 1   c632                 1
    x2        c684                -1   c697                -1
    x2        c708                 1   c718                 1
    x2        c721                 1   c729                -1
    x2        c749                 1   c773                -1
    x2        c796                -1   c842                -1
    x3        c1                  -1   c21                 -1
    x3        c66                  1   c80                 -1
    x3        c150                -1   c227                 1
    x3        c229                -1   c234                -1
    x3        c242                 1   c248                -1
    x3        c257                -1   c269                 1
    x3        c284                 1   c310                 1
    x3        c348                 1   c354                -1
    x3        c376                -1   c400                -1
    x3        c463                 1   c489                -1
    x3        c540                -1   c545                -1
    x3        c577                -1   c640                -1
    x3        c643                -1   c667                -1
    x3        c695                -1   c701                -1
    x3        c703                 1   c732                 1
    x3        c751                -1   c794                -1
    x3        c798                -1
    x4        c1                   1   c8                  -1
    x4        c11                 -1   c60                 -1
    x4        c74                  1   c78                 -1
    x4        c85                  1   c98                  1
    x4        c100                 1   c109                 1
    x4        c110                -1   c121                 1
    x4        c136                 1   c143                 1
    x4        c170                 1   c219                 1
    x4        c221                -1   c228                 1
    x4        c230                -1   c232                 1
    x4        c274                 1   c275                 1
    x4        c288                -1   c291                 1
    x4        c346                -1   c389                 1
    x4        c392                -1   c400                 1
    x4        c420                -1   c444                 1
    x4        c493                -1   c500                 1
    x4        c505                 1   c526                -1
    x4        c545                 1   c546                 1
    x4        c556                -1   c574                 1
    x4        c584                -1   c680                 1
    x4        c709                 1   c767                 1
    x4        c787                -1   c803                -1
    x4        c817                 1   c829                -1
    x4        c839                 1   c845                 1
    x4        c850                 1
    x5        c1                  -1   c21                  1
    x5        c40                 -1   c59                  1
    x5        c87                 -1   c110                 1
    x5        c124                 1   c153                -1
    x5        c156                 1   c158                -1
    x5        c162                 1   c167                -1
    x5        c200                 1   c224                -1
    x5        c226                 1   c257                -1
    x5        c261                 1   c262                -1
    x5        c280                -1   c304                 1
    x5        c324                 1   c325                 1
    x5        c330                 1   c374                -1
    x5        c387                 1   c401                 1
    x5        c431                -1   c432                -1
    x5        c438                 1   c463                -1
    x5        c512                 1   c527                 1
    x5        c551                -1   c632                 1
    x5        c633                -1   c641                -1
    x5        c644                 1   c646                 1
    x5        c647                -1   c694                -1
    x5        c728                -1   c730                -1
    x5        c750                 1   c757                 1
    x5        c804                 1   c834                -1
    x6        c1                   1   c31                 -1
    x6        c45                 -1   c57                 -1
    x6        c77                 -1   c87                 -1
    x6        c93                  1   c101                -1
    x6        c118                -1   c152                 1
    x6        c156                 1   c170                 1
    x6        c194                -1   c228                 1
    x6        c310                 1   c341                -1
    x6        c346                 1   c349                -1
    x6        c359                -1   c429                -1
    x6        c454                 1   c462                -1
    x6        c509                -1   c531                 1
    x6        c563                 1   c564                 1
    x6        c571                 1   c585                -1
    x6        c590                 1   c596                 1
    x6        c601                 1   c607                 1
    x6        c645                 1   c660                 1
    x6        c709                -1   c711                -1
    x6        c712                 1   c734                -1
    x6        c735                 1   c760                 1
    x6        c797                 1   c838                -1
    x7        c1                  -1   c6                  -1
    x7        c19                 -1   c24                  1
    x7        c48                  1   c67                  1
    x7        c75                 -1   c149                -1
    x7        c167                -1   c192                 1
    x7        c196                -1   c274                -1
    x7        c309                 1   c443                -1
    x7        c454                 1   c467                 1
    x7        c475                 1   c480                 1
    x7        c482                -1   c492                -1
    x7        c507                -1   c510                -1
    x7        c517                -1   c528                 1
    x7        c551                 1   c561                 1
    x7        c593                 1   c594                 1
    x7        c605                 1   c613                 1
    x7        c615                -1   c641                -1
    x7        c643                 1   c655                -1
    x7        c675                 1   c678                -1
    x7        c689                 1   c720                -1
    x7        c741                -1   c742                -1
    x7        c755                -1   c766                 1
    x7        c788                 1   c817                -1
    x7        c837                 1   c849                 1
    x7        c850                 1
    x8        c2                   1   c7                  -1
    x8        c15                 -1   c30                  1
    x8        c58                 -1   c71                  1
    x8        c103                 1   c118                 1
    x8        c171                 1   c194                -1
    x8        c244                 1   c268                 1
    x8        c274                -1   c275                 1
    x8        c280                -1   c282                 1
    x8        c304                -1   c325                 1
    x8        c348                 1   c367                 1
    x8        c394                 1   c445                -1
    x8        c448                -1   c455                 1
    x8        c483                -1   c533                 1
    x8        c551                 1   c570                 1
    x8        c636                -1   c640                -1
    x8        c650                 1   c666                 1
    x8        c693                -1   c696                -1
    x8        c706                 1   c720                 1
    x8        c777                 1   c831                -1
    x8        c839                 1   c850                 1
    x9        c2                   1   c23                 -1
    x9        c45                  1   c53                  1
    x9        c127                -1   c133                -1
    x9        c139                 1   c200                -1
    x9        c208                 1   c239                 1
    x9        c242                 1   c250                -1
    x9        c295                 1   c318                 1
    x9        c326                 1   c333                 1
    x9        c359                 1   c387                -1
    x9        c403                 1   c437                -1
    x9        c443                 1   c524                 1
    x9        c557                 1   c569                -1
    x9        c573                -1   c646                 1
    x9        c653                 1   c700                 1
    x9        c725                -1   c829                -1
    x9        c833                -1   c836                 1
    x10       c3                  -1   c17                 -1
    x10       c50                  1   c59                  1
    x10       c97                  1   c100                -1
    x10       c118                -1   c123                 1
    x10       c137                 1   c139                -1
    x10       c140                 1   c142                -1
    x10       c191                 1   c204                -1
    x10       c229                 1   c241                -1
    x10       c245                -1   c249                 1
    x10       c257                -1   c263                -1
    x10       c273                -1   c276                 1
    x10       c289                -1   c308                -1
    x10       c310                 1   c311                 1
    x10       c329                 1   c362                -1
    x10       c387                -1   c415                -1
    x10       c419                 1   c425                 1
    x10       c432                 1   c439                -1
    x10       c445                 1   c472                -1
    x10       c479                -1   c488                -1
    x10       c527                -1   c541                 1
    x10       c634                -1   c668                 1
    x10       c672                -1   c684                 1
    x10       c693                 1   c710                -1
    x10       c784                -1
    x11       c3                  -1   c75                  1
    x11       c82                  1   c130                 1
    x11       c155                -1   c258                -1
    x11       c262                -1   c265                 1
    x11       c284                -1   c321                -1
    x11       c385                -1   c400                 1
    x11       c435                 1   c459                 1
    x11       c493                 1   c515                 1
    x11       c517                 1   c542                 1
    x11       c553                -1   c567                -1
    x11       c629                -1   c642                 1
    x11       c647                -1   c650                 1
    x11       c654                 1   c668                 1
    x11       c679                 1   c695                 1
    x11       c703                 1   c745                -1
    x11       c777                 1   c779                -1
    x11       c798                 1   c804                 1
    x11       c831                 1
    x12       c3                  -1   c52                  1
    x12       c77                  1   c83                 -1
    x12       c84                  1   c89                 -1
    x12       c91                  1   c112                -1
    x12       c136                 1   c158                 1
    x12       c177                 1   c205                 1
    x12       c255                -1   c258                -1
    x12       c265                 1   c293                -1
    x12       c342                 1   c360                 1
    x12       c380                 1   c446                -1
    x12       c450                -1   c460                 1
    x12       c476                 1   c503                -1
    x12       c506                -1   c516                 1
    x12       c530                 1   c587                 1
    x12       c640                -1   c648                 1
    x12       c660                 1   c668                -1
    x12       c672                -1   c719                 1
    x12       c745                -1   c755                 1
    x12       c771                 1   c776                -1
    x12       c778                -1   c788                 1
    x12       c802                 1   c814                 1
    x12       c821                 1   c827                 1
    x12       c830                 1
    x13       c3                  -1   c36                  1
    x13       c119                 1   c152                -1
    x13       c156                 1   c159                -1
    x13       c169                -1   c239                -1
    x13       c264                 1   c272                -1
    x13       c318                -1   c340                 1
    x13       c373                 1   c374                 1
    x13       c381                 1   c395                -1
    x13       c400                 1   c406                 1
    x13       c411                 1   c417                 1
    x13       c455                 1   c470                 1
    x13       c519                -1   c521                -1
    x13       c522                 1   c544                -1
    x13       c545                 1   c570                 1
    x13       c607                 1   c647                -1
    x13       c661                 1   c688                 1
    x13       c694                 1   c721                 1
    x13       c734                 1   c747                -1
    x13       c752                 1   c792                 1
    x13       c799                -1   c801                -1
    x14       c4                   1   c19                  1
    x14       c28                  1   c94                 -1
    x14       c101                -1   c133                -1
    x14       c149                 1   c157                -1
    x14       c198                -1   c207                 1
    x14       c212                 1   c231                 1
    x14       c241                -1   c285                -1
    x14       c293                -1   c306                -1
    x14       c312                 1   c334                 1
    x14       c412                 1   c423                 1
    x14       c460                -1   c465                -1
    x14       c481                 1   c509                 1
    x14       c578                 1   c597                 1
    x14       c611                -1   c615                -1
    x14       c651                -1   c719                 1
    x14       c781                -1
    x15       c4                   1   c13                 -1
    x15       c109                 1   c139                 1
    x15       c198                 1   c218                -1
    x15       c234                -1   c246                 1
    x15       c258                -1   c268                 1
    x15       c274                 1   c280                 1
    x15       c281                 1   c313                 1
    x15       c325                -1   c373                -1
    x15       c416                 1   c434                -1
    x15       c446                 1   c478                -1
    x15       c482                 1   c497                -1
    x15       c502                 1   c514                 1
    x15       c538                -1   c548                -1
    x15       c555                 1   c564                 1
    x15       c597                 1   c600                 1
    x15       c628                -1   c660                 1
    x15       c672                -1   c675                 1
    x15       c680                -1   c722                 1
    x15       c739                 1   c769                -1
    x15       c802                -1
    x16       c4                   1   c55                  1
    x16       c64                  1   c97                  1
    x16       c153                 1   c177                -1
    x16       c187                 1   c197                 1
    x16       c211                -1   c226                 1
    x16       c241                -1   c259                 1
    x16       c269                -1   c274                -1
    x16       c283                -1   c323                 1
    x16       c336                 1   c337                -1
    x16       c353                 1   c369                -1
    x16       c374                 1   c375                 1
    x16       c386                -1   c400                -1
    x16       c405                 1   c430                 1
    x16       c448                 1   c456                -1
    x16       c529                -1   c548                -1
    x16       c571                 1   c575                -1
    x16       c654                -1   c689                 1
    x16       c824                -1   c835                 1
    x16       c848                 1
    x17       c4                  -1   c13                 -1
    x17       c104                 1   c119                -1
    x17       c145                 1   c174                -1
    x17       c175                -1   c195                 1
    x17       c246                 1   c255                 1
    x17       c288                 1   c342                 1
    x17       c367                -1   c376                 1
    x17       c386                 1   c400                -1
    x17       c415                 1   c431                -1
    x17       c449                 1   c459                -1
    x17       c464                -1   c473                -1
    x17       c514                 1   c527                 1
    x17       c528                -1   c544                 1
    x17       c560                -1   c564                 1
    x17       c565                 1   c576                -1
    x17       c590                -1   c595                 1
    x17       c620                 1   c638                 1
    x17       c646                -1   c719                -1
    x17       c738                -1   c761                 1
    x17       c765                -1   c845                -1
    x18       c5                  -1   c19                  1
    x18       c54                  1   c78                  1
    x18       c112                 1   c135                 1
    x18       c137                 1   c161                 1
    x18       c172                -1   c188                -1
    x18       c249                -1   c262                 1
    x18       c267                -1   c270                 1
    x18       c274                 1   c288                 1
    x18       c300                 1   c314                 1
    x18       c322                 1   c364                -1
    x18       c397                 1   c399                -1
    x18       c418                 1   c424                 1
    x18       c450                 1   c502                -1
    x18       c517                 1   c536                -1
    x18       c547                 1   c557                -1
    x18       c592                -1   c613                 1
    x18       c626                 1   c628                 1
    x18       c644                -1   c691                 1
    x18       c697                -1   c698                 1
    x18       c703                -1   c709                 1
    x18       c722                 1   c753                -1
    x18       c782                -1   c784                -1
    x18       c805                -1   c819                 1
    x18       c823                 1
    x19       c5                   1   c33                 -1
    x19       c42                  1   c47                 -1
    x19       c70                 -1   c100                -1
    x19       c134                 1   c140                -1
    x19       c160                -1   c166                -1
    x19       c167                 1   c168                -1
    x19       c205                 1   c234                 1
    x19       c253                -1   c294                -1
    x19       c330                -1   c332                 1
    x19       c419                 1   c420                 1
    x19       c429                 1   c436                 1
    x19       c447                 1   c449                 1
    x19       c482                 1   c522                 1
    x19       c555                -1   c588                 1
    x19       c618                 1   c667                -1
    x19       c674                -1   c677                -1
    x19       c687                -1   c697                 1
    x19       c765                 1   c798                -1
    x19       c812                 1   c820                -1
    x20       c5                  -1   c83                 -1
    x20       c118                 1   c253                -1
    x20       c264                 1   c277                 1
    x20       c285                 1   c290                 1
    x20       c292                -1   c303                -1
    x20       c316                -1   c319                -1
    x20       c326                -1   c337                 1
    x20       c360                 1   c370                 1
    x20       c403                 1   c404                 1
    x20       c415                 1   c423                 1
    x20       c425                -1   c451                -1
    x20       c453                 1   c465                -1
    x20       c485                 1   c488                -1
    x20       c499                 1   c530                -1
    x20       c551                -1   c552                -1
    x20       c565                -1   c576                 1
    x20       c598                 1   c626                -1
    x20       c646                 1   c658                 1
    x20       c660                 1   c661                -1
    x20       c662                -1   c683                 1
    x20       c700                -1   c724                 1
    x20       c725                 1   c727                 1
    x20       c730                 1   c736                 1
    x20       c753                -1   c765                 1
    x20       c794                -1   c803                 1
    x20       c809                -1   c832                -1
    x21       c6                   1   c27                  1
    x21       c68                 -1   c83                 -1
    x21       c93                  1   c117                 1
    x21       c118                -1   c129                 1
    x21       c160                 1   c192                -1
    x21       c219                -1   c243                -1
    x21       c249                -1   c253                -1
    x21       c255                 1   c265                -1
    x21       c271                 1   c298                 1
    x21       c306                -1   c312                -1
    x21       c314                -1   c319                -1
    x21       c327                -1   c363                -1
    x21       c383                -1   c393                -1
    x21       c484                 1   c499                -1
    x21       c524                 1   c554                -1
    x21       c555                -1   c573                 1
    x21       c625                 1   c634                 1
    x21       c667                 1   c722                 1
    x21       c747                -1   c755                 1
    x21       c765                 1   c779                -1
    x21       c794                 1   c810                -1
    x21       c829                 1   c839                -1
    x21       c844                -1
    x22       c6                   1   c27                  1
    x22       c55                 -1   c75                  1
    x22       c87                  1   c89                  1
    x22       c90                 -1   c91                 -1
    x22       c112                 1   c130                -1
    x22       c154                 1   c155                 1
    x22       c156                 1   c159                 1
    x22       c165                 1   c184                -1
    x22       c196                 1   c225                -1
    x22       c234                 1   c239                -1
    x22       c261                -1   c291                -1
    x22       c323                 1   c329                -1
    x22       c350                -1   c356                -1
    x22       c357                 1   c358                -1
    x22       c394                 1   c423                 1
    x22       c443                -1   c484                -1
    x22       c521                -1   c523                 1
    x22       c609                 1   c610                 1
    x22       c619                 1   c626                 1
    x22       c637                 1   c639                 1
    x22       c672                 1   c712                 1
    x22       c745                -1   c778                 1
    x22       c808                 1
    x23       c6                   1   c24                 -1
    x23       c105                 1   c124                -1
    x23       c129                -1   c178                -1
    x23       c206                 1   c208                 1
    x23       c228                 1   c256                -1
    x23       c265                 1   c286                -1
    x23       c338                -1   c363                -1
    x23       c367                -1   c394                -1
    x23       c395                 1   c433                 1
    x23       c452                 1   c510                -1
    x23       c519                 1   c523                 1
    x23       c529                 1   c556                 1
    x23       c608                 1   c637                -1
    x23       c640                -1   c673                 1
    x23       c676                 1   c708                -1
    x23       c728                -1   c773                 1
    x23       c790                -1   c832                 1
    x23       c846                -1
    x24       c6                   1   c19                 -1
    x24       c34                  1   c49                 -1
    x24       c68                  1   c78                 -1
    x24       c83                 -1   c92                 -1
    x24       c134                 1   c147                 1
    x24       c148                -1   c163                 1
    x24       c179                -1   c185                 1
    x24       c186                 1   c197                -1
    x24       c211                -1   c216                 1
    x24       c240                 1   c258                 1
    x24       c266                -1   c338                -1
    x24       c357                -1   c381                 1
    x24       c385                -1   c464                -1
    x24       c499                 1   c633                -1
    x24       c644                 1   c657                 1
    x24       c665                 1   c670                 1
    x24       c672                -1   c682                -1
    x24       c697                -1   c700                -1
    x24       c707                -1   c718                 1
    x24       c741                 1   c751                 1
    x24       c783                 1   c784                 1
    x24       c795                 1   c803                 1
    x24       c805                -1   c832                -1
    x24       c834                 1   c846                -1
    x25       c6                   1   c38                 -1
    x25       c51                  1   c59                 -1
    x25       c97                  1   c103                -1
    x25       c116                -1   c125                 1
    x25       c139                -1   c169                 1
    x25       c187                 1   c210                 1
    x25       c230                -1   c233                -1
    x25       c281                 1   c286                 1
    x25       c363                -1   c366                -1
    x25       c370                 1   c374                 1
    x25       c405                 1   c469                -1
    x25       c484                -1   c489                -1
    x25       c537                 1   c608                 1
    x25       c640                -1   c645                 1
    x25       c667                 1   c680                -1
    x25       c742                -1   c752                -1
    x25       c755                -1   c758                 1
    x25       c767                 1   c772                -1
    x25       c792                -1   c793                 1
    x25       c798                 1   c830                 1
    x25       c837                -1
    x26       c7                  -1   c15                  1
    x26       c20                  1   c39                  1
    x26       c49                 -1   c94                 -1
    x26       c102                -1   c114                -1
    x26       c123                 1   c145                 1
    x26       c223                 1   c234                 1
    x26       c270                -1   c275                -1
    x26       c291                 1   c318                 1
    x26       c388                 1   c407                 1
    x26       c421                -1   c425                -1
    x26       c461                -1   c529                 1
    x26       c591                -1   c673                 1
    x26       c693                 1   c696                 1
    x26       c739                 1   c771                 1
    x26       c784                 1   c806                 1
    x26       c813                 1   c825                 1
    x27       c7                   1   c26                 -1
    x27       c42                 -1   c55                  1
    x27       c67                 -1   c77                  1
    x27       c83                  1   c89                  1
    x27       c90                  1   c124                 1
    x27       c136                -1   c184                -1
    x27       c227                 1   c245                -1
    x27       c256                 1   c288                -1
    x27       c292                 1   c299                -1
    x27       c307                -1   c311                 1
    x27       c323                 1   c347                -1
    x27       c357                -1   c364                 1
    x27       c374                 1   c407                 1
    x27       c410                 1   c438                -1
    x27       c470                 1   c482                -1
    x27       c485                 1   c490                -1
    x27       c532                 1   c549                 1
    x27       c579                -1   c612                -1
    x27       c685                -1   c701                -1
    x27       c713                 1   c742                 1
    x27       c746                 1   c817                 1
    x27       c818                -1
    x28       c7                  -1   c69                 -1
    x28       c72                 -1   c96                 -1
    x28       c125                -1   c131                -1
    x28       c133                 1   c161                 1
    x28       c180                -1   c225                -1
    x28       c229                -1   c281                -1
    x28       c291                 1   c301                -1
    x28       c323                 1   c380                -1
    x28       c383                -1   c398                -1
    x28       c432                 1   c440                 1
    x28       c478                 1   c481                -1
    x28       c499                -1   c503                 1
    x28       c517                 1   c519                -1
    x28       c520                 1   c522                -1
    x28       c570                 1   c583                -1
    x28       c608                 1   c621                -1
    x28       c624                -1   c629                 1
    x28       c637                -1   c643                -1
    x28       c653                -1   c656                 1
    x28       c669                -1   c688                -1
    x28       c690                 1   c692                 1
    x28       c710                 1   c743                -1
    x28       c767                -1   c795                -1
    x28       c799                 1   c805                 1
    x28       c812                 1   c820                -1
    x28       c826                 1
    x29       c7                  -1   c22                  1
    x29       c56                 -1   c62                  1
    x29       c144                 1   c176                 1
    x29       c190                -1   c194                -1
    x29       c266                 1   c273                 1
    x29       c319                 1   c344                -1
    x29       c448                -1   c452                -1
    x29       c455                 1   c474                -1
    x29       c512                -1   c575                -1
    x29       c590                 1   c625                 1
    x29       c649                 1   c683                 1
    x29       c705                 1   c707                 1
    x29       c732                 1   c743                -1
    x29       c757                -1   c820                -1
    x29       c833                 1   c838                -1
    x29       c841                 1   c845                 1
    x30       c7                   1   c20                  1
    x30       c49                 -1   c50                 -1
    x30       c57                  1   c82                 -1
    x30       c132                 1   c147                 1
    x30       c170                -1   c252                 1
    x30       c253                -1   c261                -1
    x30       c264                 1   c266                 1
    x30       c267                -1   c313                -1
    x30       c347                -1   c349                -1
    x30       c369                 1   c377                 1
    x30       c424                 1   c453                -1
    x30       c471                -1   c528                -1
    x30       c535                 1   c552                -1
    x30       c568                -1   c596                -1
    x30       c600                 1   c636                -1
    x30       c646                 1   c667                -1
    x30       c722                -1   c740                 1
    x30       c745                -1   c755                -1
    x30       c760                 1   c777                 1
    x30       c801                 1   c809                 1
    x30       c844                -1
    x31       c7                   1   c12                 -1
    x31       c31                 -1   c32                  1
    x31       c37                  1   c68                  1
    x31       c75                 -1   c92                  1
    x31       c132                -1   c142                 1
    x31       c154                -1   c158                -1
    x31       c164                 1   c188                -1
    x31       c228                 1   c244                -1
    x31       c254                -1   c264                -1
    x31       c292                 1   c318                -1
    x31       c335                -1   c343                 1
    x31       c365                -1   c386                 1
    x31       c405                -1   c486                 1
    x31       c504                -1   c509                -1
    x31       c559                -1   c585                 1
    x31       c587                 1   c607                 1
    x31       c636                -1   c645                 1
    x31       c666                -1   c719                -1
    x31       c744                -1   c748                -1
    x31       c774                -1   c775                 1
    x31       c814                 1   c833                 1
    x32       c8                   1   c28                 -1
    x32       c87                 -1   c103                -1
    x32       c132                 1   c145                 1
    x32       c151                -1   c216                -1
    x32       c233                 1   c238                 1
    x32       c240                -1   c261                -1
    x32       c271                -1   c277                -1
    x32       c317                 1   c327                -1
    x32       c361                 1   c372                -1
    x32       c375                 1   c389                 1
    x32       c395                -1   c412                 1
    x32       c460                 1   c462                 1
    x32       c465                -1   c478                 1
    x32       c499                 1   c513                -1
    x32       c549                 1   c559                -1
    x32       c592                -1   c595                 1
    x32       c609                 1   c619                 1
    x32       c626                 1   c630                -1
    x32       c631                -1   c648                -1
    x32       c684                 1   c703                -1
    x32       c764                 1   c780                 1
    x32       c789                 1
    x33       c8                  -1   c35                 -1
    x33       c39                  1   c45                  1
    x33       c51                  1   c59                 -1
    x33       c65                  1   c92                 -1
    x33       c99                 -1   c107                -1
    x33       c148                -1   c161                 1
    x33       c255                -1   c289                 1
    x33       c293                -1   c306                 1
    x33       c313                 1   c330                -1
    x33       c405                -1   c529                -1
    x33       c568                 1   c572                 1
    x33       c594                -1   c616                 1
    x33       c624                 1   c697                -1
    x33       c703                -1   c709                 1
    x33       c769                -1   c777                 1
    x33       c809                 1   c812                 1
    x33       c821                -1
    x34       c9                   1   c14                 -1
    x34       c31                  1   c79                  1
    x34       c81                  1   c84                 -1
    x34       c97                  1   c118                 1
    x34       c133                -1   c168                 1
    x34       c178                -1   c213                -1
    x34       c216                 1   c230                 1
    x34       c239                 1   c246                 1
    x34       c250                -1   c251                -1
    x34       c268                -1   c305                 1
    x34       c322                -1   c384                 1
    x34       c400                 1   c409                 1
    x34       c475                -1   c482                -1
    x34       c513                -1   c529                 1
    x34       c538                -1   c577                -1
    x34       c586                 1   c591                 1
    x34       c610                 1   c621                -1
    x34       c665                -1   c673                -1
    x34       c685                -1   c693                 1
    x34       c715                 1   c792                 1
    x34       c803                 1   c841                -1
    x34       c846                -1
    x35       c9                   1   c12                 -1
    x35       c19                  1   c39                 -1
    x35       c63                  1   c112                -1
    x35       c119                 1   c125                 1
    x35       c146                -1   c164                 1
    x35       c165                 1   c175                -1
    x35       c195                 1   c205                -1
    x35       c301                 1   c328                 1
    x35       c387                 1   c407                -1
    x35       c423                -1   c436                 1
    x35       c448                -1   c458                 1
    x35       c464                 1   c470                 1
    x35       c471                 1   c504                 1
    x35       c516                -1   c563                -1
    x35       c606                 1   c624                -1
    x35       c636                 1   c668                -1
    x35       c672                 1   c687                -1
    x35       c692                 1   c704                 1
    x35       c728                -1   c738                -1
    x35       c745                 1   c754                 1
    x35       c787                 1   c790                 1
    x35       c819                -1   c850                 1
    x36       c9                  -1   c16                  1
    x36       c47                  1   c50                  1
    x36       c59                 -1   c104                 1
    x36       c129                 1   c137                 1
    x36       c144                 1   c169                 1
    x36       c198                -1   c214                 1
    x36       c247                -1   c253                 1
    x36       c333                 1   c366                 1
    x36       c379                -1   c383                -1
    x36       c456                 1   c463                 1
    x36       c510                 1   c535                -1
    x36       c638                -1   c642                -1
    x36       c645                 1   c664                -1
    x36       c702                -1   c765                -1
    x36       c780                 1   c816                 1
    x36       c840                 1
    x37       c9                   1   c32                 -1
    x37       c34                  1   c66                 -1
    x37       c70                  1   c71                 -1
    x37       c89                 -1   c112                 1
    x37       c135                 1   c136                 1
    x37       c141                 1   c183                 1
    x37       c185                -1   c198                 1
    x37       c212                 1   c241                -1
    x37       c242                -1   c248                 1
    x37       c273                -1   c321                 1
    x37       c336                 1   c360                -1
    x37       c442                 1   c443                -1
    x37       c451                -1   c454                 1
    x37       c456                 1   c457                -1
    x37       c504                -1   c538                -1
    x37       c540                -1   c560                 1
    x37       c567                 1   c614                 1
    x37       c643                -1   c661                -1
    x37       c718                -1   c725                 1
    x37       c742                -1   c758                -1
    x37       c786                -1   c790                 1
    x37       c827                -1   c837                 1
    x38       c9                   1   c27                  1
    x38       c41                 -1   c45                 -1
    x38       c81                 -1   c150                 1
    x38       c213                -1   c294                 1
    x38       c313                 1   c316                 1
    x38       c329                -1   c359                 1
    x38       c392                 1   c405                 1
    x38       c427                 1   c433                 1
    x38       c445                 1   c473                -1
    x38       c494                 1   c513                -1
    x38       c528                -1   c561                 1
    x38       c567                 1   c592                 1
    x38       c611                -1   c630                 1
    x38       c658                -1   c681                 1
    x38       c694                 1   c723                -1
    x38       c727                 1   c729                -1
    x38       c733                 1   c738                -1
    x38       c769                 1   c793                -1
    x38       c795                 1   c828                -1
    x38       c832                 1   c833                -1
    x38       c850                -1
    x39       c10                 -1   c19                  1
    x39       c20                  1   c25                 -1
    x39       c45                  1   c68                 -1
    x39       c105                -1   c157                -1
    x39       c163                 1   c178                -1
    x39       c213                -1   c257                 1
    x39       c271                -1   c339                -1
    x39       c416                 1   c418                -1
    x39       c423                -1   c432                 1
    x39       c438                -1   c447                -1
    x39       c459                 1   c474                 1
    x39       c500                 1   c539                 1
    x39       c545                -1   c566                -1
    x39       c590                -1   c653                 1
    x39       c679                -1   c730                -1
    x39       c735                -1   c767                -1
    x39       c831                -1   c834                -1
    x40       c10                 -1   c29                 -1
    x40       c48                 -1   c66                 -1
    x40       c117                 1   c137                -1
    x40       c155                -1   c156                -1
    x40       c175                 1   c187                 1
    x40       c215                 1   c216                 1
    x40       c261                -1   c274                -1
    x40       c368                 1   c375                 1
    x40       c410                 1   c442                 1
    x40       c506                -1   c555                -1
    x40       c562                 1   c578                -1
    x40       c581                -1   c631                -1
    x40       c645                 1   c649                -1
    x40       c656                 1   c669                 1
    x40       c671                 1   c680                 1
    x40       c681                -1   c692                 1
    x40       c706                 1   c713                 1
    x40       c741                 1   c788                 1
    x40       c790                -1   c797                 1
    x40       c799                -1   c801                 1
    x40       c845                 1   c846                 1
    x41       c10                 -1   c42                 -1
    x41       c115                -1   c132                -1
    x41       c144                 1   c172                 1
    x41       c176                 1   c247                 1
    x41       c248                -1   c295                -1
    x41       c322                 1   c404                -1
    x41       c412                -1   c417                -1
    x41       c485                -1   c511                -1
    x41       c546                -1   c550                -1
    x41       c593                 1   c595                -1
    x41       c605                -1   c630                 1
    x41       c638                 1   c645                -1
    x41       c649                -1   c661                 1
    x41       c662                 1   c699                -1
    x41       c707                -1   c728                -1
    x41       c742                 1   c762                 1
    x41       c767                -1   c776                -1
    x41       c791                 1   c820                -1
    x41       c833                 1
    x42       c11                  1   c15                 -1
    x42       c17                 -1   c27                  1
    x42       c41                  1   c52                  1
    x42       c59                  1   c65                  1
    x42       c68                  1   c120                -1
    x42       c139                -1   c145                -1
    x42       c222                 1   c238                 1
    x42       c255                 1   c280                -1
    x42       c293                -1   c305                -1
    x42       c342                -1   c390                -1
    x42       c399                -1   c412                -1
    x42       c415                -1   c419                -1
    x42       c450                -1   c455                 1
    x42       c466                -1   c469                -1
    x42       c480                -1   c526                -1
    x42       c555                 1   c557                -1
    x42       c606                 1   c618                -1
    x42       c625                 1   c637                 1
    x42       c643                 1   c655                -1
    x42       c688                -1   c711                -1
    x42       c718                -1   c721                 1
    x42       c751                -1   c774                 1
    x42       c784                -1   c819                 1
    x42       c845                 1
    x43       c11                 -1   c21                 -1
    x43       c27                 -1   c44                 -1
    x43       c66                 -1   c79                  1
    x43       c80                  1   c86                  1
    x43       c88                  1   c109                -1
    x43       c152                -1   c157                -1
    x43       c162                -1   c186                 1
    x43       c190                 1   c205                -1
    x43       c219                -1   c231                -1
    x43       c241                 1   c255                 1
    x43       c298                -1   c332                -1
    x43       c338                 1   c350                 1
    x43       c381                 1   c390                -1
    x43       c400                 1   c401                 1
    x43       c406                -1   c426                 1
    x43       c449                -1   c486                -1
    x43       c538                -1   c544                 1
    x43       c559                -1   c592                -1
    x43       c637                 1   c651                -1
    x43       c720                -1   c796                 1
    x43       c798                -1   c803                -1
    x43       c812                 1   c819                -1
    x43       c828                -1   c840                 1
    x44       c11                 -1   c19                 -1
    x44       c32                 -1   c35                 -1
    x44       c39                 -1   c70                 -1
    x44       c75                  1   c86                 -1
    x44       c89                 -1   c100                -1
    x44       c147                -1   c175                 1
    x44       c177                -1   c228                 1
    x44       c239                -1   c246                 1
    x44       c258                 1   c264                 1
    x44       c276                -1   c292                 1
    x44       c309                -1   c331                -1
    x44       c338                -1   c341                 1
    x44       c371                -1   c395                 1
    x44       c405                -1   c439                 1
    x44       c465                 1   c483                 1
    x44       c502                -1   c551                 1
    x44       c558                 1   c569                -1
    x44       c602                -1   c616                -1
    x44       c628                -1   c648                -1
    x44       c658                -1   c664                 1
    x44       c672                -1   c689                -1
    x44       c722                 1   c726                 1
    x44       c727                 1   c741                 1
    x44       c763                -1   c797                 1
    x45       c12                  1   c24                  1
    x45       c46                  1   c52                  1
    x45       c64                  1   c92                 -1
    x45       c113                 1   c133                -1
    x45       c148                -1   c180                 1
    x45       c188                 1   c213                 1
    x45       c232                -1   c250                 1
    x45       c278                -1   c302                 1
    x45       c313                 1   c342                -1
    x45       c346                 1   c348                -1
    x45       c352                 1   c357                -1
    x45       c389                 1   c413                -1
    x45       c415                 1   c447                -1
    x45       c451                 1   c452                -1
    x45       c470                -1   c493                 1
    x45       c515                 1   c516                 1
    x45       c521                 1   c564                -1
    x45       c577                 1   c591                 1
    x45       c621                -1   c622                -1
    x45       c628                 1   c653                -1
    x45       c702                 1   c717                 1
    x45       c741                -1   c823                 1
    x45       c824                -1   c832                -1
    x45       c835                 1   c837                 1
    x45       c838                -1
    x46       c13                  1   c42                  1
    x46       c62                 -1   c103                -1
    x46       c141                -1   c143                 1
    x46       c230                 1   c231                 1
    x46       c239                 1   c246                 1
    x46       c257                 1   c259                 1
    x46       c292                 1   c331                 1
    x46       c364                -1   c398                 1
    x46       c428                 1   c477                -1
    x46       c484                -1   c487                -1
    x46       c497                -1   c507                 1
    x46       c575                 1   c608                -1
    x46       c622                 1   c629                -1
    x46       c667                 1   c673                -1
    x46       c686                -1   c694                 1
    x46       c708                -1   c739                 1
    x46       c755                 1   c778                 1
    x46       c798                -1   c801                -1
    x46       c850                 1
    x47       c13                 -1   c14                  1
    x47       c52                  1   c71                  1
    x47       c130                -1   c139                 1
    x47       c143                 1   c149                 1
    x47       c175                 1   c229                 1
    x47       c257                -1   c260                -1
    x47       c293                 1   c296                 1
    x47       c327                -1   c347                -1
    x47       c393                 1   c410                -1
    x47       c451                 1   c465                -1
    x47       c478                 1   c546                -1
    x47       c562                 1   c585                 1
    x47       c619                -1   c621                 1
    x47       c638                -1   c655                 1
    x47       c679                -1   c681                 1
    x47       c688                 1   c718                -1
    x47       c770                -1   c781                -1
    x47       c787                -1   c804                -1
    x47       c827                -1   c840                 1
    x47       c841                 1   c847                 1
    x47       c849                 1
    x48       c13                  1   c64                 -1
    x48       c67                 -1   c74                  1
    x48       c102                -1   c153                 1
    x48       c170                 1   c191                 1
    x48       c256                -1   c260                -1
    x48       c270                 1   c286                 1
    x48       c312                -1   c315                -1
    x48       c325                 1   c339                 1
    x48       c397                 1   c450                -1
    x48       c458                 1   c470                 1
    x48       c478                -1   c482                -1
    x48       c529                 1   c555                -1
    x48       c565                 1   c581                 1
    x48       c586                -1   c588                -1
    x48       c598                 1   c612                 1
    x48       c623                 1   c630                 1
    x48       c636                 1   c639                 1
    x48       c691                -1   c709                -1
    x48       c715                -1   c791                 1
    x48       c807                 1   c826                 1
    x48       c850                -1
    x49       c13                 -1   c27                 -1
    x49       c39                 -1   c49                  1
    x49       c64                  1   c106                -1
    x49       c143                -1   c149                 1
    x49       c160                 1   c192                 1
    x49       c201                -1   c211                 1
    x49       c212                 1   c217                -1
    x49       c237                 1   c259                -1
    x49       c296                -1   c347                -1
    x49       c353                 1   c368                -1
    x49       c402                -1   c447                 1
    x49       c461                -1   c530                -1
    x49       c606                 1   c608                -1
    x49       c613                -1   c622                 1
    x49       c628                -1   c637                -1
    x49       c649                 1   c664                 1
    x49       c690                 1   c729                 1
    x49       c735                -1   c756                -1
    x49       c780                -1   c844                 1
    x50       c13                 -1   c36                 -1
    x50       c81                 -1   c91                 -1
    x50       c134                -1   c167                -1
    x50       c171                -1   c192                 1
    x50       c213                 1   c278                 1
    x50       c296                 1   c300                 1
    x50       c303                 1   c305                 1
    x50       c341                 1   c352                 1
    x50       c376                 1   c388                 1
    x50       c409                -1   c468                -1
    x50       c484                -1   c512                 1
    x50       c525                 1   c531                -1
    x50       c595                -1   c612                 1
    x50       c617                 1   c620                -1
    x50       c641                -1   c651                -1
    x50       c657                -1   c698                 1
    x50       c708                -1   c742                 1
    x50       c752                -1   c755                 1
    x50       c769                 1   c775                -1
    x50       c792                 1   c841                 1
    x50       c843                 1   c846                -1
    x51       c13                  1   c30                 -1
    x51       c71                  1   c85                 -1
    x51       c98                  1   c166                -1
    x51       c183                 1   c207                 1
    x51       c240                -1   c242                 1
    x51       c259                -1   c276                 1
    x51       c301                -1   c303                 1
    x51       c309                 1   c338                -1
    x51       c391                -1   c402                -1
    x51       c408                -1   c425                -1
    x51       c447                -1   c460                 1
    x51       c461                 1   c467                 1
    x51       c469                 1   c490                -1
    x51       c532                -1   c538                -1
    x51       c543                -1   c565                 1
    x51       c569                 1   c584                -1
    x51       c598                -1   c610                -1
    x51       c621                 1   c635                 1
    x51       c678                -1   c713                -1
    x51       c719                 1   c731                 1
    x51       c761                 1   c770                -1
    x51       c780                 1   c781                 1
    x51       c786                -1   c806                 1
    x51       c830                -1
    x52       c13                 -1   c38                  1
    x52       c50                 -1   c54                 -1
    x52       c59                  1   c67                 -1
    x52       c73                 -1   c83                 -1
    x52       c86                  1   c99                 -1
    x52       c118                -1   c120                 1
    x52       c122                 1   c141                 1
    x52       c173                -1   c199                -1
    x52       c227                -1   c231                 1
    x52       c237                 1   c243                 1
    x52       c250                -1   c256                 1
    x52       c283                -1   c290                -1
    x52       c299                -1   c337                -1
    x52       c351                 1   c445                -1
    x52       c479                 1   c483                -1
    x52       c495                 1   c504                 1
    x52       c521                -1   c595                -1
    x52       c719                -1   c758                 1
    x52       c762                 1   c784                -1
    x52       c806                 1   c815                 1
    x53       c14                  1   c16                  1
    x53       c36                  1   c65                 -1
    x53       c74                  1   c95                 -1
    x53       c149                -1   c173                -1
    x53       c177                -1   c205                -1
    x53       c206                 1   c244                 1
    x53       c262                 1   c319                -1
    x53       c328                 1   c332                 1
    x53       c338                 1   c365                 1
    x53       c418                 1   c447                -1
    x53       c450                -1   c483                 1
    x53       c486                 1   c518                -1
    x53       c538                -1   c583                 1
    x53       c600                -1   c641                 1
    x53       c655                -1   c668                 1
    x53       c736                -1   c752                 1
    x53       c775                 1   c809                -1
    x53       c811                 1   c829                -1
    x53       c846                 1
    x54       c14                 -1   c19                  1
    x54       c25                  1   c30                  1
    x54       c36                  1   c74                  1
    x54       c89                  1   c139                -1
    x54       c141                -1   c142                 1
    x54       c163                -1   c164                 1
    x54       c191                 1   c228                 1
    x54       c267                -1   c281                 1
    x54       c308                 1   c313                 1
    x54       c340                 1   c353                 1
    x54       c366                -1   c371                 1
    x54       c372                 1   c412                 1
    x54       c419                -1   c421                -1
    x54       c476                -1   c489                -1
    x54       c490                 1   c513                 1
    x54       c524                 1   c533                -1
    x54       c545                 1   c548                 1
    x54       c558                -1   c576                 1
    x54       c598                 1   c639                -1
    x54       c654                -1   c664                 1
    x54       c688                 1   c689                -1
    x54       c699                 1   c731                 1
    x54       c761                -1   c788                -1
    x54       c813                -1   c820                -1
    x54       c824                -1   c826                 1
    x54       c836                -1   c842                 1
    x55       c14                  1   c24                 -1
    x55       c58                  1   c84                  1
    x55       c102                 1   c121                -1
    x55       c170                 1   c177                 1
    x55       c190                -1   c223                -1
    x55       c237                -1   c248                -1
    x55       c268                -1   c278                -1
    x55       c284                 1   c292                -1
    x55       c309                -1   c341                 1
    x55       c345                 1   c346                 1
    x55       c360                 1   c383                -1
    x55       c417                 1   c500                 1
    x55       c532                -1   c537                 1
    x55       c540                -1   c550                -1
    x55       c619                -1   c644                 1
    x55       c652                -1   c699                -1
    x55       c721                 1   c753                 1
    x55       c754                 1   c761                 1
    x55       c775                -1   c780                 1
    x55       c786                 1   c791                 1
    x55       c797                 1   c836                 1
    x55       c850                 1
    x56       c15                  1   c48                 -1
    x56       c50                  1   c68                 -1
    x56       c85                  1   c109                -1
    x56       c111                 1   c118                 1
    x56       c149                -1   c202                -1
    x56       c213                -1   c219                -1
    x56       c236                -1   c257                -1
    x56       c270                 1   c271                 1
    x56       c277                 1   c279                 1
    x56       c301                -1   c341                -1
    x56       c347                -1   c352                -1
    x56       c375                 1   c379                 1
    x56       c394                -1   c408                -1
    x56       c420                -1   c431                 1
    x56       c445                 1   c488                -1
    x56       c523                -1   c529                 1
    x56       c541                 1   c571                 1
    x56       c580                -1   c590                 1
    x56       c591                 1   c596                -1
    x56       c616                 1   c639                -1
    x56       c676                -1   c728                -1
    x56       c734                 1   c749                -1
    x56       c782                -1   c828                 1
    x56       c842                -1
    x57       c16                  1   c40                  1
    x57       c47                  1   c82                 -1
    x57       c99                  1   c137                 1
    x57       c144                 1   c171                 1
    x57       c245                 1   c289                 1
    x57       c304                -1   c329                 1
    x57       c357                -1   c362                -1
    x57       c398                -1   c429                -1
    x57       c441                 1   c479                 1
    x57       c501                -1   c504                -1
    x57       c506                -1   c508                 1
    x57       c528                 1   c549                -1
    x57       c551                 1   c569                 1
    x57       c579                -1   c599                -1
    x57       c619                -1   c636                -1
    x57       c687                 1   c706                -1
    x57       c724                -1   c726                -1
    x57       c745                 1   c755                 1
    x57       c783                 1   c784                 1
    x57       c831                -1   c844                -1
    x58       c16                  1   c69                 -1
    x58       c77                  1   c89                  1
    x58       c97                 -1   c101                -1
    x58       c149                 1   c174                -1
    x58       c186                 1   c202                 1
    x58       c207                -1   c209                -1
    x58       c219                 1   c233                 1
    x58       c244                 1   c250                 1
    x58       c256                 1   c259                 1
    x58       c328                -1   c334                -1
    x58       c411                 1   c427                 1
    x58       c445                 1   c470                -1
    x58       c483                -1   c494                -1
    x58       c533                -1   c580                -1
    x58       c589                -1   c602                -1
    x58       c605                -1   c609                -1
    x58       c640                -1   c645                 1
    x58       c656                -1   c659                -1
    x58       c670                -1   c716                -1
    x58       c745                 1   c747                -1
    x58       c796                 1   c808                -1
    x58       c816                 1   c828                 1
    x58       c834                 1   c846                -1
    x59       c17                  1   c19                 -1
    x59       c38                  1   c44                  1
    x59       c70                  1   c122                -1
    x59       c138                 1   c156                -1
    x59       c167                 1   c177                -1
    x59       c214                -1   c235                 1
    x59       c247                 1   c249                 1
    x59       c265                -1   c311                 1
    x59       c317                -1   c318                 1
    x59       c323                -1   c342                 1
    x59       c374                -1   c403                -1
    x59       c405                -1   c426                -1
    x59       c439                 1   c443                 1
    x59       c495                -1   c508                -1
    x59       c519                 1   c529                 1
    x59       c532                 1   c540                -1
    x59       c560                 1   c584                -1
    x59       c607                -1   c652                -1
    x59       c662                -1   c704                -1
    x59       c738                -1   c742                -1
    x59       c761                 1   c782                 1
    x59       c849                 1
    x60       c18                  1   c38                 -1
    x60       c41                 -1   c90                  1
    x60       c95                  1   c173                -1
    x60       c176                -1   c180                 1
    x60       c185                 1   c216                 1
    x60       c279                -1   c294                -1
    x60       c300                -1   c346                 1
    x60       c418                 1   c450                -1
    x60       c455                 1   c477                 1
    x60       c490                -1   c552                -1
    x60       c562                -1   c565                -1
    x60       c568                 1   c577                 1
    x60       c582                -1   c602                -1
    x60       c603                 1   c608                 1
    x60       c639                 1   c646                -1
    x60       c663                 1   c677                 1
    x60       c702                -1   c712                 1
    x60       c724                -1   c729                -1
    x60       c735                 1   c757                -1
    x60       c797                 1   c814                -1
    x60       c825                -1   c835                -1
    x61       c18                 -1   c48                 -1
    x61       c61                  1   c99                  1
    x61       c121                -1   c125                -1
    x61       c127                -1   c129                 1
    x61       c149                 1   c169                -1
    x61       c171                 1   c191                 1
    x61       c201                -1   c221                -1
    x61       c240                -1   c257                -1
    x61       c308                 1   c326                -1
    x61       c344                -1   c346                -1
    x61       c365                 1   c376                 1
    x61       c404                 1   c405                 1
    x61       c451                -1   c464                -1
    x61       c559                 1   c565                 1
    x61       c600                 1   c632                 1
    x61       c696                -1   c745                -1
    x61       c752                 1   c768                -1
    x61       c771                -1   c822                -1
    x61       c836                 1   c840                -1
    x61       c847                 1
    x62       c18                  1   c47                  1
    x62       c97                 -1   c104                -1
    x62       c106                -1   c117                -1
    x62       c128                 1   c197                 1
    x62       c230                -1   c243                 1
    x62       c250                -1   c288                 1
    x62       c294                -1   c307                -1
    x62       c314                 1   c328                -1
    x62       c359                 1   c376                 1
    x62       c399                 1   c419                -1
    x62       c422                -1   c471                 1
    x62       c476                 1   c554                -1
    x62       c557                -1   c561                 1
    x62       c564                 1   c595                 1
    x62       c659                -1   c674                -1
    x62       c679                -1   c727                 1
    x62       c798                 1   c831                -1
    x62       c836                 1
    x63       c19                 -1   c82                  1
    x63       c108                -1   c159                -1
    x63       c164                -1   c198                -1
    x63       c260                -1   c263                -1
    x63       c287                -1   c314                -1
    x63       c320                -1   c322                 1
    x63       c351                 1   c370                -1
    x63       c414                -1   c418                -1
    x63       c471                -1   c481                 1
    x63       c490                -1   c514                 1
    x63       c570                -1   c573                -1
    x63       c588                -1   c622                 1
    x63       c630                 1   c668                 1
    x63       c671                -1   c689                -1
    x63       c693                 1   c707                 1
    x63       c709                -1   c710                 1
    x63       c712                -1   c760                 1
    x63       c773                -1   c798                 1
    x63       c811                -1   c815                -1
    x63       c820                 1   c828                -1
    x63       c834                -1   c844                -1
    x63       c847                 1
    x64       c21                 -1   c24                  1
    x64       c38                  1   c47                  1
    x64       c55                  1   c59                 -1
    x64       c60                 -1   c77                 -1
    x64       c113                 1   c133                -1
    x64       c195                 1   c211                 1
    x64       c220                 1   c285                -1
    x64       c292                -1   c322                -1
    x64       c338                 1   c347                -1
    x64       c387                -1   c396                 1
    x64       c401                 1   c420                 1
    x64       c431                -1   c475                -1
    x64       c483                -1   c495                -1
    x64       c503                 1   c525                 1
    x64       c602                 1   c613                 1
    x64       c650                -1   c655                -1
    x64       c671                 1   c699                 1
    x64       c768                 1   c787                 1
    x64       c801                -1   c805                -1
    x64       c842                -1
    x65       c21                  1   c87                  1
    x65       c105                 1   c108                 1
    x65       c111                 1   c113                 1
    x65       c152                 1   c162                 1
    x65       c187                 1   c199                 1
    x65       c220                -1   c278                -1
    x65       c294                -1   c321                 1
    x65       c334                 1   c340                -1
    x65       c405                -1   c422                 1
    x65       c427                 1   c430                -1
    x65       c451                -1   c461                -1
    x65       c467                -1   c508                 1
    x65       c518                -1   c552                 1
    x65       c562                -1   c565                 1
    x65       c579                 1   c585                -1
    x65       c602                 1   c650                 1
    x65       c652                 1   c655                -1
    x65       c668                 1   c689                 1
    x65       c703                -1   c739                 1
    x65       c749                -1   c782                -1
    x65       c785                 1   c799                 1
    x65       c809                 1   c817                 1
    x65       c821                -1   c822                -1
    x65       c839                -1
    x66       c21                 -1   c103                 1
    x66       c124                 1   c127                 1
    x66       c140                -1   c169                 1
    x66       c203                 1   c216                 1
    x66       c238                 1   c244                 1
    x66       c255                 1   c283                -1
    x66       c305                 1   c322                -1
    x66       c337                -1   c370                 1
    x66       c377                 1   c402                 1
    x66       c421                -1   c440                 1
    x66       c468                -1   c491                 1
    x66       c504                 1   c533                -1
    x66       c537                 1   c539                -1
    x66       c543                 1   c548                -1
    x66       c579                 1   c603                -1
    x66       c605                 1   c637                -1
    x66       c641                 1   c642                -1
    x66       c660                -1   c683                 1
    x66       c705                 1   c706                 1
    x66       c711                 1   c754                -1
    x66       c767                 1   c781                 1
    x66       c811                -1   c812                -1
    x66       c819                 1   c844                -1
    x67       c22                  1   c23                  1
    x67       c34                  1   c42                  1
    x67       c44                 -1   c70                 -1
    x67       c72                  1   c84                 -1
    x67       c104                 1   c106                -1
    x67       c118                 1   c150                -1
    x67       c170                -1   c171                -1
    x67       c186                -1   c197                 1
    x67       c219                 1   c246                -1
    x67       c266                 1   c278                 1
    x67       c280                 1   c281                -1
    x67       c282                -1   c304                 1
    x67       c319                -1   c343                 1
    x67       c344                 1   c346                 1
    x67       c349                 1   c355                 1
    x67       c373                -1   c385                 1
    x67       c414                -1   c423                 1
    x67       c429                -1   c451                -1
    x67       c481                -1   c514                 1
    x67       c520                -1   c541                -1
    x67       c547                -1   c548                 1
    x67       c549                -1   c584                 1
    x67       c613                 1   c633                -1
    x67       c674                -1   c711                -1
    x67       c713                 1   c799                 1
    x67       c800                 1   c809                 1
    x67       c817                 1   c828                 1
    x67       c830                 1
    x68       c22                  1   c24                 -1
    x68       c34                 -1   c59                  1
    x68       c67                  1   c74                 -1
    x68       c78                 -1   c90                  1
    x68       c91                  1   c129                -1
    x68       c137                -1   c157                -1
    x68       c171                 1   c193                 1
    x68       c198                -1   c207                -1
    x68       c222                 1   c249                -1
    x68       c262                 1   c294                 1
    x68       c309                 1   c361                 1
    x68       c383                -1   c433                 1
    x68       c458                 1   c464                -1
    x68       c465                 1   c470                -1
    x68       c472                 1   c493                -1
    x68       c516                 1   c539                 1
    x68       c558                 1   c584                 1
    x68       c635                -1   c638                -1
    x68       c645                 1   c673                -1
    x68       c723                 1   c741                 1
    x68       c760                 1   c827                -1
    x68       c831                -1   c841                 1
    x69       c22                 -1   c24                 -1
    x69       c45                 -1   c58                  1
    x69       c62                  1   c114                -1
    x69       c128                -1   c139                 1
    x69       c149                 1   c152                 1
    x69       c159                -1   c179                 1
    x69       c205                -1   c228                -1
    x69       c272                -1   c282                -1
    x69       c323                -1   c357                -1
    x69       c361                -1   c381                 1
    x69       c402                 1   c468                 1
    x69       c486                 1   c489                 1
    x69       c492                 1   c494                 1
    x69       c532                 1   c543                 1
    x69       c566                 1   c578                 1
    x69       c599                -1   c658                -1
    x69       c674                -1   c702                 1
    x69       c715                 1   c721                -1
    x69       c785                -1   c802                 1
    x69       c807                 1   c810                -1
    x69       c832                -1   c842                -1
    x69       c848                -1
    x70       c22                 -1   c43                  1
    x70       c56                  1   c58                  1
    x70       c74                 -1   c121                 1
    x70       c128                -1   c129                 1
    x70       c134                -1   c153                 1
    x70       c185                -1   c214                -1
    x70       c216                -1   c237                -1
    x70       c249                 1   c253                 1
    x70       c306                -1   c317                -1
    x70       c328                 1   c338                 1
    x70       c341                 1   c349                -1
    x70       c369                 1   c394                -1
    x70       c417                -1   c462                -1
    x70       c472                -1   c514                -1
    x70       c548                -1   c552                -1
    x70       c571                 1   c592                 1
    x70       c658                 1   c676                 1
    x70       c679                 1   c682                 1
    x70       c684                 1   c722                 1
    x70       c733                 1   c756                 1
    x70       c768                 1   c789                -1
    x70       c849                -1
    x71       c23                  1   c24                  1
    x71       c70                 -1   c83                 -1
    x71       c178                 1   c186                 1
    x71       c221                 1   c252                 1
    x71       c315                -1   c364                -1
    x71       c372                 1   c388                -1
    x71       c391                -1   c441                -1
    x71       c455                 1   c459                -1
    x71       c466                 1   c479                 1
    x71       c481                 1   c490                 1
    x71       c491                -1   c502                 1
    x71       c516                 1   c523                 1
    x71       c551                 1   c598                 1
    x71       c600                -1   c607                 1
    x71       c609                -1   c611                 1
    x71       c654                 1   c655                 1
    x71       c668                -1   c671                 1
    x71       c727                -1   c769                 1
    x71       c772                -1   c780                 1
    x71       c800                -1   c825                 1
    x72       c23                 -1   c31                 -1
    x72       c36                 -1   c104                -1
    x72       c131                -1   c165                -1
    x72       c169                -1   c214                 1
    x72       c216                -1   c226                -1
    x72       c250                 1   c258                 1
    x72       c265                -1   c269                -1
    x72       c281                 1   c282                 1
    x72       c318                -1   c326                -1
    x72       c347                -1   c361                 1
    x72       c382                 1   c387                -1
    x72       c396                -1   c411                 1
    x72       c439                -1   c452                 1
    x72       c484                 1   c499                 1
    x72       c552                 1   c573                -1
    x72       c623                 1   c648                 1
    x72       c654                -1   c655                 1
    x72       c660                -1   c662                 1
    x72       c683                -1   c706                 1
    x72       c729                 1   c748                 1
    x72       c774                 1   c826                -1
    x72       c829                -1   c836                 1
    x73       c24                 -1   c41                  1
    x73       c46                  1   c48                 -1
    x73       c70                 -1   c80                 -1
    x73       c86                 -1   c128                 1
    x73       c138                -1   c171                 1
    x73       c182                -1   c186                 1
    x73       c200                 1   c206                -1
    x73       c223                 1   c270                 1
    x73       c272                 1   c275                -1
    x73       c288                 1   c309                 1
    x73       c322                -1   c358                 1
    x73       c368                -1   c402                -1
    x73       c405                 1   c419                 1
    x73       c429                 1   c436                 1
    x73       c440                -1   c441                -1
    x73       c458                -1   c494                 1
    x73       c513                -1   c574                 1
    x73       c590                 1   c599                 1
    x73       c665                -1   c672                -1
    x73       c703                -1   c719                 1
    x73       c728                -1   c767                -1
    x73       c776                 1   c781                 1
    x73       c800                 1   c811                -1
    x74       c24                  1   c88                 -1
    x74       c103                -1   c108                -1
    x74       c156                 1   c229                 1
    x74       c260                -1   c265                 1
    x74       c287                 1   c301                -1
    x74       c361                -1   c372                -1
    x74       c375                -1   c378                 1
    x74       c387                 1   c392                -1
    x74       c412                -1   c413                 1
    x74       c418                 1   c449                 1
    x74       c456                -1   c473                 1
    x74       c487                 1   c512                -1
    x74       c522                 1   c534                -1
    x74       c539                -1   c545                 1
    x74       c567                -1   c607                 1
    x74       c623                -1   c634                -1
    x74       c644                -1   c672                 1
    x74       c686                -1   c699                -1
    x74       c716                -1   c724                 1
    x74       c746                -1   c766                 1
    x74       c785                -1
    x75       c24                 -1   c149                -1
    x75       c189                 1   c193                 1
    x75       c215                -1   c237                 1
    x75       c245                 1   c316                -1
    x75       c322                -1   c328                 1
    x75       c389                -1   c397                 1
    x75       c429                 1   c432                 1
    x75       c440                -1   c485                 1
    x75       c509                 1   c517                 1
    x75       c524                 1   c550                 1
    x75       c577                -1   c593                 1
    x75       c627                -1   c633                 1
    x75       c714                 1   c747                 1
    x75       c759                -1   c763                -1
    x75       c837                 1   c844                 1
    x76       c25                 -1   c29                  1
    x76       c65                 -1   c75                  1
    x76       c96                 -1   c152                -1
    x76       c169                 1   c174                -1
    x76       c186                -1   c191                 1
    x76       c208                 1   c232                 1
    x76       c239                 1   c273                -1
    x76       c290                 1   c326                 1
    x76       c333                 1   c361                 1
    x76       c434                 1   c479                 1
    x76       c493                -1   c520                 1
    x76       c548                -1   c553                -1
    x76       c588                -1   c619                -1
    x76       c631                 1   c669                 1
    x76       c691                -1   c694                -1
    x76       c696                -1   c698                 1
    x76       c718                 1   c739                -1
    x76       c741                 1   c759                 1
    x76       c769                -1   c789                -1
    x76       c809                -1   c827                -1
    x77       c27                 -1   c51                 -1
    x77       c58                 -1   c62                 -1
    x77       c64                  1   c74                 -1
    x77       c80                  1   c106                 1
    x77       c114                -1   c123                -1
    x77       c125                -1   c130                -1
    x77       c138                -1   c173                -1
    x77       c194                -1   c204                -1
    x77       c294                 1   c309                -1
    x77       c333                 1   c363                -1
    x77       c364                -1   c383                 1
    x77       c435                 1   c444                 1
    x77       c477                 1   c532                 1
    x77       c557                -1   c565                 1
    x77       c575                 1   c589                -1
    x77       c604                 1   c620                -1
    x77       c638                 1   c648                -1
    x77       c653                -1   c662                -1
    x77       c703                 1   c716                 1
    x77       c717                -1   c733                 1
    x77       c749                -1   c753                 1
    x77       c754                 1   c765                -1
    x77       c779                -1   c784                 1
    x77       c809                 1   c828                 1
    x77       c836                -1
    x78       c27                  1   c29                 -1
    x78       c36                  1   c38                 -1
    x78       c40                  1   c83                  1
    x78       c84                  1   c97                 -1
    x78       c100                 1   c156                -1
    x78       c200                 1   c203                -1
    x78       c211                 1   c231                -1
    x78       c254                 1   c304                -1
    x78       c310                 1   c314                 1
    x78       c335                -1   c354                 1
    x78       c355                 1   c365                -1
    x78       c384                 1   c394                -1
    x78       c490                 1   c519                 1
    x78       c577                 1   c597                -1
    x78       c613                -1   c626                 1
    x78       c638                -1   c648                 1
    x78       c654                 1   c660                 1
    x78       c661                 1   c694                 1
    x78       c706                -1   c753                -1
    x78       c796                 1   c815                -1
    x78       c827                 1
    x79       c29                  1   c61                  1
    x79       c126                -1   c174                -1
    x79       c182                 1   c199                -1
    x79       c202                -1   c251                -1
    x79       c265                 1   c269                -1
    x79       c276                 1   c289                 1
    x79       c291                 1   c301                 1
    x79       c302                -1   c311                 1
    x79       c325                 1   c332                 1
    x79       c360                 1   c408                 1
    x79       c410                -1   c417                 1
    x79       c419                -1   c421                 1
    x79       c464                 1   c465                 1
    x79       c478                -1   c481                 1
    x79       c537                -1   c579                 1
    x79       c582                -1   c590                 1
    x79       c610                -1   c634                 1
    x79       c683                -1   c690                 1
    x79       c695                 1   c716                -1
    x79       c735                 1   c736                 1
    x79       c746                -1   c764                 1
    x79       c774                -1
    x80       c30                  1   c46                  1
    x80       c64                  1   c89                 -1
    x80       c102                -1   c113                -1
    x80       c153                -1   c201                -1
    x80       c210                -1   c223                -1
    x80       c226                -1   c230                -1
    x80       c260                -1   c265                 1
    x80       c276                -1   c279                -1
    x80       c290                -1   c335                -1
    x80       c364                 1   c366                -1
    x80       c416                 1   c428                -1
    x80       c435                 1   c447                 1
    x80       c453                 1   c465                -1
    x80       c498                -1   c521                -1
    x80       c528                -1   c531                 1
    x80       c561                -1   c584                 1
    x80       c594                -1   c628                 1
    x80       c654                 1   c672                 1
    x80       c691                -1   c740                 1
    x80       c747                 1   c758                -1
    x80       c791                -1   c805                -1
    x80       c818                -1   c838                -1
    x80       c848                -1
    x81       c31                  1   c38                 -1
    x81       c40                 -1   c95                 -1
    x81       c108                -1   c109                 1
    x81       c133                 1   c144                 1
    x81       c153                -1   c164                 1
    x81       c167                 1   c177                -1
    x81       c197                 1   c219                 1
    x81       c259                -1   c274                -1
    x81       c284                 1   c308                 1
    x81       c309                -1   c318                 1
    x81       c350                 1   c381                -1
    x81       c408                -1   c439                -1
    x81       c443                -1   c445                 1
    x81       c455                -1   c461                 1
    x81       c488                 1   c495                -1
    x81       c503                -1   c505                -1
    x81       c510                -1   c518                -1
    x81       c554                -1   c573                -1
    x81       c583                -1   c674                 1
    x81       c689                -1   c714                 1
    x81       c744                -1   c745                -1
    x81       c763                 1   c816                 1
    x81       c825                 1
    x82       c32                  1   c43                  1
    x82       c80                 -1   c85                 -1
    x82       c130                 1   c200                 1
    x82       c219                 1   c233                -1
    x82       c237                -1   c272                -1
    x82       c339                 1   c402                -1
    x82       c484                 1   c504                 1
    x82       c507                 1   c520                -1
    x82       c550                 1   c582                 1
    x82       c595                 1   c617                 1
    x82       c623                 1   c635                 1
    x82       c663                -1   c684                 1
    x82       c703                -1   c718                -1
    x82       c751                 1   c757                 1
    x82       c782                 1   c801                -1
    x82       c821                 1   c849                -1
    x83       c33                 -1   c37                 -1
    x83       c90                 -1   c100                 1
    x83       c109                -1   c134                 1
    x83       c191                -1   c194                -1
    x83       c209                -1   c242                 1
    x83       c250                 1   c288                 1
    x83       c291                -1   c309                -1
    x83       c312                 1   c326                 1
    x83       c328                -1   c329                 1
    x83       c331                -1   c380                 1
    x83       c393                -1   c418                 1
    x83       c431                -1   c434                -1
    x83       c439                 1   c447                -1
    x83       c453                -1   c463                -1
    x83       c466                 1   c479                -1
    x83       c498                -1   c500                 1
    x83       c502                 1   c520                 1
    x83       c553                -1   c577                -1
    x83       c605                -1   c609                 1
    x83       c615                 1   c622                 1
    x83       c629                -1   c635                 1
    x83       c662                -1   c669                -1
    x83       c678                -1   c717                -1
    x83       c731                 1   c825                -1
    x84       c35                  1   c53                 -1
    x84       c65                  1   c97                 -1
    x84       c101                 1   c107                -1
    x84       c116                -1   c121                 1
    x84       c134                 1   c157                -1
    x84       c167                -1   c174                 1
    x84       c185                 1   c218                 1
    x84       c221                 1   c248                -1
    x84       c280                 1   c292                -1
    x84       c295                 1   c301                -1
    x84       c341                 1   c358                 1
    x84       c389                -1   c422                -1
    x84       c495                -1   c511                -1
    x84       c523                 1   c552                 1
    x84       c556                 1   c626                 1
    x84       c627                -1   c674                -1
    x84       c702                 1   c783                -1
    x84       c791                -1   c796                -1
    x85       c35                  1   c37                 -1
    x85       c42                 -1   c50                  1
    x85       c57                 -1   c66                 -1
    x85       c78                  1   c93                  1
    x85       c119                 1   c158                 1
    x85       c164                -1   c187                -1
    x85       c211                -1   c273                 1
    x85       c300                -1   c349                -1
    x85       c354                -1   c387                -1
    x85       c450                -1   c453                -1
    x85       c477                -1   c505                -1
    x85       c511                -1   c513                 1
    x85       c542                 1   c561                -1
    x85       c604                -1   c608                -1
    x85       c661                -1   c671                 1
    x85       c680                -1   c704                 1
    x85       c760                -1   c763                -1
    x85       c778                -1   c812                 1
    x85       c821                 1
    x86       c36                  1   c76                 -1
    x86       c90                  1   c117                 1
    x86       c124                 1   c151                 1
    x86       c163                 1   c176                -1
    x86       c181                 1   c182                 1
    x86       c223                 1   c230                -1
    x86       c232                -1   c286                -1
    x86       c300                -1   c301                 1
    x86       c322                 1   c333                 1
    x86       c342                -1   c354                 1
    x86       c357                 1   c367                -1
    x86       c386                 1   c408                 1
    x86       c449                -1   c464                -1
    x86       c474                 1   c498                 1
    x86       c499                -1   c509                 1
    x86       c541                 1   c571                -1
    x86       c598                -1   c629                -1
    x86       c633                -1   c635                 1
    x86       c645                -1   c651                 1
    x86       c678                 1   c685                -1
    x86       c693                -1   c695                -1
    x86       c700                -1   c708                -1
    x86       c744                -1   c763                -1
    x86       c773                -1
    x87       c36                  1   c52                 -1
    x87       c63                 -1   c73                 -1
    x87       c101                 1   c115                -1
    x87       c129                -1   c146                -1
    x87       c154                 1   c175                -1
    x87       c197                 1   c216                -1
    x87       c296                 1   c313                -1
    x87       c318                -1   c368                -1
    x87       c395                 1   c397                 1
    x87       c417                 1   c446                -1
    x87       c455                 1   c476                -1
    x87       c529                -1   c554                -1
    x87       c558                -1   c584                -1
    x87       c585                 1   c623                 1
    x87       c642                 1   c700                -1
    x87       c709                 1   c713                 1
    x87       c719                 1   c746                 1
    x87       c798                 1   c828                -1
    x87       c831                -1
    x88       c36                  1   c47                 -1
    x88       c55                  1   c67                  1
    x88       c73                  1   c85                 -1
    x88       c101                 1   c118                -1
    x88       c142                -1   c149                -1
    x88       c152                 1   c181                -1
    x88       c206                 1   c216                -1
    x88       c249                 1   c275                 1
    x88       c293                 1   c311                -1
    x88       c360                 1   c367                 1
    x88       c379                -1   c412                -1
    x88       c426                -1   c438                -1
    x88       c458                -1   c468                -1
    x88       c474                 1   c482                -1
    x88       c499                -1   c532                 1
    x88       c536                 1   c537                 1
    x88       c551                 1   c573                -1
    x88       c607                 1   c690                 1
    x88       c722                -1   c727                 1
    x88       c730                -1   c740                -1
    x88       c809                -1   c835                 1
    x88       c843                -1
    x89       c37                  1   c66                 -1
    x89       c69                 -1   c102                 1
    x89       c105                 1   c138                -1
    x89       c157                -1   c204                 1
    x89       c221                -1   c261                 1
    x89       c275                -1   c288                 1
    x89       c355                -1   c372                 1
    x89       c395                 1   c429                -1
    x89       c431                 1   c448                -1
    x89       c465                 1   c489                -1
    x89       c491                 1   c498                 1
    x89       c528                -1   c580                -1
    x89       c591                -1   c597                -1
    x89       c614                -1   c636                -1
    x89       c649                 1   c650                 1
    x89       c656                 1   c658                 1
    x89       c679                -1   c721                -1
    x89       c727                -1   c732                -1
    x89       c754                 1   c758                 1
    x89       c773                -1   c787                -1
    x89       c799                -1   c810                 1
    x89       c825                 1
    x90       c37                  1   c69                 -1
    x90       c74                  1   c96                  1
    x90       c109                -1   c171                -1
    x90       c182                -1   c186                -1
    x90       c189                 1   c198                 1
    x90       c203                -1   c223                -1
    x90       c224                 1   c229                 1
    x90       c259                 1   c266                -1
    x90       c283                 1   c297                 1
    x90       c321                -1   c331                 1
    x90       c343                -1   c348                -1
    x90       c354                 1   c377                -1
    x90       c417                 1   c433                -1
    x90       c444                -1   c454                -1
    x90       c482                 1   c496                -1
    x90       c509                -1   c526                -1
    x90       c534                 1   c556                -1
    x90       c576                 1   c595                -1
    x90       c676                 1   c694                -1
    x90       c699                -1   c749                -1
    x90       c775                 1   c777                 1
    x90       c797                 1   c827                -1
    x90       c836                 1
    x91       c38                  1   c39                  1
    x91       c47                  1   c55                  1
    x91       c66                  1   c68                  1
    x91       c101                 1   c142                 1
    x91       c174                -1   c209                 1
    x91       c287                -1   c294                -1
    x91       c297                -1   c307                -1
    x91       c316                 1   c385                 1
    x91       c418                -1   c432                 1
    x91       c439                -1   c477                 1
    x91       c483                -1   c496                -1
    x91       c504                 1   c518                -1
    x91       c549                 1   c565                 1
    x91       c588                 1   c608                -1
    x91       c611                -1   c660                 1
    x91       c665                 1   c743                -1
    x91       c746                -1   c750                 1
    x91       c753                 1   c784                 1
    x91       c849                -1
    x92       c43                  1   c72                 -1
    x92       c90                 -1   c148                -1
    x92       c155                 1   c171                -1
    x92       c189                -1   c217                -1
    x92       c221                 1   c256                -1
    x92       c266                 1   c287                -1
    x92       c341                -1   c359                 1
    x92       c364                -1   c375                -1
    x92       c380                 1   c397                 1
    x92       c421                 1   c429                 1
    x92       c463                -1   c480                 1
    x92       c517                 1   c524                 1
    x92       c552                 1   c624                 1
    x92       c669                 1   c683                -1
    x92       c710                 1   c738                -1
    x92       c743                -1   c778                -1
    x92       c809                -1   c822                 1
    x93       c47                 -1   c73                  1
    x93       c81                 -1   c129                -1
    x93       c151                 1   c184                 1
    x93       c185                 1   c192                 1
    x93       c206                -1   c211                 1
    x93       c217                 1   c222                 1
    x93       c228                 1   c265                 1
    x93       c280                 1   c328                -1
    x93       c330                -1   c331                 1
    x93       c353                -1   c354                 1
    x93       c380                 1   c417                 1
    x93       c457                -1   c471                 1
    x93       c498                 1   c504                 1
    x93       c531                 1   c544                 1
    x93       c557                -1   c562                 1
    x93       c602                 1   c609                -1
    x93       c611                -1   c666                -1
    x93       c679                -1   c680                 1
    x93       c703                 1   c714                 1
    x93       c723                -1   c735                 1
    x93       c738                 1   c748                -1
    x93       c766                 1   c788                 1
    x93       c830                -1   c845                -1
    x94       c54                  1   c99                  1
    x94       c113                -1   c141                 1
    x94       c168                -1   c173                -1
    x94       c210                -1   c240                -1
    x94       c252                 1   c290                 1
    x94       c311                -1   c314                -1
    x94       c316                -1   c318                 1
    x94       c338                 1   c359                -1
    x94       c361                 1   c380                 1
    x94       c390                -1   c410                -1
    x94       c430                -1   c447                -1
    x94       c498                 1   c517                -1
    x94       c535                -1   c537                -1
    x94       c556                 1   c566                 1
    x94       c594                 1   c595                 1
    x94       c641                -1   c654                -1
    x94       c749                 1   c755                 1
    x94       c790                 1   c823                 1
    x95       c56                  1   c57                 -1
    x95       c104                -1   c133                 1
    x95       c215                -1   c223                -1
    x95       c228                -1   c295                -1
    x95       c320                -1   c355                -1
    x95       c359                -1   c403                 1
    x95       c405                -1   c415                -1
    x95       c440                 1   c448                 1
    x95       c455                -1   c459                -1
    x95       c471                 1   c472                 1
    x95       c509                -1   c517                -1
    x95       c538                -1   c552                 1
    x95       c572                 1   c577                -1
    x95       c586                -1   c601                 1
    x95       c629                -1   c642                 1
    x95       c674                 1   c689                 1
    x95       c742                 1   c763                -1
    x95       c814                 1   c839                 1
    x95       c845                -1   c846                 1
    x95       c850                -1
    x96       c61                  1   c62                 -1
    x96       c70                 -1   c73                  1
    x96       c75                  1   c76                 -1
    x96       c124                -1   c157                -1
    x96       c159                -1   c179                 1
    x96       c188                 1   c235                 1
    x96       c263                -1   c281                -1
    x96       c337                -1   c344                 1
    x96       c361                -1   c378                -1
    x96       c406                -1   c410                 1
    x96       c446                -1   c456                 1
    x96       c477                -1   c532                -1
    x96       c550                 1   c555                -1
    x96       c565                -1   c570                 1
    x96       c587                 1   c611                 1
    x96       c619                 1   c653                -1
    x96       c670                 1   c707                 1
    x96       c714                 1   c742                 1
    x96       c815                 1
    x97       c62                 -1   c73                  1
    x97       c86                  1   c94                  1
    x97       c99                  1   c101                -1
    x97       c111                -1   c127                -1
    x97       c130                -1   c137                -1
    x97       c148                 1   c170                 1
    x97       c180                 1   c214                 1
    x97       c215                 1   c226                 1
    x97       c234                 1   c236                -1
    x97       c261                -1   c263                 1
    x97       c275                -1   c295                 1
    x97       c298                -1   c309                 1
    x97       c339                -1   c360                -1
    x97       c361                -1   c375                -1
    x97       c386                 1   c408                 1
    x97       c436                -1   c456                 1
    x97       c468                 1   c470                 1
    x97       c471                -1   c472                -1
    x97       c493                 1   c510                -1
    x97       c534                 1   c535                 1
    x97       c537                 1   c540                 1
    x97       c546                 1   c563                -1
    x97       c575                 1   c604                -1
    x97       c613                 1   c619                -1
    x97       c641                -1   c671                -1
    x97       c704                 1   c710                -1
    x97       c731                -1   c737                -1
    x97       c738                 1   c739                -1
    x97       c774                 1   c803                 1
    x97       c824                -1
    x98       c64                 -1   c98                  1
    x98       c102                -1   c114                 1
    x98       c124                 1   c141                -1
    x98       c216                -1   c338                -1
    x98       c378                 1   c382                 1
    x98       c404                -1   c426                 1
    x98       c434                 1   c507                -1
    x98       c513                -1   c519                 1
    x98       c579                -1   c587                 1
    x98       c619                 1   c622                 1
    x98       c630                -1   c675                 1
    x98       c699                 1   c707                 1
    x98       c714                 1   c740                 1
    x98       c767                -1   c783                 1
    x98       c818                -1   c824                 1
    x99       c65                 -1   c69                 -1
    x99       c79                  1   c95                  1
    x99       c123                -1   c126                -1
    x99       c136                 1   c150                 1
    x99       c208                 1   c260                -1
    x99       c268                 1   c280                 1
    x99       c288                -1   c292                -1
    x99       c338                 1   c364                -1
    x99       c375                 1   c391                 1
    x99       c396                -1   c398                -1
    x99       c408                 1   c422                 1
    x99       c433                 1   c440                 1
    x99       c446                 1   c449                 1
    x99       c501                -1   c519                -1
    x99       c525                -1   c601                 1
    x99       c617                 1   c635                 1
    x99       c660                -1   c673                -1
    x99       c684                -1   c723                -1
    x99       c770                -1   c779                -1
    x99       c792                -1   c795                -1
    x99       c799                -1   c831                -1
    x99       c836                 1   c847                -1
    x100      c67                 -1   c71                 -1
    x100      c74                  1   c93                 -1
    x100      c132                -1   c196                -1
    x100      c211                 1   c269                 1
    x100      c304                 1   c324                 1
    x100      c326                 1   c351                 1
    x100      c362                -1   c377                -1
    x100      c439                -1   c452                 1
    x100      c457                -1   c460                 1
    x100      c464                 1   c478                 1
    x100      c489                 1   c505                 1
    x100      c513                 1   c555                -1
    x100      c587                 1   c589                -1
    x100      c608                 1   c614                 1
    x100      c640                 1   c692                -1
    x100      c707                 1   c726                -1
    x100      c737                 1   c747                -1
    x100      c782                -1   c803                 1
    x100      c817                 1   c819                 1
    x100      c835                -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       c1                  -3   c2                   1
    rhs       c3                  -3   c5                  -1
    rhs       c7                  -3   c8                  -1
    rhs       c10                 -2   c11                 -2
    rhs       c12                 -1   c13                 -5
    rhs       c14                 -1   c15                 -1
    rhs       c16                  1   c17                 -1
    rhs       c19                 -4   c20                  1
    rhs       c21                 -3   c22                 -1
    rhs       c23                 -1   c24                 -5
    rhs       c25                 -1   c27                 -2
    rhs       c29                 -1   c31                 -2
    rhs       c32                 -1   c33                 -1
    rhs       c35                 -1   c36                 -1
    rhs       c37                 -1   c38                 -3
    rhs       c39                 -2   c40                 -1
    rhs       c41                 -1   c42                 -2
    rhs       c43                  1   c44                 -1
    rhs       c45                 -2   c46                  1
    rhs       c47                 -2   c48                 -3
    rhs       c49                 -2   c50                 -1
    rhs       c57                 -3   c58                 -2
    rhs       c59                 -3   c60                 -1
    rhs       c61                  1   c62                 -3
    rhs       c64                 -1   c65                 -2
    rhs       c66                 -4   c67                 -3
    rhs       c68                 -2   c69                 -4
    rhs       c70                 -5   c71                 -1
    rhs       c72                 -1   c73                 -1
    rhs       c74                 -2   c75                 -1
    rhs       c76                 -2   c77                 -1
    rhs       c78                 -2   c79                  1
    rhs       c80                 -2   c81                 -2
    rhs       c82                 -1   c83                 -5
    rhs       c84                 -1   c85                 -2
    rhs       c86                 -1   c87                 -2
    rhs       c89                 -3   c90                 -2
    rhs       c91                 -1   c92                 -2
    rhs       c94                 -1   c95                 -1
    rhs       c96                 -1   c97                 -3
    rhs       c98                  1   c99                 -1
    rhs       c100                -2   c101                -4
    rhs       c102                -3   c103                -3
    rhs       c104                -2   c106                -2
    rhs       c107                -1   c108                -2
    rhs       c109                -4   c112                -1
    rhs       c113                -1   c114                -2
    rhs       c115                -1   c116                -1
    rhs       c118                -4   c121                -1
    rhs       c123                -1   c124                -1
    rhs       c125                -2   c126                -1
    rhs       c127                -2   c128                -1
    rhs       c129                -3   c130                -3
    rhs       c131                -1   c132                -2
    rhs       c133                -4   c134                -1
    rhs       c135                 1   c137                -2
    rhs       c138                -2   c139                -3
    rhs       c140                -1   c141                -2
    rhs       c142                -1   c144                 1
    rhs       c146                -1   c148                -3
    rhs       c149                -4   c150                -1
    rhs       c152                -2   c153                -2
    rhs       c155                -1   c156                -2
    rhs       c157                -6   c158                -1
    rhs       c159                -3   c161                 1
    rhs       c164                -1   c166                -1
    rhs       c167                -3   c168                -1
    rhs       c169                -2   c170                -1
    rhs       c171                -3   c173                -4
    rhs       c174                -5   c175                -2
    rhs       c176                -1   c177                -4
    rhs       c178                -2   c182                -1
    rhs       c183                 1   c184                -1
    rhs       c185                -1   c186                -2
    rhs       c188                -1   c190                -1
    rhs       c193                 1   c194                -4
    rhs       c195                 1   c196                -1
    rhs       c198                -3   c199                -1
    rhs       c200                -1   c201                -2
    rhs       c202                -1   c203                -1
    rhs       c204                -1   c205                -3
    rhs       c206                -1   c207                -1
    rhs       c208                 1   c209                -1
    rhs       c210                -2   c211                -2
    rhs       c212                 1   c213                -3
    rhs       c214                -1   c215                -1
    rhs       c216                -5   c217                -1
    rhs       c219                -2   c221                -2
    rhs       c222                 1   c223                -3
    rhs       c225                -1   c226                -1
    rhs       c228                -1   c229                -1
    rhs       c230                -4   c231                -1
    rhs       c232                -1   c233                -2
    rhs       c234                -1   c235                 1
    rhs       c236                -1   c237                -2
    rhs       c238                 1   c239                -2
    rhs       c240                -3   c241                -3
    rhs       c245                -1   c248                -3
    rhs       c249                -2   c250                -3
    rhs       c251                -1   c252                 1
    rhs       c253                -3   c255                -1
    rhs       c256                -2   c257                -5
    rhs       c258                -2   c259                -2
    rhs       c260                -5   c261                -4
    rhs       c262                -1   c263                -2
    rhs       c265                -2   c266                -1
    rhs       c267                -2   c268                -1
    rhs       c269                -2   c271                -1
    rhs       c272                -2   c273                -2
    rhs       c274                -4   c275                -3
    rhs       c276                -1   c278                -2
    rhs       c279                -1   c280                -2
    rhs       c281                -2   c282                -1
    rhs       c283                -2   c285                -1
    rhs       c286                -1   c287                -2
    rhs       c288                -2   c290                -1
    rhs       c291                -1   c292                -4
    rhs       c293                -3   c294                -4
    rhs       c295                -1   c298                -1
    rhs       c299                -1   c300                -2
    rhs       c301                -4   c304                -2
    rhs       c306                -3   c307                -2
    rhs       c309                -4   c310                 1
    rhs       c311                -2   c312                -1
    rhs       c313                -1   c314                -2
    rhs       c315                -1   c316                -2
    rhs       c317                -1   c318                -3
    rhs       c319                -3   c320                -2
    rhs       c321                -1   c322                -4
    rhs       c323                -1   c324                 1
    rhs       c326                -2   c327                -2
    rhs       c328                -3   c329                -1
    rhs       c330                -2   c331                -1
    rhs       c333                 1   c335                -2
    rhs       c336                 1   c337                -3
    rhs       c338                -4   c339                -1
    rhs       c341                -2   c342                -2
    rhs       c344                -1   c346                -1
    rhs       c347                -6   c348                -1
    rhs       c349                -3   c351                 1
    rhs       c354                -1   c355                -1
    rhs       c357                -4   c359                -2
    rhs       c360                -1   c361                -3
    rhs       c362                -2   c363                -3
    rhs       c364                -5   c365                -1
    rhs       c366                -3   c367                -2
    rhs       c368                -2   c372                -1
    rhs       c373                -1   c374                -1
    rhs       c375                -2   c377                -1
    rhs       c379                -1   c382                 1
    rhs       c383                -4   c384                 1
    rhs       c385                -1   c387                -4
    rhs       c389                -1   c390                -2
    rhs       c391                -1   c392                -1
    rhs       c393                -1   c394                -3
    rhs       c395                -1   c396                -1
    rhs       c397                 1   c398                -2
    rhs       c399                -1   c400                -2
    rhs       c401                 1   c402                -4
    rhs       c404                -1   c405                -5
    rhs       c406                -1   c408                -2
    rhs       c410                -2   c411                 1
    rhs       c412                -3   c414                -1
    rhs       c415                -2   c416                 1
    rhs       c417                -1   c418                -2
    rhs       c419                -3   c420                -1
    rhs       c421                -2   c422                -1
    rhs       c423                -1   c424                 1
    rhs       c425                -2   c426                -1
    rhs       c427                 1   c429                -3
    rhs       c430                -1   c431                -3
    rhs       c434                -1   c435                 1
    rhs       c437                -1   c438                -2
    rhs       c439                -4   c440                -1
    rhs       c441                -1   c442                 1
    rhs       c443                -3   c445                -1
    rhs       c446                -2   c447                -5
    rhs       c448                -3   c449                -1
    rhs       c450                -5   c451                -4
    rhs       c452                -1   c453                -2
    rhs       c454                -1   c455                -1
    rhs       c456                -1   c457                -2
    rhs       c458                -1   c459                -2
    rhs       c461                -2   c462                -1
    rhs       c463                -2   c464                -4
    rhs       c465                -4   c468                -2
    rhs       c469                -1   c470                -2
    rhs       c471                -2   c472                -2
    rhs       c473                -1   c475                -1
    rhs       c476                -1   c477                -2
    rhs       c478                -2   c479                -1
    rhs       c481                -1   c482                -4
    rhs       c483                -4   c484                -4
    rhs       c488                -2   c489                -3
    rhs       c490                -3   c493                -2
    rhs       c495                -3   c496                -1
    rhs       c497                -1   c498                -1
    rhs       c499                -3   c500                 1
    rhs       c501                -1   c502                -1
    rhs       c503                -1   c504                -2
    rhs       c505                -1   c506                -2
    rhs       c507                -2   c509                -3
    rhs       c510                -3   c511                -2
    rhs       c512                -1   c513                -5
    rhs       c515                 1   c517                -2
    rhs       c518                -3   c519                -2
    rhs       c520                -1   c521                -3
    rhs       c524                 1   c526                -2
    rhs       c528                -4   c529                -2
    rhs       c530                -1   c532                -2
    rhs       c533                -2   c535                -1
    rhs       c537                -1   c538                -6
    rhs       c539                -1   c540                -3
    rhs       c542                 1   c545                -1
    rhs       c546                -1   c548                -4
    rhs       c549                -1   c550                -1
    rhs       c551                -1   c552                -3
    rhs       c553                -2   c554                -3
    rhs       c555                -5   c556                -1
    rhs       c557                -4   c558                -1
    rhs       c559                -2   c561                -1
    rhs       c562                -1   c563                -2
    rhs       c565                -2   c567                -1
    rhs       c569                -1   c572                 1
    rhs       c573                -4   c574                 1
    rhs       c575                -1   c577                -4
    rhs       c579                -2   c580                -2
    rhs       c582                -1   c583                -1
    rhs       c584                -3   c585                -1
    rhs       c586                -1   c587                 1
    rhs       c588                -2   c589                -2
    rhs       c590                -1   c591                -1
    rhs       c592                -3   c594                -2
    rhs       c595                -3   c596                -1
    rhs       c597                -1   c598                -1
    rhs       c599                -1   c600                -1
    rhs       c602                -2   c604                -1
    rhs       c605                -2   c608                -3
    rhs       c609                -2   c610                -1
    rhs       c611                -3   c613                -1
    rhs       c615                -2   c617                 1
    rhs       c619                -4   c620                -1
    rhs       c621                -2   c624                -1
    rhs       c625                 1   c627                -1
    rhs       c628                -2   c629                -4
    rhs       c630                -1   c631                -1
    rhs       c632                 1   c633                -3
    rhs       c634                -1   c636                -4
    rhs       c637                -3   c638                -3
    rhs       c639                -1   c640                -5
    rhs       c641                -4   c642                -1
    rhs       c643                -2   c644                -1
    rhs       c645                -1   c646                -1
    rhs       c647                -2   c648                -2
    rhs       c649                -1   c651                -2
    rhs       c652                -1   c653                -3
    rhs       c654                -3   c655                -4
    rhs       c658                -2   c659                -1
    rhs       c660                -2   c661                -2
    rhs       c662                -3   c665                -1
    rhs       c666                -1   c667                -2
    rhs       c668                -2   c669                -1
    rhs       c671                -1   c672                -5
    rhs       c673                -3   c674                -5
    rhs       c675                 1   c678                -2
    rhs       c679                -4   c680                -2
    rhs       c683                -2   c684                -1
    rhs       c685                -2   c686                -1
    rhs       c687                -1   c688                -1
    rhs       c689                -3   c690                 1
    rhs       c691                -2   c693                -1
    rhs       c694                -2   c695                -1
    rhs       c696                -2   c697                -3
    rhs       c698                 1   c699                -3
    rhs       c700                -4   c701                -1
    rhs       c702                -1   c703                -5
    rhs       c705                 1   c706                -1
    rhs       c707                -1   c708                -3
    rhs       c709                -2   c710                -1
    rhs       c711                -2   c714                 1
    rhs       c716                -2   c717                -1
    rhs       c718                -3   c719                -2
    rhs       c720                -1   c721                -1
    rhs       c722                -1   c723                -2
    rhs       c724                -1   c726                -1
    rhs       c727                -1   c728                -5
    rhs       c729                -2   c730                -2
    rhs       c733                 1   c735                -2
    rhs       c738                -4   c739                -2
    rhs       c741                -1   c742                -3
    rhs       c743                -3   c744                -2
    rhs       c745                -5   c746                -2
    rhs       c747                -3   c748                -1
    rhs       c749                -3   c750                 1
    rhs       c751                -1   c752                -1
    rhs       c753                -2   c755                -2
    rhs       c757                -1   c758                -1
    rhs       c762                 1   c763                -4
    rhs       c764                 1   c765                -2
    rhs       c766                 1   c767                -4
    rhs       c769                -2   c770                -2
    rhs       c772                -1   c773                -3
    rhs       c774                -1   c775                -1
    rhs       c776                -1   c777                 1
    rhs       c778                -2   c779                -3
    rhs       c781                -1   c782                -3
    rhs       c784                -4   c785                -1
    rhs       c786                -1   c787                -2
    rhs       c789                -1   c790                -1
    rhs       c791                -1   c792                -1
    rhs       c794                -2   c795                -1
    rhs       c796                -1   c797                 1
    rhs       c798                -3   c799                -3
    rhs       c801                -3   c803                -1
    rhs       c805                -3   c806                 1
    rhs       c807                 1   c809                -4
    rhs       c810                -1   c811                -2
    rhs       c815                -1   c816                 1
    rhs       c818                -2   c819                -1
    rhs       c820                -4   c821                -1
    rhs       c822                -1   c823                 1
    rhs       c824                -3   c825                -1
    rhs       c827                -4   c828                -3
    rhs       c829                -3   c830                -1
    rhs       c831                -6   c832                -3
    rhs       c833                -1   c834                -2
    rhs       c835                -2   c836                -1
    rhs       c838                -3   c839                -2
    rhs       c842                -3   c844                -4
    rhs       c845                -2   c846                -4
    rhs       c848                -1   c849                -2
    rhs       c850                -2
BOUNDS
 UP bnd       x1                   1
 UP bnd       x2                   1
 UP bnd       x3                   1
 UP bnd       x4                   1
 UP bnd       x5                   1
 UP bnd       x6                   1
 UP bnd       x7                   1
 UP bnd       x8                   1
 UP bnd       x9                   1
 UP bnd       x10                  1
 UP bnd       x11                  1
 UP bnd       x12                  1
 UP bnd       x13                  1
 UP bnd       x14                  1
 UP bnd       x15                  1
 UP bnd       x16                  1
 UP bnd       x17                  1
 UP bnd       x18                  1
 UP bnd       x19                  1
 UP bnd       x20                  1
 UP bnd       x21                  1
 UP bnd       x22                  1
 UP bnd       x23                  1
 UP bnd       x24                  1
 UP bnd       x25                  1
 UP bnd       x26                  1
 UP bnd       x27                  1
 UP bnd       x28                  1
 UP bnd       x29                  1
 UP bnd       x30                  1
 UP bnd       x31                  1
 UP bnd       x32                  1
 UP bnd       x33                  1
 UP bnd       x34                  1
 UP bnd       x35                  1
 UP bnd       x36                  1
 UP bnd       x37                  1
 UP bnd       x38                  1
 UP bnd       x39                  1
 UP bnd       x40                  1
 UP bnd       x41                  1
 UP bnd       x42                  1
 UP bnd       x43                  1
 UP bnd       x44                  1
 UP bnd       x45                  1
 UP bnd       x46                  1
 UP bnd       x47                  1
 UP bnd       x48                  1
 UP bnd       x49                  1
 UP bnd       x50                  1
 UP bnd       x51                  1
 UP bnd       x52                  1
 UP bnd       x53                  1
 UP bnd       x54                  1
 UP bnd       x55                  1
 UP bnd       x56                  1
 UP bnd       x57                  1
 UP bnd       x58                  1
 UP bnd       x59                  1
 UP bnd       x60                  1
 UP bnd       x61                  1
 UP bnd       x62                  1
 UP bnd       x63                  1
 UP bnd       x64                  1
 UP bnd       x65                  1
 UP bnd       x66                  1
 UP bnd       x67                  1
 UP bnd       x68                  1
 UP bnd       x69                  1
 UP bnd       x70                  1
 UP bnd       x71                  1
 UP bnd       x72                  1
 UP bnd       x73                  1
 UP bnd       x74                  1
 UP bnd       x75                  1
 UP bnd       x76                  1
 UP bnd       x77                  1
 UP bnd       x78                  1
 UP bnd       x79                  1
 UP bnd       x80                  1
 UP bnd       x81                  1
 UP bnd       x82                  1
 UP bnd       x83                  1
 UP bnd       x84                  1
 UP bnd       x85                  1
 UP bnd       x86                  1
 UP bnd       x87                  1
 UP bnd       x88                  1
 UP bnd       x89                  1
 UP bnd       x90                  1
 UP bnd       x91                  1
 UP bnd       x92                  1
 UP bnd       x93                  1
 UP bnd       x94                  1
 UP bnd       x95                  1
 UP bnd       x96                  1
 UP bnd       x97                  1
 UP bnd       x98                  1
 UP bnd       x99                  1
 UP bnd       x100                 1
ENDATA
