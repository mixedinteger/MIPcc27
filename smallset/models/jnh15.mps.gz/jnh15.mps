NAME           
ROWS
 N  obj     
 G  c1      
 G  c2      
 G  c3      
 G  c4      
 G  c5      
 G  c6      
 G  c7      
 G  c8      
 G  c9      
 G  c10     
 G  c11     
 G  c12     
 G  c13     
 G  c14     
 G  c15     
 G  c16     
 G  c17     
 G  c18     
 G  c19     
 G  c20     
 G  c21     
 G  c22     
 G  c23     
 G  c24     
 G  c25     
 G  c26     
 G  c27     
 G  c28     
 G  c29     
 G  c30     
 G  c31     
 G  c32     
 G  c33     
 G  c34     
 G  c35     
 G  c36     
 G  c37     
 G  c38     
 G  c39     
 G  c40     
 G  c41     
 G  c42     
 G  c43     
 G  c44     
 G  c45     
 G  c46     
 G  c47     
 G  c48     
 G  c49     
 G  c50     
 G  c51     
 G  c52     
 G  c53     
 G  c54     
 G  c55     
 G  c56     
 G  c57     
 G  c58     
 G  c59     
 G  c60     
 G  c61     
 G  c62     
 G  c63     
 G  c64     
 G  c65     
 G  c66     
 G  c67     
 G  c68     
 G  c69     
 G  c70     
 G  c71     
 G  c72     
 G  c73     
 G  c74     
 G  c75     
 G  c76     
 G  c77     
 G  c78     
 G  c79     
 G  c80     
 G  c81     
 G  c82     
 G  c83     
 G  c84     
 G  c85     
 G  c86     
 G  c87     
 G  c88     
 G  c89     
 G  c90     
 G  c91     
 G  c92     
 G  c93     
 G  c94     
 G  c95     
 G  c96     
 G  c97     
 G  c98     
 G  c99     
 G  c100    
 G  c101    
 G  c102    
 G  c103    
 G  c104    
 G  c105    
 G  c106    
 G  c107    
 G  c108    
 G  c109    
 G  c110    
 G  c111    
 G  c112    
 G  c113    
 G  c114    
 G  c115    
 G  c116    
 G  c117    
 G  c118    
 G  c119    
 G  c120    
 G  c121    
 G  c122    
 G  c123    
 G  c124    
 G  c125    
 G  c126    
 G  c127    
 G  c128    
 G  c129    
 G  c130    
 G  c131    
 G  c132    
 G  c133    
 G  c134    
 G  c135    
 G  c136    
 G  c137    
 G  c138    
 G  c139    
 G  c140    
 G  c141    
 G  c142    
 G  c143    
 G  c144    
 G  c145    
 G  c146    
 G  c147    
 G  c148    
 G  c149    
 G  c150    
 G  c151    
 G  c152    
 G  c153    
 G  c154    
 G  c155    
 G  c156    
 G  c157    
 G  c158    
 G  c159    
 G  c160    
 G  c161    
 G  c162    
 G  c163    
 G  c164    
 G  c165    
 G  c166    
 G  c167    
 G  c168    
 G  c169    
 G  c170    
 G  c171    
 G  c172    
 G  c173    
 G  c174    
 G  c175    
 G  c176    
 G  c177    
 G  c178    
 G  c179    
 G  c180    
 G  c181    
 G  c182    
 G  c183    
 G  c184    
 G  c185    
 G  c186    
 G  c187    
 G  c188    
 G  c189    
 G  c190    
 G  c191    
 G  c192    
 G  c193    
 G  c194    
 G  c195    
 G  c196    
 G  c197    
 G  c198    
 G  c199    
 G  c200    
 G  c201    
 G  c202    
 G  c203    
 G  c204    
 G  c205    
 G  c206    
 G  c207    
 G  c208    
 G  c209    
 G  c210    
 G  c211    
 G  c212    
 G  c213    
 G  c214    
 G  c215    
 G  c216    
 G  c217    
 G  c218    
 G  c219    
 G  c220    
 G  c221    
 G  c222    
 G  c223    
 G  c224    
 G  c225    
 G  c226    
 G  c227    
 G  c228    
 G  c229    
 G  c230    
 G  c231    
 G  c232    
 G  c233    
 G  c234    
 G  c235    
 G  c236    
 G  c237    
 G  c238    
 G  c239    
 G  c240    
 G  c241    
 G  c242    
 G  c243    
 G  c244    
 G  c245    
 G  c246    
 G  c247    
 G  c248    
 G  c249    
 G  c250    
 G  c251    
 G  c252    
 G  c253    
 G  c254    
 G  c255    
 G  c256    
 G  c257    
 G  c258    
 G  c259    
 G  c260    
 G  c261    
 G  c262    
 G  c263    
 G  c264    
 G  c265    
 G  c266    
 G  c267    
 G  c268    
 G  c269    
 G  c270    
 G  c271    
 G  c272    
 G  c273    
 G  c274    
 G  c275    
 G  c276    
 G  c277    
 G  c278    
 G  c279    
 G  c280    
 G  c281    
 G  c282    
 G  c283    
 G  c284    
 G  c285    
 G  c286    
 G  c287    
 G  c288    
 G  c289    
 G  c290    
 G  c291    
 G  c292    
 G  c293    
 G  c294    
 G  c295    
 G  c296    
 G  c297    
 G  c298    
 G  c299    
 G  c300    
 G  c301    
 G  c302    
 G  c303    
 G  c304    
 G  c305    
 G  c306    
 G  c307    
 G  c308    
 G  c309    
 G  c310    
 G  c311    
 G  c312    
 G  c313    
 G  c314    
 G  c315    
 G  c316    
 G  c317    
 G  c318    
 G  c319    
 G  c320    
 G  c321    
 G  c322    
 G  c323    
 G  c324    
 G  c325    
 G  c326    
 G  c327    
 G  c328    
 G  c329    
 G  c330    
 G  c331    
 G  c332    
 G  c333    
 G  c334    
 G  c335    
 G  c336    
 G  c337    
 G  c338    
 G  c339    
 G  c340    
 G  c341    
 G  c342    
 G  c343    
 G  c344    
 G  c345    
 G  c346    
 G  c347    
 G  c348    
 G  c349    
 G  c350    
 G  c351    
 G  c352    
 G  c353    
 G  c354    
 G  c355    
 G  c356    
 G  c357    
 G  c358    
 G  c359    
 G  c360    
 G  c361    
 G  c362    
 G  c363    
 G  c364    
 G  c365    
 G  c366    
 G  c367    
 G  c368    
 G  c369    
 G  c370    
 G  c371    
 G  c372    
 G  c373    
 G  c374    
 G  c375    
 G  c376    
 G  c377    
 G  c378    
 G  c379    
 G  c380    
 G  c381    
 G  c382    
 G  c383    
 G  c384    
 G  c385    
 G  c386    
 G  c387    
 G  c388    
 G  c389    
 G  c390    
 G  c391    
 G  c392    
 G  c393    
 G  c394    
 G  c395    
 G  c396    
 G  c397    
 G  c398    
 G  c399    
 G  c400    
 G  c401    
 G  c402    
 G  c403    
 G  c404    
 G  c405    
 G  c406    
 G  c407    
 G  c408    
 G  c409    
 G  c410    
 G  c411    
 G  c412    
 G  c413    
 G  c414    
 G  c415    
 G  c416    
 G  c417    
 G  c418    
 G  c419    
 G  c420    
 G  c421    
 G  c422    
 G  c423    
 G  c424    
 G  c425    
 G  c426    
 G  c427    
 G  c428    
 G  c429    
 G  c430    
 G  c431    
 G  c432    
 G  c433    
 G  c434    
 G  c435    
 G  c436    
 G  c437    
 G  c438    
 G  c439    
 G  c440    
 G  c441    
 G  c442    
 G  c443    
 G  c444    
 G  c445    
 G  c446    
 G  c447    
 G  c448    
 G  c449    
 G  c450    
 G  c451    
 G  c452    
 G  c453    
 G  c454    
 G  c455    
 G  c456    
 G  c457    
 G  c458    
 G  c459    
 G  c460    
 G  c461    
 G  c462    
 G  c463    
 G  c464    
 G  c465    
 G  c466    
 G  c467    
 G  c468    
 G  c469    
 G  c470    
 G  c471    
 G  c472    
 G  c473    
 G  c474    
 G  c475    
 G  c476    
 G  c477    
 G  c478    
 G  c479    
 G  c480    
 G  c481    
 G  c482    
 G  c483    
 G  c484    
 G  c485    
 G  c486    
 G  c487    
 G  c488    
 G  c489    
 G  c490    
 G  c491    
 G  c492    
 G  c493    
 G  c494    
 G  c495    
 G  c496    
 G  c497    
 G  c498    
 G  c499    
 G  c500    
 G  c501    
 G  c502    
 G  c503    
 G  c504    
 G  c505    
 G  c506    
 G  c507    
 G  c508    
 G  c509    
 G  c510    
 G  c511    
 G  c512    
 G  c513    
 G  c514    
 G  c515    
 G  c516    
 G  c517    
 G  c518    
 G  c519    
 G  c520    
 G  c521    
 G  c522    
 G  c523    
 G  c524    
 G  c525    
 G  c526    
 G  c527    
 G  c528    
 G  c529    
 G  c530    
 G  c531    
 G  c532    
 G  c533    
 G  c534    
 G  c535    
 G  c536    
 G  c537    
 G  c538    
 G  c539    
 G  c540    
 G  c541    
 G  c542    
 G  c543    
 G  c544    
 G  c545    
 G  c546    
 G  c547    
 G  c548    
 G  c549    
 G  c550    
 G  c551    
 G  c552    
 G  c553    
 G  c554    
 G  c555    
 G  c556    
 G  c557    
 G  c558    
 G  c559    
 G  c560    
 G  c561    
 G  c562    
 G  c563    
 G  c564    
 G  c565    
 G  c566    
 G  c567    
 G  c568    
 G  c569    
 G  c570    
 G  c571    
 G  c572    
 G  c573    
 G  c574    
 G  c575    
 G  c576    
 G  c577    
 G  c578    
 G  c579    
 G  c580    
 G  c581    
 G  c582    
 G  c583    
 G  c584    
 G  c585    
 G  c586    
 G  c587    
 G  c588    
 G  c589    
 G  c590    
 G  c591    
 G  c592    
 G  c593    
 G  c594    
 G  c595    
 G  c596    
 G  c597    
 G  c598    
 G  c599    
 G  c600    
 G  c601    
 G  c602    
 G  c603    
 G  c604    
 G  c605    
 G  c606    
 G  c607    
 G  c608    
 G  c609    
 G  c610    
 G  c611    
 G  c612    
 G  c613    
 G  c614    
 G  c615    
 G  c616    
 G  c617    
 G  c618    
 G  c619    
 G  c620    
 G  c621    
 G  c622    
 G  c623    
 G  c624    
 G  c625    
 G  c626    
 G  c627    
 G  c628    
 G  c629    
 G  c630    
 G  c631    
 G  c632    
 G  c633    
 G  c634    
 G  c635    
 G  c636    
 G  c637    
 G  c638    
 G  c639    
 G  c640    
 G  c641    
 G  c642    
 G  c643    
 G  c644    
 G  c645    
 G  c646    
 G  c647    
 G  c648    
 G  c649    
 G  c650    
 G  c651    
 G  c652    
 G  c653    
 G  c654    
 G  c655    
 G  c656    
 G  c657    
 G  c658    
 G  c659    
 G  c660    
 G  c661    
 G  c662    
 G  c663    
 G  c664    
 G  c665    
 G  c666    
 G  c667    
 G  c668    
 G  c669    
 G  c670    
 G  c671    
 G  c672    
 G  c673    
 G  c674    
 G  c675    
 G  c676    
 G  c677    
 G  c678    
 G  c679    
 G  c680    
 G  c681    
 G  c682    
 G  c683    
 G  c684    
 G  c685    
 G  c686    
 G  c687    
 G  c688    
 G  c689    
 G  c690    
 G  c691    
 G  c692    
 G  c693    
 G  c694    
 G  c695    
 G  c696    
 G  c697    
 G  c698    
 G  c699    
 G  c700    
 G  c701    
 G  c702    
 G  c703    
 G  c704    
 G  c705    
 G  c706    
 G  c707    
 G  c708    
 G  c709    
 G  c710    
 G  c711    
 G  c712    
 G  c713    
 G  c714    
 G  c715    
 G  c716    
 G  c717    
 G  c718    
 G  c719    
 G  c720    
 G  c721    
 G  c722    
 G  c723    
 G  c724    
 G  c725    
 G  c726    
 G  c727    
 G  c728    
 G  c729    
 G  c730    
 G  c731    
 G  c732    
 G  c733    
 G  c734    
 G  c735    
 G  c736    
 G  c737    
 G  c738    
 G  c739    
 G  c740    
 G  c741    
 G  c742    
 G  c743    
 G  c744    
 G  c745    
 G  c746    
 G  c747    
 G  c748    
 G  c749    
 G  c750    
 G  c751    
 G  c752    
 G  c753    
 G  c754    
 G  c755    
 G  c756    
 G  c757    
 G  c758    
 G  c759    
 G  c760    
 G  c761    
 G  c762    
 G  c763    
 G  c764    
 G  c765    
 G  c766    
 G  c767    
 G  c768    
 G  c769    
 G  c770    
 G  c771    
 G  c772    
 G  c773    
 G  c774    
 G  c775    
 G  c776    
 G  c777    
 G  c778    
 G  c779    
 G  c780    
 G  c781    
 G  c782    
 G  c783    
 G  c784    
 G  c785    
 G  c786    
 G  c787    
 G  c788    
 G  c789    
 G  c790    
 G  c791    
 G  c792    
 G  c793    
 G  c794    
 G  c795    
 G  c796    
 G  c797    
 G  c798    
 G  c799    
 G  c800    
 G  c801    
 G  c802    
 G  c803    
 G  c804    
 G  c805    
 G  c806    
 G  c807    
 G  c808    
 G  c809    
 G  c810    
 G  c811    
 G  c812    
 G  c813    
 G  c814    
 G  c815    
 G  c816    
 G  c817    
 G  c818    
 G  c819    
 G  c820    
 G  c821    
 G  c822    
 G  c823    
 G  c824    
 G  c825    
 G  c826    
 G  c827    
 G  c828    
 G  c829    
 G  c830    
 G  c831    
 G  c832    
 G  c833    
 G  c834    
 G  c835    
 G  c836    
 G  c837    
 G  c838    
 G  c839    
 G  c840    
 G  c841    
 G  c842    
 G  c843    
 G  c844    
 G  c845    
 G  c846    
 G  c847    
 G  c848    
 G  c849    
 G  c850    
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x1        c1                  -1   c22                 -1
    x1        c27                 -1   c61                 -1
    x1        c123                -1   c126                -1
    x1        c150                -1   c179                -1
    x1        c185                -1   c187                 1
    x1        c215                 1   c234                -1
    x1        c279                -1   c283                -1
    x1        c335                -1   c345                 1
    x1        c355                -1   c378                 1
    x1        c435                -1   c438                -1
    x1        c453                -1   c487                 1
    x1        c495                 1   c533                 1
    x1        c536                -1   c554                -1
    x1        c558                 1   c572                 1
    x1        c574                -1   c575                 1
    x1        c577                -1   c625                 1
    x1        c638                -1   c663                 1
    x1        c676                -1   c680                -1
    x1        c685                 1   c693                -1
    x1        c699                -1   c709                -1
    x1        c712                 1   c724                -1
    x1        c743                -1   c745                 1
    x1        c747                 1   c765                 1
    x1        c798                -1   c823                -1
    x2        c1                  -1   c16                  1
    x2        c33                  1   c54                  1
    x2        c119                -1   c123                -1
    x2        c133                 1   c149                 1
    x2        c177                -1   c180                -1
    x2        c190                 1   c204                 1
    x2        c262                 1   c314                -1
    x2        c322                 1   c334                 1
    x2        c342                -1   c346                -1
    x2        c393                 1   c419                -1
    x2        c430                 1   c446                 1
    x2        c451                -1   c453                -1
    x2        c463                 1   c477                 1
    x2        c488                 1   c495                 1
    x2        c501                 1   c504                 1
    x2        c556                -1   c574                -1
    x2        c580                -1   c656                 1
    x2        c672                 1   c691                 1
    x2        c716                -1   c728                -1
    x2        c739                -1   c778                -1
    x2        c826                -1   c835                -1
    x2        c848                -1
    x3        c1                   1   c16                  1
    x3        c40                 -1   c50                  1
    x3        c60                  1   c73                 -1
    x3        c88                  1   c103                -1
    x3        c122                 1   c132                -1
    x3        c137                -1   c146                -1
    x3        c188                 1   c201                 1
    x3        c202                -1   c217                 1
    x3        c233                -1   c239                 1
    x3        c240                 1   c251                -1
    x3        c265                -1   c270                 1
    x3        c294                 1   c312                 1
    x3        c320                -1   c393                -1
    x3        c412                -1   c436                 1
    x3        c440                -1   c519                -1
    x3        c554                 1   c689                -1
    x3        c700                 1   c713                 1
    x3        c720                 1   c725                 1
    x3        c727                -1   c737                -1
    x3        c752                -1   c755                -1
    x3        c762                -1   c773                 1
    x3        c796                 1   c807                 1
    x3        c839                 1   c840                 1
    x4        c1                   1   c63                  1
    x4        c81                  1   c95                 -1
    x4        c99                 -1   c135                -1
    x4        c204                 1   c267                -1
    x4        c348                 1   c368                 1
    x4        c371                 1   c384                -1
    x4        c414                 1   c447                 1
    x4        c460                 1   c482                 1
    x4        c488                 1   c500                 1
    x4        c528                -1   c549                 1
    x4        c568                -1   c583                -1
    x4        c616                 1   c622                 1
    x4        c647                 1   c666                -1
    x4        c686                 1   c714                -1
    x4        c736                 1   c749                 1
    x4        c778                -1   c782                 1
    x4        c784                -1   c788                 1
    x4        c793                -1   c825                 1
    x4        c849                -1
    x5        c2                   1   c16                  1
    x5        c48                 -1   c76                 -1
    x5        c78                 -1   c99                 -1
    x5        c112                 1   c116                 1
    x5        c168                -1   c182                -1
    x5        c193                 1   c203                 1
    x5        c206                 1   c213                -1
    x5        c233                 1   c259                -1
    x5        c282                -1   c326                -1
    x5        c336                -1   c378                -1
    x5        c412                -1   c416                -1
    x5        c436                 1   c457                 1
    x5        c523                 1   c541                 1
    x5        c544                 1   c547                 1
    x5        c549                 1   c587                 1
    x5        c598                 1   c621                 1
    x5        c633                 1   c654                -1
    x5        c714                -1   c729                -1
    x5        c757                 1   c770                 1
    x5        c776                -1   c841                -1
    x6        c2                  -1   c4                   1
    x6        c6                  -1   c55                  1
    x6        c67                 -1   c92                  1
    x6        c104                -1   c108                -1
    x6        c113                 1   c121                -1
    x6        c127                -1   c137                -1
    x6        c140                 1   c153                -1
    x6        c172                -1   c174                 1
    x6        c176                 1   c195                 1
    x6        c227                -1   c253                -1
    x6        c281                -1   c285                 1
    x6        c291                 1   c297                 1
    x6        c304                -1   c310                 1
    x6        c337                -1   c344                -1
    x6        c353                -1   c392                -1
    x6        c406                 1   c500                -1
    x6        c534                 1   c538                -1
    x6        c550                 1   c559                 1
    x6        c576                -1   c650                -1
    x6        c774                -1   c814                 1
    x6        c818                 1   c840                -1
    x7        c3                  -1   c23                 -1
    x7        c29                 -1   c30                  1
    x7        c31                 -1   c67                  1
    x7        c96                  1   c116                -1
    x7        c157                -1   c195                -1
    x7        c197                 1   c284                 1
    x7        c285                 1   c293                 1
    x7        c300                 1   c311                 1
    x7        c313                 1   c346                 1
    x7        c386                 1   c419                -1
    x7        c453                 1   c483                 1
    x7        c532                -1   c539                -1
    x7        c542                -1   c552                -1
    x7        c562                 1   c630                 1
    x7        c663                -1   c677                 1
    x7        c685                -1   c722                 1
    x7        c728                -1   c741                -1
    x7        c749                 1   c763                -1
    x7        c794                 1   c811                 1
    x7        c834                 1
    x8        c3                  -1   c32                  1
    x8        c66                  1   c78                  1
    x8        c100                 1   c106                 1
    x8        c118                 1   c146                -1
    x8        c167                 1   c187                -1
    x8        c202                -1   c234                 1
    x8        c242                 1   c267                 1
    x8        c286                -1   c304                 1
    x8        c332                -1   c356                 1
    x8        c368                 1   c397                -1
    x8        c401                 1   c403                -1
    x8        c407                 1   c412                -1
    x8        c444                 1   c468                -1
    x8        c470                 1   c502                -1
    x8        c506                 1   c507                -1
    x8        c525                -1   c548                 1
    x8        c570                 1   c571                 1
    x8        c576                 1   c619                -1
    x8        c632                 1   c646                 1
    x8        c676                -1   c677                -1
    x8        c684                 1   c709                -1
    x8        c757                 1   c772                 1
    x8        c796                -1
    x9        c4                  -1   c6                   1
    x9        c92                  1   c93                  1
    x9        c101                 1   c109                 1
    x9        c120                 1   c122                 1
    x9        c155                 1   c196                 1
    x9        c228                -1   c263                 1
    x9        c341                -1   c348                -1
    x9        c351                -1   c361                -1
    x9        c371                 1   c440                 1
    x9        c473                -1   c487                 1
    x9        c494                -1   c532                 1
    x9        c538                -1   c551                -1
    x9        c559                 1   c573                -1
    x9        c604                 1   c620                 1
    x9        c643                 1   c663                -1
    x9        c666                -1   c716                 1
    x9        c720                 1   c798                -1
    x9        c801                -1   c806                 1
    x9        c809                 1   c840                 1
    x10       c4                  -1   c5                   1
    x10       c26                 -1   c27                  1
    x10       c54                  1   c90                  1
    x10       c130                -1   c144                 1
    x10       c171                 1   c178                 1
    x10       c205                 1   c217                 1
    x10       c230                -1   c235                 1
    x10       c236                 1   c277                 1
    x10       c284                -1   c286                -1
    x10       c340                -1   c354                -1
    x10       c355                 1   c377                 1
    x10       c388                 1   c397                -1
    x10       c409                 1   c412                 1
    x10       c422                -1   c441                 1
    x10       c463                 1   c504                -1
    x10       c519                -1   c529                 1
    x10       c553                 1   c554                -1
    x10       c564                 1   c596                 1
    x10       c626                -1   c653                -1
    x10       c678                -1   c685                -1
    x10       c689                -1   c691                 1
    x10       c701                -1   c707                 1
    x10       c733                 1   c740                -1
    x10       c748                -1   c750                -1
    x10       c755                -1   c763                -1
    x10       c799                -1   c819                -1
    x10       c829                -1
    x11       c4                   1   c46                  1
    x11       c48                 -1   c61                  1
    x11       c74                  1   c103                -1
    x11       c104                -1   c111                 1
    x11       c136                -1   c186                 1
    x11       c201                 1   c224                -1
    x11       c306                 1   c307                -1
    x11       c315                -1   c318                 1
    x11       c320                 1   c321                -1
    x11       c368                -1   c402                -1
    x11       c404                -1   c424                 1
    x11       c432                 1   c479                 1
    x11       c508                -1   c526                -1
    x11       c583                -1   c590                 1
    x11       c607                -1   c623                -1
    x11       c651                -1   c655                 1
    x11       c692                -1   c702                 1
    x11       c722                -1   c777                -1
    x11       c795                 1   c800                -1
    x11       c811                -1   c816                 1
    x11       c833                 1
    x12       c4                  -1   c78                 -1
    x12       c203                -1   c243                 1
    x12       c247                 1   c269                -1
    x12       c291                 1   c299                 1
    x12       c371                -1   c377                -1
    x12       c383                 1   c444                -1
    x12       c452                 1   c484                 1
    x12       c487                 1   c495                -1
    x12       c540                 1   c564                 1
    x12       c572                 1   c579                 1
    x12       c605                 1   c632                -1
    x12       c648                 1   c683                -1
    x12       c689                 1   c769                 1
    x12       c802                 1   c815                -1
    x12       c819                -1
    x13       c4                   1   c36                 -1
    x13       c62                 -1   c89                 -1
    x13       c93                  1   c99                  1
    x13       c105                 1   c113                -1
    x13       c119                 1   c146                -1
    x13       c153                -1   c161                -1
    x13       c202                -1   c215                 1
    x13       c309                -1   c343                 1
    x13       c347                -1   c360                 1
    x13       c368                 1   c385                -1
    x13       c460                -1   c584                -1
    x13       c623                 1   c627                 1
    x13       c649                -1   c671                 1
    x13       c680                 1   c752                -1
    x13       c758                -1   c764                 1
    x13       c825                -1   c833                 1
    x14       c4                   1   c31                 -1
    x14       c36                 -1   c72                 -1
    x14       c102                -1   c115                 1
    x14       c153                 1   c175                -1
    x14       c179                -1   c181                -1
    x14       c183                 1   c203                 1
    x14       c223                -1   c225                 1
    x14       c245                 1   c255                -1
    x14       c275                -1   c294                -1
    x14       c311                -1   c362                 1
    x14       c381                -1   c399                -1
    x14       c401                -1   c420                 1
    x14       c431                 1   c459                 1
    x14       c460                 1   c506                -1
    x14       c519                -1   c614                 1
    x14       c620                 1   c655                 1
    x14       c688                 1   c751                -1
    x14       c800                -1   c808                 1
    x14       c824                -1   c827                -1
    x15       c5                   1   c17                 -1
    x15       c21                 -1   c27                  1
    x15       c51                 -1   c90                  1
    x15       c106                -1   c117                -1
    x15       c127                -1   c155                 1
    x15       c169                -1   c183                -1
    x15       c200                -1   c208                 1
    x15       c229                -1   c251                 1
    x15       c270                -1   c350                 1
    x15       c368                -1   c373                -1
    x15       c423                -1   c450                 1
    x15       c452                 1   c472                 1
    x15       c501                -1   c510                 1
    x15       c531                -1   c584                -1
    x15       c609                -1   c613                -1
    x15       c639                -1   c640                 1
    x15       c679                 1   c698                 1
    x15       c755                -1   c764                 1
    x15       c768                 1   c774                 1
    x15       c801                 1
    x16       c5                  -1   c12                 -1
    x16       c15                  1   c44                 -1
    x16       c68                  1   c78                 -1
    x16       c112                 1   c138                 1
    x16       c156                 1   c175                -1
    x16       c224                 1   c231                 1
    x16       c244                -1   c277                -1
    x16       c291                -1   c302                -1
    x16       c322                -1   c332                -1
    x16       c338                 1   c346                -1
    x16       c363                -1   c396                 1
    x16       c400                 1   c401                 1
    x16       c415                 1   c438                -1
    x16       c472                 1   c555                 1
    x16       c587                -1   c592                 1
    x16       c595                -1   c605                -1
    x16       c674                -1   c700                 1
    x16       c708                -1   c754                -1
    x16       c776                 1   c809                 1
    x16       c810                 1   c817                 1
    x16       c831                -1   c836                 1
    x16       c842                 1   c847                 1
    x17       c6                   1   c12                  1
    x17       c38                  1   c91                  1
    x17       c120                -1   c123                -1
    x17       c156                 1   c159                 1
    x17       c192                -1   c211                -1
    x17       c258                 1   c275                -1
    x17       c315                 1   c329                -1
    x17       c342                 1   c410                -1
    x17       c427                 1   c450                 1
    x17       c484                -1   c486                 1
    x17       c503                -1   c520                 1
    x17       c544                -1   c546                 1
    x17       c553                 1   c583                -1
    x17       c635                -1   c646                -1
    x17       c652                -1   c669                -1
    x17       c692                -1   c705                 1
    x17       c706                 1   c712                 1
    x17       c714                 1   c734                -1
    x17       c776                -1   c782                -1
    x17       c787                -1   c810                 1
    x17       c814                 1   c829                -1
    x17       c843                -1
    x18       c6                   1   c33                  1
    x18       c81                  1   c83                 -1
    x18       c90                  1   c92                 -1
    x18       c94                  1   c137                 1
    x18       c138                 1   c151                -1
    x18       c154                 1   c210                -1
    x18       c254                 1   c257                -1
    x18       c265                 1   c285                -1
    x18       c308                 1   c358                -1
    x18       c364                 1   c369                 1
    x18       c390                -1   c409                 1
    x18       c410                 1   c420                -1
    x18       c439                 1   c449                -1
    x18       c545                 1   c574                 1
    x18       c632                 1   c652                -1
    x18       c668                -1   c682                 1
    x18       c694                -1   c704                 1
    x18       c710                 1   c716                 1
    x18       c717                 1   c749                 1
    x18       c761                -1   c809                -1
    x19       c6                  -1   c12                  1
    x19       c23                  1   c55                  1
    x19       c64                 -1   c73                  1
    x19       c74                  1   c79                 -1
    x19       c99                  1   c122                -1
    x19       c159                -1   c211                -1
    x19       c217                 1   c232                -1
    x19       c267                -1   c311                 1
    x19       c325                -1   c394                -1
    x19       c471                 1   c473                -1
    x19       c478                -1   c487                 1
    x19       c493                -1   c502                -1
    x19       c514                 1   c529                 1
    x19       c555                 1   c594                 1
    x19       c600                -1   c621                -1
    x19       c645                -1   c709                 1
    x19       c734                -1   c785                -1
    x19       c790                -1   c823                -1
    x20       c6                   1   c38                 -1
    x20       c72                  1   c101                 1
    x20       c151                -1   c158                -1
    x20       c160                -1   c171                -1
    x20       c182                 1   c251                 1
    x20       c284                -1   c297                 1
    x20       c304                -1   c342                 1
    x20       c348                -1   c361                -1
    x20       c369                 1   c383                -1
    x20       c414                 1   c431                 1
    x20       c454                 1   c474                -1
    x20       c477                -1   c526                 1
    x20       c531                 1   c609                -1
    x20       c612                -1   c616                 1
    x20       c619                 1   c650                 1
    x20       c715                -1   c729                -1
    x20       c734                -1   c782                 1
    x20       c804                -1
    x21       c7                   1   c34                  1
    x21       c107                 1   c152                 1
    x21       c166                -1   c194                 1
    x21       c221                -1   c226                -1
    x21       c263                -1   c293                -1
    x21       c305                 1   c343                 1
    x21       c365                -1   c368                -1
    x21       c370                -1   c372                 1
    x21       c392                 1   c413                -1
    x21       c415                 1   c434                 1
    x21       c444                -1   c464                -1
    x21       c484                -1   c501                -1
    x21       c552                 1   c571                -1
    x21       c589                -1   c591                -1
    x21       c610                 1   c620                 1
    x21       c648                 1   c649                 1
    x21       c696                -1   c709                -1
    x21       c804                 1   c810                 1
    x21       c845                 1
    x22       c7                   1   c16                 -1
    x22       c27                  1   c30                  1
    x22       c40                 -1   c60                  1
    x22       c81                  1   c122                -1
    x22       c137                -1   c147                 1
    x22       c171                 1   c172                -1
    x22       c183                 1   c214                 1
    x22       c246                -1   c273                -1
    x22       c297                -1   c303                -1
    x22       c307                -1   c309                 1
    x22       c319                -1   c325                 1
    x22       c352                 1   c360                -1
    x22       c367                -1   c369                -1
    x22       c374                -1   c382                -1
    x22       c418                -1   c438                -1
    x22       c448                -1   c539                 1
    x22       c554                -1   c579                 1
    x22       c609                -1   c610                -1
    x22       c628                 1   c681                 1
    x22       c690                 1   c722                 1
    x22       c777                 1   c802                -1
    x22       c811                 1   c821                 1
    x22       c835                -1   c850                 1
    x23       c7                   1   c39                  1
    x23       c53                 -1   c57                 -1
    x23       c129                 1   c136                 1
    x23       c184                 1   c209                -1
    x23       c312                -1   c316                -1
    x23       c319                 1   c338                -1
    x23       c376                -1   c440                -1
    x23       c455                 1   c490                 1
    x23       c514                 1   c548                 1
    x23       c570                 1   c572                 1
    x23       c597                 1   c608                -1
    x23       c622                -1   c685                -1
    x23       c698                 1   c703                -1
    x23       c706                 1   c710                 1
    x23       c723                 1   c734                 1
    x23       c750                 1   c758                 1
    x23       c800                -1   c833                 1
    x23       c835                -1
    x24       c7                   1   c32                  1
    x24       c61                 -1   c76                  1
    x24       c110                -1   c116                 1
    x24       c198                 1   c230                 1
    x24       c244                -1   c248                -1
    x24       c320                 1   c327                 1
    x24       c374                 1   c399                -1
    x24       c503                -1   c507                -1
    x24       c510                 1   c529                -1
    x24       c567                -1   c630                -1
    x24       c645                 1   c681                 1
    x24       c705                 1   c738                 1
    x24       c760                 1   c762                 1
    x24       c787                 1   c798                -1
    x24       c813                -1
    x25       c7                   1   c35                  1
    x25       c39                  1   c110                 1
    x25       c111                -1   c158                -1
    x25       c187                 1   c269                -1
    x25       c277                -1   c282                -1
    x25       c349                -1   c375                -1
    x25       c410                -1   c414                -1
    x25       c458                 1   c460                -1
    x25       c470                -1   c495                 1
    x25       c503                 1   c510                -1
    x25       c514                -1   c526                 1
    x25       c527                 1   c564                -1
    x25       c572                -1   c593                -1
    x25       c607                 1   c627                 1
    x25       c632                -1   c641                -1
    x25       c656                 1   c685                -1
    x25       c698                 1   c729                 1
    x25       c744                 1   c797                 1
    x25       c819                -1
    x26       c8                   1   c85                  1
    x26       c96                  1   c133                -1
    x26       c138                -1   c154                 1
    x26       c183                 1   c253                 1
    x26       c272                 1   c286                -1
    x26       c290                -1   c325                -1
    x26       c393                 1   c456                -1
    x26       c538                 1   c558                 1
    x26       c561                 1   c604                 1
    x26       c636                 1   c649                 1
    x26       c671                 1   c678                 1
    x26       c690                 1   c718                -1
    x26       c738                 1   c757                -1
    x26       c772                -1   c806                 1
    x26       c812                 1   c837                 1
    x27       c8                  -1   c84                  1
    x27       c100                 1   c118                 1
    x27       c143                -1   c156                -1
    x27       c167                -1   c207                -1
    x27       c255                -1   c264                -1
    x27       c277                -1   c280                -1
    x27       c284                -1   c314                -1
    x27       c319                 1   c330                -1
    x27       c333                -1   c344                -1
    x27       c390                -1   c419                 1
    x27       c421                -1   c471                 1
    x27       c483                -1   c490                 1
    x27       c502                 1   c508                 1
    x27       c520                -1   c553                -1
    x27       c576                -1   c583                -1
    x27       c586                 1   c616                -1
    x27       c639                 1   c649                -1
    x27       c684                 1   c710                 1
    x27       c727                 1   c746                -1
    x27       c795                 1   c802                 1
    x27       c814                -1   c847                -1
    x28       c8                   1   c14                 -1
    x28       c78                 -1   c95                  1
    x28       c100                 1   c102                -1
    x28       c124                -1   c134                -1
    x28       c140                -1   c182                 1
    x28       c192                -1   c225                 1
    x28       c236                -1   c240                 1
    x28       c254                 1   c260                -1
    x28       c277                 1   c324                 1
    x28       c326                 1   c329                -1
    x28       c342                 1   c363                 1
    x28       c377                -1   c413                 1
    x28       c423                -1   c457                -1
    x28       c460                 1   c474                 1
    x28       c484                 1   c491                 1
    x28       c495                -1   c496                -1
    x28       c513                -1   c549                 1
    x28       c568                -1   c629                 1
    x28       c645                 1   c654                 1
    x28       c720                -1   c727                -1
    x28       c758                -1   c774                 1
    x28       c783                -1   c823                -1
    x28       c832                 1   c837                 1
    x29       c8                   1   c37                 -1
    x29       c38                 -1   c58                  1
    x29       c109                 1   c118                 1
    x29       c151                 1   c207                 1
    x29       c231                -1   c241                 1
    x29       c251                 1   c265                -1
    x29       c280                 1   c295                -1
    x29       c313                 1   c323                -1
    x29       c328                -1   c337                -1
    x29       c378                 1   c391                 1
    x29       c392                -1   c408                 1
    x29       c424                -1   c429                 1
    x29       c430                 1   c441                -1
    x29       c455                -1   c460                 1
    x29       c485                 1   c503                 1
    x29       c511                -1   c584                -1
    x29       c603                -1   c626                 1
    x29       c630                -1   c710                -1
    x29       c744                 1
    x30       c9                  -1   c27                  1
    x30       c28                  1   c38                 -1
    x30       c58                  1   c67                 -1
    x30       c163                 1   c193                 1
    x30       c252                 1   c272                -1
    x30       c288                -1   c300                 1
    x30       c312                -1   c322                 1
    x30       c328                 1   c334                 1
    x30       c335                 1   c368                 1
    x30       c380                -1   c428                -1
    x30       c471                 1   c489                -1
    x30       c501                 1   c533                -1
    x30       c537                 1   c552                -1
    x30       c557                 1   c569                 1
    x30       c593                -1   c603                -1
    x30       c610                 1   c619                 1
    x30       c652                 1   c655                 1
    x30       c684                -1   c716                 1
    x30       c727                -1   c730                 1
    x30       c735                -1   c777                 1
    x30       c794                 1   c825                -1
    x31       c9                  -1   c17                  1
    x31       c38                 -1   c60                  1
    x31       c78                 -1   c159                 1
    x31       c178                -1   c183                -1
    x31       c232                -1   c260                 1
    x31       c262                 1   c282                 1
    x31       c310                -1   c319                 1
    x31       c340                -1   c393                -1
    x31       c418                -1   c422                -1
    x31       c449                -1   c450                 1
    x31       c488                 1   c507                 1
    x31       c565                -1   c574                 1
    x31       c578                 1   c584                 1
    x31       c611                 1   c663                 1
    x31       c693                -1   c696                -1
    x31       c728                 1   c731                 1
    x31       c763                -1   c783                -1
    x31       c829                 1   c846                -1
    x32       c10                  1   c33                 -1
    x32       c115                 1   c116                -1
    x32       c124                -1   c127                 1
    x32       c129                 1   c130                -1
    x32       c178                -1   c211                -1
    x32       c213                -1   c233                 1
    x32       c242                 1   c289                 1
    x32       c317                -1   c335                -1
    x32       c392                -1   c399                 1
    x32       c416                -1   c433                -1
    x32       c461                -1   c465                 1
    x32       c501                -1   c511                 1
    x32       c532                -1   c587                -1
    x32       c605                 1   c610                -1
    x32       c620                -1   c625                 1
    x32       c642                 1   c666                 1
    x32       c674                 1   c709                -1
    x32       c725                 1   c762                 1
    x32       c769                 1   c797                 1
    x33       c10                  1   c11                 -1
    x33       c26                  1   c42                 -1
    x33       c48                  1   c49                  1
    x33       c60                 -1   c73                 -1
    x33       c78                  1   c102                 1
    x33       c121                 1   c129                -1
    x33       c203                -1   c221                -1
    x33       c246                 1   c250                -1
    x33       c328                -1   c363                 1
    x33       c498                -1   c509                 1
    x33       c522                 1   c530                 1
    x33       c535                 1   c537                -1
    x33       c547                -1   c562                -1
    x33       c565                -1   c572                -1
    x33       c583                 1   c606                 1
    x33       c616                 1   c648                 1
    x33       c649                 1   c660                 1
    x33       c668                 1   c670                -1
    x33       c697                -1   c699                 1
    x33       c711                -1   c730                 1
    x33       c733                -1   c744                 1
    x33       c775                -1   c796                -1
    x33       c797                -1   c811                -1
    x33       c822                 1   c844                 1
    x34       c10                 -1   c38                  1
    x34       c40                 -1   c90                  1
    x34       c101                -1   c109                 1
    x34       c121                 1   c127                 1
    x34       c139                -1   c155                 1
    x34       c172                -1   c196                -1
    x34       c203                -1   c206                 1
    x34       c235                -1   c260                 1
    x34       c270                -1   c303                 1
    x34       c329                 1   c347                 1
    x34       c366                -1   c415                 1
    x34       c422                 1   c434                -1
    x34       c467                -1   c481                -1
    x34       c493                -1   c513                -1
    x34       c523                -1   c529                 1
    x34       c537                -1   c554                -1
    x34       c587                 1   c591                 1
    x34       c592                 1   c606                 1
    x34       c628                -1   c662                 1
    x34       c745                 1   c777                -1
    x34       c782                 1   c785                -1
    x34       c795                -1
    x35       c11                 -1   c18                  1
    x35       c34                 -1   c52                 -1
    x35       c79                 -1   c83                  1
    x35       c119                -1   c129                 1
    x35       c150                -1   c206                -1
    x35       c223                 1   c228                -1
    x35       c240                -1   c245                 1
    x35       c262                 1   c286                 1
    x35       c293                 1   c327                -1
    x35       c344                 1   c381                 1
    x35       c388                 1   c416                 1
    x35       c489                 1   c534                 1
    x35       c548                -1   c575                 1
    x35       c603                -1   c608                -1
    x35       c643                -1   c674                -1
    x35       c687                 1   c724                 1
    x35       c746                -1   c749                -1
    x35       c751                -1   c753                 1
    x35       c773                 1   c794                -1
    x35       c796                 1   c815                 1
    x35       c825                -1   c845                -1
    x36       c11                  1   c33                  1
    x36       c43                  1   c76                  1
    x36       c77                  1   c88                  1
    x36       c96                  1   c98                 -1
    x36       c124                -1   c126                 1
    x36       c138                -1   c158                 1
    x36       c160                -1   c172                 1
    x36       c204                -1   c224                -1
    x36       c225                -1   c240                -1
    x36       c251                 1   c273                 1
    x36       c300                -1   c320                 1
    x36       c332                 1   c334                 1
    x36       c335                -1   c336                -1
    x36       c358                 1   c374                -1
    x36       c398                 1   c399                 1
    x36       c401                 1   c404                 1
    x36       c410                 1   c428                -1
    x36       c440                 1   c469                -1
    x36       c478                 1   c484                -1
    x36       c506                -1   c536                -1
    x36       c569                 1   c575                -1
    x36       c596                -1   c602                -1
    x36       c603                 1   c604                -1
    x36       c639                 1   c668                 1
    x36       c689                -1   c729                -1
    x36       c766                -1   c768                 1
    x37       c11                 -1   c43                  1
    x37       c51                  1   c75                  1
    x37       c94                 -1   c113                 1
    x37       c141                -1   c164                 1
    x37       c178                 1   c207                -1
    x37       c210                 1   c212                -1
    x37       c216                 1   c221                -1
    x37       c254                 1   c278                -1
    x37       c280                 1   c311                -1
    x37       c315                 1   c316                -1
    x37       c334                -1   c358                 1
    x37       c379                 1   c380                 1
    x37       c385                 1   c429                -1
    x37       c442                 1   c456                 1
    x37       c486                -1   c487                -1
    x37       c493                 1   c518                -1
    x37       c567                 1   c582                 1
    x37       c606                -1   c688                 1
    x37       c689                -1   c697                -1
    x37       c700                 1   c702                 1
    x37       c703                -1   c749                -1
    x37       c783                -1   c785                -1
    x37       c806                 1   c813                 1
    x38       c11                 -1   c24                  1
    x38       c118                -1   c152                 1
    x38       c156                -1   c168                 1
    x38       c178                 1   c195                -1
    x38       c270                -1   c393                -1
    x38       c433                 1   c437                 1
    x38       c459                -1   c481                 1
    x38       c489                 1   c562                -1
    x38       c568                -1   c574                 1
    x38       c634                -1   c642                 1
    x38       c674                 1   c677                 1
    x38       c686                -1   c730                 1
    x38       c754                 1   c762                 1
    x38       c769                 1   c795                 1
    x38       c823                -1   c839                 1
    x39       c12                  1   c20                 -1
    x39       c61                 -1   c69                  1
    x39       c74                  1   c93                  1
    x39       c103                -1   c148                -1
    x39       c156                -1   c168                -1
    x39       c177                 1   c199                 1
    x39       c277                 1   c288                 1
    x39       c324                -1   c329                -1
    x39       c345                 1   c373                 1
    x39       c443                 1   c462                 1
    x39       c476                -1   c480                -1
    x39       c516                -1   c584                 1
    x39       c646                -1   c728                 1
    x39       c748                 1   c751                 1
    x39       c794                 1   c827                 1
    x39       c840                 1
    x40       c12                  1   c37                 -1
    x40       c49                  1   c65                  1
    x40       c69                 -1   c71                 -1
    x40       c81                  1   c95                  1
    x40       c106                 1   c113                 1
    x40       c119                 1   c122                 1
    x40       c174                -1   c193                -1
    x40       c199                -1   c276                 1
    x40       c292                 1   c309                 1
    x40       c334                -1   c347                -1
    x40       c359                -1   c397                -1
    x40       c445                -1   c454                -1
    x40       c467                -1   c470                -1
    x40       c474                -1   c505                -1
    x40       c510                 1   c521                -1
    x40       c524                -1   c535                -1
    x40       c581                -1   c610                 1
    x40       c612                -1   c661                 1
    x40       c673                -1   c681                 1
    x40       c693                 1   c699                 1
    x40       c711                -1   c743                -1
    x40       c766                -1   c773                -1
    x40       c776                 1   c807                -1
    x40       c830                 1   c840                -1
    x41       c12                 -1   c36                 -1
    x41       c40                 -1   c67                 -1
    x41       c68                  1   c106                 1
    x41       c125                 1   c184                -1
    x41       c193                 1   c197                 1
    x41       c203                 1   c229                 1
    x41       c283                 1   c311                -1
    x41       c314                -1   c347                 1
    x41       c350                 1   c382                -1
    x41       c402                -1   c448                 1
    x41       c465                -1   c506                 1
    x41       c520                -1   c533                 1
    x41       c601                -1   c617                 1
    x41       c640                 1   c674                -1
    x41       c676                 1   c694                -1
    x41       c711                 1   c734                -1
    x41       c736                 1   c743                 1
    x41       c773                -1   c826                -1
    x41       c837                -1   c843                -1
    x42       c12                 -1   c30                 -1
    x42       c55                  1   c59                 -1
    x42       c137                -1   c172                 1
    x42       c307                -1   c318                 1
    x42       c331                 1   c339                 1
    x42       c344                 1   c346                -1
    x42       c357                -1   c371                -1
    x42       c374                -1   c381                -1
    x42       c392                 1   c415                 1
    x42       c425                 1   c458                 1
    x42       c459                 1   c470                 1
    x42       c478                 1   c480                -1
    x42       c506                -1   c508                 1
    x42       c520                -1   c540                 1
    x42       c543                -1   c554                 1
    x42       c585                -1   c606                -1
    x42       c607                -1   c620                -1
    x42       c631                 1   c653                 1
    x42       c682                -1   c702                 1
    x42       c714                 1   c716                 1
    x42       c717                -1   c718                -1
    x42       c738                 1   c755                -1
    x42       c779                 1   c780                 1
    x42       c782                 1   c785                 1
    x42       c791                 1   c809                -1
    x42       c821                 1   c850                -1
    x43       c12                 -1   c52                  1
    x43       c56                  1   c77                 -1
    x43       c99                  1   c107                 1
    x43       c181                -1   c187                -1
    x43       c193                 1   c254                -1
    x43       c262                 1   c293                 1
    x43       c296                 1   c304                -1
    x43       c349                 1   c373                 1
    x43       c381                 1   c388                 1
    x43       c414                 1   c442                -1
    x43       c458                 1   c492                -1
    x43       c498                 1   c579                 1
    x43       c612                 1   c624                -1
    x43       c628                -1   c702                 1
    x43       c709                 1   c755                 1
    x43       c780                -1
    x44       c12                  1   c15                  1
    x44       c22                 -1   c42                  1
    x44       c67                 -1   c90                 -1
    x44       c135                -1   c145                -1
    x44       c188                -1   c221                -1
    x44       c225                -1   c246                 1
    x44       c267                 1   c332                 1
    x44       c350                 1   c354                 1
    x44       c357                 1   c359                 1
    x44       c396                 1   c407                 1
    x44       c431                 1   c443                 1
    x44       c464                -1   c523                -1
    x44       c539                -1   c567                 1
    x44       c580                 1   c586                -1
    x44       c650                -1   c667                 1
    x44       c672                 1   c675                -1
    x44       c697                -1   c707                -1
    x44       c713                -1   c753                 1
    x44       c763                -1   c797                 1
    x44       c808                -1   c811                 1
    x44       c825                 1   c831                -1
    x44       c848                 1
    x45       c12                 -1   c65                 -1
    x45       c75                 -1   c81                 -1
    x45       c98                 -1   c120                -1
    x45       c133                 1   c134                 1
    x45       c140                 1   c142                 1
    x45       c163                -1   c206                -1
    x45       c211                -1   c216                -1
    x45       c240                 1   c244                 1
    x45       c259                -1   c273                -1
    x45       c285                -1   c295                 1
    x45       c309                 1   c352                -1
    x45       c387                -1   c393                 1
    x45       c405                 1   c436                 1
    x45       c445                -1   c455                 1
    x45       c456                 1   c461                -1
    x45       c481                 1   c504                -1
    x45       c541                -1   c593                -1
    x45       c599                 1   c614                -1
    x45       c647                -1   c693                 1
    x45       c707                -1   c775                -1
    x46       c12                  1   c32                 -1
    x46       c34                  1   c54                  1
    x46       c64                 -1   c83                 -1
    x46       c102                -1   c120                -1
    x46       c171                 1   c191                -1
    x46       c209                -1   c210                -1
    x46       c229                 1   c241                 1
    x46       c269                 1   c270                 1
    x46       c315                -1   c328                -1
    x46       c423                 1   c430                 1
    x46       c465                 1   c497                 1
    x46       c561                -1   c610                -1
    x46       c617                 1   c633                -1
    x46       c636                -1   c687                -1
    x46       c701                 1   c705                -1
    x46       c712                 1   c724                 1
    x46       c726                 1   c735                 1
    x46       c736                -1   c747                 1
    x46       c761                 1   c768                 1
    x46       c796                 1   c844                 1
    x46       c846                -1
    x47       c13                  1   c70                  1
    x47       c123                -1   c131                 1
    x47       c143                 1   c151                -1
    x47       c155                -1   c203                 1
    x47       c228                -1   c240                 1
    x47       c256                 1   c261                -1
    x47       c263                -1   c273                 1
    x47       c287                 1   c298                 1
    x47       c304                 1   c310                 1
    x47       c313                 1   c365                -1
    x47       c383                -1   c389                -1
    x47       c466                 1   c482                 1
    x47       c500                 1   c525                -1
    x47       c538                -1   c549                -1
    x47       c588                -1   c635                -1
    x47       c644                -1   c657                -1
    x47       c660                -1   c664                -1
    x47       c696                -1   c701                 1
    x47       c712                -1   c715                -1
    x47       c725                -1   c771                -1
    x47       c800                 1   c802                -1
    x48       c13                 -1   c33                 -1
    x48       c34                 -1   c49                 -1
    x48       c60                  1   c81                  1
    x48       c109                -1   c129                 1
    x48       c141                 1   c143                 1
    x48       c144                -1   c145                -1
    x48       c166                 1   c184                -1
    x48       c208                 1   c209                 1
    x48       c210                 1   c213                 1
    x48       c219                 1   c238                -1
    x48       c250                 1   c279                -1
    x48       c288                 1   c293                -1
    x48       c315                -1   c345                -1
    x48       c378                 1   c384                -1
    x48       c405                -1   c411                -1
    x48       c412                 1   c413                -1
    x48       c449                 1   c478                 1
    x48       c498                -1   c539                -1
    x48       c576                -1   c578                 1
    x48       c664                 1   c665                 1
    x48       c674                 1   c682                 1
    x48       c693                 1   c695                 1
    x48       c727                 1   c767                 1
    x48       c800                -1   c834                 1
    x49       c13                 -1   c89                  1
    x49       c91                 -1   c96                 -1
    x49       c104                 1   c111                -1
    x49       c120                -1   c132                 1
    x49       c147                 1   c173                 1
    x49       c212                 1   c218                -1
    x49       c241                -1   c265                -1
    x49       c327                 1   c354                -1
    x49       c404                -1   c409                -1
    x49       c442                -1   c505                -1
    x49       c508                -1   c532                -1
    x49       c560                -1   c566                -1
    x49       c568                 1   c597                 1
    x49       c616                -1   c659                -1
    x49       c663                -1   c717                -1
    x49       c726                 1   c735                -1
    x49       c759                 1   c816                -1
    x49       c819                -1   c834                -1
    x50       c13                  1   c75                 -1
    x50       c157                 1   c178                 1
    x50       c181                 1   c194                -1
    x50       c223                 1   c257                 1
    x50       c270                 1   c292                 1
    x50       c298                 1   c309                 1
    x50       c337                -1   c359                 1
    x50       c377                -1   c392                -1
    x50       c425                 1   c432                 1
    x50       c457                 1   c476                -1
    x50       c495                 1   c523                -1
    x50       c546                 1   c559                 1
    x50       c588                -1   c592                 1
    x50       c594                -1   c598                 1
    x50       c603                -1   c634                 1
    x50       c658                -1   c660                 1
    x50       c693                -1   c697                 1
    x50       c698                -1   c716                -1
    x50       c738                 1   c760                 1
    x50       c761                 1   c766                 1
    x50       c810                -1   c823                 1
    x50       c837                 1
    x51       c14                  1   c26                  1
    x51       c39                 -1   c44                  1
    x51       c45                  1   c85                  1
    x51       c92                 -1   c94                 -1
    x51       c149                -1   c162                -1
    x51       c163                 1   c187                 1
    x51       c198                 1   c207                -1
    x51       c218                 1   c221                 1
    x51       c231                -1   c251                 1
    x51       c273                 1   c313                -1
    x51       c328                -1   c338                 1
    x51       c362                 1   c363                -1
    x51       c373                 1   c405                 1
    x51       c436                -1   c463                -1
    x51       c494                -1   c498                -1
    x51       c500                 1   c510                -1
    x51       c516                 1   c543                 1
    x51       c550                -1   c558                -1
    x51       c560                -1   c565                -1
    x51       c573                -1   c609                -1
    x51       c628                -1   c638                -1
    x51       c729                 1   c744                -1
    x51       c769                 1   c799                -1
    x51       c800                -1   c819                 1
    x52       c14                  1   c47                  1
    x52       c48                  1   c55                  1
    x52       c68                 -1   c73                  1
    x52       c79                  1   c84                  1
    x52       c90                  1   c128                 1
    x52       c143                 1   c193                -1
    x52       c195                -1   c196                 1
    x52       c217                -1   c218                 1
    x52       c245                 1   c282                 1
    x52       c321                -1   c335                 1
    x52       c362                 1   c368                 1
    x52       c395                 1   c408                 1
    x52       c421                -1   c426                 1
    x52       c427                 1   c467                 1
    x52       c474                -1   c476                -1
    x52       c531                -1   c544                -1
    x52       c545                 1   c568                 1
    x52       c579                 1   c588                -1
    x52       c600                 1   c603                 1
    x52       c613                -1   c631                 1
    x52       c653                 1   c695                -1
    x52       c710                -1   c719                 1
    x52       c743                 1   c744                -1
    x52       c754                 1   c786                 1
    x52       c817                -1   c844                -1
    x53       c15                 -1   c32                  1
    x53       c37                 -1   c49                 -1
    x53       c54                  1   c70                  1
    x53       c94                  1   c101                 1
    x53       c136                -1   c153                 1
    x53       c191                 1   c198                 1
    x53       c225                 1   c299                 1
    x53       c343                 1   c358                -1
    x53       c384                 1   c412                -1
    x53       c417                -1   c453                -1
    x53       c484                -1   c496                 1
    x53       c534                 1   c556                -1
    x53       c559                -1   c561                -1
    x53       c563                 1   c583                 1
    x53       c604                -1   c606                 1
    x53       c624                 1   c634                -1
    x53       c654                -1   c674                -1
    x53       c692                -1   c742                 1
    x53       c761                -1   c779                -1
    x53       c781                -1   c800                 1
    x53       c811                 1   c839                 1
    x53       c840                 1
    x54       c15                 -1   c19                  1
    x54       c22                 -1   c32                 -1
    x54       c101                -1   c127                 1
    x54       c135                -1   c183                -1
    x54       c205                 1   c238                 1
    x54       c239                 1   c246                 1
    x54       c260                -1   c265                 1
    x54       c271                 1   c276                 1
    x54       c282                 1   c319                 1
    x54       c334                 1   c383                -1
    x54       c385                -1   c386                 1
    x54       c408                -1   c409                 1
    x54       c435                 1   c472                 1
    x54       c512                -1   c526                 1
    x54       c553                 1   c559                 1
    x54       c586                 1   c599                 1
    x54       c612                -1   c617                 1
    x54       c657                 1   c664                -1
    x54       c666                -1   c721                -1
    x54       c734                -1   c735                 1
    x54       c758                 1   c769                 1
    x54       c778                -1   c790                 1
    x54       c793                 1   c803                -1
    x54       c822                 1   c844                 1
    x55       c15                  1   c25                  1
    x55       c50                  1   c62                  1
    x55       c82                 -1   c141                -1
    x55       c157                -1   c186                 1
    x55       c199                 1   c205                -1
    x55       c270                -1   c287                 1
    x55       c292                 1   c294                -1
    x55       c315                -1   c325                -1
    x55       c331                -1   c372                 1
    x55       c382                -1   c416                 1
    x55       c427                -1   c430                 1
    x55       c444                 1   c450                -1
    x55       c467                 1   c515                 1
    x55       c517                 1   c520                -1
    x55       c533                 1   c554                 1
    x55       c568                -1   c604                 1
    x55       c614                -1   c647                -1
    x55       c650                 1   c664                 1
    x55       c674                 1   c682                 1
    x55       c686                -1   c687                -1
    x55       c704                -1   c739                 1
    x55       c758                -1   c820                 1
    x55       c836                 1   c845                 1
    x56       c15                  1   c19                  1
    x56       c33                  1   c57                 -1
    x56       c90                  1   c173                 1
    x56       c206                -1   c210                 1
    x56       c213                -1   c223                -1
    x56       c293                -1   c318                 1
    x56       c326                -1   c373                -1
    x56       c395                 1   c428                 1
    x56       c429                 1   c436                 1
    x56       c450                -1   c455                 1
    x56       c461                 1   c466                 1
    x56       c472                 1   c510                 1
    x56       c525                 1   c574                -1
    x56       c576                -1   c577                 1
    x56       c599                -1   c600                 1
    x56       c625                 1   c662                 1
    x56       c703                -1   c717                 1
    x56       c743                 1   c749                 1
    x56       c776                 1   c789                 1
    x56       c802                -1   c808                 1
    x56       c848                 1
    x57       c15                 -1   c20                 -1
    x57       c25                 -1   c49                  1
    x57       c53                  1   c67                 -1
    x57       c81                 -1   c93                 -1
    x57       c103                 1   c118                 1
    x57       c160                -1   c197                -1
    x57       c203                 1   c214                 1
    x57       c246                 1   c255                -1
    x57       c265                 1   c266                 1
    x57       c271                -1   c291                 1
    x57       c313                -1   c350                -1
    x57       c402                -1   c408                 1
    x57       c423                -1   c457                -1
    x57       c502                 1   c516                -1
    x57       c585                -1   c661                 1
    x57       c663                -1   c668                -1
    x57       c677                 1   c684                -1
    x57       c693                -1   c705                 1
    x57       c719                 1   c745                 1
    x57       c784                 1   c790                -1
    x57       c812                -1   c836                -1
    x58       c16                 -1   c19                  1
    x58       c21                 -1   c25                  1
    x58       c30                 -1   c63                  1
    x58       c86                 -1   c88                  1
    x58       c120                -1   c124                 1
    x58       c125                -1   c143                -1
    x58       c166                 1   c189                 1
    x58       c190                 1   c195                 1
    x58       c237                 1   c239                -1
    x58       c252                 1   c266                 1
    x58       c295                -1   c296                -1
    x58       c302                 1   c327                -1
    x58       c376                 1   c391                 1
    x58       c415                -1   c497                 1
    x58       c498                -1   c506                -1
    x58       c509                 1   c511                 1
    x58       c512                -1   c559                -1
    x58       c593                -1   c595                -1
    x58       c615                 1   c622                 1
    x58       c669                 1   c699                -1
    x58       c717                -1   c773                -1
    x58       c780                 1   c797                -1
    x58       c814                -1   c842                -1
    x58       c846                 1
    x59       c16                  1   c32                  1
    x59       c64                 -1   c96                 -1
    x59       c169                -1   c186                -1
    x59       c198                 1   c226                 1
    x59       c230                 1   c301                 1
    x59       c302                -1   c349                -1
    x59       c377                 1   c459                -1
    x59       c467                -1   c472                -1
    x59       c540                -1   c566                -1
    x59       c601                -1   c605                -1
    x59       c648                 1   c650                -1
    x59       c660                -1   c686                 1
    x59       c694                 1   c701                -1
    x59       c705                -1   c717                 1
    x59       c718                 1   c754                -1
    x59       c762                -1   c783                -1
    x59       c797                 1   c818                 1
    x59       c823                -1   c832                -1
    x59       c847                 1
    x60       c17                  1   c18                  1
    x60       c19                  1   c22                  1
    x60       c28                  1   c47                 -1
    x60       c59                  1   c87                 -1
    x60       c96                  1   c101                -1
    x60       c124                -1   c154                -1
    x60       c188                 1   c194                -1
    x60       c214                -1   c220                -1
    x60       c221                 1   c222                -1
    x60       c259                 1   c288                 1
    x60       c307                -1   c348                -1
    x60       c385                -1   c387                 1
    x60       c474                 1   c475                 1
    x60       c484                 1   c491                 1
    x60       c502                 1   c504                 1
    x60       c537                 1   c577                 1
    x60       c610                -1   c643                 1
    x60       c673                 1   c722                -1
    x60       c729                -1   c732                -1
    x60       c742                -1   c752                 1
    x60       c821                 1
    x61       c17                 -1   c65                 -1
    x61       c73                 -1   c86                 -1
    x61       c89                 -1   c93                 -1
    x61       c124                -1   c129                 1
    x61       c140                -1   c143                -1
    x61       c154                -1   c201                -1
    x61       c229                 1   c231                -1
    x61       c282                 1   c293                -1
    x61       c300                 1   c312                 1
    x61       c318                 1   c330                -1
    x61       c346                 1   c363                -1
    x61       c386                -1   c393                -1
    x61       c396                 1   c426                -1
    x61       c450                 1   c460                -1
    x61       c494                 1   c520                 1
    x61       c538                 1   c557                -1
    x61       c606                 1   c613                 1
    x61       c624                -1   c657                -1
    x61       c671                -1   c684                -1
    x61       c704                -1   c714                -1
    x61       c719                 1   c727                -1
    x61       c744                -1   c777                 1
    x61       c781                 1   c782                 1
    x61       c796                 1   c819                -1
    x62       c18                 -1   c121                -1
    x62       c125                -1   c128                 1
    x62       c147                -1   c186                -1
    x62       c250                -1   c265                 1
    x62       c323                 1   c358                 1
    x62       c379                 1   c381                 1
    x62       c406                 1   c417                -1
    x62       c432                -1   c494                -1
    x62       c507                 1   c512                -1
    x62       c515                 1   c519                 1
    x62       c533                 1   c544                 1
    x62       c560                 1   c568                 1
    x62       c610                -1   c642                 1
    x62       c644                -1   c663                 1
    x62       c669                 1   c696                 1
    x62       c747                -1   c762                 1
    x62       c781                -1   c792                 1
    x62       c802                -1   c838                -1
    x63       c18                 -1   c19                 -1
    x63       c38                  1   c50                  1
    x63       c77                  1   c78                  1
    x63       c124                -1   c137                -1
    x63       c232                 1   c240                 1
    x63       c275                 1   c306                 1
    x63       c370                -1   c419                -1
    x63       c427                 1   c443                -1
    x63       c446                -1   c496                -1
    x63       c510                 1   c514                -1
    x63       c521                 1   c534                 1
    x63       c536                 1   c545                 1
    x63       c546                -1   c557                 1
    x63       c571                 1   c578                 1
    x63       c606                 1   c653                 1
    x63       c655                -1   c662                 1
    x63       c664                -1   c666                 1
    x63       c710                 1   c711                 1
    x63       c723                -1   c726                 1
    x63       c782                -1   c825                 1
    x63       c828                -1   c836                 1
    x64       c19                 -1   c63                  1
    x64       c66                 -1   c73                  1
    x64       c93                 -1   c117                 1
    x64       c166                -1   c173                 1
    x64       c179                 1   c200                -1
    x64       c218                 1   c219                 1
    x64       c229                -1   c249                 1
    x64       c259                -1   c355                 1
    x64       c383                 1   c442                 1
    x64       c462                -1   c478                -1
    x64       c491                 1   c503                -1
    x64       c513                 1   c519                 1
    x64       c525                 1   c526                 1
    x64       c559                 1   c571                -1
    x64       c618                -1   c661                 1
    x64       c680                -1   c692                 1
    x64       c723                -1   c727                 1
    x64       c742                -1   c747                 1
    x64       c759                 1   c783                -1
    x64       c793                -1   c800                 1
    x64       c810                 1   c843                 1
    x64       c846                 1
    x65       c19                  1   c91                  1
    x65       c123                -1   c128                 1
    x65       c150                 1   c163                -1
    x65       c225                -1   c236                -1
    x65       c240                -1   c243                 1
    x65       c252                 1   c257                -1
    x65       c277                -1   c278                 1
    x65       c283                 1   c313                 1
    x65       c320                -1   c337                 1
    x65       c351                 1   c376                -1
    x65       c386                 1   c398                -1
    x65       c403                -1   c409                 1
    x65       c432                -1   c472                 1
    x65       c488                -1   c499                -1
    x65       c509                -1   c537                 1
    x65       c551                -1   c564                -1
    x65       c581                -1   c589                 1
    x65       c611                -1   c631                 1
    x65       c650                -1   c731                 1
    x65       c749                -1   c754                -1
    x65       c805                -1   c831                 1
    x65       c833                 1
    x66       c19                 -1   c30                  1
    x66       c40                 -1   c76                 -1
    x66       c97                  1   c110                 1
    x66       c112                 1   c128                -1
    x66       c175                 1   c182                -1
    x66       c183                 1   c188                -1
    x66       c207                 1   c239                -1
    x66       c268                -1   c270                -1
    x66       c291                -1   c303                 1
    x66       c307                 1   c360                -1
    x66       c372                -1   c383                 1
    x66       c393                 1   c396                 1
    x66       c404                -1   c424                 1
    x66       c449                -1   c472                -1
    x66       c517                -1   c527                -1
    x66       c569                -1   c603                -1
    x66       c607                -1   c626                 1
    x66       c647                 1   c714                 1
    x66       c731                 1   c734                 1
    x66       c737                 1   c739                 1
    x66       c777                 1   c788                 1
    x66       c812                 1   c824                 1
    x66       c845                -1
    x67       c20                 -1   c30                 -1
    x67       c37                  1   c48                  1
    x67       c80                  1   c83                  1
    x67       c111                -1   c143                 1
    x67       c155                -1   c158                 1
    x67       c163                -1   c206                 1
    x67       c222                 1   c254                -1
    x67       c287                -1   c360                -1
    x67       c375                -1   c387                 1
    x67       c416                 1   c420                 1
    x67       c491                 1   c492                -1
    x67       c539                -1   c567                 1
    x67       c648                -1   c656                -1
    x67       c661                -1   c729                -1
    x67       c755                -1   c790                -1
    x67       c794                -1   c838                 1
    x67       c840                -1   c850                -1
    x68       c20                 -1   c22                 -1
    x68       c42                  1   c51                  1
    x68       c97                  1   c126                -1
    x68       c144                -1   c202                -1
    x68       c209                 1   c225                -1
    x68       c243                -1   c271                -1
    x68       c275                 1   c310                -1
    x68       c320                 1   c341                -1
    x68       c396                -1   c414                 1
    x68       c419                -1   c430                -1
    x68       c435                 1   c452                 1
    x68       c476                 1   c484                 1
    x68       c518                -1   c535                 1
    x68       c572                 1   c579                 1
    x68       c607                 1   c680                 1
    x68       c724                 1   c738                -1
    x68       c765                 1   c793                -1
    x68       c798                -1   c834                -1
    x69       c20                 -1   c26                  1
    x69       c41                 -1   c75                 -1
    x69       c120                 1   c134                -1
    x69       c204                -1   c281                 1
    x69       c283                -1   c288                -1
    x69       c296                 1   c302                -1
    x69       c311                -1   c323                 1
    x69       c338                 1   c364                 1
    x69       c403                 1   c409                -1
    x69       c431                -1   c455                -1
    x69       c518                 1   c544                -1
    x69       c595                -1   c600                -1
    x69       c632                -1   c696                -1
    x69       c699                -1   c722                -1
    x69       c750                -1   c756                -1
    x69       c758                 1   c787                 1
    x69       c807                -1   c850                -1
    x70       c20                 -1   c34                  1
    x70       c56                  1   c61                 -1
    x70       c69                 -1   c84                  1
    x70       c112                -1   c125                 1
    x70       c157                 1   c172                 1
    x70       c225                 1   c248                -1
    x70       c298                 1   c322                 1
    x70       c328                -1   c329                 1
    x70       c334                -1   c336                 1
    x70       c358                -1   c380                 1
    x70       c403                 1   c422                 1
    x70       c449                 1   c500                -1
    x70       c503                -1   c510                 1
    x70       c538                -1   c588                 1
    x70       c606                 1   c625                 1
    x70       c692                -1   c696                -1
    x70       c706                 1   c721                 1
    x70       c748                -1   c751                -1
    x70       c761                 1   c775                 1
    x70       c833                 1
    x71       c21                  1   c27                 -1
    x71       c50                 -1   c73                 -1
    x71       c136                 1   c162                -1
    x71       c213                -1   c218                -1
    x71       c252                -1   c314                -1
    x71       c317                -1   c341                -1
    x71       c369                -1   c375                -1
    x71       c377                 1   c406                 1
    x71       c425                -1   c469                -1
    x71       c473                -1   c526                -1
    x71       c536                 1   c545                -1
    x71       c569                 1   c625                -1
    x71       c628                -1   c643                -1
    x71       c677                 1   c686                 1
    x71       c723                 1   c726                -1
    x71       c744                -1   c748                 1
    x71       c762                 1   c764                -1
    x71       c765                 1   c767                -1
    x71       c816                 1   c829                -1
    x72       c21                  1   c40                  1
    x72       c67                  1   c118                -1
    x72       c121                -1   c128                 1
    x72       c156                -1   c207                 1
    x72       c224                 1   c245                 1
    x72       c310                -1   c314                -1
    x72       c324                 1   c340                 1
    x72       c367                -1   c370                -1
    x72       c380                 1   c394                 1
    x72       c452                 1   c505                -1
    x72       c513                 1   c525                 1
    x72       c533                -1   c537                -1
    x72       c584                 1   c610                -1
    x72       c620                 1   c636                 1
    x72       c641                -1   c643                -1
    x72       c653                 1   c667                 1
    x72       c679                 1   c686                 1
    x72       c692                 1   c695                 1
    x72       c746                -1   c764                -1
    x72       c770                -1   c847                 1
    x73       c21                 -1   c67                  1
    x73       c84                 -1   c125                 1
    x73       c139                -1   c152                 1
    x73       c220                -1   c237                 1
    x73       c261                 1   c294                -1
    x73       c296                 1   c313                -1
    x73       c330                 1   c355                -1
    x73       c357                 1   c363                 1
    x73       c393                -1   c446                -1
    x73       c457                -1   c463                -1
    x73       c480                -1   c502                -1
    x73       c515                 1   c516                 1
    x73       c522                 1   c524                 1
    x73       c545                -1   c587                -1
    x73       c593                -1   c598                -1
    x73       c620                 1   c624                 1
    x73       c639                -1   c653                -1
    x73       c665                -1   c676                 1
    x73       c691                 1   c733                -1
    x73       c768                -1   c774                 1
    x73       c786                 1   c817                 1
    x73       c826                -1   c836                 1
    x73       c837                 1   c842                -1
    x74       c23                  1   c55                 -1
    x74       c81                 -1   c105                -1
    x74       c112                -1   c116                -1
    x74       c118                 1   c128                -1
    x74       c134                 1   c160                 1
    x74       c168                -1   c177                -1
    x74       c179                -1   c184                -1
    x74       c192                -1   c227                -1
    x74       c248                -1   c258                -1
    x74       c348                 1   c363                -1
    x74       c388                 1   c418                -1
    x74       c419                -1   c438                 1
    x74       c490                 1   c499                 1
    x74       c532                 1   c587                 1
    x74       c612                -1   c620                 1
    x74       c630                 1   c644                -1
    x74       c659                 1   c675                -1
    x74       c694                 1   c704                -1
    x74       c709                -1   c718                -1
    x74       c758                 1   c771                 1
    x74       c772                -1   c788                 1
    x74       c805                -1   c809                 1
    x74       c810                 1   c821                -1
    x74       c835                -1   c840                 1
    x75       c24                  1   c35                 -1
    x75       c51                 -1   c112                -1
    x75       c125                 1   c130                -1
    x75       c133                 1   c137                 1
    x75       c151                 1   c162                 1
    x75       c179                 1   c187                 1
    x75       c228                -1   c262                 1
    x75       c264                -1   c283                 1
    x75       c289                 1   c314                 1
    x75       c366                -1   c381                 1
    x75       c400                -1   c411                 1
    x75       c421                -1   c457                -1
    x75       c478                 1   c491                 1
    x75       c493                 1   c509                -1
    x75       c556                 1   c562                -1
    x75       c563                 1   c568                -1
    x75       c574                 1   c587                 1
    x75       c618                -1   c647                -1
    x75       c649                -1   c670                -1
    x75       c684                 1   c688                 1
    x75       c739                -1   c752                -1
    x75       c763                 1   c773                 1
    x75       c776                 1   c784                -1
    x75       c805                 1   c829                -1
    x76       c24                  1   c43                 -1
    x76       c87                 -1   c91                 -1
    x76       c144                -1   c154                 1
    x76       c163                -1   c188                 1
    x76       c245                -1   c248                -1
    x76       c263                -1   c296                 1
    x76       c304                 1   c342                 1
    x76       c345                -1   c363                -1
    x76       c367                 1   c381                 1
    x76       c383                -1   c384                 1
    x76       c386                -1   c435                 1
    x76       c448                -1   c473                 1
    x76       c486                -1   c489                -1
    x76       c494                 1   c502                -1
    x76       c508                -1   c518                -1
    x76       c521                 1   c534                -1
    x76       c553                -1   c555                 1
    x76       c557                 1   c575                 1
    x76       c608                -1   c632                -1
    x76       c660                -1   c664                 1
    x76       c670                 1   c677                 1
    x76       c685                -1   c691                 1
    x76       c718                -1   c724                -1
    x76       c733                -1   c772                -1
    x76       c786                 1
    x77       c28                 -1   c32                 -1
    x77       c76                  1   c78                 -1
    x77       c88                 -1   c113                 1
    x77       c121                 1   c128                -1
    x77       c132                -1   c144                 1
    x77       c145                 1   c183                -1
    x77       c191                -1   c211                -1
    x77       c225                 1   c247                 1
    x77       c252                -1   c261                -1
    x77       c276                 1   c303                -1
    x77       c316                 1   c348                 1
    x77       c363                 1   c416                 1
    x77       c438                -1   c488                 1
    x77       c513                 1   c519                -1
    x77       c520                 1   c525                -1
    x77       c527                 1   c548                -1
    x77       c571                 1   c594                 1
    x77       c613                 1   c639                 1
    x77       c691                -1   c694                -1
    x77       c701                 1   c728                -1
    x77       c778                 1   c796                 1
    x77       c816                 1
    x78       c29                 -1   c46                  1
    x78       c69                  1   c102                -1
    x78       c104                 1   c122                -1
    x78       c139                 1   c163                -1
    x78       c165                 1   c172                 1
    x78       c203                -1   c256                -1
    x78       c267                -1   c273                -1
    x78       c290                -1   c311                -1
    x78       c324                 1   c325                 1
    x78       c331                 1   c333                 1
    x78       c355                -1   c396                -1
    x78       c402                -1   c407                -1
    x78       c430                 1   c434                 1
    x78       c449                -1   c463                -1
    x78       c475                -1   c486                 1
    x78       c500                 1   c543                -1
    x78       c578                -1   c584                 1
    x78       c596                 1   c626                 1
    x78       c635                -1   c645                 1
    x78       c646                 1   c651                -1
    x78       c671                 1   c695                -1
    x78       c731                -1   c783                -1
    x78       c789                 1   c805                -1
    x78       c838                -1
    x79       c30                 -1   c34                 -1
    x79       c55                  1   c75                  1
    x79       c141                 1   c159                 1
    x79       c162                 1   c165                 1
    x79       c167                 1   c206                 1
    x79       c216                 1   c241                 1
    x79       c253                 1   c274                -1
    x79       c332                -1   c348                -1
    x79       c376                 1   c389                 1
    x79       c395                -1   c460                -1
    x79       c477                 1   c482                 1
    x79       c485                -1   c506                -1
    x79       c516                -1   c522                -1
    x79       c563                 1   c573                -1
    x79       c607                 1   c617                -1
    x79       c620                 1   c634                 1
    x79       c640                -1   c657                 1
    x79       c706                 1   c708                 1
    x79       c711                -1   c723                 1
    x79       c744                 1   c758                -1
    x79       c794                 1   c805                -1
    x79       c838                -1   c841                 1
    x80       c31                  1   c41                 -1
    x80       c75                 -1   c78                  1
    x80       c92                  1   c101                 1
    x80       c109                 1   c113                -1
    x80       c114                -1   c131                -1
    x80       c167                 1   c187                -1
    x80       c249                 1   c265                 1
    x80       c274                 1   c339                -1
    x80       c346                -1   c377                -1
    x80       c393                 1   c402                -1
    x80       c442                -1   c451                 1
    x80       c456                 1   c475                 1
    x80       c486                -1   c530                -1
    x80       c538                -1   c550                -1
    x80       c558                 1   c580                 1
    x80       c657                 1   c668                 1
    x80       c706                -1   c711                -1
    x80       c726                 1   c754                 1
    x80       c824                 1   c843                 1
    x81       c32                  1   c50                  1
    x81       c72                  1   c92                 -1
    x81       c95                 -1   c144                 1
    x81       c149                 1   c227                -1
    x81       c230                -1   c234                 1
    x81       c239                 1   c270                 1
    x81       c333                -1   c348                -1
    x81       c354                -1   c401                 1
    x81       c473                 1   c505                -1
    x81       c510                 1   c532                 1
    x81       c545                -1   c607                -1
    x81       c617                -1   c620                -1
    x81       c623                 1   c632                 1
    x81       c637                -1   c657                -1
    x81       c658                 1   c663                 1
    x81       c695                 1   c702                -1
    x81       c732                 1   c757                -1
    x81       c767                 1   c779                -1
    x81       c784                -1   c790                 1
    x81       c813                -1
    x82       c33                  1   c40                  1
    x82       c53                 -1   c85                 -1
    x82       c99                 -1   c111                -1
    x82       c131                -1   c141                -1
    x82       c147                 1   c155                -1
    x82       c172                -1   c206                 1
    x82       c210                 1   c224                 1
    x82       c248                -1   c282                 1
    x82       c364                 1   c396                -1
    x82       c401                 1   c404                -1
    x82       c414                -1   c484                -1
    x82       c509                 1   c517                -1
    x82       c564                -1   c586                 1
    x82       c618                 1   c619                 1
    x82       c626                 1   c640                -1
    x82       c645                 1   c651                 1
    x82       c656                 1   c662                 1
    x82       c701                 1   c716                 1
    x82       c764                -1   c766                -1
    x82       c767                 1   c789                -1
    x82       c790                 1   c816                 1
    x83       c34                  1   c45                 -1
    x83       c49                  1   c63                  1
    x83       c68                 -1   c85                  1
    x83       c133                 1   c135                 1
    x83       c138                -1   c151                 1
    x83       c172                 1   c187                -1
    x83       c222                 1   c232                -1
    x83       c267                -1   c270                 1
    x83       c284                 1   c293                 1
    x83       c300                 1   c304                -1
    x83       c305                -1   c322                -1
    x83       c359                 1   c377                -1
    x83       c439                 1   c455                 1
    x83       c464                 1   c530                -1
    x83       c537                -1   c568                -1
    x83       c584                 1   c593                -1
    x83       c632                -1   c641                 1
    x83       c646                 1   c665                 1
    x83       c676                -1   c720                -1
    x83       c728                -1   c740                -1
    x83       c748                 1   c770                 1
    x83       c848                 1
    x84       c34                  1   c57                 -1
    x84       c106                 1   c131                 1
    x84       c137                -1   c138                 1
    x84       c143                -1   c145                 1
    x84       c166                -1   c190                 1
    x84       c212                 1   c231                 1
    x84       c259                 1   c309                -1
    x84       c312                -1   c319                 1
    x84       c347                -1   c397                 1
    x84       c415                 1   c435                 1
    x84       c501                -1   c505                -1
    x84       c515                 1   c531                 1
    x84       c558                -1   c561                -1
    x84       c571                 1   c585                 1
    x84       c642                 1   c696                -1
    x84       c704                 1   c716                 1
    x84       c723                -1   c727                -1
    x84       c774                 1   c800                -1
    x84       c811                 1   c827                 1
    x84       c832                -1   c834                -1
    x84       c844                 1
    x85       c34                 -1   c45                 -1
    x85       c49                 -1   c52                  1
    x85       c61                  1   c66                 -1
    x85       c85                 -1   c86                  1
    x85       c91                  1   c122                 1
    x85       c129                -1   c146                 1
    x85       c186                -1   c196                 1
    x85       c208                -1   c212                -1
    x85       c218                 1   c242                -1
    x85       c282                 1   c298                -1
    x85       c308                -1   c318                -1
    x85       c346                 1   c373                -1
    x85       c390                -1   c398                 1
    x85       c420                -1   c441                 1
    x85       c460                -1   c541                 1
    x85       c559                -1   c564                -1
    x85       c614                -1   c640                 1
    x85       c642                 1   c662                 1
    x85       c692                -1   c701                 1
    x85       c721                -1   c774                -1
    x85       c799                -1   c803                -1
    x85       c830                -1   c831                 1
    x86       c36                 -1   c39                 -1
    x86       c43                  1   c48                  1
    x86       c78                  1   c142                -1
    x86       c157                -1   c162                -1
    x86       c210                 1   c283                 1
    x86       c314                -1   c319                 1
    x86       c341                 1   c355                -1
    x86       c416                -1   c427                -1
    x86       c430                -1   c433                 1
    x86       c442                 1   c447                -1
    x86       c467                -1   c468                 1
    x86       c473                 1   c504                 1
    x86       c511                -1   c528                 1
    x86       c542                 1   c567                -1
    x86       c577                 1   c589                -1
    x86       c594                -1   c600                 1
    x86       c622                -1   c662                 1
    x86       c679                -1   c690                -1
    x86       c700                -1   c727                 1
    x86       c741                -1   c754                -1
    x86       c771                -1   c779                 1
    x86       c801                -1   c822                 1
    x86       c841                -1
    x87       c37                 -1   c45                  1
    x87       c62                 -1   c65                 -1
    x87       c114                -1   c128                 1
    x87       c132                -1   c139                 1
    x87       c152                 1   c154                 1
    x87       c163                 1   c164                -1
    x87       c175                 1   c190                 1
    x87       c197                 1   c224                 1
    x87       c273                 1   c275                -1
    x87       c282                 1   c284                -1
    x87       c286                 1   c328                 1
    x87       c329                 1   c342                -1
    x87       c345                 1   c401                -1
    x87       c444                 1   c447                -1
    x87       c455                 1   c475                -1
    x87       c499                 1   c548                -1
    x87       c555                 1   c560                 1
    x87       c581                -1   c600                 1
    x87       c601                 1   c611                -1
    x87       c629                 1   c639                -1
    x87       c735                 1   c764                 1
    x87       c823                 1   c843                -1
    x88       c37                 -1   c58                 -1
    x88       c67                 -1   c158                 1
    x88       c173                -1   c199                 1
    x88       c228                -1   c229                -1
    x88       c249                 1   c300                 1
    x88       c309                 1   c342                 1
    x88       c397                 1   c422                -1
    x88       c431                 1   c441                 1
    x88       c455                -1   c470                 1
    x88       c486                -1   c504                 1
    x88       c514                -1   c519                -1
    x88       c528                -1   c569                 1
    x88       c582                 1   c583                -1
    x88       c599                 1   c615                -1
    x88       c619                 1   c620                 1
    x88       c631                -1   c645                -1
    x88       c650                 1   c675                 1
    x88       c694                 1   c702                -1
    x88       c774                -1   c793                -1
    x88       c817                 1   c821                -1
    x89       c38                 -1   c71                  1
    x89       c73                 -1   c92                  1
    x89       c98                  1   c124                 1
    x89       c176                -1   c192                 1
    x89       c210                -1   c221                 1
    x89       c231                -1   c268                -1
    x89       c289                 1   c301                 1
    x89       c303                 1   c319                -1
    x89       c366                 1   c372                -1
    x89       c373                 1   c378                -1
    x89       c397                 1   c429                -1
    x89       c458                -1   c460                -1
    x89       c481                -1   c494                 1
    x89       c498                 1   c550                -1
    x89       c563                -1   c574                 1
    x89       c584                 1   c587                 1
    x89       c595                -1   c615                 1
    x89       c639                -1   c662                -1
    x89       c708                -1   c718                -1
    x89       c759                -1   c793                -1
    x89       c797                -1   c817                 1
    x89       c838                 1
    x90       c41                 -1   c68                  1
    x90       c70                  1   c90                  1
    x90       c119                -1   c128                 1
    x90       c149                -1   c203                -1
    x90       c227                -1   c231                -1
    x90       c259                -1   c260                 1
    x90       c298                 1   c316                 1
    x90       c374                -1   c383                 1
    x90       c387                 1   c393                 1
    x90       c420                 1   c473                 1
    x90       c502                -1   c505                -1
    x90       c538                 1   c541                 1
    x90       c573                -1   c593                -1
    x90       c638                 1   c655                -1
    x90       c697                 1   c711                -1
    x90       c723                 1   c791                -1
    x90       c808                 1   c831                 1
    x91       c41                  1   c49                  1
    x91       c83                  1   c115                 1
    x91       c180                -1   c228                -1
    x91       c236                 1   c253                -1
    x91       c256                -1   c305                -1
    x91       c319                 1   c323                -1
    x91       c330                 1   c343                 1
    x91       c345                 1   c355                 1
    x91       c356                -1   c366                 1
    x91       c380                 1   c387                 1
    x91       c415                 1   c463                 1
    x91       c465                -1   c472                 1
    x91       c474                -1   c476                 1
    x91       c519                 1   c520                 1
    x91       c533                -1   c536                 1
    x91       c592                -1   c634                 1
    x91       c637                -1   c645                 1
    x91       c665                -1   c690                 1
    x91       c738                -1   c745                 1
    x91       c750                 1   c771                -1
    x91       c790                 1   c791                 1
    x91       c801                -1   c820                 1
    x91       c830                -1
    x92       c47                 -1   c89                  1
    x92       c107                -1   c119                 1
    x92       c151                -1   c155                 1
    x92       c161                -1   c170                -1
    x92       c175                 1   c188                 1
    x92       c211                -1   c221                -1
    x92       c228                 1   c239                 1
    x92       c272                 1   c275                 1
    x92       c302                -1   c334                 1
    x92       c346                -1   c349                 1
    x92       c355                -1   c396                 1
    x92       c413                 1   c444                -1
    x92       c477                -1   c550                -1
    x92       c566                -1   c578                 1
    x92       c607                 1   c611                 1
    x92       c682                 1   c683                -1
    x92       c729                -1   c757                 1
    x92       c839                -1   c847                -1
    x93       c54                 -1   c57                 -1
    x93       c71                 -1   c104                 1
    x93       c113                 1   c151                 1
    x93       c154                -1   c172                -1
    x93       c177                 1   c191                 1
    x93       c193                -1   c194                 1
    x93       c196                -1   c245                 1
    x93       c258                -1   c283                 1
    x93       c295                -1   c299                -1
    x93       c303                 1   c311                -1
    x93       c317                -1   c327                -1
    x93       c330                 1   c343                -1
    x93       c362                -1   c364                 1
    x93       c366                 1   c384                 1
    x93       c417                -1   c442                -1
    x93       c470                -1   c474                 1
    x93       c480                 1   c487                 1
    x93       c494                -1   c500                 1
    x93       c527                -1   c534                -1
    x93       c543                -1   c582                -1
    x93       c596                 1   c690                -1
    x93       c723                 1   c727                -1
    x93       c739                 1   c748                 1
    x93       c765                -1   c840                -1
    x94       c58                  1   c73                  1
    x94       c82                  1   c148                -1
    x94       c155                -1   c187                -1
    x94       c203                 1   c211                -1
    x94       c252                -1   c261                 1
    x94       c266                 1   c285                 1
    x94       c295                -1   c339                -1
    x94       c347                -1   c360                -1
    x94       c367                 1   c389                 1
    x94       c467                 1   c478                 1
    x94       c515                -1   c520                -1
    x94       c536                 1   c564                 1
    x94       c633                 1   c652                 1
    x94       c666                -1   c670                -1
    x94       c707                -1   c774                 1
    x94       c837                -1
    x95       c59                 -1   c73                  1
    x95       c108                 1   c132                 1
    x95       c166                 1   c189                 1
    x95       c191                 1   c215                 1
    x95       c226                -1   c242                -1
    x95       c303                -1   c316                 1
    x95       c321                -1   c324                 1
    x95       c328                 1   c342                 1
    x95       c354                 1   c369                 1
    x95       c377                 1   c419                -1
    x95       c452                 1   c454                -1
    x95       c473                 1   c479                 1
    x95       c505                 1   c557                -1
    x95       c572                 1   c591                -1
    x95       c602                 1   c612                -1
    x95       c647                -1   c668                 1
    x95       c682                 1   c684                 1
    x95       c700                -1   c746                 1
    x95       c752                -1   c753                 1
    x95       c758                -1   c764                 1
    x95       c777                 1   c809                -1
    x95       c838                -1   c840                -1
    x96       c60                  1   c92                 -1
    x96       c105                 1   c113                -1
    x96       c151                 1   c157                -1
    x96       c170                -1   c179                 1
    x96       c193                -1   c223                 1
    x96       c241                 1   c264                 1
    x96       c284                -1   c287                -1
    x96       c335                 1   c340                 1
    x96       c418                -1   c421                -1
    x96       c425                 1   c429                 1
    x96       c460                 1   c524                -1
    x96       c539                -1   c544                -1
    x96       c592                 1   c663                 1
    x96       c696                -1   c701                 1
    x96       c722                 1   c735                -1
    x96       c797                -1   c808                -1
    x96       c811                -1   c814                 1
    x96       c823                 1   c828                -1
    x96       c848                -1   c849                 1
    x97       c61                  1   c80                 -1
    x97       c96                 -1   c109                 1
    x97       c121                -1   c131                 1
    x97       c137                 1   c143                 1
    x97       c144                 1   c178                 1
    x97       c190                -1   c238                -1
    x97       c281                 1   c299                -1
    x97       c310                 1   c342                -1
    x97       c346                 1   c353                -1
    x97       c361                -1   c366                 1
    x97       c378                 1   c402                -1
    x97       c412                -1   c419                 1
    x97       c429                 1   c462                 1
    x97       c465                 1   c493                -1
    x97       c525                 1   c537                -1
    x97       c540                 1   c545                -1
    x97       c587                 1   c604                 1
    x97       c634                -1   c667                -1
    x97       c740                -1   c756                -1
    x97       c768                 1   c797                 1
    x97       c801                 1
    x98       c63                 -1   c70                  1
    x98       c101                 1   c104                 1
    x98       c113                -1   c158                 1
    x98       c183                 1   c191                 1
    x98       c198                 1   c223                 1
    x98       c252                -1   c268                 1
    x98       c301                -1   c307                 1
    x98       c388                 1   c421                 1
    x98       c434                -1   c438                -1
    x98       c511                 1   c518                 1
    x98       c565                 1   c590                -1
    x98       c694                -1   c698                -1
    x98       c701                 1   c719                -1
    x98       c757                -1   c821                -1
    x98       c836                 1
    x99       c77                 -1   c85                 -1
    x99       c90                 -1   c158                -1
    x99       c185                -1   c219                -1
    x99       c223                -1   c268                 1
    x99       c270                -1   c280                -1
    x99       c304                 1   c312                 1
    x99       c319                -1   c323                -1
    x99       c335                 1   c336                 1
    x99       c373                -1   c381                -1
    x99       c402                -1   c416                 1
    x99       c437                 1   c442                -1
    x99       c451                -1   c466                 1
    x99       c494                -1   c507                 1
    x99       c539                 1   c554                 1
    x99       c607                 1   c628                -1
    x99       c679                 1   c704                 1
    x99       c710                -1   c711                 1
    x99       c716                -1   c718                 1
    x99       c738                -1   c761                 1
    x99       c784                 1   c803                 1
    x99       c830                 1
    x100      c116                -1   c127                 1
    x100      c140                 1   c148                 1
    x100      c153                 1   c155                -1
    x100      c165                -1   c181                -1
    x100      c184                -1   c191                -1
    x100      c202                 1   c224                 1
    x100      c234                 1   c268                 1
    x100      c269                 1   c280                 1
    x100      c288                 1   c290                -1
    x100      c315                -1   c317                 1
    x100      c329                -1   c349                 1
    x100      c352                -1   c363                 1
    x100      c394                -1   c415                -1
    x100      c416                -1   c430                -1
    x100      c441                 1   c463                 1
    x100      c491                -1   c511                 1
    x100      c523                 1   c525                 1
    x100      c526                -1   c527                -1
    x100      c548                 1   c565                -1
    x100      c589                 1   c590                 1
    x100      c592                 1   c595                 1
    x100      c601                 1   c618                -1
    x100      c630                 1   c659                -1
    x100      c668                 1   c674                -1
    x100      c697                -1   c726                -1
    x100      c759                 1   c765                -1
    x100      c786                -1   c792                -1
    x100      c793                 1   c794                -1
    x100      c830                 1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       c1                  -1   c3                  -1
    rhs       c4                  -2   c6                  -1
    rhs       c7                   1   c9                  -1
    rhs       c11                 -3   c12                 -4
    rhs       c13                 -1   c15                 -2
    rhs       c16                 -1   c17                 -1
    rhs       c18                 -1   c19                 -2
    rhs       c20                 -5   c21                 -2
    rhs       c22                 -3   c24                  1
    rhs       c27                 -1   c29                 -1
    rhs       c30                 -3   c31                 -1
    rhs       c32                 -2   c33                 -1
    rhs       c34                 -3   c36                 -3
    rhs       c37                 -4   c38                 -4
    rhs       c39                 -1   c40                 -4
    rhs       c41                 -2   c45                 -1
    rhs       c46                  1   c47                 -1
    rhs       c48                 -1   c49                 -2
    rhs       c51                 -1   c53                 -1
    rhs       c56                  1   c57                 -3
    rhs       c59                 -1   c61                 -3
    rhs       c62                 -1   c64                 -2
    rhs       c65                 -2   c66                 -1
    rhs       c67                 -5   c68                 -1
    rhs       c69                 -1   c70                  1
    rhs       c71                 -1   c73                 -4
    rhs       c74                  1   c75                 -3
    rhs       c76                 -1   c77                 -1
    rhs       c78                 -5   c79                 -1
    rhs       c81                 -2   c83                 -1
    rhs       c85                 -2   c86                 -1
    rhs       c87                 -1   c89                 -1
    rhs       c90                 -1   c91                 -1
    rhs       c92                 -3   c93                 -2
    rhs       c94                 -1   c95                 -1
    rhs       c96                 -2   c97                  1
    rhs       c98                 -1   c99                 -2
    rhs       c100                 1   c101                -2
    rhs       c102                -3   c103                -2
    rhs       c104                -1   c111                -3
    rhs       c112                -2   c113                -3
    rhs       c114                -1   c115                 1
    rhs       c116                -3   c118                -1
    rhs       c119                -2   c120                -4
    rhs       c121                -3   c122                -2
    rhs       c123                -4   c124                -5
    rhs       c125                -1   c126                -1
    rhs       c127                -1   c128                -2
    rhs       c129                -1   c130                -2
    rhs       c131                -1   c132                -2
    rhs       c134                -1   c135                -2
    rhs       c136                -1   c137                -5
    rhs       c138                -2   c139                -1
    rhs       c140                -1   c141                -2
    rhs       c143                -3   c144                -2
    rhs       c145                -1   c146                -2
    rhs       c148                -1   c149                -1
    rhs       c150                -1   c151                -3
    rhs       c152                 1   c153                -1
    rhs       c154                -2   c155                -4
    rhs       c156                -3   c157                -3
    rhs       c158                -2   c160                -2
    rhs       c161                -1   c162                -2
    rhs       c163                -4   c166                -2
    rhs       c168                -2   c169                -1
    rhs       c170                -1   c172                -4
    rhs       c175                -1   c177                -1
    rhs       c178                -1   c179                -2
    rhs       c180                -1   c181                -2
    rhs       c182                -1   c183                -3
    rhs       c184                -3   c185                -1
    rhs       c186                -2   c187                -4
    rhs       c188                -1   c189                 1
    rhs       c191                -2   c192                -2
    rhs       c193                -3   c194                -1
    rhs       c195                -2   c196                -1
    rhs       c198                 1   c200                -1
    rhs       c202                -3   c203                -4
    rhs       c204                -1   c206                -2
    rhs       c207                -2   c209                -1
    rhs       c210                -2   c211                -6
    rhs       c212                -1   c213                -3
    rhs       c215                 1   c218                -1
    rhs       c220                -1   c221                -4
    rhs       c223                -2   c224                -1
    rhs       c225                -3   c226                -1
    rhs       c227                -3   c228                -5
    rhs       c229                -2   c230                -1
    rhs       c231                -4   c232                -2
    rhs       c236                -1   c237                 1
    rhs       c238                -1   c239                -1
    rhs       c240                -2   c242                -1
    rhs       c244                -1   c247                 1
    rhs       c248                -4   c249                 1
    rhs       c250                -1   c252                -3
    rhs       c253                -1   c254                -1
    rhs       c255                -2   c256                -1
    rhs       c257                -1   c258                -1
    rhs       c259                -3   c260                -1
    rhs       c261                -1   c262                 1
    rhs       c263                -2   c264                -1
    rhs       c265                -2   c266                 1
    rhs       c267                -3   c268                -1
    rhs       c269                -1   c270                -5
    rhs       c271                -1   c273                -2
    rhs       c275                -2   c276                 1
    rhs       c277                -3   c279                -1
    rhs       c280                -1   c282                -1
    rhs       c283                -1   c284                -4
    rhs       c285                -1   c286                -2
    rhs       c287                -1   c288                -1
    rhs       c289                 1   c290                -2
    rhs       c291                -1   c292                 1
    rhs       c293                -3   c294                -2
    rhs       c295                -3   c299                -1
    rhs       c302                -3   c303                -2
    rhs       c304                -3   c305                -1
    rhs       c306                 1   c307                -3
    rhs       c309                -1   c310                -2
    rhs       c311                -5   c312                -2
    rhs       c313                -2   c314                -5
    rhs       c315                -4   c316                -1
    rhs       c317                -2   c319                -2
    rhs       c320                -1   c321                -2
    rhs       c322                -1   c323                -2
    rhs       c325                -2   c326                -1
    rhs       c327                -2   c328                -4
    rhs       c329                -3   c330                -1
    rhs       c332                -2   c333                -1
    rhs       c334                -2   c335                -2
    rhs       c336                -1   c337                -2
    rhs       c339                -1   c340                -1
    rhs       c341                -2   c342                -2
    rhs       c344                -1   c345                -1
    rhs       c346                -4   c347                -3
    rhs       c348                -4   c349                -1
    rhs       c352                -1   c353                -1
    rhs       c354                -2   c355                -4
    rhs       c358                -2   c360                -3
    rhs       c361                -2   c363                -4
    rhs       c364                 1   c365                -1
    rhs       c366                -1   c367                -1
    rhs       c368                -2   c369                -1
    rhs       c370                -2   c371                -1
    rhs       c372                -1   c373                -3
    rhs       c374                -3   c375                -2
    rhs       c376                -1   c377                -4
    rhs       c378                -1   c379                 1
    rhs       c381                -2   c382                -2
    rhs       c383                -3   c384                -1
    rhs       c385                -2   c386                -1
    rhs       c388                 1   c390                -2
    rhs       c391                 1   c392                -3
    rhs       c393                -4   c394                -1
    rhs       c396                -2   c397                -2
    rhs       c399                -1   c401                -1
    rhs       c402                -6   c403                -1
    rhs       c404                -3   c406                 1
    rhs       c409                -1   c410                -1
    rhs       c412                -4   c413                -1
    rhs       c414                -1   c415                -1
    rhs       c416                -3   c417                -2
    rhs       c418                -3   c419                -5
    rhs       c420                -1   c421                -3
    rhs       c422                -2   c423                -2
    rhs       c427                -1   c428                -1
    rhs       c429                -1   c430                -2
    rhs       c432                -1   c434                -1
    rhs       c437                 1   c438                -4
    rhs       c439                 1   c440                -1
    rhs       c442                -4   c444                -2
    rhs       c445                -1   c446                -1
    rhs       c447                -1   c448                -1
    rhs       c449                -3   c450                -1
    rhs       c451                -1   c452                 1
    rhs       c453                -2   c454                -1
    rhs       c455                -2   c457                -3
    rhs       c459                -1   c460                -5
    rhs       c461                -1   c463                -2
    rhs       c464                -1   c465                -1
    rhs       c466                 1   c467                -3
    rhs       c469                -1   c470                -2
    rhs       c471                 1   c472                -1
    rhs       c473                -2   c474                -3
    rhs       c475                -1   c476                -2
    rhs       c477                -1   c478                -1
    rhs       c479                 1   c480                -2
    rhs       c481                -1   c482                 1
    rhs       c484                -4   c486                -3
    rhs       c489                -1   c490                 1
    rhs       c492                -1   c493                -2
    rhs       c494                -4   c495                -1
    rhs       c496                -1   c497                 1
    rhs       c498                -3   c500                -1
    rhs       c501                -3   c502                -4
    rhs       c503                -3   c504                -1
    rhs       c505                -5   c506                -4
    rhs       c507                -1   c508                -2
    rhs       c509                -1   c510                -1
    rhs       c511                -1   c512                -2
    rhs       c513                -1   c514                -2
    rhs       c516                -2   c517                -1
    rhs       c518                -2   c519                -4
    rhs       c520                -4   c523                -2
    rhs       c524                -1   c525                -2
    rhs       c526                -2   c527                -2
    rhs       c528                -1   c530                -1
    rhs       c531                -1   c532                -2
    rhs       c533                -2   c534                -1
    rhs       c536                -1   c537                -4
    rhs       c538                -4   c539                -4
    rhs       c543                -2   c544                -3
    rhs       c545                -3   c548                -2
    rhs       c550                -3   c551                -1
    rhs       c552                -1   c553                -1
    rhs       c554                -3   c555                 1
    rhs       c556                -1   c557                -1
    rhs       c558                -1   c559                -2
    rhs       c560                -1   c561                -2
    rhs       c562                -2   c564                -3
    rhs       c565                -3   c566                -2
    rhs       c567                -1   c568                -5
    rhs       c570                 1   c571                -1
    rhs       c572                -1   c573                -3
    rhs       c574                -2   c576                -3
    rhs       c579                 1   c581                -2
    rhs       c583                -4   c584                -2
    rhs       c585                -1   c587                -2
    rhs       c588                -2   c589                -1
    rhs       c591                -1   c593                -6
    rhs       c594                -1   c595                -3
    rhs       c597                 1   c600                -1
    rhs       c601                -1   c603                -4
    rhs       c604                -1   c605                -1
    rhs       c606                -1   c607                -3
    rhs       c608                -2   c609                -3
    rhs       c610                -5   c611                -1
    rhs       c612                -4   c613                -1
    rhs       c614                -2   c616                -1
    rhs       c617                -1   c618                -2
    rhs       c620                -2   c622                -1
    rhs       c624                -1   c627                 1
    rhs       c628                -4   c629                 1
    rhs       c630                -1   c632                -4
    rhs       c634                -2   c635                -2
    rhs       c637                -1   c638                -1
    rhs       c639                -3   c640                -1
    rhs       c641                -1   c642                 1
    rhs       c643                -2   c644                -2
    rhs       c645                -1   c646                -1
    rhs       c647                -3   c649                -2
    rhs       c650                -3   c651                -1
    rhs       c652                -1   c653                -1
    rhs       c654                -1   c655                -1
    rhs       c657                -2   c659                -1
    rhs       c660                -2   c663                -3
    rhs       c664                -2   c665                -1
    rhs       c666                -3   c668                -1
    rhs       c670                -2   c672                 1
    rhs       c674                -4   c675                -1
    rhs       c676                -2   c680                -1
    rhs       c681                 1   c683                -1
    rhs       c684                -2   c685                -4
    rhs       c686                -1   c687                -1
    rhs       c688                 1   c689                -3
    rhs       c690                -1   c692                -4
    rhs       c693                -3   c694                -3
    rhs       c695                -1   c696                -6
    rhs       c697                -3   c698                -1
    rhs       c699                -2   c700                -1
    rhs       c701                -1   c702                -1
    rhs       c703                -2   c704                -2
    rhs       c705                -1   c707                -2
    rhs       c708                -1   c709                -4
    rhs       c710                -2   c711                -4
    rhs       c714                -2   c715                -1
    rhs       c716                -2   c717                -2
    rhs       c718                -4   c720                -1
    rhs       c721                -1   c722                -2
    rhs       c723                -2   c724                -1
    rhs       c726                -1   c727                -5
    rhs       c728                -3   c729                -5
    rhs       c730                 1   c733                -2
    rhs       c734                -4   c735                -2
    rhs       c738                -2   c739                -1
    rhs       c740                -2   c741                -1
    rhs       c742                -1   c743                -1
    rhs       c744                -3   c745                 1
    rhs       c746                -2   c748                -1
    rhs       c749                -2   c750                -1
    rhs       c751                -2   c752                -3
    rhs       c753                 1   c754                -3
    rhs       c755                -4   c756                -1
    rhs       c757                -2   c758                -4
    rhs       c760                 1   c761                -1
    rhs       c762                -1   c763                -3
    rhs       c764                -2   c765                -1
    rhs       c766                -2   c769                 1
    rhs       c771                -2   c772                -2
    rhs       c773                -2   c774                -2
    rhs       c775                -1   c776                -1
    rhs       c777                -1   c778                -2
    rhs       c779                -1   c781                -1
    rhs       c782                -1   c783                -5
    rhs       c784                -2   c785                -2
    rhs       c788                 1   c790                -2
    rhs       c793                -4   c794                -2
    rhs       c796                -1   c797                -3
    rhs       c798                -3   c799                -2
    rhs       c800                -5   c801                -2
    rhs       c802                -3   c803                -1
    rhs       c805                -3   c806                 1
    rhs       c807                -1   c808                -1
    rhs       c809                -2   c811                -2
    rhs       c813                -1   c814                -1
    rhs       c818                 1   c819                -4
    rhs       c820                 1   c821                -2
    rhs       c822                 1   c823                -4
    rhs       c825                -2   c826                -2
    rhs       c828                -1   c829                -3
    rhs       c830                -1   c831                -1
    rhs       c832                -1   c833                 1
    rhs       c834                -2   c835                -3
    rhs       c837                -1   c838                -3
    rhs       c840                -4   c841                -1
    rhs       c842                -1   c843                -2
    rhs       c845                -1   c846                -1
    rhs       c847                -1   c848                -1
    rhs       c850                -2
BOUNDS
 UP bnd       x1                   1
 UP bnd       x2                   1
 UP bnd       x3                   1
 UP bnd       x4                   1
 UP bnd       x5                   1
 UP bnd       x6                   1
 UP bnd       x7                   1
 UP bnd       x8                   1
 UP bnd       x9                   1
 UP bnd       x10                  1
 UP bnd       x11                  1
 UP bnd       x12                  1
 UP bnd       x13                  1
 UP bnd       x14                  1
 UP bnd       x15                  1
 UP bnd       x16                  1
 UP bnd       x17                  1
 UP bnd       x18                  1
 UP bnd       x19                  1
 UP bnd       x20                  1
 UP bnd       x21                  1
 UP bnd       x22                  1
 UP bnd       x23                  1
 UP bnd       x24                  1
 UP bnd       x25                  1
 UP bnd       x26                  1
 UP bnd       x27                  1
 UP bnd       x28                  1
 UP bnd       x29                  1
 UP bnd       x30                  1
 UP bnd       x31                  1
 UP bnd       x32                  1
 UP bnd       x33                  1
 UP bnd       x34                  1
 UP bnd       x35                  1
 UP bnd       x36                  1
 UP bnd       x37                  1
 UP bnd       x38                  1
 UP bnd       x39                  1
 UP bnd       x40                  1
 UP bnd       x41                  1
 UP bnd       x42                  1
 UP bnd       x43                  1
 UP bnd       x44                  1
 UP bnd       x45                  1
 UP bnd       x46                  1
 UP bnd       x47                  1
 UP bnd       x48                  1
 UP bnd       x49                  1
 UP bnd       x50                  1
 UP bnd       x51                  1
 UP bnd       x52                  1
 UP bnd       x53                  1
 UP bnd       x54                  1
 UP bnd       x55                  1
 UP bnd       x56                  1
 UP bnd       x57                  1
 UP bnd       x58                  1
 UP bnd       x59                  1
 UP bnd       x60                  1
 UP bnd       x61                  1
 UP bnd       x62                  1
 UP bnd       x63                  1
 UP bnd       x64                  1
 UP bnd       x65                  1
 UP bnd       x66                  1
 UP bnd       x67                  1
 UP bnd       x68                  1
 UP bnd       x69                  1
 UP bnd       x70                  1
 UP bnd       x71                  1
 UP bnd       x72                  1
 UP bnd       x73                  1
 UP bnd       x74                  1
 UP bnd       x75                  1
 UP bnd       x76                  1
 UP bnd       x77                  1
 UP bnd       x78                  1
 UP bnd       x79                  1
 UP bnd       x80                  1
 UP bnd       x81                  1
 UP bnd       x82                  1
 UP bnd       x83                  1
 UP bnd       x84                  1
 UP bnd       x85                  1
 UP bnd       x86                  1
 UP bnd       x87                  1
 UP bnd       x88                  1
 UP bnd       x89                  1
 UP bnd       x90                  1
 UP bnd       x91                  1
 UP bnd       x92                  1
 UP bnd       x93                  1
 UP bnd       x94                  1
 UP bnd       x95                  1
 UP bnd       x96                  1
 UP bnd       x97                  1
 UP bnd       x98                  1
 UP bnd       x99                  1
 UP bnd       x100                 1
ENDATA
