NAME           
ROWS
 N  obj     
 G  c1      
 G  c2      
 G  c3      
 G  c4      
 G  c5      
 G  c6      
 G  c7      
 G  c8      
 G  c9      
 G  c10     
 G  c11     
 G  c12     
 G  c13     
 G  c14     
 G  c15     
 G  c16     
 G  c17     
 G  c18     
 G  c19     
 G  c20     
 G  c21     
 G  c22     
 G  c23     
 G  c24     
 G  c25     
 G  c26     
 G  c27     
 G  c28     
 G  c29     
 G  c30     
 G  c31     
 G  c32     
 G  c33     
 G  c34     
 G  c35     
 G  c36     
 G  c37     
 G  c38     
 G  c39     
 G  c40     
 G  c41     
 G  c42     
 G  c43     
 G  c44     
 G  c45     
 G  c46     
 G  c47     
 G  c48     
 G  c49     
 G  c50     
 G  c51     
 G  c52     
 G  c53     
 G  c54     
 G  c55     
 G  c56     
 G  c57     
 G  c58     
 G  c59     
 G  c60     
 G  c61     
 G  c62     
 G  c63     
 G  c64     
 G  c65     
 G  c66     
 G  c67     
 G  c68     
 G  c69     
 G  c70     
 G  c71     
 G  c72     
 G  c73     
 G  c74     
 G  c75     
 G  c76     
 G  c77     
 G  c78     
 G  c79     
 G  c80     
 G  c81     
 G  c82     
 G  c83     
 G  c84     
 G  c85     
 G  c86     
 G  c87     
 G  c88     
 G  c89     
 G  c90     
 G  c91     
 G  c92     
 G  c93     
 G  c94     
 G  c95     
 G  c96     
 G  c97     
 G  c98     
 G  c99     
 G  c100    
 G  c101    
 G  c102    
 G  c103    
 G  c104    
 G  c105    
 G  c106    
 G  c107    
 G  c108    
 G  c109    
 G  c110    
 G  c111    
 G  c112    
 G  c113    
 G  c114    
 G  c115    
 G  c116    
 G  c117    
 G  c118    
 G  c119    
 G  c120    
 G  c121    
 G  c122    
 G  c123    
 G  c124    
 G  c125    
 G  c126    
 G  c127    
 G  c128    
 G  c129    
 G  c130    
 G  c131    
 G  c132    
 G  c133    
 G  c134    
 G  c135    
 G  c136    
 G  c137    
 G  c138    
 G  c139    
 G  c140    
 G  c141    
 G  c142    
 G  c143    
 G  c144    
 G  c145    
 G  c146    
 G  c147    
 G  c148    
 G  c149    
 G  c150    
 G  c151    
 G  c152    
 G  c153    
 G  c154    
 G  c155    
 G  c156    
 G  c157    
 G  c158    
 G  c159    
 G  c160    
 G  c161    
 G  c162    
 G  c163    
 G  c164    
 G  c165    
 G  c166    
 G  c167    
 G  c168    
 G  c169    
 G  c170    
 G  c171    
 G  c172    
 G  c173    
 G  c174    
 G  c175    
 G  c176    
 G  c177    
 G  c178    
 G  c179    
 G  c180    
 G  c181    
 G  c182    
 G  c183    
 G  c184    
 G  c185    
 G  c186    
 G  c187    
 G  c188    
 G  c189    
 G  c190    
 G  c191    
 G  c192    
 G  c193    
 G  c194    
 G  c195    
 G  c196    
 G  c197    
 G  c198    
 G  c199    
 G  c200    
 G  c201    
 G  c202    
 G  c203    
 G  c204    
 G  c205    
 G  c206    
 G  c207    
 G  c208    
 G  c209    
 G  c210    
 G  c211    
 G  c212    
 G  c213    
 G  c214    
 G  c215    
 G  c216    
 G  c217    
 G  c218    
 G  c219    
 G  c220    
 G  c221    
 G  c222    
 G  c223    
 G  c224    
 G  c225    
 G  c226    
 G  c227    
 G  c228    
 G  c229    
 G  c230    
 G  c231    
 G  c232    
 G  c233    
 G  c234    
 G  c235    
 G  c236    
 G  c237    
 G  c238    
 G  c239    
 G  c240    
 G  c241    
 G  c242    
 G  c243    
 G  c244    
 G  c245    
 G  c246    
 G  c247    
 G  c248    
 G  c249    
 G  c250    
 G  c251    
 G  c252    
 G  c253    
 G  c254    
 G  c255    
 G  c256    
 G  c257    
 G  c258    
 G  c259    
 G  c260    
 G  c261    
 G  c262    
 G  c263    
 G  c264    
 G  c265    
 G  c266    
 G  c267    
 G  c268    
 G  c269    
 G  c270    
 G  c271    
 G  c272    
 G  c273    
 G  c274    
 G  c275    
 G  c276    
 G  c277    
 G  c278    
 G  c279    
 G  c280    
 G  c281    
 G  c282    
 G  c283    
 G  c284    
 G  c285    
 G  c286    
 G  c287    
 G  c288    
 G  c289    
 G  c290    
 G  c291    
 G  c292    
 G  c293    
 G  c294    
 G  c295    
 G  c296    
 G  c297    
 G  c298    
 G  c299    
 G  c300    
 G  c301    
 G  c302    
 G  c303    
 G  c304    
 G  c305    
 G  c306    
 G  c307    
 G  c308    
 G  c309    
 G  c310    
 G  c311    
 G  c312    
 G  c313    
 G  c314    
 G  c315    
 G  c316    
 G  c317    
 G  c318    
 G  c319    
 G  c320    
 G  c321    
 G  c322    
 G  c323    
 G  c324    
 G  c325    
 G  c326    
 G  c327    
 G  c328    
 G  c329    
 G  c330    
 G  c331    
 G  c332    
 G  c333    
 G  c334    
 G  c335    
 G  c336    
 G  c337    
 G  c338    
 G  c339    
 G  c340    
 G  c341    
 G  c342    
 G  c343    
 G  c344    
 G  c345    
 G  c346    
 G  c347    
 G  c348    
 G  c349    
 G  c350    
 G  c351    
 G  c352    
 G  c353    
 G  c354    
 G  c355    
 G  c356    
 G  c357    
 G  c358    
 G  c359    
 G  c360    
 G  c361    
 G  c362    
 G  c363    
 G  c364    
 G  c365    
 G  c366    
 G  c367    
 G  c368    
 G  c369    
 G  c370    
 G  c371    
 G  c372    
 G  c373    
 G  c374    
 G  c375    
 G  c376    
 G  c377    
 G  c378    
 G  c379    
 G  c380    
 G  c381    
 G  c382    
 G  c383    
 G  c384    
 G  c385    
 G  c386    
 G  c387    
 G  c388    
 G  c389    
 G  c390    
 G  c391    
 G  c392    
 G  c393    
 G  c394    
 G  c395    
 G  c396    
 G  c397    
 G  c398    
 G  c399    
 G  c400    
 G  c401    
 G  c402    
 G  c403    
 G  c404    
 G  c405    
 G  c406    
 G  c407    
 G  c408    
 G  c409    
 G  c410    
 G  c411    
 G  c412    
 G  c413    
 G  c414    
 G  c415    
 G  c416    
 G  c417    
 G  c418    
 G  c419    
 G  c420    
 G  c421    
 G  c422    
 G  c423    
 G  c424    
 G  c425    
 G  c426    
 G  c427    
 G  c428    
 G  c429    
 G  c430    
 G  c431    
 G  c432    
 G  c433    
 G  c434    
 G  c435    
 G  c436    
 G  c437    
 G  c438    
 G  c439    
 G  c440    
 G  c441    
 G  c442    
 G  c443    
 G  c444    
 G  c445    
 G  c446    
 G  c447    
 G  c448    
 G  c449    
 G  c450    
 G  c451    
 G  c452    
 G  c453    
 G  c454    
 G  c455    
 G  c456    
 G  c457    
 G  c458    
 G  c459    
 G  c460    
 G  c461    
 G  c462    
 G  c463    
 G  c464    
 G  c465    
 G  c466    
 G  c467    
 G  c468    
 G  c469    
 G  c470    
 G  c471    
 G  c472    
 G  c473    
 G  c474    
 G  c475    
 G  c476    
 G  c477    
 G  c478    
 G  c479    
 G  c480    
 G  c481    
 G  c482    
 G  c483    
 G  c484    
 G  c485    
 G  c486    
 G  c487    
 G  c488    
 G  c489    
 G  c490    
 G  c491    
 G  c492    
 G  c493    
 G  c494    
 G  c495    
 G  c496    
 G  c497    
 G  c498    
 G  c499    
 G  c500    
 G  c501    
 G  c502    
 G  c503    
 G  c504    
 G  c505    
 G  c506    
 G  c507    
 G  c508    
 G  c509    
 G  c510    
 G  c511    
 G  c512    
 G  c513    
 G  c514    
 G  c515    
 G  c516    
 G  c517    
 G  c518    
 G  c519    
 G  c520    
 G  c521    
 G  c522    
 G  c523    
 G  c524    
 G  c525    
 G  c526    
 G  c527    
 G  c528    
 G  c529    
 G  c530    
 G  c531    
 G  c532    
 G  c533    
 G  c534    
 G  c535    
 G  c536    
 G  c537    
 G  c538    
 G  c539    
 G  c540    
 G  c541    
 G  c542    
 G  c543    
 G  c544    
 G  c545    
 G  c546    
 G  c547    
 G  c548    
 G  c549    
 G  c550    
 G  c551    
 G  c552    
 G  c553    
 G  c554    
 G  c555    
 G  c556    
 G  c557    
 G  c558    
 G  c559    
 G  c560    
 G  c561    
 G  c562    
 G  c563    
 G  c564    
 G  c565    
 G  c566    
 G  c567    
 G  c568    
 G  c569    
 G  c570    
 G  c571    
 G  c572    
 G  c573    
 G  c574    
 G  c575    
 G  c576    
 G  c577    
 G  c578    
 G  c579    
 G  c580    
 G  c581    
 G  c582    
 G  c583    
 G  c584    
 G  c585    
 G  c586    
 G  c587    
 G  c588    
 G  c589    
 G  c590    
 G  c591    
 G  c592    
 G  c593    
 G  c594    
 G  c595    
 G  c596    
 G  c597    
 G  c598    
 G  c599    
 G  c600    
 G  c601    
 G  c602    
 G  c603    
 G  c604    
 G  c605    
 G  c606    
 G  c607    
 G  c608    
 G  c609    
 G  c610    
 G  c611    
 G  c612    
 G  c613    
 G  c614    
 G  c615    
 G  c616    
 G  c617    
 G  c618    
 G  c619    
 G  c620    
 G  c621    
 G  c622    
 G  c623    
 G  c624    
 G  c625    
 G  c626    
 G  c627    
 G  c628    
 G  c629    
 G  c630    
 G  c631    
 G  c632    
 G  c633    
 G  c634    
 G  c635    
 G  c636    
 G  c637    
 G  c638    
 G  c639    
 G  c640    
 G  c641    
 G  c642    
 G  c643    
 G  c644    
 G  c645    
 G  c646    
 G  c647    
 G  c648    
 G  c649    
 G  c650    
 G  c651    
 G  c652    
 G  c653    
 G  c654    
 G  c655    
 G  c656    
 G  c657    
 G  c658    
 G  c659    
 G  c660    
 G  c661    
 G  c662    
 G  c663    
 G  c664    
 G  c665    
 G  c666    
 G  c667    
 G  c668    
 G  c669    
 G  c670    
 G  c671    
 G  c672    
 G  c673    
 G  c674    
 G  c675    
 G  c676    
 G  c677    
 G  c678    
 G  c679    
 G  c680    
 G  c681    
 G  c682    
 G  c683    
 G  c684    
 G  c685    
 G  c686    
 G  c687    
 G  c688    
 G  c689    
 G  c690    
 G  c691    
 G  c692    
 G  c693    
 G  c694    
 G  c695    
 G  c696    
 G  c697    
 G  c698    
 G  c699    
 G  c700    
 G  c701    
 G  c702    
 G  c703    
 G  c704    
 G  c705    
 G  c706    
 G  c707    
 G  c708    
 G  c709    
 G  c710    
 G  c711    
 G  c712    
 G  c713    
 G  c714    
 G  c715    
 G  c716    
 G  c717    
 G  c718    
 G  c719    
 G  c720    
 G  c721    
 G  c722    
 G  c723    
 G  c724    
 G  c725    
 G  c726    
 G  c727    
 G  c728    
 G  c729    
 G  c730    
 G  c731    
 G  c732    
 G  c733    
 G  c734    
 G  c735    
 G  c736    
 G  c737    
 G  c738    
 G  c739    
 G  c740    
 G  c741    
 G  c742    
 G  c743    
 G  c744    
 G  c745    
 G  c746    
 G  c747    
 G  c748    
 G  c749    
 G  c750    
 G  c751    
 G  c752    
 G  c753    
 G  c754    
 G  c755    
 G  c756    
 G  c757    
 G  c758    
 G  c759    
 G  c760    
 G  c761    
 G  c762    
 G  c763    
 G  c764    
 G  c765    
 G  c766    
 G  c767    
 G  c768    
 G  c769    
 G  c770    
 G  c771    
 G  c772    
 G  c773    
 G  c774    
 G  c775    
 G  c776    
 G  c777    
 G  c778    
 G  c779    
 G  c780    
 G  c781    
 G  c782    
 G  c783    
 G  c784    
 G  c785    
 G  c786    
 G  c787    
 G  c788    
 G  c789    
 G  c790    
 G  c791    
 G  c792    
 G  c793    
 G  c794    
 G  c795    
 G  c796    
 G  c797    
 G  c798    
 G  c799    
 G  c800    
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x1        c1                   1   c6                  -1
    x1        c8                   1   c37                  1
    x1        c57                 -1   c100                -1
    x1        c104                -1   c157                -1
    x1        c167                 1   c178                -1
    x1        c202                 1   c259                -1
    x1        c261                -1   c276                -1
    x1        c308                 1   c317                 1
    x1        c355                 1   c358                -1
    x1        c378                -1   c382                 1
    x1        c396                 1   c398                -1
    x1        c399                 1   c401                -1
    x1        c451                 1   c463                -1
    x1        c487                 1   c499                -1
    x1        c503                -1   c508                 1
    x1        c516                -1   c522                -1
    x1        c532                -1   c535                 1
    x1        c547                -1   c568                -1
    x1        c570                 1   c572                 1
    x1        c590                 1   c623                -1
    x1        c649                -1   c674                -1
    x1        c678                 1   c684                 1
    x1        c690                 1   c698                -1
    x1        c704                 1   c731                -1
    x1        c738                -1   c748                -1
    x1        c787                -1
    x2        c1                   1   c4                  -1
    x2        c26                  1   c59                  1
    x2        c60                  1   c67                  1
    x2        c81                 -1   c86                  1
    x2        c92                  1   c97                  1
    x2        c103                 1   c142                 1
    x2        c156                 1   c207                -1
    x2        c209                -1   c210                 1
    x2        c232                -1   c233                 1
    x2        c259                 1   c294                 1
    x2        c334                -1   c348                 1
    x2        c377                 1   c383                 1
    x2        c410                 1   c423                 1
    x2        c436                -1   c442                 1
    x2        c443                 1   c482                 1
    x2        c488                -1   c490                -1
    x2        c544                -1   c559                -1
    x2        c560                 1   c583                 1
    x2        c594                 1   c603                -1
    x2        c615                 1   c618                 1
    x2        c628                -1   c648                 1
    x2        c668                 1   c708                -1
    x2        c723                -1   c733                 1
    x2        c758                 1   c759                -1
    x2        c768                 1
    x3        c1                  -1   c130                -1
    x3        c141                 1   c154                 1
    x3        c161                 1   c166                 1
    x3        c169                -1   c180                -1
    x3        c195                -1   c198                -1
    x3        c205                -1   c216                 1
    x3        c239                 1   c249                 1
    x3        c281                 1   c282                 1
    x3        c292                 1   c300                 1
    x3        c302                -1   c328                -1
    x3        c330                 1   c342                -1
    x3        c363                 1   c366                -1
    x3        c378                 1   c409                -1
    x3        c430                -1   c431                -1
    x3        c446                -1   c457                 1
    x3        c478                 1   c505                -1
    x3        c525                 1   c537                 1
    x3        c539                 1   c540                -1
    x3        c541                -1   c563                 1
    x3        c580                -1   c604                 1
    x3        c605                 1   c607                 1
    x3        c610                 1   c616                 1
    x3        c635                -1   c647                 1
    x3        c673                -1   c682                 1
    x3        c687                -1   c710                -1
    x3        c740                -1   c773                 1
    x3        c779                -1
    x4        c2                  -1   c13                  1
    x4        c23                  1   c26                  1
    x4        c34                 -1   c55                  1
    x4        c79                 -1   c102                -1
    x4        c148                -1   c157                -1
    x4        c201                -1   c235                -1
    x4        c239                -1   c259                 1
    x4        c279                 1   c344                 1
    x4        c363                 1   c367                 1
    x4        c370                 1   c372                 1
    x4        c410                 1   c421                 1
    x4        c446                 1   c458                 1
    x4        c478                -1   c536                -1
    x4        c552                -1   c581                 1
    x4        c594                 1   c600                -1
    x4        c665                -1   c680                 1
    x4        c685                 1   c687                -1
    x4        c709                -1   c719                -1
    x4        c725                -1   c766                 1
    x4        c776                -1
    x5        c2                  -1   c3                   1
    x5        c8                  -1   c14                  1
    x5        c27                  1   c59                 -1
    x5        c88                 -1   c90                 -1
    x5        c111                -1   c125                 1
    x5        c129                 1   c182                -1
    x5        c195                -1   c206                 1
    x5        c216                 1   c219                 1
    x5        c227                -1   c247                 1
    x5        c271                -1   c293                -1
    x5        c338                -1   c348                -1
    x5        c392                -1   c426                -1
    x5        c430                -1   c451                 1
    x5        c471                 1   c536                 1
    x5        c554                 1   c558                 1
    x5        c561                 1   c563                 1
    x5        c601                 1   c612                 1
    x5        c637                 1   c649                 1
    x5        c668                -1   c726                -1
    x5        c743                -1   c770                 1
    x5        c783                 1   c790                -1
    x6        c2                   1   c71                  1
    x6        c104                -1   c118                 1
    x6        c126                -1   c163                 1
    x6        c170                -1   c184                -1
    x6        c192                 1   c206                -1
    x6        c237                 1   c254                 1
    x6        c276                 1   c295                -1
    x6        c298                -1   c347                 1
    x6        c352                 1   c432                -1
    x6        c435                -1   c440                 1
    x6        c444                 1   c474                 1
    x6        c537                -1   c552                -1
    x6        c558                -1   c606                 1
    x6        c628                -1   c676                 1
    x6        c708                -1   c713                 1
    x6        c735                 1   c750                -1
    x7        c2                  -1   c5                  -1
    x7        c12                 -1   c23                  1
    x7        c46                  1   c57                  1
    x7        c89                  1   c90                  1
    x7        c101                 1   c109                 1
    x7        c111                -1   c138                -1
    x7        c140                 1   c152                -1
    x7        c172                 1   c175                -1
    x7        c187                 1   c218                -1
    x7        c239                -1   c240                -1
    x7        c254                -1   c264                 1
    x7        c286                 1   c313                -1
    x7        c333                 1   c345                 1
    x7        c347                 1   c348                -1
    x7        c349                -1   c372                 1
    x7        c389                -1   c413                 1
    x7        c414                 1   c416                 1
    x7        c419                 1   c425                 1
    x7        c444                -1   c456                 1
    x7        c483                -1   c492                 1
    x7        c497                -1   c520                -1
    x7        c549                -1   c584                 1
    x7        c590                -1   c611                -1
    x7        c617                -1   c618                 1
    x7        c619                -1   c655                 1
    x7        c682                 1   c702                -1
    x7        c744                -1   c780                -1
    x7        c782                 1
    x8        c2                  -1   c8                  -1
    x8        c14                  1   c75                 -1
    x8        c83                  1   c115                 1
    x8        c118                 1   c127                -1
    x8        c172                 1   c197                 1
    x8        c205                 1   c212                 1
    x8        c238                 1   c265                -1
    x8        c281                 1   c314                -1
    x8        c320                 1   c403                 1
    x8        c436                 1   c450                -1
    x8        c454                -1   c525                 1
    x8        c532                 1   c580                 1
    x8        c605                -1   c707                -1
    x8        c711                -1   c714                 1
    x8        c733                -1   c771                -1
    x9        c3                   1   c23                  1
    x9        c44                 -1   c46                  1
    x9        c65                  1   c75                 -1
    x9        c95                 -1   c115                -1
    x9        c133                -1   c185                 1
    x9        c204                -1   c222                -1
    x9        c224                -1   c243                 1
    x9        c254                 1   c281                 1
    x9        c282                 1   c327                -1
    x9        c340                -1   c438                 1
    x9        c445                 1   c479                 1
    x9        c510                 1   c575                -1
    x9        c624                -1   c633                 1
    x9        c649                -1   c652                -1
    x9        c699                -1   c713                 1
    x9        c717                -1   c724                 1
    x9        c737                 1   c739                 1
    x9        c750                 1   c751                -1
    x9        c760                 1   c774                 1
    x9        c781                 1
    x10       c3                   1   c13                 -1
    x10       c47                  1   c58                 -1
    x10       c61                  1   c75                  1
    x10       c81                 -1   c98                  1
    x10       c147                 1   c149                 1
    x10       c152                -1   c164                 1
    x10       c187                 1   c201                -1
    x10       c237                 1   c247                -1
    x10       c280                -1   c283                 1
    x10       c296                 1   c305                 1
    x10       c313                 1   c317                -1
    x10       c318                -1   c335                -1
    x10       c373                 1   c392                -1
    x10       c455                 1   c470                 1
    x10       c479                 1   c543                -1
    x10       c551                -1   c583                -1
    x10       c599                 1   c608                -1
    x10       c649                -1   c657                 1
    x10       c662                 1   c679                 1
    x10       c689                -1   c734                -1
    x10       c743                -1   c756                -1
    x10       c762                 1   c784                 1
    x11       c4                   1   c74                  1
    x11       c93                  1   c107                -1
    x11       c111                -1   c148                -1
    x11       c217                 1   c279                -1
    x11       c361                 1   c382                 1
    x11       c385                 1   c428                 1
    x11       c462                 1   c474                 1
    x11       c501                 1   c513                 1
    x11       c541                -1   c563                 1
    x11       c582                -1   c597                -1
    x11       c631                 1   c638                 1
    x11       c662                 1   c679                -1
    x11       c698                 1   c726                -1
    x11       c751                 1   c762                 1
    x11       c792                -1   c796                 1
    x11       c798                -1
    x12       c4                   1   c36                  1
    x12       c67                 -1   c94                 -1
    x12       c119                -1   c126                -1
    x12       c130                -1   c132                 1
    x12       c142                -1   c148                 1
    x12       c175                 1   c183                -1
    x12       c191                -1   c193                -1
    x12       c198                -1   c206                -1
    x12       c242                -1   c261                -1
    x12       c271                -1   c362                 1
    x12       c378                -1   c403                 1
    x12       c433                -1   c434                -1
    x12       c454                 1   c504                 1
    x12       c513                 1   c545                 1
    x12       c602                 1   c627                -1
    x12       c637                 1   c647                 1
    x12       c660                -1   c673                 1
    x12       c688                -1   c707                 1
    x12       c717                -1   c722                -1
    x12       c731                -1   c772                 1
    x12       c786                 1   c787                -1
    x13       c4                  -1   c55                 -1
    x13       c81                  1   c83                  1
    x13       c103                 1   c133                -1
    x13       c142                 1   c162                -1
    x13       c217                -1   c242                -1
    x13       c246                -1   c272                -1
    x13       c273                 1   c310                 1
    x13       c329                 1   c389                -1
    x13       c398                 1   c402                 1
    x13       c408                 1   c435                 1
    x13       c487                 1   c516                -1
    x13       c519                -1   c552                 1
    x13       c555                 1   c588                -1
    x13       c608                -1   c654                 1
    x13       c670                -1   c710                 1
    x13       c724                -1   c737                 1
    x14       c4                  -1   c21                 -1
    x14       c29                  1   c51                 -1
    x14       c72                  1   c91                 -1
    x14       c173                 1   c192                -1
    x14       c197                -1   c247                -1
    x14       c273                 1   c275                 1
    x14       c294                 1   c323                -1
    x14       c332                 1   c353                -1
    x14       c408                -1   c433                -1
    x14       c437                -1   c464                -1
    x14       c465                 1   c502                 1
    x14       c521                 1   c580                -1
    x14       c589                 1   c593                 1
    x14       c599                 1   c626                 1
    x14       c677                 1   c706                -1
    x14       c709                -1   c743                 1
    x14       c746                 1   c777                -1
    x14       c798                -1
    x15       c4                   1   c12                  1
    x15       c19                  1   c45                  1
    x15       c73                 -1   c89                  1
    x15       c124                -1   c130                 1
    x15       c212                 1   c245                 1
    x15       c258                -1   c261                -1
    x15       c333                 1   c340                 1
    x15       c389                 1   c414                -1
    x15       c517                -1   c521                -1
    x15       c524                 1   c542                -1
    x15       c582                -1   c647                -1
    x15       c661                 1   c694                 1
    x15       c718                 1   c754                 1
    x15       c774                 1   c776                 1
    x16       c4                  -1   c12                 -1
    x16       c33                 -1   c47                  1
    x16       c68                  1   c73                 -1
    x16       c82                 -1   c97                  1
    x16       c126                -1   c139                 1
    x16       c171                 1   c187                 1
    x16       c240                 1   c261                -1
    x16       c310                 1   c335                 1
    x16       c341                -1   c342                 1
    x16       c347                -1   c349                 1
    x16       c372                -1   c395                 1
    x16       c418                 1   c437                 1
    x16       c464                 1   c514                -1
    x16       c517                -1   c524                 1
    x16       c552                -1   c603                 1
    x16       c621                 1   c642                 1
    x16       c705                -1   c709                -1
    x16       c719                 1   c735                 1
    x16       c762                -1   c765                -1
    x16       c775                 1   c790                 1
    x17       c5                  -1   c40                 -1
    x17       c44                 -1   c88                  1
    x17       c90                 -1   c100                -1
    x17       c126                 1   c134                 1
    x17       c141                -1   c145                -1
    x17       c156                 1   c157                 1
    x17       c196                -1   c204                -1
    x17       c225                -1   c239                 1
    x17       c260                 1   c264                -1
    x17       c273                -1   c288                 1
    x17       c315                -1   c328                 1
    x17       c361                 1   c377                 1
    x17       c430                 1   c453                -1
    x17       c501                 1   c526                 1
    x17       c532                -1   c533                 1
    x17       c538                -1   c540                 1
    x17       c562                -1   c585                 1
    x17       c608                 1   c627                 1
    x17       c654                 1   c703                -1
    x17       c706                -1   c713                 1
    x17       c742                -1   c792                 1
    x18       c5                  -1   c13                 -1
    x18       c49                 -1   c69                 -1
    x18       c79                 -1   c171                 1
    x18       c187                -1   c212                 1
    x18       c242                -1   c243                -1
    x18       c261                 1   c312                 1
    x18       c321                 1   c354                 1
    x18       c411                 1   c436                -1
    x18       c446                 1   c456                 1
    x18       c469                -1   c483                 1
    x18       c498                -1   c517                 1
    x18       c527                -1   c532                -1
    x18       c541                -1   c583                 1
    x18       c596                 1   c597                -1
    x18       c613                 1   c630                -1
    x18       c635                 1   c636                 1
    x18       c647                -1   c660                -1
    x18       c665                 1   c687                 1
    x18       c706                 1   c714                -1
    x18       c788                -1
    x19       c5                  -1   c14                  1
    x19       c18                  1   c24                  1
    x19       c51                  1   c104                 1
    x19       c134                -1   c137                -1
    x19       c170                 1   c173                 1
    x19       c206                -1   c226                -1
    x19       c271                 1   c288                -1
    x19       c328                 1   c342                -1
    x19       c355                 1   c425                -1
    x19       c443                 1   c465                 1
    x19       c497                -1   c499                 1
    x19       c517                -1   c534                 1
    x19       c559                -1   c561                 1
    x19       c568                 1   c598                -1
    x19       c652                -1   c662                -1
    x19       c667                -1   c683                -1
    x19       c705                -1   c718                 1
    x19       c719                 1   c725                 1
    x19       c727                 1   c750                -1
    x19       c791                -1   c797                -1
    x20       c5                  -1   c29                  1
    x20       c30                  1   c32                  1
    x20       c35                  1   c41                  1
    x20       c59                 -1   c71                  1
    x20       c100                -1   c109                 1
    x20       c115                -1   c138                -1
    x20       c167                -1   c202                 1
    x20       c208                -1   c229                -1
    x20       c235                -1   c236                 1
    x20       c237                -1   c272                 1
    x20       c300                 1   c320                -1
    x20       c362                -1   c400                -1
    x20       c402                 1   c488                 1
    x20       c489                 1   c497                 1
    x20       c505                 1   c516                 1
    x20       c518                 1   c551                 1
    x20       c592                 1   c625                -1
    x20       c659                 1   c686                 1
    x20       c736                -1   c744                -1
    x20       c747                -1   c757                -1
    x20       c766                 1
    x21       c5                   1   c30                 -1
    x21       c135                -1   c139                -1
    x21       c142                 1   c160                -1
    x21       c200                -1   c263                -1
    x21       c278                 1   c312                 1
    x21       c336                 1   c372                 1
    x21       c394                 1   c396                 1
    x21       c421                 1   c432                -1
    x21       c448                -1   c508                -1
    x21       c521                 1   c526                -1
    x21       c529                 1   c533                 1
    x21       c546                 1   c559                 1
    x21       c575                 1   c583                 1
    x21       c625                -1   c658                 1
    x21       c660                -1   c677                 1
    x21       c683                 1   c709                 1
    x21       c761                -1   c776                 1
    x21       c796                -1
    x22       c6                  -1   c18                  1
    x22       c47                  1   c51                  1
    x22       c123                 1   c124                -1
    x22       c171                -1   c200                 1
    x22       c281                -1   c289                -1
    x22       c293                -1   c362                -1
    x22       c389                -1   c424                -1
    x22       c428                -1   c472                 1
    x22       c474                -1   c483                -1
    x22       c508                 1   c516                 1
    x22       c523                -1   c527                -1
    x22       c539                 1   c540                 1
    x22       c578                -1   c586                -1
    x22       c607                -1   c621                 1
    x22       c643                 1   c648                -1
    x22       c656                -1   c670                 1
    x22       c697                -1   c710                 1
    x22       c743                 1   c758                 1
    x23       c7                  -1   c22                 -1
    x23       c56                  1   c62                  1
    x23       c87                  1   c106                -1
    x23       c126                 1   c154                -1
    x23       c178                 1   c191                 1
    x23       c220                -1   c224                 1
    x23       c226                -1   c230                 1
    x23       c235                -1   c266                 1
    x23       c290                -1   c291                 1
    x23       c323                -1   c327                 1
    x23       c328                -1   c346                -1
    x23       c371                 1   c393                 1
    x23       c394                 1   c399                 1
    x23       c443                 1   c444                -1
    x23       c457                 1   c470                 1
    x23       c498                -1   c499                -1
    x23       c506                 1   c531                -1
    x23       c581                 1   c596                 1
    x23       c620                -1   c700                 1
    x23       c701                -1   c709                -1
    x23       c712                 1   c714                 1
    x23       c715                -1   c762                -1
    x23       c797                -1   c799                -1
    x24       c7                   1   c89                 -1
    x24       c97                 -1   c102                -1
    x24       c171                -1   c198                -1
    x24       c233                -1   c237                -1
    x24       c280                 1   c282                -1
    x24       c291                -1   c316                 1
    x24       c324                 1   c331                -1
    x24       c335                -1   c347                 1
    x24       c348                 1   c387                -1
    x24       c395                -1   c416                -1
    x24       c430                 1   c452                 1
    x24       c457                -1   c465                -1
    x24       c480                 1   c507                -1
    x24       c520                 1   c552                 1
    x24       c568                 1   c621                 1
    x24       c644                -1   c691                 1
    x24       c716                 1   c722                -1
    x24       c723                 1   c728                -1
    x24       c730                 1   c753                -1
    x24       c774                 1   c798                 1
    x25       c7                  -1   c71                 -1
    x25       c86                  1   c122                 1
    x25       c146                 1   c181                 1
    x25       c203                 1   c205                 1
    x25       c230                 1   c241                -1
    x25       c256                -1   c316                -1
    x25       c329                 1   c334                -1
    x25       c337                 1   c341                 1
    x25       c355                 1   c368                 1
    x25       c384                 1   c392                 1
    x25       c434                -1   c467                 1
    x25       c469                -1   c487                 1
    x25       c493                 1   c519                 1
    x25       c572                -1   c587                 1
    x25       c606                -1   c617                 1
    x25       c627                -1   c663                -1
    x25       c682                 1   c695                 1
    x25       c697                 1   c713                -1
    x25       c760                 1   c766                -1
    x25       c767                 1   c772                -1
    x25       c778                 1   c792                 1
    x26       c7                   1   c22                  1
    x26       c46                 -1   c129                 1
    x26       c130                -1   c138                -1
    x26       c141                 1   c143                 1
    x26       c144                -1   c192                -1
    x26       c226                -1   c228                -1
    x26       c248                 1   c256                 1
    x26       c301                 1   c330                -1
    x26       c348                -1   c407                -1
    x26       c414                 1   c431                -1
    x26       c449                -1   c476                -1
    x26       c480                 1   c515                -1
    x26       c525                 1   c545                -1
    x26       c602                -1   c620                 1
    x26       c625                -1   c637                -1
    x26       c642                 1   c658                 1
    x26       c680                 1   c687                 1
    x26       c722                -1   c739                 1
    x26       c776                 1   c783                 1
    x27       c7                  -1   c17                  1
    x27       c29                 -1   c34                 -1
    x27       c40                  1   c63                 -1
    x27       c103                 1   c120                -1
    x27       c131                -1   c141                -1
    x27       c169                 1   c184                -1
    x27       c197                -1   c214                -1
    x27       c222                 1   c244                -1
    x27       c264                 1   c283                -1
    x27       c364                 1   c383                -1
    x27       c388                -1   c439                -1
    x27       c465                 1   c467                 1
    x27       c486                 1   c515                -1
    x27       c524                 1   c544                -1
    x27       c599                -1   c624                -1
    x27       c628                -1   c655                -1
    x27       c656                 1   c692                 1
    x27       c711                 1   c769                -1
    x27       c778                 1   c782                 1
    x27       c789                 1
    x28       c7                   1   c20                  1
    x28       c26                 -1   c91                 -1
    x28       c108                 1   c113                 1
    x28       c116                -1   c138                -1
    x28       c148                -1   c154                -1
    x28       c196                 1   c206                -1
    x28       c240                 1   c251                -1
    x28       c254                 1   c267                 1
    x28       c273                -1   c290                 1
    x28       c337                 1   c339                 1
    x28       c342                -1   c355                 1
    x28       c378                 1   c392                -1
    x28       c428                 1   c439                -1
    x28       c472                -1   c475                 1
    x28       c488                 1   c497                 1
    x28       c505                 1   c509                -1
    x28       c510                -1   c527                -1
    x28       c564                 1   c583                -1
    x28       c646                 1   c661                 1
    x28       c669                 1   c734                -1
    x28       c742                -1   c772                -1
    x28       c789                 1   c798                -1
    x29       c8                   1   c21                  1
    x29       c22                 -1   c38                  1
    x29       c55                 -1   c59                  1
    x29       c60                  1   c71                 -1
    x29       c85                 -1   c90                  1
    x29       c115                 1   c134                 1
    x29       c142                -1   c216                -1
    x29       c235                -1   c259                 1
    x29       c262                -1   c340                -1
    x29       c377                 1   c511                -1
    x29       c522                 1   c535                 1
    x29       c542                 1   c547                 1
    x29       c550                -1   c561                -1
    x29       c576                -1   c579                -1
    x29       c586                -1   c597                 1
    x29       c620                 1   c631                 1
    x29       c663                 1   c664                 1
    x29       c673                 1   c681                 1
    x29       c683                -1   c709                -1
    x29       c711                 1   c723                -1
    x29       c744                 1   c747                -1
    x29       c758                 1   c789                -1
    x30       c8                   1   c50                 -1
    x30       c83                  1   c85                 -1
    x30       c104                 1   c110                 1
    x30       c137                 1   c190                -1
    x30       c205                 1   c224                -1
    x30       c235                 1   c245                -1
    x30       c280                -1   c300                 1
    x30       c313                 1   c315                 1
    x30       c331                -1   c380                 1
    x30       c386                -1   c387                 1
    x30       c392                -1   c398                 1
    x30       c411                 1   c444                -1
    x30       c472                -1   c474                -1
    x30       c494                -1   c507                 1
    x30       c511                 1   c564                -1
    x30       c577                -1   c588                 1
    x30       c598                 1   c601                 1
    x30       c609                -1   c630                 1
    x30       c654                -1   c675                -1
    x30       c720                -1   c730                -1
    x30       c772                -1
    x31       c8                  -1   c24                  1
    x31       c33                 -1   c73                 -1
    x31       c82                  1   c87                  1
    x31       c106                 1   c117                -1
    x31       c161                -1   c170                -1
    x31       c183                -1   c191                 1
    x31       c213                 1   c290                 1
    x31       c300                 1   c337                -1
    x31       c342                -1   c358                 1
    x31       c388                 1   c459                 1
    x31       c477                 1   c490                -1
    x31       c494                -1   c530                -1
    x31       c599                 1   c662                -1
    x31       c743                 1   c762                 1
    x31       c765                 1
    x32       c8                   1   c19                  1
    x32       c28                 -1   c40                  1
    x32       c43                  1   c53                 -1
    x32       c72                  1   c94                  1
    x32       c136                -1   c151                -1
    x32       c160                 1   c186                 1
    x32       c187                -1   c197                 1
    x32       c229                 1   c260                -1
    x32       c286                -1   c309                -1
    x32       c316                -1   c320                -1
    x32       c322                 1   c332                -1
    x32       c338                 1   c366                 1
    x32       c374                -1   c382                -1
    x32       c384                -1   c389                -1
    x32       c397                -1   c433                -1
    x32       c454                -1   c463                -1
    x32       c553                 1   c569                -1
    x32       c594                 1   c624                -1
    x32       c625                -1   c645                 1
    x32       c694                 1   c703                 1
    x32       c736                 1   c792                 1
    x33       c8                  -1   c70                  1
    x33       c86                  1   c95                  1
    x33       c161                -1   c169                -1
    x33       c201                -1   c217                 1
    x33       c226                -1   c265                -1
    x33       c274                 1   c279                 1
    x33       c297                 1   c307                -1
    x33       c352                -1   c361                -1
    x33       c374                -1   c382                 1
    x33       c404                 1   c482                 1
    x33       c492                 1   c529                -1
    x33       c534                -1   c549                 1
    x33       c579                 1   c650                 1
    x33       c667                 1   c680                -1
    x33       c684                -1   c720                -1
    x33       c789                 1
    x34       c8                  -1   c44                  1
    x34       c55                 -1   c88                 -1
    x34       c91                  1   c105                 1
    x34       c115                 1   c123                 1
    x34       c127                -1   c128                -1
    x34       c145                -1   c182                 1
    x34       c201                -1   c262                 1
    x34       c278                 1   c287                 1
    x34       c352                -1   c360                -1
    x34       c392                -1   c408                 1
    x34       c417                -1   c458                -1
    x34       c466                 1   c471                 1
    x34       c489                 1   c499                -1
    x34       c543                -1   c552                -1
    x34       c565                -1   c573                 1
    x34       c595                 1   c672                 1
    x34       c682                 1   c719                -1
    x34       c724                -1   c740                 1
    x34       c768                 1
    x35       c9                   1   c33                 -1
    x35       c43                 -1   c50                  1
    x35       c60                  1   c93                  1
    x35       c96                  1   c125                -1
    x35       c156                 1   c169                -1
    x35       c172                 1   c178                -1
    x35       c220                 1   c237                 1
    x35       c267                -1   c299                -1
    x35       c374                -1   c390                -1
    x35       c402                 1   c431                 1
    x35       c435                 1   c505                 1
    x35       c506                -1   c553                -1
    x35       c582                 1   c664                -1
    x35       c671                -1   c675                -1
    x35       c744                -1   c769                -1
    x36       c9                   1   c66                 -1
    x36       c69                 -1   c84                 -1
    x36       c118                 1   c127                 1
    x36       c164                 1   c167                -1
    x36       c187                -1   c191                 1
    x36       c205                 1   c207                -1
    x36       c208                 1   c210                -1
    x36       c259                 1   c271                -1
    x36       c295                 1   c307                -1
    x36       c311                -1   c316                 1
    x36       c324                -1   c330                -1
    x36       c340                -1   c343                 1
    x36       c356                -1   c377                -1
    x36       c379                 1   c381                 1
    x36       c399                 1   c432                -1
    x36       c458                -1   c484                -1
    x36       c488                 1   c494                 1
    x36       c500                 1   c508                -1
    x36       c514                 1   c541                -1
    x36       c547                -1   c557                -1
    x36       c597                -1   c611                 1
    x36       c703                -1   c737                 1
    x36       c742                -1   c755                 1
    x36       c762                 1   c779                -1
    x37       c9                   1   c15                 -1
    x37       c36                 -1   c42                 -1
    x37       c43                  1   c44                 -1
    x37       c80                  1   c109                 1
    x37       c130                -1   c171                -1
    x37       c209                -1   c211                 1
    x37       c296                 1   c297                 1
    x37       c305                 1   c313                 1
    x37       c324                 1   c326                 1
    x37       c360                 1   c401                 1
    x37       c434                -1   c468                 1
    x37       c496                 1   c545                -1
    x37       c553                -1   c556                -1
    x37       c567                -1   c577                 1
    x37       c647                 1   c677                -1
    x37       c690                 1   c698                -1
    x37       c736                 1   c743                -1
    x37       c763                 1   c777                -1
    x38       c9                  -1   c43                 -1
    x38       c47                 -1   c67                  1
    x38       c88                  1   c155                 1
    x38       c173                 1   c177                 1
    x38       c180                 1   c182                 1
    x38       c220                 1   c231                 1
    x38       c255                 1   c266                 1
    x38       c287                -1   c345                -1
    x38       c362                -1   c391                 1
    x38       c404                 1   c410                -1
    x38       c475                -1   c491                 1
    x38       c495                 1   c498                -1
    x38       c520                -1   c530                -1
    x38       c536                -1   c578                 1
    x38       c588                -1   c622                 1
    x38       c634                -1   c637                 1
    x38       c651                 1   c656                -1
    x38       c672                 1   c719                 1
    x38       c721                 1   c724                -1
    x38       c737                 1   c759                 1
    x38       c772                -1
    x39       c10                  1   c12                  1
    x39       c37                  1   c48                 -1
    x39       c63                 -1   c126                -1
    x39       c139                 1   c144                -1
    x39       c147                 1   c151                 1
    x39       c164                 1   c177                 1
    x39       c193                 1   c201                 1
    x39       c243                -1   c275                 1
    x39       c277                -1   c295                 1
    x39       c301                 1   c327                 1
    x39       c381                -1   c396                 1
    x39       c415                -1   c426                 1
    x39       c436                -1   c472                -1
    x39       c492                 1   c505                 1
    x39       c507                 1   c523                -1
    x39       c571                 1   c577                -1
    x39       c578                 1   c583                -1
    x39       c589                 1   c602                 1
    x39       c635                -1   c663                -1
    x39       c665                -1   c684                -1
    x39       c697                 1   c701                 1
    x39       c755                -1   c766                -1
    x39       c777                 1   c788                 1
    x39       c791                 1   c799                -1
    x40       c10                  1   c11                  1
    x40       c16                  1   c60                 -1
    x40       c73                  1   c87                  1
    x40       c117                -1   c118                -1
    x40       c125                 1   c150                -1
    x40       c200                 1   c215                 1
    x40       c239                -1   c319                 1
    x40       c320                -1   c328                -1
    x40       c331                 1   c333                 1
    x40       c334                -1   c383                -1
    x40       c417                -1   c419                -1
    x40       c440                 1   c448                 1
    x40       c493                 1   c522                -1
    x40       c540                -1   c598                -1
    x40       c605                 1   c622                -1
    x40       c640                -1   c670                 1
    x40       c705                -1   c715                 1
    x40       c736                -1   c792                -1
    x41       c11                 -1   c29                 -1
    x41       c31                 -1   c50                  1
    x41       c61                  1   c89                  1
    x41       c90                  1   c137                -1
    x41       c150                -1   c253                 1
    x41       c287                 1   c318                 1
    x41       c384                -1   c433                -1
    x41       c442                 1   c458                -1
    x41       c461                -1   c509                -1
    x41       c523                 1   c527                -1
    x41       c534                 1   c546                 1
    x41       c548                 1   c559                 1
    x41       c560                -1   c571                 1
    x41       c585                 1   c592                 1
    x41       c620                 1   c667                 1
    x41       c669                -1   c675                 1
    x41       c677                -1   c679                 1
    x41       c722                 1   c723                 1
    x41       c736                -1   c739                 1
    x41       c796                -1
    x42       c11                 -1   c59                 -1
    x42       c102                 1   c121                -1
    x42       c133                 1   c164                -1
    x42       c169                 1   c176                -1
    x42       c185                -1   c190                 1
    x42       c202                 1   c226                -1
    x42       c236                -1   c243                 1
    x42       c253                 1   c285                 1
    x42       c288                 1   c315                -1
    x42       c347                 1   c360                -1
    x42       c363                 1   c369                -1
    x42       c411                 1   c428                 1
    x42       c460                -1   c491                -1
    x42       c565                -1   c581                -1
    x42       c593                 1   c622                 1
    x42       c626                 1   c695                 1
    x42       c696                -1   c744                -1
    x42       c771                 1
    x43       c11                  1   c25                  1
    x43       c83                  1   c137                -1
    x43       c145                 1   c156                 1
    x43       c164                -1   c169                -1
    x43       c217                 1   c243                -1
    x43       c254                 1   c269                 1
    x43       c274                -1   c276                -1
    x43       c286                 1   c299                 1
    x43       c310                 1   c317                 1
    x43       c323                 1   c326                 1
    x43       c380                -1   c398                -1
    x43       c404                -1   c481                 1
    x43       c495                 1   c514                 1
    x43       c539                -1   c552                -1
    x43       c564                -1   c603                -1
    x43       c652                -1   c660                -1
    x43       c672                -1   c674                -1
    x43       c678                -1   c709                -1
    x43       c714                 1   c725                -1
    x43       c728                -1   c739                -1
    x43       c786                -1
    x44       c11                  1   c34                  1
    x44       c53                  1   c80                  1
    x44       c132                -1   c135                -1
    x44       c142                 1   c170                -1
    x44       c221                 1   c239                 1
    x44       c259                 1   c323                -1
    x44       c327                -1   c337                 1
    x44       c353                 1   c382                -1
    x44       c385                -1   c395                 1
    x44       c409                 1   c467                 1
    x44       c519                -1   c527                 1
    x44       c539                 1   c546                -1
    x44       c551                -1   c599                 1
    x44       c625                -1   c637                 1
    x44       c653                 1   c657                -1
    x44       c659                -1   c668                 1
    x44       c681                 1   c692                 1
    x44       c699                 1   c705                 1
    x44       c708                 1   c760                -1
    x44       c778                -1   c784                -1
    x45       c11                  1   c18                  1
    x45       c46                  1   c94                  1
    x45       c96                 -1   c103                 1
    x45       c105                -1   c107                 1
    x45       c151                 1   c152                 1
    x45       c164                -1   c167                 1
    x45       c225                -1   c267                 1
    x45       c270                -1   c278                 1
    x45       c297                -1   c321                 1
    x45       c372                -1   c379                 1
    x45       c384                 1   c405                -1
    x45       c424                 1   c425                 1
    x45       c435                -1   c455                 1
    x45       c464                -1   c560                 1
    x45       c589                 1   c649                 1
    x45       c667                -1   c682                -1
    x45       c695                 1   c707                -1
    x45       c717                 1   c723                 1
    x45       c729                 1   c730                 1
    x45       c763                 1   c775                -1
    x46       c12                  1   c31                 -1
    x46       c42                  1   c52                 -1
    x46       c88                 -1   c109                 1
    x46       c123                 1   c125                 1
    x46       c141                -1   c189                 1
    x46       c195                -1   c196                 1
    x46       c201                -1   c207                 1
    x46       c220                 1   c252                -1
    x46       c280                -1   c282                -1
    x46       c302                -1   c315                 1
    x46       c319                 1   c373                -1
    x46       c386                -1   c397                 1
    x46       c407                 1   c410                 1
    x46       c418                -1   c439                 1
    x46       c463                -1   c485                -1
    x46       c530                -1   c540                -1
    x46       c583                -1   c617                -1
    x46       c621                -1   c642                 1
    x46       c662                 1   c726                 1
    x46       c745                 1   c749                 1
    x46       c752                 1   c754                 1
    x46       c791                 1
    x47       c12                  1   c14                 -1
    x47       c15                  1   c17                 -1
    x47       c66                  1   c79                 -1
    x47       c104                 1   c117                -1
    x47       c121                -1   c126                 1
    x47       c134                -1   c140                -1
    x47       c150                -1   c153                 1
    x47       c165                -1   c186                -1
    x47       c188                 1   c190                 1
    x47       c208                 1   c241                -1
    x47       c265                -1   c292                -1
    x47       c296                 1   c302                 1
    x47       c308                 1   c316                -1
    x47       c322                 1   c349                -1
    x47       c356                -1   c366                -1
    x47       c406                -1   c420                 1
    x47       c513                -1   c546                 1
    x47       c551                -1   c564                 1
    x47       c573                 1   c590                -1
    x47       c665                -1   c788                -1
    x48       c12                  1   c19                  1
    x48       c47                  1   c121                 1
    x48       c165                 1   c181                -1
    x48       c208                 1   c236                -1
    x48       c241                -1   c276                -1
    x48       c305                -1   c318                 1
    x48       c356                 1   c380                -1
    x48       c383                -1   c385                -1
    x48       c387                 1   c407                 1
    x48       c428                -1   c430                 1
    x48       c450                 1   c460                -1
    x48       c479                -1   c497                -1
    x48       c515                -1   c567                 1
    x48       c586                -1   c604                -1
    x48       c606                -1   c625                 1
    x48       c637                 1   c664                 1
    x48       c665                 1   c709                -1
    x48       c722                -1
    x49       c13                 -1   c44                  1
    x49       c61                  1   c84                  1
    x49       c104                -1   c107                -1
    x49       c156                 1   c161                 1
    x49       c241                -1   c244                -1
    x49       c248                 1   c252                 1
    x49       c282                 1   c345                -1
    x49       c361                -1   c367                -1
    x49       c415                 1   c437                -1
    x49       c486                 1   c518                -1
    x49       c523                 1   c544                 1
    x49       c559                -1   c621                -1
    x49       c633                -1   c636                -1
    x49       c639                 1   c648                 1
    x49       c653                -1   c671                -1
    x49       c672                 1   c676                 1
    x49       c707                 1   c714                -1
    x49       c731                 1   c746                 1
    x49       c770                -1   c780                 1
    x49       c793                -1   c798                -1
    x50       c13                 -1   c33                 -1
    x50       c79                  1   c96                 -1
    x50       c138                 1   c152                -1
    x50       c164                 1   c234                -1
    x50       c251                 1   c273                 1
    x50       c305                -1   c307                 1
    x50       c325                -1   c342                 1
    x50       c368                -1   c370                 1
    x50       c377                 1   c407                -1
    x50       c461                -1   c471                -1
    x50       c477                -1   c493                -1
    x50       c515                -1   c528                 1
    x50       c529                 1   c535                 1
    x50       c537                 1   c559                -1
    x50       c601                -1   c607                -1
    x50       c612                -1   c636                 1
    x50       c640                 1   c654                -1
    x50       c667                -1   c678                -1
    x50       c688                 1   c703                 1
    x50       c747                -1   c781                -1
    x50       c788                 1   c800                 1
    x51       c14                 -1   c20                 -1
    x51       c97                  1   c113                 1
    x51       c132                 1   c156                -1
    x51       c170                -1   c182                -1
    x51       c221                -1   c268                -1
    x51       c277                -1   c290                -1
    x51       c292                -1   c296                -1
    x51       c327                -1   c332                 1
    x51       c343                -1   c346                -1
    x51       c357                -1   c405                -1
    x51       c434                 1   c436                -1
    x51       c485                 1   c496                -1
    x51       c504                 1   c516                 1
    x51       c522                 1   c534                -1
    x51       c550                 1   c568                -1
    x51       c591                -1   c598                -1
    x51       c601                 1   c632                -1
    x51       c655                 1   c665                -1
    x51       c697                 1   c723                 1
    x51       c742                 1   c760                -1
    x52       c14                  1   c73                  1
    x52       c93                 -1   c109                -1
    x52       c123                 1   c135                -1
    x52       c145                 1   c151                 1
    x52       c156                 1   c157                 1
    x52       c192                 1   c204                -1
    x52       c252                -1   c293                 1
    x52       c311                -1   c323                 1
    x52       c355                -1   c360                 1
    x52       c367                -1   c376                -1
    x52       c381                 1   c393                 1
    x52       c417                -1   c427                -1
    x52       c434                 1   c445                 1
    x52       c477                 1   c480                 1
    x52       c507                -1   c539                 1
    x52       c551                -1   c554                 1
    x52       c560                -1   c602                 1
    x52       c619                 1   c651                -1
    x52       c681                -1   c756                -1
    x52       c770                -1   c782                 1
    x53       c14                 -1   c16                 -1
    x53       c17                  1   c39                 -1
    x53       c40                  1   c66                  1
    x53       c103                 1   c144                -1
    x53       c157                 1   c186                 1
    x53       c192                 1   c219                 1
    x53       c232                 1   c245                -1
    x53       c250                 1   c251                 1
    x53       c290                 1   c296                -1
    x53       c298                -1   c353                -1
    x53       c368                -1   c369                 1
    x53       c392                 1   c403                 1
    x53       c412                -1   c424                 1
    x53       c427                 1   c437                -1
    x53       c457                 1   c478                 1
    x53       c518                -1   c533                -1
    x53       c542                 1   c568                 1
    x53       c569                -1   c579                 1
    x53       c611                 1   c643                -1
    x53       c668                -1   c691                -1
    x53       c698                -1   c702                -1
    x53       c704                 1   c714                -1
    x53       c720                 1   c748                 1
    x53       c756                -1   c762                -1
    x53       c764                -1   c769                -1
    x53       c777                -1
    x54       c15                 -1   c90                 -1
    x54       c216                -1   c256                 1
    x54       c260                 1   c281                -1
    x54       c302                 1   c310                 1
    x54       c385                -1   c391                -1
    x54       c397                 1   c459                -1
    x54       c466                 1   c496                 1
    x54       c499                 1   c508                -1
    x54       c553                 1   c578                 1
    x54       c586                 1   c593                 1
    x54       c619                 1   c648                -1
    x54       c663                 1   c695                -1
    x54       c701                 1   c782                 1
    x55       c15                  1   c48                 -1
    x55       c73                 -1   c101                -1
    x55       c105                 1   c111                 1
    x55       c118                 1   c126                -1
    x55       c132                 1   c158                -1
    x55       c165                -1   c175                -1
    x55       c215                -1   c229                 1
    x55       c321                -1   c355                 1
    x55       c360                -1   c373                 1
    x55       c382                 1   c399                -1
    x55       c474                -1   c598                -1
    x55       c639                 1   c643                 1
    x55       c664                -1   c684                 1
    x55       c692                 1   c765                -1
    x55       c771                -1   c777                 1
    x56       c15                  1   c43                 -1
    x56       c48                 -1   c84                 -1
    x56       c115                -1   c128                 1
    x56       c165                 1   c189                -1
    x56       c192                -1   c194                -1
    x56       c196                 1   c216                 1
    x56       c237                -1   c239                 1
    x56       c258                 1   c267                -1
    x56       c287                -1   c305                -1
    x56       c323                -1   c376                 1
    x56       c395                -1   c413                -1
    x56       c415                -1   c434                 1
    x56       c446                 1   c473                 1
    x56       c474                 1   c519                -1
    x56       c532                -1   c629                 1
    x56       c636                 1   c669                 1
    x56       c700                 1   c764                -1
    x57       c16                 -1   c23                 -1
    x57       c26                  1   c57                 -1
    x57       c80                  1   c90                 -1
    x57       c125                 1   c151                 1
    x57       c169                 1   c189                -1
    x57       c238                 1   c245                 1
    x57       c257                -1   c289                -1
    x57       c302                -1   c314                -1
    x57       c334                -1   c344                -1
    x57       c350                 1   c359                -1
    x57       c377                -1   c410                 1
    x57       c414                 1   c415                 1
    x57       c429                 1   c453                -1
    x57       c485                 1   c569                 1
    x57       c601                -1   c606                 1
    x57       c609                -1   c619                -1
    x57       c686                -1   c712                 1
    x57       c720                -1   c767                -1
    x57       c790                 1
    x58       c16                 -1   c18                  1
    x58       c105                 1   c106                 1
    x58       c115                 1   c123                 1
    x58       c134                 1   c136                 1
    x58       c169                 1   c210                 1
    x58       c243                -1   c276                 1
    x58       c304                 1   c354                -1
    x58       c362                -1   c365                -1
    x58       c376                -1   c386                 1
    x58       c456                 1   c487                -1
    x58       c500                 1   c508                -1
    x58       c545                 1   c552                -1
    x58       c566                -1   c574                 1
    x58       c588                -1   c619                 1
    x58       c637                 1   c659                 1
    x58       c677                -1   c680                -1
    x58       c729                 1   c734                 1
    x59       c17                  1   c50                 -1
    x59       c84                  1   c114                 1
    x59       c163                -1   c171                -1
    x59       c174                -1   c185                -1
    x59       c195                 1   c263                 1
    x59       c295                -1   c308                 1
    x59       c316                -1   c354                 1
    x59       c361                -1   c375                -1
    x59       c383                 1   c397                -1
    x59       c428                 1   c446                 1
    x59       c468                 1   c487                -1
    x59       c490                -1   c539                 1
    x59       c543                 1   c623                -1
    x59       c626                -1   c631                 1
    x59       c635                 1   c665                 1
    x59       c727                -1   c743                -1
    x59       c749                -1   c796                 1
    x60       c18                 -1   c24                  1
    x60       c36                  1   c67                  1
    x60       c76                 -1   c86                  1
    x60       c87                  1   c92                 -1
    x60       c112                 1   c136                -1
    x60       c173                -1   c226                -1
    x60       c232                 1   c247                -1
    x60       c280                -1   c324                 1
    x60       c338                -1   c409                -1
    x60       c485                 1   c487                -1
    x60       c492                -1   c500                 1
    x60       c507                -1   c516                -1
    x60       c528                 1   c542                 1
    x60       c570                 1   c609                 1
    x60       c615                -1   c638                -1
    x60       c661                -1   c722                 1
    x60       c750                -1   c800                -1
    x61       c19                  1   c49                 -1
    x61       c50                 -1   c69                  1
    x61       c122                 1   c131                 1
    x61       c163                 1   c220                 1
    x61       c245                -1   c254                 1
    x61       c263                 1   c277                -1
    x61       c291                 1   c306                -1
    x61       c325                 1   c335                -1
    x61       c340                -1   c349                -1
    x61       c392                 1   c405                 1
    x61       c406                -1   c422                 1
    x61       c439                -1   c444                 1
    x61       c445                 1   c456                -1
    x61       c469                -1   c474                 1
    x61       c497                 1   c516                 1
    x61       c524                -1   c598                -1
    x61       c617                -1   c642                 1
    x61       c646                -1   c722                -1
    x61       c758                 1
    x62       c19                  1   c52                  1
    x62       c65                 -1   c69                 -1
    x62       c143                 1   c150                 1
    x62       c198                 1   c223                -1
    x62       c325                -1   c329                -1
    x62       c332                 1   c351                -1
    x62       c391                -1   c456                -1
    x62       c470                 1   c504                 1
    x62       c528                 1   c563                 1
    x62       c585                 1   c587                 1
    x62       c612                 1   c623                -1
    x62       c639                -1   c698                -1
    x62       c711                 1   c716                -1
    x62       c719                 1   c723                 1
    x62       c737                 1   c750                 1
    x62       c764                 1   c772                 1
    x63       c20                  1   c98                  1
    x63       c109                 1   c147                -1
    x63       c152                -1   c167                 1
    x63       c197                 1   c266                 1
    x63       c285                 1   c298                -1
    x63       c302                -1   c338                -1
    x63       c408                 1   c471                -1
    x63       c552                 1   c573                 1
    x63       c576                 1   c619                 1
    x63       c653                 1   c665                 1
    x63       c685                 1   c691                 1
    x63       c703                 1   c731                -1
    x63       c754                 1   c771                -1
    x63       c787                -1
    x64       c21                 -1   c50                  1
    x64       c52                 -1   c102                 1
    x64       c114                -1   c122                 1
    x64       c134                 1   c140                 1
    x64       c152                -1   c168                 1
    x64       c186                -1   c209                -1
    x64       c216                -1   c219                 1
    x64       c249                -1   c272                 1
    x64       c282                -1   c315                 1
    x64       c341                 1   c360                 1
    x64       c380                -1   c429                 1
    x64       c436                 1   c449                -1
    x64       c481                -1   c494                -1
    x64       c506                -1   c526                -1
    x64       c536                -1   c550                -1
    x64       c568                -1   c601                 1
    x64       c605                 1   c606                 1
    x64       c620                 1   c644                -1
    x64       c675                 1   c759                 1
    x64       c791                -1   c796                 1
    x64       c799                -1
    x65       c21                 -1   c40                  1
    x65       c41                  1   c51                 -1
    x65       c70                  1   c80                 -1
    x65       c178                 1   c207                 1
    x65       c265                 1   c285                -1
    x65       c300                -1   c313                 1
    x65       c325                -1   c335                 1
    x65       c341                 1   c347                 1
    x65       c348                 1   c383                 1
    x65       c395                -1   c444                -1
    x65       c485                 1   c503                -1
    x65       c515                 1   c546                -1
    x65       c551                 1   c558                -1
    x65       c567                -1   c572                 1
    x65       c584                 1   c608                -1
    x65       c618                -1   c625                 1
    x65       c636                 1   c667                 1
    x65       c670                 1   c697                -1
    x65       c729                 1   c742                -1
    x65       c745                 1   c751                -1
    x65       c792                 1
    x66       c22                 -1   c36                  1
    x66       c131                -1   c164                 1
    x66       c169                -1   c182                 1
    x66       c191                 1   c208                -1
    x66       c282                -1   c407                -1
    x66       c448                 1   c452                 1
    x66       c473                -1   c494                 1
    x66       c502                 1   c576                -1
    x66       c582                -1   c588                 1
    x66       c650                -1   c657                 1
    x66       c686                 1   c689                 1
    x66       c698                -1   c744                 1
    x66       c767                 1   c775                 1
    x66       c782                 1
    x67       c23                 -1   c76                 -1
    x67       c87                 -1   c93                 -1
    x67       c110                -1   c133                -1
    x67       c146                 1   c147                 1
    x67       c153                 1   c155                 1
    x67       c177                -1   c219                -1
    x67       c225                -1   c230                -1
    x67       c253                 1   c257                 1
    x67       c271                -1   c285                -1
    x67       c296                -1   c306                 1
    x67       c321                 1   c365                -1
    x67       c401                -1   c407                 1
    x67       c419                 1   c451                 1
    x67       c460                -1   c469                 1
    x67       c470                 1   c475                -1
    x67       c494                 1   c517                -1
    x67       c554                -1   c607                -1
    x67       c613                 1   c629                -1
    x67       c662                -1   c705                 1
    x67       c719                -1   c789                -1
    x68       c23                 -1   c30                  1
    x68       c47                 -1   c64                 -1
    x68       c92                 -1   c96                  1
    x68       c133                -1   c143                 1
    x68       c163                -1   c220                -1
    x68       c238                 1   c243                -1
    x68       c254                -1   c259                 1
    x68       c275                 1   c298                 1
    x68       c305                 1   c340                -1
    x68       c357                 1   c396                 1
    x68       c403                 1   c431                 1
    x68       c503                 1   c547                 1
    x68       c563                -1   c590                 1
    x68       c618                -1   c623                -1
    x68       c659                -1   c687                -1
    x68       c700                 1   c738                 1
    x68       c760                -1   c763                -1
    x68       c765                -1   c767                 1
    x68       c788                 1
    x69       c24                  1   c87                 -1
    x69       c170                 1   c191                 1
    x69       c194                 1   c237                 1
    x69       c269                 1   c282                 1
    x69       c309                 1   c321                 1
    x69       c349                -1   c372                 1
    x69       c391                -1   c406                -1
    x69       c440                 1   c447                 1
    x69       c471                 1   c489                -1
    x69       c508                 1   c536                -1
    x69       c560                 1   c573                 1
    x69       c602                -1   c606                 1
    x69       c608                -1   c612                 1
    x69       c617                -1   c650                 1
    x69       c672                -1   c673                 1
    x69       c705                -1   c709                 1
    x69       c710                -1   c728                -1
    x69       c753                 1   c773                 1
    x69       c774                 1   c779                 1
    x70       c24                  1   c50                 -1
    x70       c61                  1   c77                  1
    x70       c82                 -1   c84                 -1
    x70       c94                  1   c108                 1
    x70       c120                 1   c127                 1
    x70       c133                 1   c136                 1
    x70       c189                -1   c207                -1
    x70       c213                -1   c289                 1
    x70       c303                 1   c322                 1
    x70       c347                -1   c361                -1
    x70       c373                -1   c412                -1
    x70       c461                -1   c469                -1
    x70       c482                -1   c484                -1
    x70       c488                -1   c519                -1
    x70       c524                 1   c535                -1
    x70       c538                -1   c548                -1
    x70       c596                -1   c625                 1
    x70       c627                -1   c675                 1
    x70       c686                -1   c694                 1
    x70       c706                 1   c712                 1
    x70       c724                -1   c741                 1
    x70       c758                -1   c780                -1
    x70       c788                -1   c791                 1
    x71       c24                 -1   c49                 -1
    x71       c53                 -1   c80                 -1
    x71       c81                  1   c120                 1
    x71       c139                 1   c198                -1
    x71       c207                 1   c211                 1
    x71       c217                 1   c244                 1
    x71       c295                 1   c324                -1
    x71       c327                -1   c361                 1
    x71       c364                 1   c397                -1
    x71       c417                -1   c463                 1
    x71       c480                -1   c520                 1
    x71       c534                -1   c546                 1
    x71       c616                -1   c634                 1
    x71       c656                 1   c687                -1
    x71       c689                 1   c707                -1
    x71       c724                 1   c750                -1
    x71       c752                 1   c758                 1
    x71       c788                -1
    x72       c24                 -1   c43                 -1
    x72       c67                  1   c71                 -1
    x72       c151                -1   c187                 1
    x72       c320                -1   c331                 1
    x72       c344                 1   c352                 1
    x72       c357                 1   c360                -1
    x72       c371                -1   c386                -1
    x72       c389                -1   c396                -1
    x72       c407                 1   c430                 1
    x72       c441                 1   c473                 1
    x72       c474                 1   c484                 1
    x72       c492                 1   c494                -1
    x72       c520                -1   c522                 1
    x72       c534                -1   c554                 1
    x72       c557                -1   c569                 1
    x72       c600                -1   c621                -1
    x72       c622                -1   c637                -1
    x72       c648                 1   c668                 1
    x72       c695                -1   c715                 1
    x72       c727                 1   c729                 1
    x72       c730                -1   c731                -1
    x72       c754                 1   c769                -1
    x72       c794                 1   c795                 1
    x72       c797                 1   c800                 1
    x73       c24                 -1   c64                  1
    x73       c68                  1   c90                 -1
    x73       c112                 1   c121                 1
    x73       c195                -1   c201                -1
    x73       c207                 1   c267                -1
    x73       c275                 1   c305                 1
    x73       c308                 1   c317                -1
    x73       c363                 1   c388                 1
    x73       c396                 1   c403                 1
    x73       c429                 1   c458                -1
    x73       c473                 1   c506                -1
    x73       c512                 1   c594                 1
    x73       c627                 1   c641                -1
    x73       c645                -1   c715                 1
    x73       c722                 1   c769                 1
    x73       c795                -1
    x74       c25                 -1   c46                 -1
    x74       c47                 -1   c61                 -1
    x74       c72                  1   c94                  1
    x74       c123                -1   c143                 1
    x74       c155                 1   c156                 1
    x74       c157                -1   c158                -1
    x74       c181                 1   c198                -1
    x74       c222                 1   c223                 1
    x74       c225                 1   c228                 1
    x74       c234                 1   c252                -1
    x74       c263                 1   c291                -1
    x74       c300                 1   c305                -1
    x74       c328                -1   c358                -1
    x74       c393                 1   c399                -1
    x74       c420                -1   c426                -1
    x74       c427                 1   c428                -1
    x74       c464                 1   c492                 1
    x74       c512                -1   c553                -1
    x74       c591                -1   c593                 1
    x74       c678                 1   c679                 1
    x74       c687                 1   c695                 1
    x74       c706                 1   c708                 1
    x74       c742                 1   c781                 1
    x75       c25                 -1   c102                 1
    x75       c104                -1   c109                -1
    x75       c118                 1   c125                -1
    x75       c134                -1   c146                 1
    x75       c160                 1   c188                 1
    x75       c227                 1   c233                -1
    x75       c255                -1   c278                -1
    x75       c340                 1   c368                -1
    x75       c419                -1   c424                -1
    x75       c458                -1   c519                -1
    x75       c522                -1   c545                -1
    x75       c575                -1   c581                -1
    x75       c583                 1   c612                 1
    x75       c632                -1   c673                -1
    x75       c677                -1   c730                -1
    x75       c740                 1   c751                -1
    x75       c773                 1
    x76       c26                 -1   c32                 -1
    x76       c37                 -1   c60                  1
    x76       c64                  1   c79                 -1
    x76       c93                 -1   c105                -1
    x76       c116                 1   c131                 1
    x76       c174                -1   c210                -1
    x76       c216                 1   c228                 1
    x76       c259                 1   c267                -1
    x76       c277                 1   c278                 1
    x76       c283                -1   c302                 1
    x76       c325                -1   c363                -1
    x76       c416                -1   c422                 1
    x76       c438                -1   c471                -1
    x76       c515                 1   c529                -1
    x76       c599                -1   c674                 1
    x76       c676                -1   c681                -1
    x76       c689                 1   c696                -1
    x76       c705                -1   c717                 1
    x76       c732                 1   c759                 1
    x76       c784                -1   c798                 1
    x77       c26                  1   c39                  1
    x77       c52                 -1   c58                  1
    x77       c98                  1   c105                -1
    x77       c107                -1   c162                -1
    x77       c177                -1   c178                 1
    x77       c201                 1   c212                 1
    x77       c221                -1   c233                 1
    x77       c236                 1   c246                -1
    x77       c264                 1   c286                 1
    x77       c326                -1   c341                -1
    x77       c351                 1   c377                 1
    x77       c378                -1   c388                 1
    x77       c420                 1   c452                -1
    x77       c478                -1   c501                -1
    x77       c508                -1   c512                -1
    x77       c514                 1   c524                -1
    x77       c530                 1   c557                 1
    x77       c565                -1   c573                -1
    x77       c575                -1   c580                -1
    x77       c588                -1   c624                -1
    x77       c645                -1   c654                -1
    x77       c744                 1   c759                -1
    x77       c783                 1
    x78       c27                  1   c52                 -1
    x78       c61                  1   c71                  1
    x78       c85                 -1   c100                 1
    x78       c116                -1   c135                 1
    x78       c145                -1   c150                -1
    x78       c158                -1   c201                 1
    x78       c214                 1   c215                -1
    x78       c231                 1   c247                -1
    x78       c252                 1   c253                 1
    x78       c263                -1   c277                -1
    x78       c282                 1   c305                 1
    x78       c324                 1   c332                -1
    x78       c407                -1   c426                -1
    x78       c451                 1   c455                -1
    x78       c532                -1   c568                 1
    x78       c701                -1   c712                 1
    x78       c725                 1   c733                 1
    x78       c738                 1   c741                -1
    x78       c752                -1   c765                -1
    x78       c768                -1   c775                -1
    x78       c787                 1
    x79       c27                  1   c44                  1
    x79       c75                 -1   c108                -1
    x79       c183                -1   c199                -1
    x79       c211                 1   c240                 1
    x79       c244                 1   c313                 1
    x79       c314                -1   c362                -1
    x79       c391                 1   c473                -1
    x79       c481                -1   c485                -1
    x79       c553                -1   c580                -1
    x79       c615                -1   c619                -1
    x79       c663                 1   c665                -1
    x79       c673                -1   c698                 1
    x79       c706                 1   c713                -1
    x79       c717                -1   c729                 1
    x79       c730                 1   c767                -1
    x79       c775                -1   c797                -1
    x80       c27                 -1   c45                  1
    x80       c50                 -1   c61                 -1
    x80       c66                  1   c83                  1
    x80       c107                 1   c115                 1
    x80       c150                -1   c166                 1
    x80       c205                 1   c212                 1
    x80       c240                 1   c311                 1
    x80       c356                 1   c372                -1
    x80       c399                 1   c427                -1
    x80       c432                -1   c468                -1
    x80       c497                -1   c510                 1
    x80       c547                 1   c571                -1
    x80       c574                -1   c576                -1
    x80       c578                 1   c598                 1
    x80       c619                -1   c621                 1
    x80       c641                 1   c651                -1
    x80       c669                -1   c687                -1
    x80       c705                -1   c757                 1
    x80       c775                -1   c794                -1
    x80       c796                -1
    x81       c27                 -1   c32                  1
    x81       c35                 -1   c45                 -1
    x81       c115                -1   c141                 1
    x81       c149                -1   c197                -1
    x81       c219                 1   c252                 1
    x81       c253                 1   c260                 1
    x81       c273                -1   c278                 1
    x81       c284                 1   c289                 1
    x81       c294                 1   c332                 1
    x81       c347                 1   c398                -1
    x81       c400                -1   c401                 1
    x81       c423                -1   c424                 1
    x81       c451                 1   c486                 1
    x81       c526                -1   c540                 1
    x81       c568                 1   c574                 1
    x81       c601                 1   c614                 1
    x81       c627                -1   c633                 1
    x81       c634                 1   c672                 1
    x81       c678                -1   c680                -1
    x81       c735                -1   c750                -1
    x81       c751                 1   c772                 1
    x81       c783                 1   c793                -1
    x82       c27                  1   c38                  1
    x82       c62                  1   c74                  1
    x82       c95                 -1   c155                -1
    x82       c171                -1   c200                 1
    x82       c213                 1   c219                -1
    x82       c283                -1   c299                 1
    x82       c303                 1   c306                -1
    x82       c328                -1   c338                -1
    x82       c344                -1   c387                 1
    x82       c397                -1   c431                 1
    x82       c443                -1   c446                 1
    x82       c460                 1   c465                -1
    x82       c482                 1   c529                 1
    x82       c531                 1   c534                -1
    x82       c546                 1   c569                 1
    x82       c583                -1   c619                 1
    x82       c630                -1   c663                -1
    x82       c666                 1   c678                 1
    x82       c687                 1   c695                 1
    x82       c699                -1   c700                -1
    x82       c717                -1   c755                 1
    x82       c772                -1
    x83       c27                  1   c31                  1
    x83       c32                  1   c46                  1
    x83       c69                 -1   c103                 1
    x83       c188                 1   c220                -1
    x83       c225                 1   c228                -1
    x83       c238                -1   c305                -1
    x83       c331                 1   c339                -1
    x83       c388                -1   c410                 1
    x83       c444                 1   c445                 1
    x83       c452                 1   c465                -1
    x83       c470                 1   c476                 1
    x83       c481                 1   c486                 1
    x83       c524                 1   c539                 1
    x83       c589                -1   c591                -1
    x83       c592                 1   c614                -1
    x83       c615                 1   c642                 1
    x83       c676                 1   c716                -1
    x83       c730                 1   c758                 1
    x83       c763                 1   c791                 1
    x84       c28                 -1   c76                 -1
    x84       c85                 -1   c98                 -1
    x84       c101                -1   c105                -1
    x84       c137                -1   c142                 1
    x84       c153                -1   c166                -1
    x84       c214                -1   c243                 1
    x84       c245                -1   c293                 1
    x84       c304                -1   c312                 1
    x84       c324                 1   c330                 1
    x84       c342                -1   c359                 1
    x84       c377                -1   c400                -1
    x84       c407                -1   c410                 1
    x84       c441                -1   c464                 1
    x84       c474                -1   c507                 1
    x84       c533                 1   c551                 1
    x84       c571                -1   c620                 1
    x84       c627                 1   c640                -1
    x84       c671                -1   c684                -1
    x84       c696                -1   c716                -1
    x84       c726                -1   c732                 1
    x84       c741                -1   c758                -1
    x84       c791                 1   c795                 1
    x84       c796                 1
    x85       c28                  1   c46                  1
    x85       c66                  1   c133                -1
    x85       c137                -1   c147                 1
    x85       c162                 1   c191                -1
    x85       c194                -1   c204                 1
    x85       c218                 1   c275                 1
    x85       c327                -1   c335                 1
    x85       c347                 1   c355                -1
    x85       c360                -1   c408                 1
    x85       c434                -1   c446                 1
    x85       c462                 1   c466                -1
    x85       c468                -1   c478                 1
    x85       c491                 1   c502                 1
    x85       c509                 1   c515                 1
    x85       c518                 1   c571                -1
    x85       c589                -1   c595                -1
    x85       c671                 1   c704                 1
    x85       c729                -1   c743                -1
    x85       c755                -1   c793                -1
    x86       c28                 -1   c32                  1
    x86       c34                 -1   c38                  1
    x86       c43                 -1   c75                  1
    x86       c99                 -1   c101                 1
    x86       c134                -1   c138                 1
    x86       c139                -1   c156                -1
    x86       c181                 1   c203                 1
    x86       c204                 1   c209                 1
    x86       c253                -1   c265                 1
    x86       c279                 1   c307                -1
    x86       c308                -1   c315                 1
    x86       c340                -1   c391                 1
    x86       c406                 1   c430                -1
    x86       c511                 1   c512                -1
    x86       c520                -1   c523                 1
    x86       c525                 1   c526                -1
    x86       c574                -1   c608                -1
    x86       c610                -1   c631                 1
    x86       c639                 1   c683                 1
    x86       c712                -1   c730                -1
    x86       c788                -1   c795                 1
    x87       c32                 -1   c75                  1
    x87       c78                 -1   c86                  1
    x87       c106                -1   c131                 1
    x87       c181                -1   c188                 1
    x87       c193                 1   c214                -1
    x87       c233                 1   c234                 1
    x87       c244                -1   c262                 1
    x87       c272                -1   c369                 1
    x87       c398                 1   c458                 1
    x87       c477                -1   c492                -1
    x87       c505                 1   c517                -1
    x87       c527                 1   c533                 1
    x87       c539                 1   c540                 1
    x87       c574                 1   c586                -1
    x87       c635                -1   c675                 1
    x87       c693                -1   c705                 1
    x87       c737                -1   c742                 1
    x87       c749                -1   c757                -1
    x87       c761                 1   c773                 1
    x87       c798                -1
    x88       c32                  1   c54                 -1
    x88       c104                 1   c137                -1
    x88       c142                 1   c163                 1
    x88       c178                -1   c240                -1
    x88       c251                -1   c254                -1
    x88       c257                 1   c265                 1
    x88       c270                -1   c290                -1
    x88       c295                 1   c326                 1
    x88       c333                -1   c350                 1
    x88       c365                 1   c391                -1
    x88       c401                 1   c413                -1
    x88       c418                -1   c424                 1
    x88       c448                -1   c486                 1
    x88       c502                -1   c513                -1
    x88       c523                -1   c551                 1
    x88       c566                -1   c579                -1
    x88       c596                -1   c604                 1
    x88       c626                -1   c648                 1
    x88       c666                -1   c746                 1
    x88       c763                -1   c768                -1
    x89       c33                 -1   c35                 -1
    x89       c56                  1   c63                  1
    x89       c110                 1   c140                -1
    x89       c157                -1   c216                -1
    x89       c223                 1   c240                -1
    x89       c257                -1   c284                -1
    x89       c288                 1   c323                -1
    x89       c333                 1   c354                -1
    x89       c411                -1   c429                 1
    x89       c434                -1   c446                -1
    x89       c451                 1   c467                 1
    x89       c490                 1   c497                 1
    x89       c532                -1   c548                 1
    x89       c587                 1   c594                 1
    x89       c622                 1   c693                 1
    x89       c738                 1   c754                -1
    x89       c779                 1
    x90       c33                 -1   c39                  1
    x90       c55                 -1   c88                 -1
    x90       c134                 1   c148                -1
    x90       c218                -1   c293                 1
    x90       c295                -1   c300                -1
    x90       c308                 1   c315                -1
    x90       c324                -1   c336                 1
    x90       c351                 1   c379                 1
    x90       c418                 1   c424                -1
    x90       c447                -1   c470                -1
    x90       c532                 1   c559                -1
    x90       c610                -1   c615                -1
    x90       c649                -1   c709                -1
    x90       c712                -1   c736                -1
    x90       c764                -1   c770                -1
    x90       c772                 1
    x91       c34                  1   c40                 -1
    x91       c62                 -1   c86                 -1
    x91       c150                 1   c177                -1
    x91       c228                -1   c233                -1
    x91       c265                -1   c327                -1
    x91       c330                -1   c354                -1
    x91       c384                -1   c390                -1
    x91       c392                 1   c421                 1
    x91       c441                -1   c483                -1
    x91       c487                -1   c540                -1
    x91       c549                 1   c560                -1
    x91       c584                 1   c642                -1
    x91       c645                -1   c659                -1
    x91       c690                 1   c699                 1
    x91       c737                 1   c740                -1
    x91       c759                -1   c762                 1
    x91       c776                 1   c778                -1
    x91       c779                 1   c781                -1
    x92       c35                 -1   c40                 -1
    x92       c73                 -1   c137                -1
    x92       c140                -1   c163                -1
    x92       c193                -1   c199                -1
    x92       c201                 1   c230                 1
    x92       c249                -1   c291                -1
    x92       c295                -1   c348                -1
    x92       c358                 1   c369                -1
    x92       c393                 1   c451                -1
    x92       c454                -1   c468                -1
    x92       c500                 1   c509                 1
    x92       c546                 1   c549                -1
    x92       c569                -1   c573                 1
    x92       c587                 1   c589                -1
    x92       c590                 1   c592                -1
    x92       c642                 1   c654                -1
    x92       c677                 1   c689                -1
    x92       c693                -1   c698                 1
    x92       c706                -1   c712                -1
    x92       c722                -1   c725                 1
    x92       c738                -1   c758                -1
    x92       c761                 1   c779                 1
    x93       c41                 -1   c58                  1
    x93       c81                  1   c115                -1
    x93       c117                 1   c135                -1
    x93       c152                 1   c177                -1
    x93       c179                 1   c186                 1
    x93       c216                -1   c268                -1
    x93       c279                -1   c285                -1
    x93       c301                -1   c323                -1
    x93       c336                 1   c337                 1
    x93       c343                 1   c345                 1
    x93       c368                -1   c410                -1
    x93       c416                -1   c421                -1
    x93       c445                 1   c449                 1
    x93       c463                -1   c477                -1
    x93       c488                -1   c498                 1
    x93       c513                 1   c556                -1
    x93       c592                -1   c598                 1
    x93       c610                 1   c642                 1
    x93       c651                -1   c660                 1
    x93       c661                 1   c666                -1
    x93       c684                 1   c707                -1
    x93       c745                -1   c797                -1
    x94       c44                  1   c77                  1
    x94       c90                  1   c112                 1
    x94       c119                 1   c131                 1
    x94       c158                -1   c181                 1
    x94       c200                -1   c215                -1
    x94       c248                 1   c255                 1
    x94       c279                 1   c297                -1
    x94       c316                 1   c344                -1
    x94       c369                 1   c382                 1
    x94       c411                -1   c415                 1
    x94       c417                -1   c421                 1
    x94       c426                -1   c459                 1
    x94       c482                -1   c483                 1
    x94       c515                -1   c519                 1
    x94       c520                -1   c538                -1
    x94       c562                 1   c584                 1
    x94       c585                 1   c590                 1
    x94       c634                 1   c635                -1
    x94       c648                 1   c661                 1
    x94       c688                -1   c689                -1
    x94       c696                 1   c721                -1
    x94       c770                 1   c786                 1
    x95       c45                  1   c52                  1
    x95       c64                 -1   c97                 -1
    x95       c111                -1   c124                -1
    x95       c144                -1   c154                -1
    x95       c159                 1   c168                -1
    x95       c186                -1   c219                 1
    x95       c223                 1   c224                 1
    x95       c238                 1   c293                 1
    x95       c378                 1   c410                -1
    x95       c415                 1   c418                -1
    x95       c428                -1   c496                -1
    x95       c522                 1   c530                -1
    x95       c578                -1   c600                 1
    x95       c635                 1   c642                 1
    x95       c655                -1   c660                 1
    x95       c666                 1   c670                 1
    x95       c675                 1   c713                 1
    x95       c728                 1   c777                -1
    x95       c779                -1   c780                 1
    x96       c47                  1   c69                 -1
    x96       c120                 1   c145                 1
    x96       c151                -1   c152                 1
    x96       c156                -1   c158                 1
    x96       c181                -1   c204                 1
    x96       c227                 1   c246                 1
    x96       c272                 1   c322                -1
    x96       c325                -1   c332                 1
    x96       c361                -1   c412                 1
    x96       c430                 1   c451                 1
    x96       c515                -1   c519                -1
    x96       c529                 1   c544                 1
    x96       c573                -1   c576                -1
    x96       c586                 1   c600                 1
    x96       c658                 1   c709                -1
    x96       c717                 1   c729                 1
    x96       c737                -1   c742                -1
    x96       c789                 1
    x97       c47                 -1   c58                 -1
    x97       c61                 -1   c64                  1
    x97       c73                  1   c78                 -1
    x97       c98                 -1   c99                  1
    x97       c104                 1   c136                 1
    x97       c143                -1   c159                 1
    x97       c174                 1   c200                -1
    x97       c210                 1   c222                -1
    x97       c227                -1   c233                 1
    x97       c256                -1   c294                 1
    x97       c310                -1   c321                -1
    x97       c331                -1   c360                 1
    x97       c375                -1   c388                -1
    x97       c405                -1   c413                 1
    x97       c435                -1   c457                 1
    x97       c475                -1   c555                 1
    x97       c574                -1   c579                -1
    x97       c630                -1   c656                 1
    x97       c658                 1   c676                 1
    x97       c705                -1   c714                 1
    x97       c735                -1   c789                -1
    x98       c48                 -1   c51                 -1
    x98       c56                  1   c59                  1
    x98       c90                  1   c155                -1
    x98       c170                -1   c176                -1
    x98       c224                 1   c246                -1
    x98       c294                 1   c326                -1
    x98       c331                 1   c353                 1
    x98       c368                -1   c430                -1
    x98       c442                -1   c445                -1
    x98       c448                 1   c457                 1
    x98       c462                -1   c481                -1
    x98       c482                 1   c486                 1
    x98       c517                 1   c524                -1
    x98       c541                 1   c555                 1
    x98       c581                -1   c591                 1
    x98       c603                -1   c608                -1
    x98       c614                 1   c638                -1
    x98       c675                 1   c691                -1
    x98       c702                -1   c712                -1
    x98       c741                 1   c756                -1
    x98       c767                -1   c785                -1
    x98       c793                 1
    x99       c50                 -1   c58                  1
    x99       c74                 -1   c77                 -1
    x99       c128                -1   c142                 1
    x99       c146                -1   c153                 1
    x99       c165                 1   c167                 1
    x99       c178                 1   c179                -1
    x99       c190                 1   c204                 1
    x99       c211                 1   c239                 1
    x99       c286                 1   c288                -1
    x99       c294                 1   c296                -1
    x99       c298                 1   c341                 1
    x99       c342                 1   c355                -1
    x99       c358                 1   c416                -1
    x99       c460                 1   c470                 1
    x99       c489                -1   c513                 1
    x99       c563                -1   c570                 1
    x99       c575                 1   c596                -1
    x99       c615                 1   c616                 1
    x99       c626                -1   c646                 1
    x99       c655                -1   c751                 1
    x99       c778                 1
    x100      c54                  1   c60                  1
    x100      c95                  1   c128                 1
    x100      c193                -1   c242                -1
    x100      c250                 1   c265                -1
    x100      c268                -1   c317                -1
    x100      c331                 1   c335                -1
    x100      c342                 1   c355                 1
    x100      c357                 1   c368                 1
    x100      c369                -1   c380                 1
    x100      c394                 1   c401                 1
    x100      c429                 1   c477                 1
    x100      c479                -1   c485                 1
    x100      c487                -1   c489                 1
    x100      c532                 1   c533                 1
    x100      c545                -1   c548                 1
    x100      c606                -1   c650                 1
    x100      c653                -1   c660                 1
    x100      c678                -1   c702                 1
    x100      c753                -1   c759                 1
    x100      c763                 1   c785                -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       c2                  -3   c3                   1
    rhs       c4                  -3   c5                  -4
    rhs       c6                  -1   c7                  -2
    rhs       c8                  -4   c10                  1
    rhs       c11                 -1   c12                 -1
    rhs       c13                 -3   c14                 -2
    rhs       c15                 -1   c16                 -2
    rhs       c19                  1   c21                 -2
    rhs       c22                 -2   c23                 -2
    rhs       c24                 -2   c25                 -1
    rhs       c26                 -1   c27                 -1
    rhs       c28                 -2   c29                 -1
    rhs       c31                 -1   c32                 -1
    rhs       c33                 -5   c34                 -2
    rhs       c35                 -2   c38                  1
    rhs       c40                 -2   c43                 -4
    rhs       c44                 -2   c46                 -1
    rhs       c47                 -3   c48                 -3
    rhs       c49                 -2   c50                 -5
    rhs       c51                 -2   c52                 -3
    rhs       c53                 -1   c55                 -3
    rhs       c56                  1   c57                 -1
    rhs       c58                 -1   c59                 -2
    rhs       c61                 -2   c63                 -1
    rhs       c64                 -1   c68                  1
    rhs       c69                 -4   c70                  1
    rhs       c71                 -2   c72                  1
    rhs       c73                 -4   c75                 -2
    rhs       c76                 -2   c78                 -1
    rhs       c79                 -3   c80                 -1
    rhs       c81                 -1   c82                 -1
    rhs       c83                  1   c84                 -2
    rhs       c85                 -3   c87                 -1
    rhs       c88                 -3   c90                 -4
    rhs       c91                 -1   c92                 -1
    rhs       c93                 -2   c95                 -1
    rhs       c96                 -1   c97                 -1
    rhs       c98                 -1   c100                -2
    rhs       c101                -1   c102                -1
    rhs       c103                 1   c104                -3
    rhs       c105                -3   c106                -1
    rhs       c107                -2   c109                -1
    rhs       c111                -3   c112                 1
    rhs       c113                 1   c115                -4
    rhs       c116                -1   c117                -2
    rhs       c121                -1   c122                 1
    rhs       c124                -2   c125                -1
    rhs       c126                -4   c127                -1
    rhs       c128                -1   c129                 1
    rhs       c130                -3   c131                -1
    rhs       c133                -4   c134                -3
    rhs       c135                -3   c136                -1
    rhs       c137                -6   c138                -3
    rhs       c139                -1   c140                -2
    rhs       c141                -2   c142                -1
    rhs       c144                -3   c145                -2
    rhs       c148                -3   c150                -4
    rhs       c151                -2   c152                -4
    rhs       c154                -2   c155                -1
    rhs       c156                -2   c157                -3
    rhs       c158                -3   c159                 1
    rhs       c161                -1   c162                -1
    rhs       c163                -2   c164                -2
    rhs       c165                -1   c167                -1
    rhs       c169                -4   c170                -4
    rhs       c171                -4   c172                 1
    rhs       c174                -1   c175                -1
    rhs       c176                -1   c177                -3
    rhs       c178                -2   c181                -2
    rhs       c182                -1   c183                -2
    rhs       c184                -1   c185                -1
    rhs       c186                -2   c187                -2
    rhs       c188                 1   c189                -2
    rhs       c191                -1   c192                -2
    rhs       c193                -2   c194                -1
    rhs       c195                -3   c197                -2
    rhs       c198                -4   c199                -1
    rhs       c200                -2   c201                -5
    rhs       c202                 1   c203                 1
    rhs       c204                -2   c206                -3
    rhs       c207                -2   c208                -1
    rhs       c209                -2   c210                -1
    rhs       c211                 1   c212                 1
    rhs       c214                -2   c215                -2
    rhs       c216                -4   c218                -1
    rhs       c219                -1   c220                -2
    rhs       c221                -1   c222                -1
    rhs       c224                -1   c225                -2
    rhs       c226                -5   c227                -1
    rhs       c228                -2   c231                 1
    rhs       c233                -2   c235                -3
    rhs       c236                -1   c237                -2
    rhs       c239                -2   c240                -2
    rhs       c241                -3   c242                -3
    rhs       c243                -4   c244                -2
    rhs       c245                -3   c246                -2
    rhs       c247                -3   c248                 1
    rhs       c249                -1   c250                 1
    rhs       c251                -1   c252                -2
    rhs       c254                -2   c256                -1
    rhs       c257                -1   c261                -3
    rhs       c263                -1   c265                -4
    rhs       c266                 1   c267                -3
    rhs       c268                -2   c269                 1
    rhs       c270                -1   c271                -3
    rhs       c272                -1   c273                -2
    rhs       c275                 1   c276                -2
    rhs       c277                -3   c279                -1
    rhs       c280                -3   c281                -1
    rhs       c282                -3   c283                -2
    rhs       c285                -2   c287                -1
    rhs       c288                -1   c289                -1
    rhs       c290                -2   c291                -2
    rhs       c292                -1   c293                -1
    rhs       c294                 1   c295                -3
    rhs       c296                -3   c297                -1
    rhs       c298                -2   c300                -1
    rhs       c302                -3   c303                 1
    rhs       c305                -4   c306                -1
    rhs       c307                -2   c311                -1
    rhs       c312                 1   c314                -2
    rhs       c315                -2   c316                -3
    rhs       c317                -2   c319                 1
    rhs       c320                -3   c321                -1
    rhs       c323                -5   c324                -2
    rhs       c325                -4   c326                -1
    rhs       c327                -5   c328                -4
    rhs       c330                -2   c331                -2
    rhs       c332                -1   c334                -3
    rhs       c335                -3   c336                 1
    rhs       c338                -3   c340                -5
    rhs       c341                -1   c342                -4
    rhs       c344                -2   c345                -1
    rhs       c346                -1   c347                -1
    rhs       c348                -3   c349                -3
    rhs       c350                 1   c352                -1
    rhs       c353                -1   c354                -2
    rhs       c355                -2   c356                -1
    rhs       c358                -1   c360                -4
    rhs       c361                -4   c362                -4
    rhs       c364                 1   c365                -1
    rhs       c366                -1   c367                -1
    rhs       c368                -4   c369                -2
    rhs       c370                 1   c372                -2
    rhs       c373                -1   c374                -2
    rhs       c375                -1   c376                -1
    rhs       c377                -2   c378                -2
    rhs       c379                 1   c380                -2
    rhs       c382                -1   c383                -2
    rhs       c384                -2   c385                -2
    rhs       c386                -2   c388                -2
    rhs       c389                -4   c390                -1
    rhs       c391                -3   c392                -4
    rhs       c393                 1   c394                 1
    rhs       c395                -2   c397                -3
    rhs       c398                -2   c399                -1
    rhs       c400                -2   c401                -1
    rhs       c402                 1   c403                 1
    rhs       c405                -2   c406                -2
    rhs       c407                -4   c409                -1
    rhs       c410                -2   c411                -1
    rhs       c412                -1   c413                -1
    rhs       c415                -1   c416                -3
    rhs       c417                -4   c418                -2
    rhs       c419                -1   c422                 1
    rhs       c424                -2   c426                -3
    rhs       c427                -1   c428                -3
    rhs       c429                 1   c430                -3
    rhs       c431                -1   c432                -3
    rhs       c433                -3   c434                -4
    rhs       c435                -2   c436                -3
    rhs       c437                -2   c439                -2
    rhs       c440                 1   c441                -1
    rhs       c444                -3   c446                -1
    rhs       c448                -1   c449                -1
    rhs       c453                -1   c454                -2
    rhs       c456                -1   c458                -4
    rhs       c460                -2   c461                -2
    rhs       c463                -3   c464                -1
    rhs       c465                -2   c467                 1
    rhs       c468                -2   c469                -3
    rhs       c471                -2   c472                -2
    rhs       c473                -1   c474                -3
    rhs       c475                -2   c477                -2
    rhs       c478                -1   c479                -1
    rhs       c481                -2   c482                -1
    rhs       c483                -2   c484                -1
    rhs       c485                -1   c486                 1
    rhs       c487                -4   c488                -2
    rhs       c489                -1   c490                -2
    rhs       c492                -1   c494                -3
    rhs       c495                 1   c496                -1
    rhs       c497                -3   c498                -2
    rhs       c499                -2   c500                 1
    rhs       c503                -1   c504                 1
    rhs       c506                -2   c507                -2
    rhs       c508                -4   c509                -1
    rhs       c512                -2   c513                -1
    rhs       c515                -5   c516                -2
    rhs       c517                -4   c518                -1
    rhs       c519                -5   c520                -4
    rhs       c522                -2   c523                -2
    rhs       c524                -2   c525                 1
    rhs       c526                -3   c527                -3
    rhs       c528                 1   c529                -1
    rhs       c530                -3   c532                -5
    rhs       c534                -4   c536                -3
    rhs       c538                -2   c540                -3
    rhs       c541                -3   c543                -1
    rhs       c544                -1   c545                -3
    rhs       c546                -1   c547                -1
    rhs       c549                -1   c550                -1
    rhs       c551                -3   c552                -5
    rhs       c553                -3   c555                 1
    rhs       c556                -1   c557                -1
    rhs       c558                -1   c559                -4
    rhs       c560                -2   c563                -1
    rhs       c564                -1   c565                -2
    rhs       c566                -1   c567                -1
    rhs       c568                -2   c569                -2
    rhs       c570                 1   c571                -2
    rhs       c573                -1   c574                -2
    rhs       c575                -2   c576                -3
    rhs       c577                -1   c578                -1
    rhs       c579                -2   c580                -3
    rhs       c581                -2   c582                -2
    rhs       c583                -4   c584                 1
    rhs       c585                 1   c586                -3
    rhs       c587                 1   c588                -3
    rhs       c589                -2   c590                -1
    rhs       c591                -2   c592                -1
    rhs       c593                 1   c594                 1
    rhs       c596                -2   c597                -2
    rhs       c598                -4   c599                -1
    rhs       c600                -1   c601                -1
    rhs       c602                -1   c603                -2
    rhs       c606                -2   c607                -2
    rhs       c608                -5   c609                -1
    rhs       c610                -1   c613                 1
    rhs       c615                -2   c617                -3
    rhs       c618                -1   c619                -3
    rhs       c621                -2   c622                -1
    rhs       c623                -3   c624                -3
    rhs       c625                -4   c626                -2
    rhs       c627                -3   c628                -2
    rhs       c630                -2   c631                 1
    rhs       c632                -1   c635                -3
    rhs       c637                -1   c638                -1
    rhs       c640                -1   c644                -1
    rhs       c645                -2   c647                -1
    rhs       c648                -1   c649                -3
    rhs       c651                -2   c652                -2
    rhs       c653                -1   c654                -3
    rhs       c655                -2   c656                -1
    rhs       c658                 1   c659                -2
    rhs       c660                -3   c662                -2
    rhs       c663                -2   c664                -1
    rhs       c665                -4   c666                -1
    rhs       c667                -2   c668                -1
    rhs       c669                -1   c671                -2
    rhs       c672                -1   c673                -2
    rhs       c674                -1   c675                -1
    rhs       c677                -3   c678                -3
    rhs       c680                -2   c681                -1
    rhs       c683                -1   c684                -2
    rhs       c685                 1   c686                -1
    rhs       c687                -4   c688                -1
    rhs       c689                -2   c690                 1
    rhs       c691                -1   c692                 1
    rhs       c693                -1   c694                 1
    rhs       c695                -1   c696                -2
    rhs       c697                -1   c698                -4
    rhs       c699                -1   c701                -1
    rhs       c702                -2   c703                -1
    rhs       c704                 1   c705                -6
    rhs       c706                -2   c707                -3
    rhs       c708                -1   c709                -8
    rhs       c710                -1   c712                -3
    rhs       c713                -1   c714                -2
    rhs       c716                -2   c717                -3
    rhs       c718                 1   c719                -2
    rhs       c720                -2   c722                -5
    rhs       c723                -1   c724                -3
    rhs       c725                -1   c726                -2
    rhs       c728                -2   c730                -3
    rhs       c731                -3   c732                 1
    rhs       c734                -1   c735                -1
    rhs       c736                -3   c737                -1
    rhs       c738                -1   c740                -1
    rhs       c741                -1   c742                -4
    rhs       c743                -4   c744                -3
    rhs       c746                 1   c747                -2
    rhs       c749                -1   c750                -4
    rhs       c751                -2   c753                -1
    rhs       c755                -1   c756                -3
    rhs       c757                -1   c758                -2
    rhs       c759                -2   c760                -2
    rhs       c762                -2   c763                -1
    rhs       c764                -2   c765                -3
    rhs       c766                -1   c767                -2
    rhs       c768                -1   c769                -3
    rhs       c770                -2   c771                -2
    rhs       c772                -4   c773                 1
    rhs       c774                 1   c775                -3
    rhs       c777                -3   c778                -1
    rhs       c779                -2   c780                -1
    rhs       c781                -1   c782                 1
    rhs       c783                 1   c784                -1
    rhs       c785                -1   c787                -2
    rhs       c788                -4   c789                -2
    rhs       c791                -1   c792                -1
    rhs       c793                -2   c796                -2
    rhs       c797                -3   c798                -4
    rhs       c799                -2
BOUNDS
 UP bnd       x1                   1
 UP bnd       x2                   1
 UP bnd       x3                   1
 UP bnd       x4                   1
 UP bnd       x5                   1
 UP bnd       x6                   1
 UP bnd       x7                   1
 UP bnd       x8                   1
 UP bnd       x9                   1
 UP bnd       x10                  1
 UP bnd       x11                  1
 UP bnd       x12                  1
 UP bnd       x13                  1
 UP bnd       x14                  1
 UP bnd       x15                  1
 UP bnd       x16                  1
 UP bnd       x17                  1
 UP bnd       x18                  1
 UP bnd       x19                  1
 UP bnd       x20                  1
 UP bnd       x21                  1
 UP bnd       x22                  1
 UP bnd       x23                  1
 UP bnd       x24                  1
 UP bnd       x25                  1
 UP bnd       x26                  1
 UP bnd       x27                  1
 UP bnd       x28                  1
 UP bnd       x29                  1
 UP bnd       x30                  1
 UP bnd       x31                  1
 UP bnd       x32                  1
 UP bnd       x33                  1
 UP bnd       x34                  1
 UP bnd       x35                  1
 UP bnd       x36                  1
 UP bnd       x37                  1
 UP bnd       x38                  1
 UP bnd       x39                  1
 UP bnd       x40                  1
 UP bnd       x41                  1
 UP bnd       x42                  1
 UP bnd       x43                  1
 UP bnd       x44                  1
 UP bnd       x45                  1
 UP bnd       x46                  1
 UP bnd       x47                  1
 UP bnd       x48                  1
 UP bnd       x49                  1
 UP bnd       x50                  1
 UP bnd       x51                  1
 UP bnd       x52                  1
 UP bnd       x53                  1
 UP bnd       x54                  1
 UP bnd       x55                  1
 UP bnd       x56                  1
 UP bnd       x57                  1
 UP bnd       x58                  1
 UP bnd       x59                  1
 UP bnd       x60                  1
 UP bnd       x61                  1
 UP bnd       x62                  1
 UP bnd       x63                  1
 UP bnd       x64                  1
 UP bnd       x65                  1
 UP bnd       x66                  1
 UP bnd       x67                  1
 UP bnd       x68                  1
 UP bnd       x69                  1
 UP bnd       x70                  1
 UP bnd       x71                  1
 UP bnd       x72                  1
 UP bnd       x73                  1
 UP bnd       x74                  1
 UP bnd       x75                  1
 UP bnd       x76                  1
 UP bnd       x77                  1
 UP bnd       x78                  1
 UP bnd       x79                  1
 UP bnd       x80                  1
 UP bnd       x81                  1
 UP bnd       x82                  1
 UP bnd       x83                  1
 UP bnd       x84                  1
 UP bnd       x85                  1
 UP bnd       x86                  1
 UP bnd       x87                  1
 UP bnd       x88                  1
 UP bnd       x89                  1
 UP bnd       x90                  1
 UP bnd       x91                  1
 UP bnd       x92                  1
 UP bnd       x93                  1
 UP bnd       x94                  1
 UP bnd       x95                  1
 UP bnd       x96                  1
 UP bnd       x97                  1
 UP bnd       x98                  1
 UP bnd       x99                  1
 UP bnd       x100                 1
ENDATA
