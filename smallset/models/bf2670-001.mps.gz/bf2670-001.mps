NAME           
ROWS
 N  obj     
 G  c1      
 G  c2      
 G  c3      
 G  c4      
 G  c5      
 G  c6      
 G  c7      
 G  c8      
 G  c9      
 G  c10     
 G  c11     
 G  c12     
 G  c13     
 G  c14     
 G  c15     
 G  c16     
 G  c17     
 G  c18     
 G  c19     
 G  c20     
 G  c21     
 G  c22     
 G  c23     
 G  c24     
 G  c25     
 G  c26     
 G  c27     
 G  c28     
 G  c29     
 G  c30     
 G  c31     
 G  c32     
 G  c33     
 G  c34     
 G  c35     
 G  c36     
 G  c37     
 G  c38     
 G  c39     
 G  c40     
 G  c41     
 G  c42     
 G  c43     
 G  c44     
 G  c45     
 G  c46     
 G  c47     
 G  c48     
 G  c49     
 G  c50     
 G  c51     
 G  c52     
 G  c53     
 G  c54     
 G  c55     
 G  c56     
 G  c57     
 G  c58     
 G  c59     
 G  c60     
 G  c61     
 G  c62     
 G  c63     
 G  c64     
 G  c65     
 G  c66     
 G  c67     
 G  c68     
 G  c69     
 G  c70     
 G  c71     
 G  c72     
 G  c73     
 G  c74     
 G  c75     
 G  c76     
 G  c77     
 G  c78     
 G  c79     
 G  c80     
 G  c81     
 G  c82     
 G  c83     
 G  c84     
 G  c85     
 G  c86     
 G  c87     
 G  c88     
 G  c89     
 G  c90     
 G  c91     
 G  c92     
 G  c93     
 G  c94     
 G  c95     
 G  c96     
 G  c97     
 G  c98     
 G  c99     
 G  c100    
 G  c101    
 G  c102    
 G  c103    
 G  c104    
 G  c105    
 G  c106    
 G  c107    
 G  c108    
 G  c109    
 G  c110    
 G  c111    
 G  c112    
 G  c113    
 G  c114    
 G  c115    
 G  c116    
 G  c117    
 G  c118    
 G  c119    
 G  c120    
 G  c121    
 G  c122    
 G  c123    
 G  c124    
 G  c125    
 G  c126    
 G  c127    
 G  c128    
 G  c129    
 G  c130    
 G  c131    
 G  c132    
 G  c133    
 G  c134    
 G  c135    
 G  c136    
 G  c137    
 G  c138    
 G  c139    
 G  c140    
 G  c141    
 G  c142    
 G  c143    
 G  c144    
 G  c145    
 G  c146    
 G  c147    
 G  c148    
 G  c149    
 G  c150    
 G  c151    
 G  c152    
 G  c153    
 G  c154    
 G  c155    
 G  c156    
 G  c157    
 G  c158    
 G  c159    
 G  c160    
 G  c161    
 G  c162    
 G  c163    
 G  c164    
 G  c165    
 G  c166    
 G  c167    
 G  c168    
 G  c169    
 G  c170    
 G  c171    
 G  c172    
 G  c173    
 G  c174    
 G  c175    
 G  c176    
 G  c177    
 G  c178    
 G  c179    
 G  c180    
 G  c181    
 G  c182    
 G  c183    
 G  c184    
 G  c185    
 G  c186    
 G  c187    
 G  c188    
 G  c189    
 G  c190    
 G  c191    
 G  c192    
 G  c193    
 G  c194    
 G  c195    
 G  c196    
 G  c197    
 G  c198    
 G  c199    
 G  c200    
 G  c201    
 G  c202    
 G  c203    
 G  c204    
 G  c205    
 G  c206    
 G  c207    
 G  c208    
 G  c209    
 G  c210    
 G  c211    
 G  c212    
 G  c213    
 G  c214    
 G  c215    
 G  c216    
 G  c217    
 G  c218    
 G  c219    
 G  c220    
 G  c221    
 G  c222    
 G  c223    
 G  c224    
 G  c225    
 G  c226    
 G  c227    
 G  c228    
 G  c229    
 G  c230    
 G  c231    
 G  c232    
 G  c233    
 G  c234    
 G  c235    
 G  c236    
 G  c237    
 G  c238    
 G  c239    
 G  c240    
 G  c241    
 G  c242    
 G  c243    
 G  c244    
 G  c245    
 G  c246    
 G  c247    
 G  c248    
 G  c249    
 G  c250    
 G  c251    
 G  c252    
 G  c253    
 G  c254    
 G  c255    
 G  c256    
 G  c257    
 G  c258    
 G  c259    
 G  c260    
 G  c261    
 G  c262    
 G  c263    
 G  c264    
 G  c265    
 G  c266    
 G  c267    
 G  c268    
 G  c269    
 G  c270    
 G  c271    
 G  c272    
 G  c273    
 G  c274    
 G  c275    
 G  c276    
 G  c277    
 G  c278    
 G  c279    
 G  c280    
 G  c281    
 G  c282    
 G  c283    
 G  c284    
 G  c285    
 G  c286    
 G  c287    
 G  c288    
 G  c289    
 G  c290    
 G  c291    
 G  c292    
 G  c293    
 G  c294    
 G  c295    
 G  c296    
 G  c297    
 G  c298    
 G  c299    
 G  c300    
 G  c301    
 G  c302    
 G  c303    
 G  c304    
 G  c305    
 G  c306    
 G  c307    
 G  c308    
 G  c309    
 G  c310    
 G  c311    
 G  c312    
 G  c313    
 G  c314    
 G  c315    
 G  c316    
 G  c317    
 G  c318    
 G  c319    
 G  c320    
 G  c321    
 G  c322    
 G  c323    
 G  c324    
 G  c325    
 G  c326    
 G  c327    
 G  c328    
 G  c329    
 G  c330    
 G  c331    
 G  c332    
 G  c333    
 G  c334    
 G  c335    
 G  c336    
 G  c337    
 G  c338    
 G  c339    
 G  c340    
 G  c341    
 G  c342    
 G  c343    
 G  c344    
 G  c345    
 G  c346    
 G  c347    
 G  c348    
 G  c349    
 G  c350    
 G  c351    
 G  c352    
 G  c353    
 G  c354    
 G  c355    
 G  c356    
 G  c357    
 G  c358    
 G  c359    
 G  c360    
 G  c361    
 G  c362    
 G  c363    
 G  c364    
 G  c365    
 G  c366    
 G  c367    
 G  c368    
 G  c369    
 G  c370    
 G  c371    
 G  c372    
 G  c373    
 G  c374    
 G  c375    
 G  c376    
 G  c377    
 G  c378    
 G  c379    
 G  c380    
 G  c381    
 G  c382    
 G  c383    
 G  c384    
 G  c385    
 G  c386    
 G  c387    
 G  c388    
 G  c389    
 G  c390    
 G  c391    
 G  c392    
 G  c393    
 G  c394    
 G  c395    
 G  c396    
 G  c397    
 G  c398    
 G  c399    
 G  c400    
 G  c401    
 G  c402    
 G  c403    
 G  c404    
 G  c405    
 G  c406    
 G  c407    
 G  c408    
 G  c409    
 G  c410    
 G  c411    
 G  c412    
 G  c413    
 G  c414    
 G  c415    
 G  c416    
 G  c417    
 G  c418    
 G  c419    
 G  c420    
 G  c421    
 G  c422    
 G  c423    
 G  c424    
 G  c425    
 G  c426    
 G  c427    
 G  c428    
 G  c429    
 G  c430    
 G  c431    
 G  c432    
 G  c433    
 G  c434    
 G  c435    
 G  c436    
 G  c437    
 G  c438    
 G  c439    
 G  c440    
 G  c441    
 G  c442    
 G  c443    
 G  c444    
 G  c445    
 G  c446    
 G  c447    
 G  c448    
 G  c449    
 G  c450    
 G  c451    
 G  c452    
 G  c453    
 G  c454    
 G  c455    
 G  c456    
 G  c457    
 G  c458    
 G  c459    
 G  c460    
 G  c461    
 G  c462    
 G  c463    
 G  c464    
 G  c465    
 G  c466    
 G  c467    
 G  c468    
 G  c469    
 G  c470    
 G  c471    
 G  c472    
 G  c473    
 G  c474    
 G  c475    
 G  c476    
 G  c477    
 G  c478    
 G  c479    
 G  c480    
 G  c481    
 G  c482    
 G  c483    
 G  c484    
 G  c485    
 G  c486    
 G  c487    
 G  c488    
 G  c489    
 G  c490    
 G  c491    
 G  c492    
 G  c493    
 G  c494    
 G  c495    
 G  c496    
 G  c497    
 G  c498    
 G  c499    
 G  c500    
 G  c501    
 G  c502    
 G  c503    
 G  c504    
 G  c505    
 G  c506    
 G  c507    
 G  c508    
 G  c509    
 G  c510    
 G  c511    
 G  c512    
 G  c513    
 G  c514    
 G  c515    
 G  c516    
 G  c517    
 G  c518    
 G  c519    
 G  c520    
 G  c521    
 G  c522    
 G  c523    
 G  c524    
 G  c525    
 G  c526    
 G  c527    
 G  c528    
 G  c529    
 G  c530    
 G  c531    
 G  c532    
 G  c533    
 G  c534    
 G  c535    
 G  c536    
 G  c537    
 G  c538    
 G  c539    
 G  c540    
 G  c541    
 G  c542    
 G  c543    
 G  c544    
 G  c545    
 G  c546    
 G  c547    
 G  c548    
 G  c549    
 G  c550    
 G  c551    
 G  c552    
 G  c553    
 G  c554    
 G  c555    
 G  c556    
 G  c557    
 G  c558    
 G  c559    
 G  c560    
 G  c561    
 G  c562    
 G  c563    
 G  c564    
 G  c565    
 G  c566    
 G  c567    
 G  c568    
 G  c569    
 G  c570    
 G  c571    
 G  c572    
 G  c573    
 G  c574    
 G  c575    
 G  c576    
 G  c577    
 G  c578    
 G  c579    
 G  c580    
 G  c581    
 G  c582    
 G  c583    
 G  c584    
 G  c585    
 G  c586    
 G  c587    
 G  c588    
 G  c589    
 G  c590    
 G  c591    
 G  c592    
 G  c593    
 G  c594    
 G  c595    
 G  c596    
 G  c597    
 G  c598    
 G  c599    
 G  c600    
 G  c601    
 G  c602    
 G  c603    
 G  c604    
 G  c605    
 G  c606    
 G  c607    
 G  c608    
 G  c609    
 G  c610    
 G  c611    
 G  c612    
 G  c613    
 G  c614    
 G  c615    
 G  c616    
 G  c617    
 G  c618    
 G  c619    
 G  c620    
 G  c621    
 G  c622    
 G  c623    
 G  c624    
 G  c625    
 G  c626    
 G  c627    
 G  c628    
 G  c629    
 G  c630    
 G  c631    
 G  c632    
 G  c633    
 G  c634    
 G  c635    
 G  c636    
 G  c637    
 G  c638    
 G  c639    
 G  c640    
 G  c641    
 G  c642    
 G  c643    
 G  c644    
 G  c645    
 G  c646    
 G  c647    
 G  c648    
 G  c649    
 G  c650    
 G  c651    
 G  c652    
 G  c653    
 G  c654    
 G  c655    
 G  c656    
 G  c657    
 G  c658    
 G  c659    
 G  c660    
 G  c661    
 G  c662    
 G  c663    
 G  c664    
 G  c665    
 G  c666    
 G  c667    
 G  c668    
 G  c669    
 G  c670    
 G  c671    
 G  c672    
 G  c673    
 G  c674    
 G  c675    
 G  c676    
 G  c677    
 G  c678    
 G  c679    
 G  c680    
 G  c681    
 G  c682    
 G  c683    
 G  c684    
 G  c685    
 G  c686    
 G  c687    
 G  c688    
 G  c689    
 G  c690    
 G  c691    
 G  c692    
 G  c693    
 G  c694    
 G  c695    
 G  c696    
 G  c697    
 G  c698    
 G  c699    
 G  c700    
 G  c701    
 G  c702    
 G  c703    
 G  c704    
 G  c705    
 G  c706    
 G  c707    
 G  c708    
 G  c709    
 G  c710    
 G  c711    
 G  c712    
 G  c713    
 G  c714    
 G  c715    
 G  c716    
 G  c717    
 G  c718    
 G  c719    
 G  c720    
 G  c721    
 G  c722    
 G  c723    
 G  c724    
 G  c725    
 G  c726    
 G  c727    
 G  c728    
 G  c729    
 G  c730    
 G  c731    
 G  c732    
 G  c733    
 G  c734    
 G  c735    
 G  c736    
 G  c737    
 G  c738    
 G  c739    
 G  c740    
 G  c741    
 G  c742    
 G  c743    
 G  c744    
 G  c745    
 G  c746    
 G  c747    
 G  c748    
 G  c749    
 G  c750    
 G  c751    
 G  c752    
 G  c753    
 G  c754    
 G  c755    
 G  c756    
 G  c757    
 G  c758    
 G  c759    
 G  c760    
 G  c761    
 G  c762    
 G  c763    
 G  c764    
 G  c765    
 G  c766    
 G  c767    
 G  c768    
 G  c769    
 G  c770    
 G  c771    
 G  c772    
 G  c773    
 G  c774    
 G  c775    
 G  c776    
 G  c777    
 G  c778    
 G  c779    
 G  c780    
 G  c781    
 G  c782    
 G  c783    
 G  c784    
 G  c785    
 G  c786    
 G  c787    
 G  c788    
 G  c789    
 G  c790    
 G  c791    
 G  c792    
 G  c793    
 G  c794    
 G  c795    
 G  c796    
 G  c797    
 G  c798    
 G  c799    
 G  c800    
 G  c801    
 G  c802    
 G  c803    
 G  c804    
 G  c805    
 G  c806    
 G  c807    
 G  c808    
 G  c809    
 G  c810    
 G  c811    
 G  c812    
 G  c813    
 G  c814    
 G  c815    
 G  c816    
 G  c817    
 G  c818    
 G  c819    
 G  c820    
 G  c821    
 G  c822    
 G  c823    
 G  c824    
 G  c825    
 G  c826    
 G  c827    
 G  c828    
 G  c829    
 G  c830    
 G  c831    
 G  c832    
 G  c833    
 G  c834    
 G  c835    
 G  c836    
 G  c837    
 G  c838    
 G  c839    
 G  c840    
 G  c841    
 G  c842    
 G  c843    
 G  c844    
 G  c845    
 G  c846    
 G  c847    
 G  c848    
 G  c849    
 G  c850    
 G  c851    
 G  c852    
 G  c853    
 G  c854    
 G  c855    
 G  c856    
 G  c857    
 G  c858    
 G  c859    
 G  c860    
 G  c861    
 G  c862    
 G  c863    
 G  c864    
 G  c865    
 G  c866    
 G  c867    
 G  c868    
 G  c869    
 G  c870    
 G  c871    
 G  c872    
 G  c873    
 G  c874    
 G  c875    
 G  c876    
 G  c877    
 G  c878    
 G  c879    
 G  c880    
 G  c881    
 G  c882    
 G  c883    
 G  c884    
 G  c885    
 G  c886    
 G  c887    
 G  c888    
 G  c889    
 G  c890    
 G  c891    
 G  c892    
 G  c893    
 G  c894    
 G  c895    
 G  c896    
 G  c897    
 G  c898    
 G  c899    
 G  c900    
 G  c901    
 G  c902    
 G  c903    
 G  c904    
 G  c905    
 G  c906    
 G  c907    
 G  c908    
 G  c909    
 G  c910    
 G  c911    
 G  c912    
 G  c913    
 G  c914    
 G  c915    
 G  c916    
 G  c917    
 G  c918    
 G  c919    
 G  c920    
 G  c921    
 G  c922    
 G  c923    
 G  c924    
 G  c925    
 G  c926    
 G  c927    
 G  c928    
 G  c929    
 G  c930    
 G  c931    
 G  c932    
 G  c933    
 G  c934    
 G  c935    
 G  c936    
 G  c937    
 G  c938    
 G  c939    
 G  c940    
 G  c941    
 G  c942    
 G  c943    
 G  c944    
 G  c945    
 G  c946    
 G  c947    
 G  c948    
 G  c949    
 G  c950    
 G  c951    
 G  c952    
 G  c953    
 G  c954    
 G  c955    
 G  c956    
 G  c957    
 G  c958    
 G  c959    
 G  c960    
 G  c961    
 G  c962    
 G  c963    
 G  c964    
 G  c965    
 G  c966    
 G  c967    
 G  c968    
 G  c969    
 G  c970    
 G  c971    
 G  c972    
 G  c973    
 G  c974    
 G  c975    
 G  c976    
 G  c977    
 G  c978    
 G  c979    
 G  c980    
 G  c981    
 G  c982    
 G  c983    
 G  c984    
 G  c985    
 G  c986    
 G  c987    
 G  c988    
 G  c989    
 G  c990    
 G  c991    
 G  c992    
 G  c993    
 G  c994    
 G  c995    
 G  c996    
 G  c997    
 G  c998    
 G  c999    
 G  c1000   
 G  c1001   
 G  c1002   
 G  c1003   
 G  c1004   
 G  c1005   
 G  c1006   
 G  c1007   
 G  c1008   
 G  c1009   
 G  c1010   
 G  c1011   
 G  c1012   
 G  c1013   
 G  c1014   
 G  c1015   
 G  c1016   
 G  c1017   
 G  c1018   
 G  c1019   
 G  c1020   
 G  c1021   
 G  c1022   
 G  c1023   
 G  c1024   
 G  c1025   
 G  c1026   
 G  c1027   
 G  c1028   
 G  c1029   
 G  c1030   
 G  c1031   
 G  c1032   
 G  c1033   
 G  c1034   
 G  c1035   
 G  c1036   
 G  c1037   
 G  c1038   
 G  c1039   
 G  c1040   
 G  c1041   
 G  c1042   
 G  c1043   
 G  c1044   
 G  c1045   
 G  c1046   
 G  c1047   
 G  c1048   
 G  c1049   
 G  c1050   
 G  c1051   
 G  c1052   
 G  c1053   
 G  c1054   
 G  c1055   
 G  c1056   
 G  c1057   
 G  c1058   
 G  c1059   
 G  c1060   
 G  c1061   
 G  c1062   
 G  c1063   
 G  c1064   
 G  c1065   
 G  c1066   
 G  c1067   
 G  c1068   
 G  c1069   
 G  c1070   
 G  c1071   
 G  c1072   
 G  c1073   
 G  c1074   
 G  c1075   
 G  c1076   
 G  c1077   
 G  c1078   
 G  c1079   
 G  c1080   
 G  c1081   
 G  c1082   
 G  c1083   
 G  c1084   
 G  c1085   
 G  c1086   
 G  c1087   
 G  c1088   
 G  c1089   
 G  c1090   
 G  c1091   
 G  c1092   
 G  c1093   
 G  c1094   
 G  c1095   
 G  c1096   
 G  c1097   
 G  c1098   
 G  c1099   
 G  c1100   
 G  c1101   
 G  c1102   
 G  c1103   
 G  c1104   
 G  c1105   
 G  c1106   
 G  c1107   
 G  c1108   
 G  c1109   
 G  c1110   
 G  c1111   
 G  c1112   
 G  c1113   
 G  c1114   
 G  c1115   
 G  c1116   
 G  c1117   
 G  c1118   
 G  c1119   
 G  c1120   
 G  c1121   
 G  c1122   
 G  c1123   
 G  c1124   
 G  c1125   
 G  c1126   
 G  c1127   
 G  c1128   
 G  c1129   
 G  c1130   
 G  c1131   
 G  c1132   
 G  c1133   
 G  c1134   
 G  c1135   
 G  c1136   
 G  c1137   
 G  c1138   
 G  c1139   
 G  c1140   
 G  c1141   
 G  c1142   
 G  c1143   
 G  c1144   
 G  c1145   
 G  c1146   
 G  c1147   
 G  c1148   
 G  c1149   
 G  c1150   
 G  c1151   
 G  c1152   
 G  c1153   
 G  c1154   
 G  c1155   
 G  c1156   
 G  c1157   
 G  c1158   
 G  c1159   
 G  c1160   
 G  c1161   
 G  c1162   
 G  c1163   
 G  c1164   
 G  c1165   
 G  c1166   
 G  c1167   
 G  c1168   
 G  c1169   
 G  c1170   
 G  c1171   
 G  c1172   
 G  c1173   
 G  c1174   
 G  c1175   
 G  c1176   
 G  c1177   
 G  c1178   
 G  c1179   
 G  c1180   
 G  c1181   
 G  c1182   
 G  c1183   
 G  c1184   
 G  c1185   
 G  c1186   
 G  c1187   
 G  c1188   
 G  c1189   
 G  c1190   
 G  c1191   
 G  c1192   
 G  c1193   
 G  c1194   
 G  c1195   
 G  c1196   
 G  c1197   
 G  c1198   
 G  c1199   
 G  c1200   
 G  c1201   
 G  c1202   
 G  c1203   
 G  c1204   
 G  c1205   
 G  c1206   
 G  c1207   
 G  c1208   
 G  c1209   
 G  c1210   
 G  c1211   
 G  c1212   
 G  c1213   
 G  c1214   
 G  c1215   
 G  c1216   
 G  c1217   
 G  c1218   
 G  c1219   
 G  c1220   
 G  c1221   
 G  c1222   
 G  c1223   
 G  c1224   
 G  c1225   
 G  c1226   
 G  c1227   
 G  c1228   
 G  c1229   
 G  c1230   
 G  c1231   
 G  c1232   
 G  c1233   
 G  c1234   
 G  c1235   
 G  c1236   
 G  c1237   
 G  c1238   
 G  c1239   
 G  c1240   
 G  c1241   
 G  c1242   
 G  c1243   
 G  c1244   
 G  c1245   
 G  c1246   
 G  c1247   
 G  c1248   
 G  c1249   
 G  c1250   
 G  c1251   
 G  c1252   
 G  c1253   
 G  c1254   
 G  c1255   
 G  c1256   
 G  c1257   
 G  c1258   
 G  c1259   
 G  c1260   
 G  c1261   
 G  c1262   
 G  c1263   
 G  c1264   
 G  c1265   
 G  c1266   
 G  c1267   
 G  c1268   
 G  c1269   
 G  c1270   
 G  c1271   
 G  c1272   
 G  c1273   
 G  c1274   
 G  c1275   
 G  c1276   
 G  c1277   
 G  c1278   
 G  c1279   
 G  c1280   
 G  c1281   
 G  c1282   
 G  c1283   
 G  c1284   
 G  c1285   
 G  c1286   
 G  c1287   
 G  c1288   
 G  c1289   
 G  c1290   
 G  c1291   
 G  c1292   
 G  c1293   
 G  c1294   
 G  c1295   
 G  c1296   
 G  c1297   
 G  c1298   
 G  c1299   
 G  c1300   
 G  c1301   
 G  c1302   
 G  c1303   
 G  c1304   
 G  c1305   
 G  c1306   
 G  c1307   
 G  c1308   
 G  c1309   
 G  c1310   
 G  c1311   
 G  c1312   
 G  c1313   
 G  c1314   
 G  c1315   
 G  c1316   
 G  c1317   
 G  c1318   
 G  c1319   
 G  c1320   
 G  c1321   
 G  c1322   
 G  c1323   
 G  c1324   
 G  c1325   
 G  c1326   
 G  c1327   
 G  c1328   
 G  c1329   
 G  c1330   
 G  c1331   
 G  c1332   
 G  c1333   
 G  c1334   
 G  c1335   
 G  c1336   
 G  c1337   
 G  c1338   
 G  c1339   
 G  c1340   
 G  c1341   
 G  c1342   
 G  c1343   
 G  c1344   
 G  c1345   
 G  c1346   
 G  c1347   
 G  c1348   
 G  c1349   
 G  c1350   
 G  c1351   
 G  c1352   
 G  c1353   
 G  c1354   
 G  c1355   
 G  c1356   
 G  c1357   
 G  c1358   
 G  c1359   
 G  c1360   
 G  c1361   
 G  c1362   
 G  c1363   
 G  c1364   
 G  c1365   
 G  c1366   
 G  c1367   
 G  c1368   
 G  c1369   
 G  c1370   
 G  c1371   
 G  c1372   
 G  c1373   
 G  c1374   
 G  c1375   
 G  c1376   
 G  c1377   
 G  c1378   
 G  c1379   
 G  c1380   
 G  c1381   
 G  c1382   
 G  c1383   
 G  c1384   
 G  c1385   
 G  c1386   
 G  c1387   
 G  c1388   
 G  c1389   
 G  c1390   
 G  c1391   
 G  c1392   
 G  c1393   
 G  c1394   
 G  c1395   
 G  c1396   
 G  c1397   
 G  c1398   
 G  c1399   
 G  c1400   
 G  c1401   
 G  c1402   
 G  c1403   
 G  c1404   
 G  c1405   
 G  c1406   
 G  c1407   
 G  c1408   
 G  c1409   
 G  c1410   
 G  c1411   
 G  c1412   
 G  c1413   
 G  c1414   
 G  c1415   
 G  c1416   
 G  c1417   
 G  c1418   
 G  c1419   
 G  c1420   
 G  c1421   
 G  c1422   
 G  c1423   
 G  c1424   
 G  c1425   
 G  c1426   
 G  c1427   
 G  c1428   
 G  c1429   
 G  c1430   
 G  c1431   
 G  c1432   
 G  c1433   
 G  c1434   
 G  c1435   
 G  c1436   
 G  c1437   
 G  c1438   
 G  c1439   
 G  c1440   
 G  c1441   
 G  c1442   
 G  c1443   
 G  c1444   
 G  c1445   
 G  c1446   
 G  c1447   
 G  c1448   
 G  c1449   
 G  c1450   
 G  c1451   
 G  c1452   
 G  c1453   
 G  c1454   
 G  c1455   
 G  c1456   
 G  c1457   
 G  c1458   
 G  c1459   
 G  c1460   
 G  c1461   
 G  c1462   
 G  c1463   
 G  c1464   
 G  c1465   
 G  c1466   
 G  c1467   
 G  c1468   
 G  c1469   
 G  c1470   
 G  c1471   
 G  c1472   
 G  c1473   
 G  c1474   
 G  c1475   
 G  c1476   
 G  c1477   
 G  c1478   
 G  c1479   
 G  c1480   
 G  c1481   
 G  c1482   
 G  c1483   
 G  c1484   
 G  c1485   
 G  c1486   
 G  c1487   
 G  c1488   
 G  c1489   
 G  c1490   
 G  c1491   
 G  c1492   
 G  c1493   
 G  c1494   
 G  c1495   
 G  c1496   
 G  c1497   
 G  c1498   
 G  c1499   
 G  c1500   
 G  c1501   
 G  c1502   
 G  c1503   
 G  c1504   
 G  c1505   
 G  c1506   
 G  c1507   
 G  c1508   
 G  c1509   
 G  c1510   
 G  c1511   
 G  c1512   
 G  c1513   
 G  c1514   
 G  c1515   
 G  c1516   
 G  c1517   
 G  c1518   
 G  c1519   
 G  c1520   
 G  c1521   
 G  c1522   
 G  c1523   
 G  c1524   
 G  c1525   
 G  c1526   
 G  c1527   
 G  c1528   
 G  c1529   
 G  c1530   
 G  c1531   
 G  c1532   
 G  c1533   
 G  c1534   
 G  c1535   
 G  c1536   
 G  c1537   
 G  c1538   
 G  c1539   
 G  c1540   
 G  c1541   
 G  c1542   
 G  c1543   
 G  c1544   
 G  c1545   
 G  c1546   
 G  c1547   
 G  c1548   
 G  c1549   
 G  c1550   
 G  c1551   
 G  c1552   
 G  c1553   
 G  c1554   
 G  c1555   
 G  c1556   
 G  c1557   
 G  c1558   
 G  c1559   
 G  c1560   
 G  c1561   
 G  c1562   
 G  c1563   
 G  c1564   
 G  c1565   
 G  c1566   
 G  c1567   
 G  c1568   
 G  c1569   
 G  c1570   
 G  c1571   
 G  c1572   
 G  c1573   
 G  c1574   
 G  c1575   
 G  c1576   
 G  c1577   
 G  c1578   
 G  c1579   
 G  c1580   
 G  c1581   
 G  c1582   
 G  c1583   
 G  c1584   
 G  c1585   
 G  c1586   
 G  c1587   
 G  c1588   
 G  c1589   
 G  c1590   
 G  c1591   
 G  c1592   
 G  c1593   
 G  c1594   
 G  c1595   
 G  c1596   
 G  c1597   
 G  c1598   
 G  c1599   
 G  c1600   
 G  c1601   
 G  c1602   
 G  c1603   
 G  c1604   
 G  c1605   
 G  c1606   
 G  c1607   
 G  c1608   
 G  c1609   
 G  c1610   
 G  c1611   
 G  c1612   
 G  c1613   
 G  c1614   
 G  c1615   
 G  c1616   
 G  c1617   
 G  c1618   
 G  c1619   
 G  c1620   
 G  c1621   
 G  c1622   
 G  c1623   
 G  c1624   
 G  c1625   
 G  c1626   
 G  c1627   
 G  c1628   
 G  c1629   
 G  c1630   
 G  c1631   
 G  c1632   
 G  c1633   
 G  c1634   
 G  c1635   
 G  c1636   
 G  c1637   
 G  c1638   
 G  c1639   
 G  c1640   
 G  c1641   
 G  c1642   
 G  c1643   
 G  c1644   
 G  c1645   
 G  c1646   
 G  c1647   
 G  c1648   
 G  c1649   
 G  c1650   
 G  c1651   
 G  c1652   
 G  c1653   
 G  c1654   
 G  c1655   
 G  c1656   
 G  c1657   
 G  c1658   
 G  c1659   
 G  c1660   
 G  c1661   
 G  c1662   
 G  c1663   
 G  c1664   
 G  c1665   
 G  c1666   
 G  c1667   
 G  c1668   
 G  c1669   
 G  c1670   
 G  c1671   
 G  c1672   
 G  c1673   
 G  c1674   
 G  c1675   
 G  c1676   
 G  c1677   
 G  c1678   
 G  c1679   
 G  c1680   
 G  c1681   
 G  c1682   
 G  c1683   
 G  c1684   
 G  c1685   
 G  c1686   
 G  c1687   
 G  c1688   
 G  c1689   
 G  c1690   
 G  c1691   
 G  c1692   
 G  c1693   
 G  c1694   
 G  c1695   
 G  c1696   
 G  c1697   
 G  c1698   
 G  c1699   
 G  c1700   
 G  c1701   
 G  c1702   
 G  c1703   
 G  c1704   
 G  c1705   
 G  c1706   
 G  c1707   
 G  c1708   
 G  c1709   
 G  c1710   
 G  c1711   
 G  c1712   
 G  c1713   
 G  c1714   
 G  c1715   
 G  c1716   
 G  c1717   
 G  c1718   
 G  c1719   
 G  c1720   
 G  c1721   
 G  c1722   
 G  c1723   
 G  c1724   
 G  c1725   
 G  c1726   
 G  c1727   
 G  c1728   
 G  c1729   
 G  c1730   
 G  c1731   
 G  c1732   
 G  c1733   
 G  c1734   
 G  c1735   
 G  c1736   
 G  c1737   
 G  c1738   
 G  c1739   
 G  c1740   
 G  c1741   
 G  c1742   
 G  c1743   
 G  c1744   
 G  c1745   
 G  c1746   
 G  c1747   
 G  c1748   
 G  c1749   
 G  c1750   
 G  c1751   
 G  c1752   
 G  c1753   
 G  c1754   
 G  c1755   
 G  c1756   
 G  c1757   
 G  c1758   
 G  c1759   
 G  c1760   
 G  c1761   
 G  c1762   
 G  c1763   
 G  c1764   
 G  c1765   
 G  c1766   
 G  c1767   
 G  c1768   
 G  c1769   
 G  c1770   
 G  c1771   
 G  c1772   
 G  c1773   
 G  c1774   
 G  c1775   
 G  c1776   
 G  c1777   
 G  c1778   
 G  c1779   
 G  c1780   
 G  c1781   
 G  c1782   
 G  c1783   
 G  c1784   
 G  c1785   
 G  c1786   
 G  c1787   
 G  c1788   
 G  c1789   
 G  c1790   
 G  c1791   
 G  c1792   
 G  c1793   
 G  c1794   
 G  c1795   
 G  c1796   
 G  c1797   
 G  c1798   
 G  c1799   
 G  c1800   
 G  c1801   
 G  c1802   
 G  c1803   
 G  c1804   
 G  c1805   
 G  c1806   
 G  c1807   
 G  c1808   
 G  c1809   
 G  c1810   
 G  c1811   
 G  c1812   
 G  c1813   
 G  c1814   
 G  c1815   
 G  c1816   
 G  c1817   
 G  c1818   
 G  c1819   
 G  c1820   
 G  c1821   
 G  c1822   
 G  c1823   
 G  c1824   
 G  c1825   
 G  c1826   
 G  c1827   
 G  c1828   
 G  c1829   
 G  c1830   
 G  c1831   
 G  c1832   
 G  c1833   
 G  c1834   
 G  c1835   
 G  c1836   
 G  c1837   
 G  c1838   
 G  c1839   
 G  c1840   
 G  c1841   
 G  c1842   
 G  c1843   
 G  c1844   
 G  c1845   
 G  c1846   
 G  c1847   
 G  c1848   
 G  c1849   
 G  c1850   
 G  c1851   
 G  c1852   
 G  c1853   
 G  c1854   
 G  c1855   
 G  c1856   
 G  c1857   
 G  c1858   
 G  c1859   
 G  c1860   
 G  c1861   
 G  c1862   
 G  c1863   
 G  c1864   
 G  c1865   
 G  c1866   
 G  c1867   
 G  c1868   
 G  c1869   
 G  c1870   
 G  c1871   
 G  c1872   
 G  c1873   
 G  c1874   
 G  c1875   
 G  c1876   
 G  c1877   
 G  c1878   
 G  c1879   
 G  c1880   
 G  c1881   
 G  c1882   
 G  c1883   
 G  c1884   
 G  c1885   
 G  c1886   
 G  c1887   
 G  c1888   
 G  c1889   
 G  c1890   
 G  c1891   
 G  c1892   
 G  c1893   
 G  c1894   
 G  c1895   
 G  c1896   
 G  c1897   
 G  c1898   
 G  c1899   
 G  c1900   
 G  c1901   
 G  c1902   
 G  c1903   
 G  c1904   
 G  c1905   
 G  c1906   
 G  c1907   
 G  c1908   
 G  c1909   
 G  c1910   
 G  c1911   
 G  c1912   
 G  c1913   
 G  c1914   
 G  c1915   
 G  c1916   
 G  c1917   
 G  c1918   
 G  c1919   
 G  c1920   
 G  c1921   
 G  c1922   
 G  c1923   
 G  c1924   
 G  c1925   
 G  c1926   
 G  c1927   
 G  c1928   
 G  c1929   
 G  c1930   
 G  c1931   
 G  c1932   
 G  c1933   
 G  c1934   
 G  c1935   
 G  c1936   
 G  c1937   
 G  c1938   
 G  c1939   
 G  c1940   
 G  c1941   
 G  c1942   
 G  c1943   
 G  c1944   
 G  c1945   
 G  c1946   
 G  c1947   
 G  c1948   
 G  c1949   
 G  c1950   
 G  c1951   
 G  c1952   
 G  c1953   
 G  c1954   
 G  c1955   
 G  c1956   
 G  c1957   
 G  c1958   
 G  c1959   
 G  c1960   
 G  c1961   
 G  c1962   
 G  c1963   
 G  c1964   
 G  c1965   
 G  c1966   
 G  c1967   
 G  c1968   
 G  c1969   
 G  c1970   
 G  c1971   
 G  c1972   
 G  c1973   
 G  c1974   
 G  c1975   
 G  c1976   
 G  c1977   
 G  c1978   
 G  c1979   
 G  c1980   
 G  c1981   
 G  c1982   
 G  c1983   
 G  c1984   
 G  c1985   
 G  c1986   
 G  c1987   
 G  c1988   
 G  c1989   
 G  c1990   
 G  c1991   
 G  c1992   
 G  c1993   
 G  c1994   
 G  c1995   
 G  c1996   
 G  c1997   
 G  c1998   
 G  c1999   
 G  c2000   
 G  c2001   
 G  c2002   
 G  c2003   
 G  c2004   
 G  c2005   
 G  c2006   
 G  c2007   
 G  c2008   
 G  c2009   
 G  c2010   
 G  c2011   
 G  c2012   
 G  c2013   
 G  c2014   
 G  c2015   
 G  c2016   
 G  c2017   
 G  c2018   
 G  c2019   
 G  c2020   
 G  c2021   
 G  c2022   
 G  c2023   
 G  c2024   
 G  c2025   
 G  c2026   
 G  c2027   
 G  c2028   
 G  c2029   
 G  c2030   
 G  c2031   
 G  c2032   
 G  c2033   
 G  c2034   
 G  c2035   
 G  c2036   
 G  c2037   
 G  c2038   
 G  c2039   
 G  c2040   
 G  c2041   
 G  c2042   
 G  c2043   
 G  c2044   
 G  c2045   
 G  c2046   
 G  c2047   
 G  c2048   
 G  c2049   
 G  c2050   
 G  c2051   
 G  c2052   
 G  c2053   
 G  c2054   
 G  c2055   
 G  c2056   
 G  c2057   
 G  c2058   
 G  c2059   
 G  c2060   
 G  c2061   
 G  c2062   
 G  c2063   
 G  c2064   
 G  c2065   
 G  c2066   
 G  c2067   
 G  c2068   
 G  c2069   
 G  c2070   
 G  c2071   
 G  c2072   
 G  c2073   
 G  c2074   
 G  c2075   
 G  c2076   
 G  c2077   
 G  c2078   
 G  c2079   
 G  c2080   
 G  c2081   
 G  c2082   
 G  c2083   
 G  c2084   
 G  c2085   
 G  c2086   
 G  c2087   
 G  c2088   
 G  c2089   
 G  c2090   
 G  c2091   
 G  c2092   
 G  c2093   
 G  c2094   
 G  c2095   
 G  c2096   
 G  c2097   
 G  c2098   
 G  c2099   
 G  c2100   
 G  c2101   
 G  c2102   
 G  c2103   
 G  c2104   
 G  c2105   
 G  c2106   
 G  c2107   
 G  c2108   
 G  c2109   
 G  c2110   
 G  c2111   
 G  c2112   
 G  c2113   
 G  c2114   
 G  c2115   
 G  c2116   
 G  c2117   
 G  c2118   
 G  c2119   
 G  c2120   
 G  c2121   
 G  c2122   
 G  c2123   
 G  c2124   
 G  c2125   
 G  c2126   
 G  c2127   
 G  c2128   
 G  c2129   
 G  c2130   
 G  c2131   
 G  c2132   
 G  c2133   
 G  c2134   
 G  c2135   
 G  c2136   
 G  c2137   
 G  c2138   
 G  c2139   
 G  c2140   
 G  c2141   
 G  c2142   
 G  c2143   
 G  c2144   
 G  c2145   
 G  c2146   
 G  c2147   
 G  c2148   
 G  c2149   
 G  c2150   
 G  c2151   
 G  c2152   
 G  c2153   
 G  c2154   
 G  c2155   
 G  c2156   
 G  c2157   
 G  c2158   
 G  c2159   
 G  c2160   
 G  c2161   
 G  c2162   
 G  c2163   
 G  c2164   
 G  c2165   
 G  c2166   
 G  c2167   
 G  c2168   
 G  c2169   
 G  c2170   
 G  c2171   
 G  c2172   
 G  c2173   
 G  c2174   
 G  c2175   
 G  c2176   
 G  c2177   
 G  c2178   
 G  c2179   
 G  c2180   
 G  c2181   
 G  c2182   
 G  c2183   
 G  c2184   
 G  c2185   
 G  c2186   
 G  c2187   
 G  c2188   
 G  c2189   
 G  c2190   
 G  c2191   
 G  c2192   
 G  c2193   
 G  c2194   
 G  c2195   
 G  c2196   
 G  c2197   
 G  c2198   
 G  c2199   
 G  c2200   
 G  c2201   
 G  c2202   
 G  c2203   
 G  c2204   
 G  c2205   
 G  c2206   
 G  c2207   
 G  c2208   
 G  c2209   
 G  c2210   
 G  c2211   
 G  c2212   
 G  c2213   
 G  c2214   
 G  c2215   
 G  c2216   
 G  c2217   
 G  c2218   
 G  c2219   
 G  c2220   
 G  c2221   
 G  c2222   
 G  c2223   
 G  c2224   
 G  c2225   
 G  c2226   
 G  c2227   
 G  c2228   
 G  c2229   
 G  c2230   
 G  c2231   
 G  c2232   
 G  c2233   
 G  c2234   
 G  c2235   
 G  c2236   
 G  c2237   
 G  c2238   
 G  c2239   
 G  c2240   
 G  c2241   
 G  c2242   
 G  c2243   
 G  c2244   
 G  c2245   
 G  c2246   
 G  c2247   
 G  c2248   
 G  c2249   
 G  c2250   
 G  c2251   
 G  c2252   
 G  c2253   
 G  c2254   
 G  c2255   
 G  c2256   
 G  c2257   
 G  c2258   
 G  c2259   
 G  c2260   
 G  c2261   
 G  c2262   
 G  c2263   
 G  c2264   
 G  c2265   
 G  c2266   
 G  c2267   
 G  c2268   
 G  c2269   
 G  c2270   
 G  c2271   
 G  c2272   
 G  c2273   
 G  c2274   
 G  c2275   
 G  c2276   
 G  c2277   
 G  c2278   
 G  c2279   
 G  c2280   
 G  c2281   
 G  c2282   
 G  c2283   
 G  c2284   
 G  c2285   
 G  c2286   
 G  c2287   
 G  c2288   
 G  c2289   
 G  c2290   
 G  c2291   
 G  c2292   
 G  c2293   
 G  c2294   
 G  c2295   
 G  c2296   
 G  c2297   
 G  c2298   
 G  c2299   
 G  c2300   
 G  c2301   
 G  c2302   
 G  c2303   
 G  c2304   
 G  c2305   
 G  c2306   
 G  c2307   
 G  c2308   
 G  c2309   
 G  c2310   
 G  c2311   
 G  c2312   
 G  c2313   
 G  c2314   
 G  c2315   
 G  c2316   
 G  c2317   
 G  c2318   
 G  c2319   
 G  c2320   
 G  c2321   
 G  c2322   
 G  c2323   
 G  c2324   
 G  c2325   
 G  c2326   
 G  c2327   
 G  c2328   
 G  c2329   
 G  c2330   
 G  c2331   
 G  c2332   
 G  c2333   
 G  c2334   
 G  c2335   
 G  c2336   
 G  c2337   
 G  c2338   
 G  c2339   
 G  c2340   
 G  c2341   
 G  c2342   
 G  c2343   
 G  c2344   
 G  c2345   
 G  c2346   
 G  c2347   
 G  c2348   
 G  c2349   
 G  c2350   
 G  c2351   
 G  c2352   
 G  c2353   
 G  c2354   
 G  c2355   
 G  c2356   
 G  c2357   
 G  c2358   
 G  c2359   
 G  c2360   
 G  c2361   
 G  c2362   
 G  c2363   
 G  c2364   
 G  c2365   
 G  c2366   
 G  c2367   
 G  c2368   
 G  c2369   
 G  c2370   
 G  c2371   
 G  c2372   
 G  c2373   
 G  c2374   
 G  c2375   
 G  c2376   
 G  c2377   
 G  c2378   
 G  c2379   
 G  c2380   
 G  c2381   
 G  c2382   
 G  c2383   
 G  c2384   
 G  c2385   
 G  c2386   
 G  c2387   
 G  c2388   
 G  c2389   
 G  c2390   
 G  c2391   
 G  c2392   
 G  c2393   
 G  c2394   
 G  c2395   
 G  c2396   
 G  c2397   
 G  c2398   
 G  c2399   
 G  c2400   
 G  c2401   
 G  c2402   
 G  c2403   
 G  c2404   
 G  c2405   
 G  c2406   
 G  c2407   
 G  c2408   
 G  c2409   
 G  c2410   
 G  c2411   
 G  c2412   
 G  c2413   
 G  c2414   
 G  c2415   
 G  c2416   
 G  c2417   
 G  c2418   
 G  c2419   
 G  c2420   
 G  c2421   
 G  c2422   
 G  c2423   
 G  c2424   
 G  c2425   
 G  c2426   
 G  c2427   
 G  c2428   
 G  c2429   
 G  c2430   
 G  c2431   
 G  c2432   
 G  c2433   
 G  c2434   
 G  c2435   
 G  c2436   
 G  c2437   
 G  c2438   
 G  c2439   
 G  c2440   
 G  c2441   
 G  c2442   
 G  c2443   
 G  c2444   
 G  c2445   
 G  c2446   
 G  c2447   
 G  c2448   
 G  c2449   
 G  c2450   
 G  c2451   
 G  c2452   
 G  c2453   
 G  c2454   
 G  c2455   
 G  c2456   
 G  c2457   
 G  c2458   
 G  c2459   
 G  c2460   
 G  c2461   
 G  c2462   
 G  c2463   
 G  c2464   
 G  c2465   
 G  c2466   
 G  c2467   
 G  c2468   
 G  c2469   
 G  c2470   
 G  c2471   
 G  c2472   
 G  c2473   
 G  c2474   
 G  c2475   
 G  c2476   
 G  c2477   
 G  c2478   
 G  c2479   
 G  c2480   
 G  c2481   
 G  c2482   
 G  c2483   
 G  c2484   
 G  c2485   
 G  c2486   
 G  c2487   
 G  c2488   
 G  c2489   
 G  c2490   
 G  c2491   
 G  c2492   
 G  c2493   
 G  c2494   
 G  c2495   
 G  c2496   
 G  c2497   
 G  c2498   
 G  c2499   
 G  c2500   
 G  c2501   
 G  c2502   
 G  c2503   
 G  c2504   
 G  c2505   
 G  c2506   
 G  c2507   
 G  c2508   
 G  c2509   
 G  c2510   
 G  c2511   
 G  c2512   
 G  c2513   
 G  c2514   
 G  c2515   
 G  c2516   
 G  c2517   
 G  c2518   
 G  c2519   
 G  c2520   
 G  c2521   
 G  c2522   
 G  c2523   
 G  c2524   
 G  c2525   
 G  c2526   
 G  c2527   
 G  c2528   
 G  c2529   
 G  c2530   
 G  c2531   
 G  c2532   
 G  c2533   
 G  c2534   
 G  c2535   
 G  c2536   
 G  c2537   
 G  c2538   
 G  c2539   
 G  c2540   
 G  c2541   
 G  c2542   
 G  c2543   
 G  c2544   
 G  c2545   
 G  c2546   
 G  c2547   
 G  c2548   
 G  c2549   
 G  c2550   
 G  c2551   
 G  c2552   
 G  c2553   
 G  c2554   
 G  c2555   
 G  c2556   
 G  c2557   
 G  c2558   
 G  c2559   
 G  c2560   
 G  c2561   
 G  c2562   
 G  c2563   
 G  c2564   
 G  c2565   
 G  c2566   
 G  c2567   
 G  c2568   
 G  c2569   
 G  c2570   
 G  c2571   
 G  c2572   
 G  c2573   
 G  c2574   
 G  c2575   
 G  c2576   
 G  c2577   
 G  c2578   
 G  c2579   
 G  c2580   
 G  c2581   
 G  c2582   
 G  c2583   
 G  c2584   
 G  c2585   
 G  c2586   
 G  c2587   
 G  c2588   
 G  c2589   
 G  c2590   
 G  c2591   
 G  c2592   
 G  c2593   
 G  c2594   
 G  c2595   
 G  c2596   
 G  c2597   
 G  c2598   
 G  c2599   
 G  c2600   
 G  c2601   
 G  c2602   
 G  c2603   
 G  c2604   
 G  c2605   
 G  c2606   
 G  c2607   
 G  c2608   
 G  c2609   
 G  c2610   
 G  c2611   
 G  c2612   
 G  c2613   
 G  c2614   
 G  c2615   
 G  c2616   
 G  c2617   
 G  c2618   
 G  c2619   
 G  c2620   
 G  c2621   
 G  c2622   
 G  c2623   
 G  c2624   
 G  c2625   
 G  c2626   
 G  c2627   
 G  c2628   
 G  c2629   
 G  c2630   
 G  c2631   
 G  c2632   
 G  c2633   
 G  c2634   
 G  c2635   
 G  c2636   
 G  c2637   
 G  c2638   
 G  c2639   
 G  c2640   
 G  c2641   
 G  c2642   
 G  c2643   
 G  c2644   
 G  c2645   
 G  c2646   
 G  c2647   
 G  c2648   
 G  c2649   
 G  c2650   
 G  c2651   
 G  c2652   
 G  c2653   
 G  c2654   
 G  c2655   
 G  c2656   
 G  c2657   
 G  c2658   
 G  c2659   
 G  c2660   
 G  c2661   
 G  c2662   
 G  c2663   
 G  c2664   
 G  c2665   
 G  c2666   
 G  c2667   
 G  c2668   
 G  c2669   
 G  c2670   
 G  c2671   
 G  c2672   
 G  c2673   
 G  c2674   
 G  c2675   
 G  c2676   
 G  c2677   
 G  c2678   
 G  c2679   
 G  c2680   
 G  c2681   
 G  c2682   
 G  c2683   
 G  c2684   
 G  c2685   
 G  c2686   
 G  c2687   
 G  c2688   
 G  c2689   
 G  c2690   
 G  c2691   
 G  c2692   
 G  c2693   
 G  c2694   
 G  c2695   
 G  c2696   
 G  c2697   
 G  c2698   
 G  c2699   
 G  c2700   
 G  c2701   
 G  c2702   
 G  c2703   
 G  c2704   
 G  c2705   
 G  c2706   
 G  c2707   
 G  c2708   
 G  c2709   
 G  c2710   
 G  c2711   
 G  c2712   
 G  c2713   
 G  c2714   
 G  c2715   
 G  c2716   
 G  c2717   
 G  c2718   
 G  c2719   
 G  c2720   
 G  c2721   
 G  c2722   
 G  c2723   
 G  c2724   
 G  c2725   
 G  c2726   
 G  c2727   
 G  c2728   
 G  c2729   
 G  c2730   
 G  c2731   
 G  c2732   
 G  c2733   
 G  c2734   
 G  c2735   
 G  c2736   
 G  c2737   
 G  c2738   
 G  c2739   
 G  c2740   
 G  c2741   
 G  c2742   
 G  c2743   
 G  c2744   
 G  c2745   
 G  c2746   
 G  c2747   
 G  c2748   
 G  c2749   
 G  c2750   
 G  c2751   
 G  c2752   
 G  c2753   
 G  c2754   
 G  c2755   
 G  c2756   
 G  c2757   
 G  c2758   
 G  c2759   
 G  c2760   
 G  c2761   
 G  c2762   
 G  c2763   
 G  c2764   
 G  c2765   
 G  c2766   
 G  c2767   
 G  c2768   
 G  c2769   
 G  c2770   
 G  c2771   
 G  c2772   
 G  c2773   
 G  c2774   
 G  c2775   
 G  c2776   
 G  c2777   
 G  c2778   
 G  c2779   
 G  c2780   
 G  c2781   
 G  c2782   
 G  c2783   
 G  c2784   
 G  c2785   
 G  c2786   
 G  c2787   
 G  c2788   
 G  c2789   
 G  c2790   
 G  c2791   
 G  c2792   
 G  c2793   
 G  c2794   
 G  c2795   
 G  c2796   
 G  c2797   
 G  c2798   
 G  c2799   
 G  c2800   
 G  c2801   
 G  c2802   
 G  c2803   
 G  c2804   
 G  c2805   
 G  c2806   
 G  c2807   
 G  c2808   
 G  c2809   
 G  c2810   
 G  c2811   
 G  c2812   
 G  c2813   
 G  c2814   
 G  c2815   
 G  c2816   
 G  c2817   
 G  c2818   
 G  c2819   
 G  c2820   
 G  c2821   
 G  c2822   
 G  c2823   
 G  c2824   
 G  c2825   
 G  c2826   
 G  c2827   
 G  c2828   
 G  c2829   
 G  c2830   
 G  c2831   
 G  c2832   
 G  c2833   
 G  c2834   
 G  c2835   
 G  c2836   
 G  c2837   
 G  c2838   
 G  c2839   
 G  c2840   
 G  c2841   
 G  c2842   
 G  c2843   
 G  c2844   
 G  c2845   
 G  c2846   
 G  c2847   
 G  c2848   
 G  c2849   
 G  c2850   
 G  c2851   
 G  c2852   
 G  c2853   
 G  c2854   
 G  c2855   
 G  c2856   
 G  c2857   
 G  c2858   
 G  c2859   
 G  c2860   
 G  c2861   
 G  c2862   
 G  c2863   
 G  c2864   
 G  c2865   
 G  c2866   
 G  c2867   
 G  c2868   
 G  c2869   
 G  c2870   
 G  c2871   
 G  c2872   
 G  c2873   
 G  c2874   
 G  c2875   
 G  c2876   
 G  c2877   
 G  c2878   
 G  c2879   
 G  c2880   
 G  c2881   
 G  c2882   
 G  c2883   
 G  c2884   
 G  c2885   
 G  c2886   
 G  c2887   
 G  c2888   
 G  c2889   
 G  c2890   
 G  c2891   
 G  c2892   
 G  c2893   
 G  c2894   
 G  c2895   
 G  c2896   
 G  c2897   
 G  c2898   
 G  c2899   
 G  c2900   
 G  c2901   
 G  c2902   
 G  c2903   
 G  c2904   
 G  c2905   
 G  c2906   
 G  c2907   
 G  c2908   
 G  c2909   
 G  c2910   
 G  c2911   
 G  c2912   
 G  c2913   
 G  c2914   
 G  c2915   
 G  c2916   
 G  c2917   
 G  c2918   
 G  c2919   
 G  c2920   
 G  c2921   
 G  c2922   
 G  c2923   
 G  c2924   
 G  c2925   
 G  c2926   
 G  c2927   
 G  c2928   
 G  c2929   
 G  c2930   
 G  c2931   
 G  c2932   
 G  c2933   
 G  c2934   
 G  c2935   
 G  c2936   
 G  c2937   
 G  c2938   
 G  c2939   
 G  c2940   
 G  c2941   
 G  c2942   
 G  c2943   
 G  c2944   
 G  c2945   
 G  c2946   
 G  c2947   
 G  c2948   
 G  c2949   
 G  c2950   
 G  c2951   
 G  c2952   
 G  c2953   
 G  c2954   
 G  c2955   
 G  c2956   
 G  c2957   
 G  c2958   
 G  c2959   
 G  c2960   
 G  c2961   
 G  c2962   
 G  c2963   
 G  c2964   
 G  c2965   
 G  c2966   
 G  c2967   
 G  c2968   
 G  c2969   
 G  c2970   
 G  c2971   
 G  c2972   
 G  c2973   
 G  c2974   
 G  c2975   
 G  c2976   
 G  c2977   
 G  c2978   
 G  c2979   
 G  c2980   
 G  c2981   
 G  c2982   
 G  c2983   
 G  c2984   
 G  c2985   
 G  c2986   
 G  c2987   
 G  c2988   
 G  c2989   
 G  c2990   
 G  c2991   
 G  c2992   
 G  c2993   
 G  c2994   
 G  c2995   
 G  c2996   
 G  c2997   
 G  c2998   
 G  c2999   
 G  c3000   
 G  c3001   
 G  c3002   
 G  c3003   
 G  c3004   
 G  c3005   
 G  c3006   
 G  c3007   
 G  c3008   
 G  c3009   
 G  c3010   
 G  c3011   
 G  c3012   
 G  c3013   
 G  c3014   
 G  c3015   
 G  c3016   
 G  c3017   
 G  c3018   
 G  c3019   
 G  c3020   
 G  c3021   
 G  c3022   
 G  c3023   
 G  c3024   
 G  c3025   
 G  c3026   
 G  c3027   
 G  c3028   
 G  c3029   
 G  c3030   
 G  c3031   
 G  c3032   
 G  c3033   
 G  c3034   
 G  c3035   
 G  c3036   
 G  c3037   
 G  c3038   
 G  c3039   
 G  c3040   
 G  c3041   
 G  c3042   
 G  c3043   
 G  c3044   
 G  c3045   
 G  c3046   
 G  c3047   
 G  c3048   
 G  c3049   
 G  c3050   
 G  c3051   
 G  c3052   
 G  c3053   
 G  c3054   
 G  c3055   
 G  c3056   
 G  c3057   
 G  c3058   
 G  c3059   
 G  c3060   
 G  c3061   
 G  c3062   
 G  c3063   
 G  c3064   
 G  c3065   
 G  c3066   
 G  c3067   
 G  c3068   
 G  c3069   
 G  c3070   
 G  c3071   
 G  c3072   
 G  c3073   
 G  c3074   
 G  c3075   
 G  c3076   
 G  c3077   
 G  c3078   
 G  c3079   
 G  c3080   
 G  c3081   
 G  c3082   
 G  c3083   
 G  c3084   
 G  c3085   
 G  c3086   
 G  c3087   
 G  c3088   
 G  c3089   
 G  c3090   
 G  c3091   
 G  c3092   
 G  c3093   
 G  c3094   
 G  c3095   
 G  c3096   
 G  c3097   
 G  c3098   
 G  c3099   
 G  c3100   
 G  c3101   
 G  c3102   
 G  c3103   
 G  c3104   
 G  c3105   
 G  c3106   
 G  c3107   
 G  c3108   
 G  c3109   
 G  c3110   
 G  c3111   
 G  c3112   
 G  c3113   
 G  c3114   
 G  c3115   
 G  c3116   
 G  c3117   
 G  c3118   
 G  c3119   
 G  c3120   
 G  c3121   
 G  c3122   
 G  c3123   
 G  c3124   
 G  c3125   
 G  c3126   
 G  c3127   
 G  c3128   
 G  c3129   
 G  c3130   
 G  c3131   
 G  c3132   
 G  c3133   
 G  c3134   
 G  c3135   
 G  c3136   
 G  c3137   
 G  c3138   
 G  c3139   
 G  c3140   
 G  c3141   
 G  c3142   
 G  c3143   
 G  c3144   
 G  c3145   
 G  c3146   
 G  c3147   
 G  c3148   
 G  c3149   
 G  c3150   
 G  c3151   
 G  c3152   
 G  c3153   
 G  c3154   
 G  c3155   
 G  c3156   
 G  c3157   
 G  c3158   
 G  c3159   
 G  c3160   
 G  c3161   
 G  c3162   
 G  c3163   
 G  c3164   
 G  c3165   
 G  c3166   
 G  c3167   
 G  c3168   
 G  c3169   
 G  c3170   
 G  c3171   
 G  c3172   
 G  c3173   
 G  c3174   
 G  c3175   
 G  c3176   
 G  c3177   
 G  c3178   
 G  c3179   
 G  c3180   
 G  c3181   
 G  c3182   
 G  c3183   
 G  c3184   
 G  c3185   
 G  c3186   
 G  c3187   
 G  c3188   
 G  c3189   
 G  c3190   
 G  c3191   
 G  c3192   
 G  c3193   
 G  c3194   
 G  c3195   
 G  c3196   
 G  c3197   
 G  c3198   
 G  c3199   
 G  c3200   
 G  c3201   
 G  c3202   
 G  c3203   
 G  c3204   
 G  c3205   
 G  c3206   
 G  c3207   
 G  c3208   
 G  c3209   
 G  c3210   
 G  c3211   
 G  c3212   
 G  c3213   
 G  c3214   
 G  c3215   
 G  c3216   
 G  c3217   
 G  c3218   
 G  c3219   
 G  c3220   
 G  c3221   
 G  c3222   
 G  c3223   
 G  c3224   
 G  c3225   
 G  c3226   
 G  c3227   
 G  c3228   
 G  c3229   
 G  c3230   
 G  c3231   
 G  c3232   
 G  c3233   
 G  c3234   
 G  c3235   
 G  c3236   
 G  c3237   
 G  c3238   
 G  c3239   
 G  c3240   
 G  c3241   
 G  c3242   
 G  c3243   
 G  c3244   
 G  c3245   
 G  c3246   
 G  c3247   
 G  c3248   
 G  c3249   
 G  c3250   
 G  c3251   
 G  c3252   
 G  c3253   
 G  c3254   
 G  c3255   
 G  c3256   
 G  c3257   
 G  c3258   
 G  c3259   
 G  c3260   
 G  c3261   
 G  c3262   
 G  c3263   
 G  c3264   
 G  c3265   
 G  c3266   
 G  c3267   
 G  c3268   
 G  c3269   
 G  c3270   
 G  c3271   
 G  c3272   
 G  c3273   
 G  c3274   
 G  c3275   
 G  c3276   
 G  c3277   
 G  c3278   
 G  c3279   
 G  c3280   
 G  c3281   
 G  c3282   
 G  c3283   
 G  c3284   
 G  c3285   
 G  c3286   
 G  c3287   
 G  c3288   
 G  c3289   
 G  c3290   
 G  c3291   
 G  c3292   
 G  c3293   
 G  c3294   
 G  c3295   
 G  c3296   
 G  c3297   
 G  c3298   
 G  c3299   
 G  c3300   
 G  c3301   
 G  c3302   
 G  c3303   
 G  c3304   
 G  c3305   
 G  c3306   
 G  c3307   
 G  c3308   
 G  c3309   
 G  c3310   
 G  c3311   
 G  c3312   
 G  c3313   
 G  c3314   
 G  c3315   
 G  c3316   
 G  c3317   
 G  c3318   
 G  c3319   
 G  c3320   
 G  c3321   
 G  c3322   
 G  c3323   
 G  c3324   
 G  c3325   
 G  c3326   
 G  c3327   
 G  c3328   
 G  c3329   
 G  c3330   
 G  c3331   
 G  c3332   
 G  c3333   
 G  c3334   
 G  c3335   
 G  c3336   
 G  c3337   
 G  c3338   
 G  c3339   
 G  c3340   
 G  c3341   
 G  c3342   
 G  c3343   
 G  c3344   
 G  c3345   
 G  c3346   
 G  c3347   
 G  c3348   
 G  c3349   
 G  c3350   
 G  c3351   
 G  c3352   
 G  c3353   
 G  c3354   
 G  c3355   
 G  c3356   
 G  c3357   
 G  c3358   
 G  c3359   
 G  c3360   
 G  c3361   
 G  c3362   
 G  c3363   
 G  c3364   
 G  c3365   
 G  c3366   
 G  c3367   
 G  c3368   
 G  c3369   
 G  c3370   
 G  c3371   
 G  c3372   
 G  c3373   
 G  c3374   
 G  c3375   
 G  c3376   
 G  c3377   
 G  c3378   
 G  c3379   
 G  c3380   
 G  c3381   
 G  c3382   
 G  c3383   
 G  c3384   
 G  c3385   
 G  c3386   
 G  c3387   
 G  c3388   
 G  c3389   
 G  c3390   
 G  c3391   
 G  c3392   
 G  c3393   
 G  c3394   
 G  c3395   
 G  c3396   
 G  c3397   
 G  c3398   
 G  c3399   
 G  c3400   
 G  c3401   
 G  c3402   
 G  c3403   
 G  c3404   
 G  c3405   
 G  c3406   
 G  c3407   
 G  c3408   
 G  c3409   
 G  c3410   
 G  c3411   
 G  c3412   
 G  c3413   
 G  c3414   
 G  c3415   
 G  c3416   
 G  c3417   
 G  c3418   
 G  c3419   
 G  c3420   
 G  c3421   
 G  c3422   
 G  c3423   
 G  c3424   
 G  c3425   
 G  c3426   
 G  c3427   
 G  c3428   
 G  c3429   
 G  c3430   
 G  c3431   
 G  c3432   
 G  c3433   
 G  c3434   
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x1        c1                   1   c4                   1
    x2        c2                  -1   c15                  1
    x2        c16                 -1   c17                  1
    x2        c18                 -1
    x3        c3                   1   c2514                1
    x3        c2515                1   c2516                1
    x3        c2517                1   c3434               -1
    x4        c5                  -1   c9                   1
    x4        c10                 -1   c15                 -1
    x4        c16                  1   c19                  1
    x4        c20                 -1   c1869                1
    x4        c2948               -1
    x5        c6                   1   c9                   1
    x5        c10                 -1   c13                  1
    x5        c14                 -1   c1867                1
    x5        c1884                1   c1885               -1
    x5        c2945               -1
    x6        c7                   1   c8                  -1
    x6        c13                  1   c14                 -1
    x6        c1871                1   c1872               -1
    x6        c1873                1   c1874               -1
    x6        c1875                1   c1876               -1
    x7        c7                  -1   c8                   1
    x7        c17                 -1   c18                  1
    x7        c19                 -1   c20                  1
    x8        c11                 -1   c12                  1
    x8        c1875                1   c1876               -1
    x8        c1877               -1   c1878                1
    x9        c11                 -1   c12                  1
    x9        c1884                1   c1885               -1
    x9        c1888               -1   c1889                1
    x10       c21                 -1   c23                  1
    x10       c30                  1   c31                 -1
    x10       c2518                1   c2519               -1
    x10       c2521                1   c2522               -1
    x11       c21                 -1   c22                 -1
    x11       c26                 -1   c2518                1
    x11       c2520                1
    x12       c22                  1   c24                 -1
    x12       c27                  1   c28                 -1
    x12       c2518               -1   c2519                1
    x12       c2521                1   c2522               -1
    x13       c23                 -1   c24                 -1
    x13       c25                 -1   c2519                1
    x13       c2520                1
    x14       c25                  1   c26                  1
    x14       c2517               -1   c2520               -1
    x14       c3434                1
    x15       c27                  1   c28                 -1
    x15       c32                 -1   c33                  1
    x15       c2526                1   c2527               -1
    x16       c29                 -1   c36                 -1
    x16       c2523                1   c2526               -1
    x16       c2527               -1
    x17       c29                  1   c2521               -1
    x17       c2522               -1   c3224                1
    x18       c30                  1   c31                 -1
    x18       c38                 -1   c39                  1
    x18       c2526                1   c2527               -1
    x19       c32                  1   c33                 -1
    x19       c34                  1   c35                 -1
    x19       c42                  1   c2528                1
    x19       c2529               -1   c2530               -1
    x19       c2543                1   c2544               -1
    x20       c34                 -1   c35                  1
    x20       c1966                1   c2524                1
    x20       c2525               -1   c3429               -1
    x21       c36                  1   c37                  1
    x21       c43                  1   c44                  1
    x21       c45                  1   c2523               -1
    x21       c2543               -1   c2544               -1
    x22       c37                 -1   c1967               -1
    x22       c1968               -1   c1969               -1
    x22       c1970               -1   c2523                1
    x22       c2524               -1   c2525               -1
    x23       c38                  1   c39                 -1
    x23       c40                  1   c41                 -1
    x23       c46                  1   c2543                1
    x23       c2544               -1   c2545                1
    x23       c2546               -1   c2547               -1
    x24       c40                 -1   c41                  1
    x24       c1974                1   c2524                1
    x24       c2525               -1   c3430               -1
    x25       c42                  1   c51                 -1
    x25       c52                  1   c2529               -1
    x25       c2530               -1   c2538                1
    x25       c2539                1   c2541                1
    x25       c2542                1   c2548                1
    x25       c2549               -1   c3225               -1
    x26       c43                 -1   c1928                1
    x26       c2534               -1   c2535               -1
    x26       c2536               -1   c2540               -1
    x26       c2541               -1   c2542               -1
    x26       c2953               -1   c2954               -1
    x27       c44                 -1   c54                 -1
    x27       c2531               -1   c2532               -1
    x27       c2533               -1   c2537               -1
    x27       c2538               -1   c2539               -1
    x27       c2550               -1   c2551               -1
    x27       c3227                1
    x28       c45                 -1   c55                 -1
    x28       c2548               -1   c2549               -1
    x28       c3225               -1   c3226               -1
    x28       c3227                1
    x29       c46                  1   c60                 -1
    x29       c61                  1   c2537                1
    x29       c2539                1   c2540                1
    x29       c2542                1   c2546               -1
    x29       c2547               -1   c2548                1
    x29       c2549               -1   c3226               -1
    x30       c47                  1   c48                 -1
    x30       c49                  1   c50                 -1
    x30       c51                  1   c52                 -1
    x30       c2554                1   c2555                1
    x30       c2556               -1   c2557               -1
    x30       c2558               -1   c2559               -1
    x30       c2569                1   c2570               -1
    x31       c47                 -1   c48                  1
    x31       c1926                1   c1927               -1
    x31       c2552                1   c2553               -1
    x32       c49                 -1   c50                  1
    x32       c2528                1   c2530               -1
    x32       c2532               -1   c2534               -1
    x32       c2536               -1   c2538               -1
    x32       c2550                1   c2551               -1
    x32       c3225                1
    x33       c53                  1   c54                  1
    x33       c55                  1   c62                  1
    x33       c63                  1   c64                  1
    x33       c2569               -1   c2570               -1
    x33       c3227               -1
    x34       c53                 -1   c1928               -1
    x34       c2552               -1   c2553               -1
    x34       c3227                1
    x35       c56                  1   c57                 -1
    x35       c58                  1   c59                 -1
    x35       c60                  1   c61                 -1
    x35       c2569                1   c2570               -1
    x35       c2571                1   c2572                1
    x35       c2573               -1   c2574               -1
    x35       c2575               -1   c2576               -1
    x36       c56                 -1   c57                  1
    x36       c1929                1   c1930               -1
    x36       c2552                1   c2553               -1
    x37       c58                 -1   c59                  1
    x37       c2531               -1   c2535               -1
    x37       c2536               -1   c2537               -1
    x37       c2545                1   c2547               -1
    x37       c2550                1   c2551               -1
    x37       c3226                1
    x38       c62                 -1   c1528               -1
    x38       c2566               -1   c2567               -1
    x38       c2568               -1   c2816               -1
    x38       c2817               -1   c3235               -1
    x38       c3236               -1   c3237               -1
    x38       c3327                1
    x39       c63                 -1   c1509               -1
    x39       c2563               -1   c2564               -1
    x39       c2565               -1   c2805                1
    x39       c2808               -1   c2809               -1
    x39       c3232               -1   c3233               -1
    x39       c3234               -1
    x40       c64                 -1   c65                 -1
    x40       c1510               -1   c2805                1
    x40       c2806               -1   c2807               -1
    x40       c3230               -1   c3231               -1
    x41       c65                 -1   c68                 -1
    x41       c69                  1   c2555                1
    x41       c2557               -1   c2559               -1
    x41       c2561               -1   c2572                1
    x41       c2574               -1   c2576               -1
    x41       c3228               -1   c3232                1
    x41       c3233                1   c3234                1
    x41       c3235                1   c3236                1
    x41       c3237                1
    x42       c66                  1   c67                 -1
    x42       c68                  1   c69                 -1
    x42       c70                 -1   c2577               -1
    x42       c2578                1   c2579                1
    x43       c66                 -1   c67                  1
    x43       c1516               -1   c1518               -1
    x43       c1520               -1   c2810                1
    x43       c2813                1
    x44       c70                 -1   c71                 -1
    x44       c2578                1   c2579                1
    x44       c2580               -1   c2581                1
    x44       c2582                1
    x45       c71                 -1   c72                 -1
    x45       c73                  1   c2581                1
    x45       c2582                1
    x46       c72                  1   c73                 -1
    x46       c74                  1   c75                 -1
    x46       c76                 -1   c77                 -1
    x46       c78                 -1   c79                 -1
    x46       c3414                1
    x47       c74                 -1   c75                  1
    x47       c2577               -1   c2578                1
    x48       c76                 -1   c1190                1
    x48       c1191                1   c1192                1
    x48       c3295               -1   c3414                1
    x49       c77                 -1   c732                -1
    x49       c2623                1   c2624                1
    x49       c2625                1   c3263               -1
    x49       c3414                1
    x50       c78                 -1   c590                -1
    x50       c591                -1   c592                -1
    x50       c3256                1   c3414                1
    x51       c79                 -1   c80                 -1
    x51       c81                 -1   c2583                1
    x51       c3414                1
    x52       c80                 -1   c575                -1
    x52       c576                 1   c2583                1
    x53       c81                 -1   c82                  1
    x53       c83                 -1   c2583                1
    x54       c82                  1   c83                 -1
    x54       c86                 -1   c87                  1
    x55       c84                  1   c85                 -1
    x55       c86                  1   c87                 -1
    x55       c88                  1   c89                  1
    x55       c90                  1   c3238               -1
    x56       c84                 -1   c85                  1
    x56       c2619                1   c2620               -1
    x56       c2621                1   c2622               -1
    x57       c88                  1   c561                -1
    x57       c562                 1   c3238               -1
    x58       c89                  1   c372                -1
    x58       c373                 1   c3238               -1
    x59       c90                  1   c117                -1
    x59       c118                 1   c3238               -1
    x60       c91                  1   c92                 -1
    x60       c93                  1   c94                 -1
    x60       c95                  1   c96                 -1
    x60       c97                  1   c98                 -1
    x60       c99                  1   c100                -1
    x60       c101                 1   c102                -1
    x60       c103                 1   c104                -1
    x60       c105                 1   c106                -1
    x60       c107                 1   c108                -1
    x60       c109                 1   c110                -1
    x60       c111                 1   c112                -1
    x60       c113                 1   c114                -1
    x60       c115                 1   c116                -1
    x60       c117                 1   c118                -1
    x60       c119                 1   c120                -1
    x60       c121                 1   c122                -1
    x60       c123                 1   c124                -1
    x60       c125                 1   c126                -1
    x60       c127                 1   c128                -1
    x60       c129                 1   c130                -1
    x60       c131                 1   c132                -1
    x60       c133                 1   c134                -1
    x60       c135                 1   c136                -1
    x60       c137                 1   c138                -1
    x60       c139                 1   c140                -1
    x60       c141                 1   c142                -1
    x60       c143                 1   c144                -1
    x60       c145                 1   c146                -1
    x60       c147                 1   c148                 1
    x60       c149                 1   c3239               -1
    x61       c91                 -1   c92                  1
    x61       c1866                1   c3353               -1
    x62       c93                 -1   c94                  1
    x62       c1457                1   c3325               -1
    x63       c95                 -1   c96                  1
    x63       c1244                1   c3297               -1
    x64       c97                 -1   c98                  1
    x64       c1298                1   c3299               -1
    x65       c99                 -1   c100                 1
    x65       c1807                1   c3345               -1
    x66       c101                -1   c102                 1
    x66       c1894                1   c3355               -1
    x67       c103                -1   c104                 1
    x67       c1840                1   c3348               -1
    x68       c105                -1   c106                 1
    x68       c1883                1   c3354               -1
    x69       c107                -1   c108                 1
    x69       c579                 1   c3255               -1
    x70       c109                -1   c110                 1
    x70       c2680               -1   c2684                1
    x70       c2685                1
    x71       c111                -1   c112                 1
    x71       c688                 1   c689                -1
    x72       c113                -1   c114                 1
    x72       c920                 1   c2677               -1
    x73       c115                -1   c116                 1
    x73       c1729                1   c2912               -1
    x74       c119                -1   c120                 1
    x74       c853                -1   c2656                1
    x75       c121                -1   c122                 1
    x75       c897                 1   c2670               -1
    x76       c123                -1   c124                 1
    x76       c1738               -1   c2917                1
    x77       c125                -1   c126                 1
    x77       c1664               -1   c2875                1
    x78       c127                -1   c128                 1
    x78       c2643               -1   c2645                1
    x78       c2647                1
    x79       c129                -1   c130                 1
    x79       c2854               -1   c2856                1
    x79       c2858                1
    x80       c131                -1   c132                 1
    x80       c601                 1   c3257               -1
    x81       c133                -1   c134                 1
    x81       c2704                1   c2708               -1
    x81       c2709               -1
    x82       c135                -1   c136                 1
    x82       c2879                1   c2883               -1
    x82       c2884               -1
    x83       c137                -1   c138                 1
    x83       c2714               -1   c2716                1
    x83       c2718                1
    x84       c139                -1   c140                 1
    x84       c2890               -1   c2892                1
    x84       c2894                1
    x85       c141                -1   c142                 1
    x85       c1657               -1   c2871                1
    x86       c143                -1   c144                 1
    x86       c1699                1   c2898               -1
    x87       c145                -1   c146                 1
    x87       c1158               -1   c2742                1
    x88       c147                 1   c368                -1
    x88       c369                 1   c3239               -1
    x89       c148                 1   c343                -1
    x89       c344                 1   c3239               -1
    x90       c149                 1   c152                -1
    x90       c153                 1   c3239               -1
    x91       c150                 1   c151                -1
    x91       c152                 1   c153                -1
    x91       c154                 1   c155                -1
    x92       c150                -1   c151                 1
    x92       c1289                1   c3298               -1
    x93       c154                 1   c155                -1
    x93       c156                -1   c157                 1
    x94       c156                 1   c157                -1
    x94       c158                 1   c159                -1
    x94       c160                 1   c161                -1
    x94       c162                 1   c163                -1
    x94       c164                 1   c165                 1
    x94       c166                 1   c3240               -1
    x95       c158                -1   c159                 1
    x95       c2107               -1   c2109                1
    x95       c3042                1   c3043               -1
    x96       c160                -1   c161                 1
    x97       c162                -1   c163                 1
    x98       c164                 1   c2584                1
    x98       c2585                1   c2586                1
    x98       c2587                1   c2588                1
    x98       c2589                1   c2590                1
    x98       c2591                1   c2592                1
    x98       c3240               -1   c3243               -1
    x98       c3244               -1
    x99       c165                 1   c300                 1
    x99       c301                 1   c302                 1
    x99       c3240               -1   c3242               -1
    x100      c166                 1   c167                 1
    x100      c168                 1   c169                 1
    x100      c3240               -1   c3241               -1
    x101      c167                 1   c294                -1
    x101      c295                 1   c3241               -1
    x102      c168                 1   c3241               -1
    x103      c169                 1   c204                -1
    x103      c205                 1   c3241               -1
    x104      c170                 1   c171                -1
    x104      c172                 1   c173                -1
    x104      c174                 1   c175                -1
    x104      c176                 1   c177                -1
    x104      c178                 1   c179                -1
    x104      c180                 1   c181                -1
    x104      c182                 1   c183                -1
    x104      c184                 1   c185                -1
    x104      c186                 1   c187                -1
    x104      c188                 1   c189                -1
    x104      c190                 1   c191                -1
    x104      c192                 1   c193                -1
    x104      c194                 1   c195                -1
    x104      c196                 1   c197                -1
    x104      c198                 1   c199                -1
    x104      c200                 1   c201                -1
    x104      c202                 1   c203                -1
    x104      c204                 1   c205                -1
    x104      c206                 1   c207                -1
    x104      c208                 1   c209                -1
    x104      c210                 1   c211                -1
    x105      c170                -1   c171                 1
    x105      c1362                1   c3311               -1
    x106      c172                -1   c173                 1
    x106      c3077                1   c3080                1
    x106      c3083                1   c3391               -1
    x107      c174                -1   c175                 1
    x107      c2770                1   c2773                1
    x107      c2776                1   c3310               -1
    x108      c176                -1   c177                 1
    x108      c2761                1   c2762                1
    x108      c2763                1   c3303               -1
    x109      c178                -1   c179                 1
    x109      c3035                1   c3038                1
    x109      c3041                1   c3375               -1
    x110      c180                -1   c181                 1
    x110      c2596                1   c2599                1
    x110      c2602                1   c3248               -1
    x111      c182                -1   c183                 1
    x111      c2785                1   c2788                1
    x111      c2791                1   c3317               -1
    x112      c184                -1   c185                 1
    x112      c1408                1   c3318               -1
    x113      c186                -1   c187                 1
    x113      c2194                1   c3392               -1
    x114      c188                -1   c189                 1
    x114      c2106                1   c3376               -1
    x115      c190                -1   c191                 1
    x115      c1312                1   c3301               -1
    x116      c192                -1   c193                 1
    x116      c2128                1   c3378               -1
    x117      c194                -1   c195                 1
    x117      c2134                1   c3380               -1
    x118      c196                -1   c197                 1
    x118      c2590                1   c2591                1
    x118      c2592                1   c3243               -1
    x119      c198                -1   c199                 1
    x119      c3061                1   c3064                1
    x119      c3067                1   c3386               -1
    x120      c200                -1   c201                 1
    x120      c3026                1   c3368               -1
    x120      c3370               -1
    x121      c202                -1   c203                 1
    x121      c3028               -1   c3029                1
    x121      c3031                1
    x122      c206                -1   c207                 1
    x122      c2155                1   c3387               -1
    x123      c208                -1   c209                 1
    x123      c365                 1   c3249               -1
    x124      c210                 1   c211                -1
    x124      c246                -1   c247                 1
    x125      c212                 1   c213                -1
    x125      c214                 1   c215                -1
    x125      c216                 1   c217                -1
    x125      c218                 1   c219                -1
    x125      c220                 1   c221                -1
    x125      c222                 1   c223                -1
    x125      c224                 1   c225                -1
    x125      c226                 1   c227                -1
    x125      c228                 1   c229                -1
    x125      c230                 1   c231                -1
    x125      c232                 1   c233                -1
    x125      c234                 1   c235                -1
    x125      c236                 1   c237                -1
    x125      c238                 1   c239                -1
    x125      c240                 1   c241                -1
    x125      c242                 1   c243                -1
    x125      c244                 1   c245                -1
    x125      c246                 1   c247                -1
    x125      c248                 1   c249                -1
    x125      c250                 1   c251                -1
    x125      c252                 1   c253                -1
    x126      c212                -1   c213                 1
    x126      c1405                1   c3315               -1
    x127      c214                -1   c215                 1
    x127      c1359                1   c3308               -1
    x128      c216                -1   c217                 1
    x128      c2191                1   c3389               -1
    x129      c218                -1   c219                 1
    x129      c3081                1   c3082                1
    x129      c3083                1   c3390               -1
    x130      c220                -1   c221                 1
    x130      c2774                1   c2775                1
    x130      c2776                1   c3309               -1
    x131      c222                -1   c223                 1
    x131      c2757                1   c2760                1
    x131      c2763                1   c3304               -1
    x132      c224                -1   c225                 1
    x132      c3039                1   c3040                1
    x132      c3041                1   c3374               -1
    x133      c226                -1   c227                 1
    x133      c2600                1   c2601                1
    x133      c2602                1   c3247               -1
    x134      c228                -1   c229                 1
    x134      c2789                1   c2790                1
    x134      c2791                1   c3316               -1
    x135      c230                -1   c231                 1
    x135      c2103                1   c3373               -1
    x136      c232                -1   c233                 1
    x136      c2131                1   c3379               -1
    x137      c234                -1   c235                 1
    x137      c2125                1   c3377               -1
    x138      c236                -1   c237                 1
    x138      c2586                1   c2589                1
    x138      c2592                1   c3244               -1
    x139      c238                -1   c239                 1
    x139      c3065                1   c3066                1
    x139      c3067                1   c3385               -1
    x140      c240                -1   c241                 1
    x140      c1315                1   c3302               -1
    x141      c242                -1   c243                 1
    x141      c3025                1   c3368               -1
    x141      c3369               -1
    x142      c244                -1   c245                 1
    x142      c3027               -1   c3029                1
    x142      c3030                1
    x143      c248                -1   c249                 1
    x143      c302                 1   c3242               -1
    x144      c250                -1   c251                 1
    x144      c2152                1   c3384               -1
    x145      c252                -1   c253                 1
    x145      c362                 1   c3246               -1
    x146      c254                 1   c255                -1
    x146      c256                 1   c257                -1
    x146      c258                 1   c259                -1
    x146      c260                 1   c261                -1
    x146      c262                 1   c263                -1
    x146      c264                 1   c265                -1
    x146      c266                 1   c267                -1
    x146      c268                 1   c269                -1
    x146      c270                 1   c271                -1
    x146      c272                 1   c273                -1
    x146      c274                 1   c275                -1
    x146      c276                 1   c277                -1
    x146      c278                 1   c279                -1
    x146      c280                 1   c281                -1
    x146      c282                 1   c283                -1
    x146      c284                 1   c285                -1
    x146      c286                 1   c287                -1
    x146      c288                 1   c289                -1
    x146      c290                 1   c291                -1
    x146      c292                 1   c293                -1
    x146      c294                 1   c295                -1
    x146      c296                 1   c297                -1
    x146      c298                 1   c299                -1
    x147      c254                -1   c255                 1
    x147      c3075                1   c3076                1
    x147      c3077                1   c3390               -1
    x148      c256                -1   c257                 1
    x148      c3075                1   c3078                1
    x148      c3081                1   c3391               -1
    x149      c258                -1   c259                 1
    x149      c2768                1   c2769                1
    x149      c2770                1   c3309               -1
    x150      c260                -1   c261                 1
    x150      c2768                1   c2771                1
    x150      c2774                1   c3310               -1
    x151      c262                -1   c263                 1
    x151      c3033                1   c3034                1
    x151      c3035                1   c3374               -1
    x152      c264                -1   c265                 1
    x152      c3033                1   c3036                1
    x152      c3039                1   c3375               -1
    x153      c266                -1   c267                 1
    x153      c2594                1   c2595                1
    x153      c2596                1   c3247               -1
    x154      c268                -1   c269                 1
    x154      c2594                1   c2597                1
    x154      c2600                1   c3248               -1
    x155      c270                -1   c271                 1
    x155      c2783                1   c2784                1
    x155      c2785                1   c3316               -1
    x156      c272                -1   c273                 1
    x156      c2783                1   c2786                1
    x156      c2789                1   c3317               -1
    x157      c274                -1   c275                 1
    x157      c1310                1   c3301               -1
    x158      c276                -1   c277                 1
    x158      c2129                1   c3379               -1
    x159      c278                -1   c279                 1
    x159      c2126                1   c3378               -1
    x160      c280                -1   c281                 1
    x160      c3059                1   c3060                1
    x160      c3061                1   c3385               -1
    x161      c282                -1   c283                 1
    x161      c3059                1   c3062                1
    x161      c3065                1   c3386               -1
    x162      c284                -1   c285                 1
    x162      c1313                1   c3302               -1
    x163      c286                -1   c287                 1
    x163      c3025                1   c3370               -1
    x163      c3371               -1
    x164      c288                -1   c289                 1
    x164      c3026                1   c3369               -1
    x164      c3371               -1
    x165      c290                -1   c291                 1
    x165      c3027               -1   c3031                1
    x165      c3032                1
    x166      c292                -1   c293                 1
    x166      c3028               -1   c3030                1
    x166      c3032                1
    x167      c296                -1   c297                 1
    x167      c300                 1   c3242               -1
    x168      c298                -1   c299                 1
    x168      c339                 1   c340                -1
    x169      c301                 1   c3242               -1
    x170      c303                 1   c304                -1
    x170      c305                 1   c306                -1
    x170      c307                 1   c308                -1
    x170      c309                 1   c310                -1
    x170      c311                 1   c312                -1
    x170      c313                 1   c314                -1
    x170      c315                 1   c316                -1
    x170      c317                 1   c318                -1
    x170      c319                 1   c320                -1
    x170      c321                 1   c322                -1
    x170      c323                 1   c324                -1
    x170      c325                 1   c326                -1
    x170      c327                 1   c328                -1
    x170      c329                 1   c330                -1
    x170      c331                 1   c332                -1
    x170      c333                 1   c334                -1
    x170      c335                 1   c336                -1
    x170      c337                 1   c338                -1
    x170      c339                 1   c340                -1
    x171      c303                -1   c304                 1
    x171      c1403                1   c3315               -1
    x172      c305                -1   c306                 1
    x172      c1357                1   c3308               -1
    x173      c307                -1   c308                 1
    x173      c1360                1   c3311               -1
    x174      c309                -1   c310                 1
    x174      c2189                1   c3389               -1
    x175      c311                -1   c312                 1
    x175      c2755                1   c2756                1
    x175      c2757                1   c3303               -1
    x176      c313                -1   c314                 1
    x176      c2755                1   c2758                1
    x176      c2761                1   c3304               -1
    x177      c315                -1   c316                 1
    x177      c1406                1   c3318               -1
    x178      c317                -1   c318                 1
    x178      c2192                1   c3392               -1
    x179      c319                -1   c320                 1
    x179      c2101                1   c3373               -1
    x180      c321                -1   c322                 1
    x180      c2104                1   c3376               -1
    x181      c323                -1   c324                 1
    x181      c2132                1   c3380               -1
    x182      c325                -1   c326                 1
    x182      c2123                1   c3377               -1
    x183      c327                -1   c328                 1
    x183      c2584                1   c2585                1
    x183      c2586                1   c3243               -1
    x184      c329                -1   c330                 1
    x184      c2584                1   c2587                1
    x184      c2590                1   c3244               -1
    x185      c331                -1   c332                 1
    x185      c2153                1   c3387               -1
    x186      c333                -1   c334                 1
    x186      c2150                1   c3384               -1
    x187      c335                -1   c336                 1
    x187      c360                 1   c3246               -1
    x188      c337                -1   c338                 1
    x188      c363                 1   c3249               -1
    x189      c341                 1   c342                -1
    x189      c343                 1   c344                -1
    x189      c345                -1   c346                -1
    x189      c2593                1
    x190      c341                -1   c342                 1
    x190      c1290                1   c1291               -1
    x191      c345                -1   c2593                1
    x192      c346                -1   c347                 1
    x192      c348                -1   c2593                1
    x193      c347                 1   c348                -1
    x193      c353                -1   c354                 1
    x194      c349                 1   c350                -1
    x194      c351                 1   c352                -1
    x194      c353                 1   c354                -1
    x194      c355                 1   c356                -1
    x194      c357                 1   c358                 1
    x194      c359                 1   c3245               -1
    x195      c349                -1   c350                 1
    x195      c2177                1   c2179               -1
    x195      c3072               -1   c3073                1
    x196      c351                -1   c352                 1
    x197      c355                -1   c356                 1
    x198      c357                 1   c363                 1
    x198      c364                 1   c365                 1
    x198      c3245               -1   c3249               -1
    x199      c358                 1   c2594                1
    x199      c2595                1   c2596                1
    x199      c2597                1   c2598                1
    x199      c2599                1   c2600                1
    x199      c2601                1   c2602                1
    x199      c3245               -1   c3247               -1
    x199      c3248               -1
    x200      c359                 1   c360                 1
    x200      c361                 1   c362                 1
    x200      c3245               -1   c3246               -1
    x201      c361                 1   c3246               -1
    x202      c364                 1   c3249               -1
    x203      c366                 1   c367                -1
    x203      c368                 1   c369                -1
    x204      c366                -1   c367                 1
    x204      c1287                1   c3298               -1
    x205      c370                 1   c371                -1
    x205      c372                 1   c373                -1
    x205      c374                 1   c375                -1
    x205      c376                 1   c377                -1
    x205      c378                 1   c379                -1
    x205      c380                 1   c381                 1
    x205      c382                 1   c3250               -1
    x206      c370                -1   c371                 1
    x207      c374                -1   c375                 1
    x207      c1568                1   c1569               -1
    x208      c376                -1   c377                 1
    x208      c2357               -1   c2359                1
    x208      c3166                1   c3167               -1
    x209      c378                -1   c379                 1
    x210      c380                 1   c2603                1
    x210      c2604                1   c2605                1
    x210      c2606                1   c2607                1
    x210      c2608                1   c2609                1
    x210      c2610                1   c2611                1
    x210      c3250               -1   c3253               -1
    x210      c3254               -1
    x211      c381                 1   c512                 1
    x211      c513                 1   c514                 1
    x211      c3250               -1   c3252               -1
    x212      c382                 1   c383                 1
    x212      c384                 1   c385                 1
    x212      c3250               -1   c3251               -1
    x213      c383                 1   c500                -1
    x213      c501                 1   c3251               -1
    x214      c384                 1   c3251               -1
    x215      c385                 1   c412                -1
    x215      c413                 1   c3251               -1
    x216      c386                 1   c387                -1
    x216      c388                 1   c389                -1
    x216      c390                 1   c391                -1
    x216      c392                 1   c393                -1
    x216      c394                 1   c395                -1
    x216      c396                 1   c397                -1
    x216      c398                 1   c399                -1
    x216      c400                 1   c401                -1
    x216      c402                 1   c403                -1
    x216      c404                 1   c405                -1
    x216      c406                 1   c407                -1
    x216      c408                 1   c409                -1
    x216      c410                 1   c411                -1
    x216      c412                 1   c413                -1
    x216      c414                 1   c415                -1
    x216      c416                 1   c417                -1
    x216      c418                 1   c419                -1
    x216      c420                 1   c421                -1
    x216      c422                 1   c423                -1
    x216      c424                 1   c425                -1
    x216      c426                 1   c427                -1
    x217      c386                -1   c387                 1
    x217      c2734                1   c2737                1
    x217      c2740                1   c3293               -1
    x218      c388                -1   c389                 1
    x218      c2795                1   c2798                1
    x218      c2801                1   c3323               -1
    x219      c390                -1   c391                 1
    x219      c2635                1   c2638                1
    x219      c2641                1   c3267               -1
    x220      c392                -1   c393                 1
    x220      c2609                1   c2610                1
    x220      c2611                1   c3253               -1
    x221      c394                -1   c395                 1
    x221      c2721                1   c2724                1
    x221      c2727                1   c3288               -1
    x222      c396                -1   c397                 1
    x222      c2663                1   c2666                1
    x222      c2669                1   c3272               -1
    x223      c398                -1   c399                 1
    x223      c2617                1   c2618                1
    x223      c3260               -1
    x224      c400                -1   c401                 1
    x224      c2612               -1   c2613                1
    x224      c2615                1   c2617                1
    x225      c402                -1   c403                 1
    x225      c1112                1   c3289               -1
    x226      c404                -1   c405                 1
    x226      c2688                1   c2691                1
    x226      c2694                1   c3277               -1
    x227      c406                -1   c407                 1
    x227      c2701                1   c2702                1
    x227      c2703                1   c3283               -1
    x228      c408                -1   c409                 1
    x228      c1146                1   c3294               -1
    x229      c410                -1   c411                 1
    x229      c792                 1   c3268               -1
    x230      c414                -1   c415                 1
    x230      c979                 1   c3278               -1
    x231      c416                -1   c417                 1
    x231      c1018                1   c3281               -1
    x232      c418                -1   c419                 1
    x232      c895                 1   c3273               -1
    x233      c420                -1   c421                 1
    x233      c1444                1   c3324               -1
    x234      c422                -1   c423                 1
    x234      c2314                1   c3406               -1
    x235      c424                -1   c425                 1
    x235      c3140                1   c3143                1
    x235      c3146                1   c3405               -1
    x236      c426                 1   c427                -1
    x236      c456                -1   c457                 1
    x237      c428                 1   c429                -1
    x237      c430                 1   c431                -1
    x237      c432                 1   c433                -1
    x237      c434                 1   c435                -1
    x237      c436                 1   c437                -1
    x237      c438                 1   c439                -1
    x237      c440                 1   c441                -1
    x237      c442                 1   c443                -1
    x237      c444                 1   c445                -1
    x237      c446                 1   c447                -1
    x237      c448                 1   c449                -1
    x237      c450                 1   c451                -1
    x237      c452                 1   c453                -1
    x237      c454                 1   c455                -1
    x237      c456                 1   c457                -1
    x237      c458                 1   c459                -1
    x237      c460                 1   c461                -1
    x237      c462                 1   c463                -1
    x237      c464                 1   c465                -1
    x237      c466                 1   c467                -1
    x237      c468                 1   c469                -1
    x238      c428                -1   c429                 1
    x238      c620                 1   c3261               -1
    x239      c430                -1   c431                 1
    x239      c2738                1   c2739                1
    x239      c2740                1   c3292               -1
    x240      c432                -1   c433                 1
    x240      c2799                1   c2800                1
    x240      c2801                1   c3322               -1
    x241      c434                -1   c435                 1
    x241      c2639                1   c2640                1
    x241      c2641                1   c3266               -1
    x242      c436                -1   c437                 1
    x242      c2605                1   c2608                1
    x242      c2611                1   c3254               -1
    x243      c438                -1   c439                 1
    x243      c2725                1   c2726                1
    x243      c2727                1   c3287               -1
    x244      c440                -1   c441                 1
    x244      c2667                1   c2668                1
    x244      c2669                1   c3271               -1
    x245      c442                -1   c443                 1
    x245      c617                 1   c3259               -1
    x246      c444                -1   c445                 1
    x246      c1109                1   c3286               -1
    x247      c446                -1   c447                 1
    x247      c789                 1   c3265               -1
    x248      c448                -1   c449                 1
    x248      c2692                1   c2693                1
    x248      c2694                1   c3276               -1
    x249      c450                -1   c451                 1
    x249      c1021                1   c3282               -1
    x250      c452                -1   c453                 1
    x250      c2697                1   c2700                1
    x250      c2703                1   c3284               -1
    x251      c454                -1   c455                 1
    x251      c892                 1   c3270               -1
    x252      c458                -1   c459                 1
    x252      c1143                1   c3291               -1
    x253      c460                -1   c461                 1
    x253      c976                 1   c3275               -1
    x254      c462                -1   c463                 1
    x254      c1441                1   c3321               -1
    x255      c464                -1   c465                 1
    x255      c2311                1   c3403               -1
    x256      c466                -1   c467                 1
    x256      c3144                1   c3145                1
    x256      c3146                1   c3404               -1
    x257      c468                -1   c469                 1
    x257      c514                 1   c3252               -1
    x258      c470                 1   c471                -1
    x258      c472                 1   c473                -1
    x258      c474                 1   c475                -1
    x258      c476                 1   c477                -1
    x258      c478                 1   c479                -1
    x258      c480                 1   c481                -1
    x258      c482                 1   c483                -1
    x258      c484                 1   c485                -1
    x258      c486                 1   c487                -1
    x258      c488                 1   c489                -1
    x258      c490                 1   c491                -1
    x258      c492                 1   c493                -1
    x258      c494                 1   c495                -1
    x258      c496                 1   c497                -1
    x258      c498                 1   c499                -1
    x258      c500                 1   c501                -1
    x258      c502                 1   c503                -1
    x258      c504                 1   c505                -1
    x258      c506                 1   c507                -1
    x258      c508                 1   c509                -1
    x258      c510                 1   c511                -1
    x259      c470                -1   c471                 1
    x259      c618                 1   c3261               -1
    x260      c472                -1   c473                 1
    x260      c2732                1   c2733                1
    x260      c2734                1   c3292               -1
    x261      c474                -1   c475                 1
    x261      c2732                1   c2735                1
    x261      c2738                1   c3293               -1
    x262      c476                -1   c477                 1
    x262      c2793                1   c2794                1
    x262      c2795                1   c3322               -1
    x263      c478                -1   c479                 1
    x263      c2793                1   c2796                1
    x263      c2799                1   c3323               -1
    x264      c480                -1   c481                 1
    x264      c2633                1   c2634                1
    x264      c2635                1   c3266               -1
    x265      c482                -1   c483                 1
    x265      c2633                1   c2636                1
    x265      c2639                1   c3267               -1
    x266      c484                -1   c485                 1
    x266      c2719                1   c2720                1
    x266      c2721                1   c3287               -1
    x267      c486                -1   c487                 1
    x267      c2719                1   c2722                1
    x267      c2725                1   c3288               -1
    x268      c488                -1   c489                 1
    x268      c2661                1   c2662                1
    x268      c2663                1   c3271               -1
    x269      c490                -1   c491                 1
    x269      c2661                1   c2664                1
    x269      c2667                1   c3272               -1
    x270      c492                -1   c493                 1
    x270      c2612               -1   c2614                1
    x270      c2616                1   c2618                1
    x271      c494                -1   c495                 1
    x271      c2686                1   c2687                1
    x271      c2688                1   c3276               -1
    x272      c496                -1   c497                 1
    x272      c2686                1   c2689                1
    x272      c2692                1   c3277               -1
    x273      c498                -1   c499                 1
    x273      c1019                1   c3282               -1
    x274      c502                -1   c503                 1
    x274      c1016                1   c3281               -1
    x275      c504                -1   c505                 1
    x275      c3138                1   c3139                1
    x275      c3140                1   c3404               -1
    x276      c506                -1   c507                 1
    x276      c3138                1   c3141                1
    x276      c3144                1   c3405               -1
    x277      c508                -1   c509                 1
    x277      c512                 1   c3252               -1
    x278      c510                -1   c511                 1
    x278      c555                 1   c556                -1
    x279      c513                 1   c3252               -1
    x280      c515                 1   c516                -1
    x280      c517                 1   c518                -1
    x280      c519                 1   c520                -1
    x280      c521                 1   c522                -1
    x280      c523                 1   c524                -1
    x280      c525                 1   c526                -1
    x280      c527                 1   c528                -1
    x280      c529                 1   c530                -1
    x280      c531                 1   c532                -1
    x280      c533                 1   c534                -1
    x280      c535                 1   c536                -1
    x280      c537                 1   c538                -1
    x280      c539                 1   c540                -1
    x280      c541                 1   c542                -1
    x280      c543                 1   c544                -1
    x280      c545                 1   c546                -1
    x280      c547                 1   c548                -1
    x280      c549                 1   c550                -1
    x280      c551                 1   c552                -1
    x280      c553                 1   c554                -1
    x280      c555                 1   c556                -1
    x281      c515                -1   c516                 1
    x281      c2603                1   c2604                1
    x281      c2605                1   c3253               -1
    x282      c517                -1   c518                 1
    x282      c2603                1   c2606                1
    x282      c2609                1   c3254               -1
    x283      c519                -1   c520                 1
    x283      c615                 1   c3259               -1
    x284      c521                -1   c522                 1
    x284      c2613                1   c2614                1
    x284      c3260               -1
    x285      c523                -1   c524                 1
    x285      c1107                1   c3286               -1
    x286      c525                -1   c526                 1
    x286      c787                 1   c3265               -1
    x287      c527                -1   c528                 1
    x287      c1110                1   c3289               -1
    x288      c529                -1   c530                 1
    x288      c2695                1   c2696                1
    x288      c2697                1   c3283               -1
    x289      c531                -1   c532                 1
    x289      c2695                1   c2698                1
    x289      c2701                1   c3284               -1
    x290      c533                -1   c534                 1
    x290      c890                 1   c3270               -1
    x291      c535                -1   c536                 1
    x291      c1141                1   c3291               -1
    x292      c537                -1   c538                 1
    x292      c1144                1   c3294               -1
    x293      c539                -1   c540                 1
    x293      c790                 1   c3268               -1
    x294      c541                -1   c542                 1
    x294      c974                 1   c3275               -1
    x295      c543                -1   c544                 1
    x295      c977                 1   c3278               -1
    x296      c545                -1   c546                 1
    x296      c893                 1   c3273               -1
    x297      c547                -1   c548                 1
    x297      c1442                1   c3324               -1
    x298      c549                -1   c550                 1
    x298      c1439                1   c3321               -1
    x299      c551                -1   c552                 1
    x299      c2309                1   c3403               -1
    x300      c553                -1   c554                 1
    x300      c2312                1   c3406               -1
    x301      c557                 1   c558                -1
    x301      c559                 1   c560                -1
    x301      c561                 1   c562                -1
    x301      c563                 1   c564                -1
    x301      c565                 1   c566                -1
    x301      c567                 1   c568                -1
    x301      c569                 1   c570                -1
    x301      c571                 1   c572                -1
    x302      c557                -1   c558                 1
    x302      c716                 1   c717                -1
    x303      c559                -1   c560                 1
    x303      c577                 1   c3255               -1
    x304      c563                -1   c564                 1
    x304      c841                 1   c2653               -1
    x304      c2654               -1
    x305      c565                -1   c566                 1
    x305      c1736                1   c2915               -1
    x305      c2916               -1
    x306      c567                -1   c568                 1
    x306      c1662                1   c2873               -1
    x306      c2874               -1
    x307      c569                -1   c570                 1
    x307      c599                 1   c3257               -1
    x308      c571                -1   c572                 1
    x308      c1653                1   c2868               -1
    x308      c2869               -1
    x309      c573                 1   c574                -1
    x309      c575                 1   c576                -1
    x309      c577                 1   c578                 1
    x309      c579                 1   c3255               -1
    x310      c573                -1   c574                 1
    x310      c2619                1   c2620               -1
    x310      c2621               -1   c2622                1
    x311      c578                 1   c580                 1
    x311      c581                -1   c3255               -1
    x312      c580                 1   c581                -1
    x312      c584                -1   c585                 1
    x313      c582                 1   c583                -1
    x313      c584                 1   c585                -1
    x313      c586                 1   c587                -1
    x313      c588                 1   c589                -1
    x314      c582                -1   c583                 1
    x314      c1577               -1   c3332                1
    x315      c586                -1   c587                 1
    x316      c588                -1   c589                 1
    x316      c3204                1   c3205               -1
    x316      c3206                1   c3207               -1
    x317      c590                -1   c718                -1
    x317      c719                 1   c3256                1
    x318      c591                -1   c621                 1
    x318      c622                -1   c3256                1
    x319      c592                -1   c593                 1
    x319      c594                -1   c3256                1
    x320      c593                 1   c594                -1
    x320      c595                -1   c596                 1
    x321      c595                 1   c596                -1
    x321      c597                 1   c598                -1
    x321      c599                 1   c600                 1
    x321      c601                 1   c3257               -1
    x322      c597                -1   c598                 1
    x322      c750                -1   c752                 1
    x322      c2629                1   c2630               -1
    x323      c600                 1   c610                -1
    x323      c611                 1   c3257               -1
    x324      c602                 1   c603                -1
    x324      c604                 1   c605                -1
    x324      c606                 1   c607                -1
    x324      c608                 1   c609                -1
    x324      c610                 1   c611                -1
    x324      c612                 1   c613                 1
    x324      c614                 1   c3258               -1
    x325      c602                -1   c603                 1
    x326      c604                -1   c605                 1
    x326      c1593                1   c1594               -1
    x327      c606                -1   c607                 1
    x328      c608                -1   c609                 1
    x328      c3169                1   c3170               -1
    x328      c3171               -1   c3172                1
    x329      c612                 1   c618                 1
    x329      c619                 1   c620                 1
    x329      c3258               -1   c3261               -1
    x330      c613                 1   c2612               -1
    x330      c2613                1   c2614                1
    x330      c2615                1   c2616                1
    x330      c2617                1   c2618                1
    x330      c3258               -1   c3260               -1
    x331      c614                 1   c615                 1
    x331      c616                 1   c617                 1
    x331      c3258               -1   c3259               -1
    x332      c616                 1   c3259               -1
    x333      c619                 1   c3261               -1
    x334      c621                 1   c622                -1
    x334      c623                -1   c624                 1
    x335      c623                 1   c624                -1
    x335      c625                 1   c626                -1
    x335      c627                -1   c628                -1
    x335      c629                -1   c3262                1
    x336      c625                -1   c626                 1
    x336      c751                 1   c753                -1
    x336      c2629               -1   c2630                1
    x337      c627                -1   c712                -1
    x337      c713                 1   c3262                1
    x338      c628                -1   c692                -1
    x338      c693                 1   c3262                1
    x339      c629                -1   c660                -1
    x339      c661                 1   c3262                1
    x340      c630                 1   c631                -1
    x340      c632                 1   c633                -1
    x340      c634                 1   c635                -1
    x340      c636                 1   c637                -1
    x340      c638                 1   c639                -1
    x340      c640                 1   c641                -1
    x340      c642                 1   c643                -1
    x340      c644                 1   c645                -1
    x340      c646                 1   c647                -1
    x340      c648                 1   c649                -1
    x340      c650                 1   c651                -1
    x340      c652                 1   c653                -1
    x340      c654                 1   c655                -1
    x340      c656                 1   c657                -1
    x340      c658                 1   c659                -1
    x340      c660                 1   c661                -1
    x340      c662                 1   c663                -1
    x340      c664                 1   c665                -1
    x340      c666                 1   c667                -1
    x340      c668                 1   c669                -1
    x340      c670                 1   c671                -1
    x340      c672                 1   c673                -1
    x340      c674                 1   c675                -1
    x340      c676                 1   c677                -1
    x340      c678                 1   c679                -1
    x340      c680                 1   c681                -1
    x340      c682                 1   c683                -1
    x340      c684                 1   c685                -1
    x340      c686                 1   c687                -1
    x340      c688                 1   c689                -1
    x341      c630                -1   c631                 1
    x341      c1419               -1   c3319                1
    x342      c632                -1   c633                 1
    x342      c1343               -1   c3306                1
    x343      c634                -1   c635                 1
    x343      c1833               -1   c3347                1
    x344      c636                -1   c637                 1
    x344      c1326               -1   c3305                1
    x345      c638                -1   c639                 1
    x345      c1389               -1   c3313                1
    x346      c640                -1   c641                 1
    x346      c1859               -1   c3352                1
    x347      c642                -1   c643                 1
    x347      c1382               -1   c3312                1
    x348      c644                -1   c645                 1
    x348      c1814               -1   c3346                1
    x349      c646                -1   c647                 1
    x349      c1603               -1   c3335                1
    x350      c648                -1   c649                 1
    x350      c1578               -1   c3332                1
    x351      c650                -1   c651                 1
    x351      c1563               -1   c3331                1
    x352      c652                -1   c653                 1
    x352      c2681               -1   c2683                1
    x352      c2685                1
    x353      c654                -1   c655                 1
    x353      c1731                1   c2913               -1
    x354      c656                -1   c657                 1
    x354      c936                 1   c2678               -1
    x355      c658                -1   c659                 1
    x355      c1588               -1   c3334                1
    x356      c662                -1   c663                 1
    x356      c872                 1   c2660               -1
    x357      c664                -1   c665                 1
    x357      c1748               -1   c2918                1
    x358      c666                -1   c667                 1
    x358      c1674               -1   c2876                1
    x359      c668                -1   c669                 1
    x359      c2642               -1   c2646                1
    x359      c2647                1
    x360      c670                -1   c671                 1
    x360      c2853               -1   c2857                1
    x360      c2858                1
    x361      c672                -1   c673                 1
    x361      c2705                1   c2707               -1
    x361      c2709               -1
    x362      c674                -1   c675                 1
    x362      c2880                1   c2882               -1
    x362      c2884               -1
    x363      c676                -1   c677                 1
    x363      c843                -1   c2655                1
    x364      c678                -1   c679                 1
    x364      c2713               -1   c2717                1
    x364      c2718                1
    x365      c680                -1   c681                 1
    x365      c2889               -1   c2893                1
    x365      c2894                1
    x366      c682                -1   c683                 1
    x366      c1655               -1   c2870                1
    x367      c684                -1   c685                 1
    x367      c1703                1   c2899               -1
    x368      c686                -1   c687                 1
    x368      c1148               -1   c2741                1
    x369      c690                 1   c691                -1
    x369      c692                 1   c693                -1
    x369      c694                 1   c695                -1
    x369      c696                 1   c697                -1
    x370      c690                -1   c691                 1
    x370      c1602               -1   c3335                1
    x371      c694                -1   c695                 1
    x371      c2410                1   c2412               -1
    x371      c3185               -1   c3186                1
    x372      c696                -1   c697                 1
    x373      c698                 1   c699                -1
    x373      c700                 1   c701                -1
    x373      c702                 1   c703                -1
    x373      c704                 1   c705                -1
    x373      c706                 1   c707                -1
    x373      c708                 1   c709                -1
    x373      c710                 1   c711                -1
    x373      c712                 1   c713                -1
    x373      c714                 1   c715                -1
    x373      c716                 1   c717                -1
    x374      c698                -1   c699                 1
    x374      c1601               -1   c3335                1
    x375      c700                -1   c701                 1
    x375      c1576               -1   c3332                1
    x376      c702                -1   c703                 1
    x376      c1561               -1   c3331                1
    x377      c704                -1   c705                 1
    x377      c918                -1   c2675                1
    x377      c2676                1
    x378      c706                -1   c707                 1
    x378      c1727               -1   c2910                1
    x378      c2911                1
    x379      c708                -1   c709                 1
    x379      c956                -1   c2679                1
    x380      c710                -1   c711                 1
    x380      c1586               -1   c3334                1
    x381      c714                -1   c715                 1
    x381      c870                -1   c2658                1
    x381      c2659                1
    x382      c718                 1   c719                -1
    x382      c720                 1   c721                -1
    x382      c722                 1   c723                -1
    x382      c724                 1   c725                -1
    x383      c720                -1   c721                 1
    x383      c1207               -1   c2750                1
    x384      c722                -1   c723                 1
    x384      c1200               -1   c2749                1
    x385      c724                 1   c725                -1
    x385      c726                -1   c727                 1
    x386      c726                 1   c727                -1
    x386      c728                 1   c729                -1
    x386      c730                 1   c731                -1
    x386      c2619                1   c2620                1
    x386      c2621               -1   c2622               -1
    x387      c728                -1   c729                 1
    x387      c1213                1   c3418               -1
    x388      c730                -1   c731                 1
    x388      c735                 1   c3415               -1
    x389      c732                -1   c733                 1
    x389      c734                 1   c735                 1
    x389      c736                 1   c2623                1
    x389      c2624                1   c2625                1
    x389      c3415               -1
    x390      c733                 1   c900                -1
    x390      c901                 1   c3415               -1
    x391      c734                 1   c829                -1
    x391      c830                 1   c3415               -1
    x392      c736                 1   c737                -1
    x392      c2626               -1   c2627                1
    x392      c2628                1   c3415               -1
    x393      c737                -1   c740                -1
    x393      c741                 1   c2627                1
    x393      c2628                1
    x394      c738                 1   c739                -1
    x394      c740                 1   c741                -1
    x394      c742                 1   c743                -1
    x395      c738                -1   c739                 1
    x395      c1208               -1   c2750                1
    x396      c742                 1   c743                -1
    x396      c746                -1   c747                 1
    x397      c744                 1   c745                -1
    x397      c746                 1   c747                -1
    x397      c748                 1   c749                -1
    x397      c754                 1   c755                 1
    x397      c2631               -1
    x398      c744                -1   c745                 1
    x398      c1193                1   c3416               -1
    x399      c748                -1   c749                 1
    x399      c1211                1   c3418               -1
    x400      c750                -1   c751                -1
    x400      c755                -1   c2629                1
    x400      c2631                1
    x401      c752                -1   c753                -1
    x401      c754                -1   c2630                1
    x401      c2631                1
    x402      c756                 1   c757                -1
    x402      c758                -1   c759                -1
    x402      c2632                1
    x403      c756                 1   c757                -1
    x403      c2626               -1   c2628                1
    x404      c758                -1   c793                -1
    x404      c794                 1   c2632                1
    x405      c759                -1   c760                -1
    x405      c761                 1   c2632                1
    x406      c760                 1   c761                -1
    x406      c762                 1   c763                -1
    x406      c764                 1   c765                -1
    x406      c766                 1   c767                -1
    x407      c762                -1   c763                 1
    x407      c825                 1   c2648               -1
    x408      c764                -1   c765                 1
    x409      c766                 1   c767                -1
    x409      c780                -1   c781                 1
    x410      c768                 1   c769                -1
    x410      c770                 1   c771                -1
    x410      c772                 1   c773                -1
    x410      c774                 1   c775                -1
    x410      c776                 1   c777                -1
    x410      c778                 1   c779                -1
    x410      c780                 1   c781                -1
    x410      c782                 1   c783                -1
    x410      c784                 1   c785                 1
    x410      c786                 1   c3264               -1
    x411      c768                -1   c769                 1
    x411      c1627               -1   c1629                1
    x411      c2850                1   c2851               -1
    x412      c770                -1   c771                 1
    x412      c1771               -1   c2921                1
    x413      c772                -1   c773                 1
    x414      c774                -1   c775                 1
    x414      c2345               -1   c2347                1
    x414      c3150                1   c3151               -1
    x415      c776                -1   c777                 1
    x416      c778                -1   c779                 1
    x416      c1210               -1   c2751                1
    x417      c782                -1   c783                 1
    x418      c784                 1   c790                 1
    x418      c791                 1   c792                 1
    x418      c3264               -1   c3268               -1
    x419      c785                 1   c2633                1
    x419      c2634                1   c2635                1
    x419      c2636                1   c2637                1
    x419      c2638                1   c2639                1
    x419      c2640                1   c2641                1
    x419      c3264               -1   c3266               -1
    x419      c3267               -1
    x420      c786                 1   c787                 1
    x420      c788                 1   c789                 1
    x420      c3264               -1   c3265               -1
    x421      c788                 1   c3265               -1
    x422      c791                 1   c3268               -1
    x423      c793                 1   c794                -1
    x423      c795                 1   c796                -1
    x423      c797                 1   c798                -1
    x423      c2642               -1   c2643               -1
    x423      c2644                1   c2645                1
    x423      c2646                1   c2647                1
    x424      c795                -1   c796                 1
    x424      c826                 1   c2648               -1
    x425      c797                -1   c798                 1
    x425      c1209               -1   c2751                1
    x426      c799                 1   c800                -1
    x426      c801                 1   c802                -1
    x426      c803                 1   c804                -1
    x427      c799                -1   c800                 1
    x427      c2643               -1   c2644                1
    x427      c2646                1
    x428      c801                -1   c802                 1
    x428      c2854               -1   c2855                1
    x428      c2857                1
    x429      c803                 1   c804                -1
    x429      c809                -1   c810                 1
    x430      c805                 1   c806                -1
    x430      c807                 1   c808                -1
    x430      c809                 1   c810                -1
    x431      c805                -1   c806                 1
    x431      c3181                1   c3182               -1
    x431      c3183                1   c3184               -1
    x432      c807                -1   c808                 1
    x433      c811                 1   c812                -1
    x433      c813                 1   c814                -1
    x433      c815                 1   c816                -1
    x434      c811                -1   c812                 1
    x434      c2642               -1   c2644                1
    x434      c2645                1
    x435      c813                -1   c814                 1
    x435      c2853               -1   c2855                1
    x435      c2856                1
    x436      c815                 1   c816                -1
    x436      c819                -1   c820                 1
    x437      c817                 1   c818                -1
    x437      c819                 1   c820                -1
    x437      c821                 1   c822                -1
    x437      c823                 1   c824                -1
    x438      c817                -1   c818                 1
    x439      c821                -1   c822                 1
    x439      c2246                1   c2248               -1
    x439      c3100               -1   c3101                1
    x440      c823                -1   c824                 1
    x441      c825                 1   c826                 1
    x441      c2626               -1   c2627                1
    x441      c2648               -1
    x442      c827                 1   c828                -1
    x442      c829                 1   c830                -1
    x442      c835                 1   c836                 1
    x442      c2651               -1
    x443      c827                -1   c828                 1
    x443      c1203                1   c3417               -1
    x444      c831                -1   c833                 1
    x444      c866                -1   c867                 1
    x444      c2649                1   c2650               -1
    x445      c831                -1   c832                -1
    x445      c836                -1   c2649                1
    x445      c2651                1
    x446      c832                 1   c834                -1
    x446      c839                -1   c840                 1
    x446      c2649               -1   c2650                1
    x447      c833                -1   c834                -1
    x447      c835                -1   c2650                1
    x447      c2651                1
    x448      c837                 1   c838                -1
    x448      c839                 1   c840                -1
    x448      c841                 1   c2652                1
    x448      c2653               -1   c2654               -1
    x449      c837                -1   c838                 1
    x449      c1201                1   c1202               -1
    x450      c842                -1   c848                -1
    x450      c849                 1   c2655                1
    x451      c842                -1   c843                -1
    x451      c2652                1   c2654               -1
    x451      c2655                1
    x452      c844                 1   c845                -1
    x452      c846                 1   c847                -1
    x452      c848                 1   c849                -1
    x452      c850                 1   c851                -1
    x453      c844                -1   c845                 1
    x454      c846                -1   c847                 1
    x454      c3181                1   c3182               -1
    x454      c3183               -1   c3184                1
    x455      c850                -1   c851                 1
    x455      c1654               -1   c2870                1
    x456      c852                -1   c854                -1
    x456      c855                 1   c2656                1
    x457      c852                -1   c853                -1
    x457      c2652                1   c2653               -1
    x457      c2656                1
    x458      c854                 1   c855                -1
    x458      c856                 1   c857                -1
    x458      c858                 1   c859                -1
    x458      c860                 1   c861                -1
    x458      c862                 1   c863                -1
    x458      c864                 1   c865                -1
    x459      c856                -1   c857                 1
    x459      c1656               -1   c2871                1
    x460      c858                -1   c859                 1
    x460      c3103                1   c3104               -1
    x460      c3105                1   c3106               -1
    x461      c860                -1   c861                 1
    x462      c862                -1   c863                 1
    x463      c864                -1   c865                 1
    x464      c866                 1   c867                -1
    x464      c868                 1   c869                -1
    x464      c870                -1   c2657               -1
    x464      c2658                1   c2659                1
    x465      c868                -1   c869                 1
    x465      c1197                1   c1198               -1
    x466      c871                 1   c877                -1
    x466      c878                 1   c2660               -1
    x467      c871                 1   c872                 1
    x467      c2657               -1   c2659                1
    x467      c2660               -1
    x468      c873                 1   c874                -1
    x468      c875                 1   c876                -1
    x468      c877                 1   c878                -1
    x468      c879                 1   c880                -1
    x468      c881                 1   c882                -1
    x468      c883                 1   c884                -1
    x468      c885                 1   c886                -1
    x468      c887                 1   c888                 1
    x468      c889                 1   c3269               -1
    x469      c873                -1   c874                 1
    x470      c875                -1   c876                 1
    x470      c896                 1   c2670               -1
    x471      c879                -1   c880                 1
    x471      c2346                1   c2348               -1
    x471      c3150               -1   c3151                1
    x472      c881                -1   c882                 1
    x473      c883                -1   c884                 1
    x474      c885                -1   c886                 1
    x474      c1671                1   c1672               -1
    x475      c887                 1   c893                 1
    x475      c894                 1   c895                 1
    x475      c3269               -1   c3273               -1
    x476      c888                 1   c2661                1
    x476      c2662                1   c2663                1
    x476      c2664                1   c2665                1
    x476      c2666                1   c2667                1
    x476      c2668                1   c2669                1
    x476      c3269               -1   c3271               -1
    x476      c3272               -1
    x477      c889                 1   c890                 1
    x477      c891                 1   c892                 1
    x477      c3269               -1   c3270               -1
    x478      c891                 1   c3270               -1
    x479      c894                 1   c3273               -1
    x480      c896                 1   c897                 1
    x480      c2657               -1   c2658                1
    x480      c2670               -1
    x481      c898                 1   c899                -1
    x481      c900                 1   c901                -1
    x481      c902                 1   c903                -1
    x482      c898                -1   c899                 1
    x482      c1206                1   c3417               -1
    x483      c902                 1   c903                -1
    x483      c906                -1   c907                 1
    x484      c904                 1   c905                -1
    x484      c906                 1   c907                -1
    x484      c912                 1   c913                 1
    x484      c2673               -1
    x485      c904                -1   c905                 1
    x485      c1199               -1   c2749                1
    x486      c908                -1   c910                 1
    x486      c951                -1   c952                 1
    x486      c2671                1   c2672               -1
    x487      c908                -1   c909                -1
    x487      c913                -1   c2671                1
    x487      c2673                1
    x488      c909                 1   c911                -1
    x488      c916                -1   c917                 1
    x488      c2671               -1   c2672                1
    x489      c910                -1   c911                -1
    x489      c912                -1   c2672                1
    x489      c2673                1
    x490      c914                 1   c915                -1
    x490      c916                 1   c917                -1
    x490      c918                -1   c2674               -1
    x490      c2675                1   c2676                1
    x491      c914                -1   c915                 1
    x491      c1212                1   c3418               -1
    x492      c919                 1   c921                -1
    x492      c922                 1   c2677               -1
    x493      c919                 1   c920                 1
    x493      c2674               -1   c2676                1
    x493      c2677               -1
    x494      c921                 1   c922                -1
    x494      c923                 1   c924                -1
    x494      c925                 1   c926                -1
    x494      c927                 1   c928                -1
    x495      c923                -1   c924                 1
    x495      c1728                1   c2912               -1
    x496      c925                -1   c926                 1
    x497      c927                 1   c928                -1
    x497      c931                -1   c932                 1
    x498      c929                 1   c930                -1
    x498      c931                 1   c932                -1
    x498      c933                 1   c934                -1
    x499      c929                -1   c930                 1
    x499      c2409               -1   c2411                1
    x499      c3185                1   c3186               -1
    x500      c933                -1   c934                 1
    x501      c935                 1   c939                -1
    x501      c940                 1   c2678               -1
    x502      c935                 1   c936                 1
    x502      c2674               -1   c2675                1
    x502      c2678               -1
    x503      c937                 1   c938                -1
    x503      c939                 1   c940                -1
    x503      c941                 1   c942                -1
    x504      c937                -1   c938                 1
    x504      c1730                1   c2913               -1
    x505      c941                 1   c942                -1
    x505      c943                -1   c944                 1
    x506      c943                 1   c944                -1
    x506      c945                 1   c946                -1
    x506      c947                 1   c948                -1
    x506      c949                 1   c950                -1
    x507      c945                -1   c946                 1
    x508      c947                -1   c948                 1
    x508      c3103                1   c3104               -1
    x508      c3105               -1   c3106                1
    x509      c949                -1   c950                 1
    x510      c951                 1   c952                -1
    x510      c953                 1   c954                -1
    x510      c955                -1   c956                -1
    x510      c2679                1
    x511      c953                -1   c954                 1
    x511      c1215                1   c1216               -1
    x512      c955                -1   c2679                1
    x512      c2680               -1   c2681               -1
    x512      c2682                1   c2683                1
    x512      c2684                1   c2685                1
    x513      c957                 1   c958                -1
    x513      c959                 1   c960                -1
    x513      c961                 1   c962                -1
    x513      c963                 1   c964                -1
    x513      c965                 1   c966                -1
    x513      c967                 1   c968                -1
    x513      c969                 1   c970                -1
    x513      c971                 1   c972                 1
    x513      c973                 1   c3274               -1
    x514      c957                -1   c958                 1
    x514      c2680               -1   c2682                1
    x514      c2683                1
    x515      c959                -1   c960                 1
    x515      c2681               -1   c2682                1
    x515      c2684                1
    x516      c961                -1   c962                 1
    x517      c963                -1   c964                 1
    x518      c965                -1   c966                 1
    x518      c1745                1   c1746               -1
    x519      c967                -1   c968                 1
    x519      c3169                1   c3170               -1
    x519      c3171                1   c3172               -1
    x520      c969                -1   c970                 1
    x521      c971                 1   c977                 1
    x521      c978                 1   c979                 1
    x521      c3274               -1   c3278               -1
    x522      c972                 1   c2686                1
    x522      c2687                1   c2688                1
    x522      c2689                1   c2690                1
    x522      c2691                1   c2692                1
    x522      c2693                1   c2694                1
    x522      c3274               -1   c3276               -1
    x522      c3277               -1
    x523      c973                 1   c974                 1
    x523      c975                 1   c976                 1
    x523      c3274               -1   c3275               -1
    x524      c975                 1   c3275               -1
    x525      c978                 1   c3278               -1
    x526      c980                 1   c1046               -1
    x526      c1047                1   c3279               -1
    x527      c980                 1   c981                 1
    x527      c982                 1   c2625                1
    x527      c3263               -1   c3279               -1
    x528      c981                 1   c1022               -1
    x528      c1023                1   c3279               -1
    x529      c982                 1   c987                -1
    x529      c988                 1   c3279               -1
    x530      c983                 1   c984                -1
    x530      c985                 1   c986                -1
    x530      c987                 1   c988                -1
    x530      c989                 1   c990                -1
    x531      c983                -1   c984                 1
    x532      c985                -1   c986                 1
    x532      c1713                1   c2904               -1
    x533      c989                 1   c990                -1
    x533      c1001               -1   c1002                1
    x534      c991                 1   c992                -1
    x534      c993                 1   c994                -1
    x534      c995                 1   c996                -1
    x534      c997                 1   c998                -1
    x534      c999                 1   c1000               -1
    x534      c1001                1   c1002               -1
    x534      c1003                1   c1004               -1
    x534      c1005                1   c1006               -1
    x534      c1007                1   c1008               -1
    x534      c1009                1   c1010               -1
    x534      c1011                1   c1012               -1
    x534      c1013                1   c1014                1
    x534      c1015                1   c3280               -1
    x535      c991                -1   c992                 1
    x536      c993                -1   c994                 1
    x537      c995                -1   c996                 1
    x538      c997                -1   c998                 1
    x538      c2327               -1   c2329                1
    x538      c3147                1   c3148               -1
    x539      c999                -1   c1000                1
    x540      c1003               -1   c1004                1
    x541      c1005               -1   c1006                1
    x541      c1678               -1   c3341                1
    x542      c1007               -1   c1008                1
    x542      c1712                1   c2903               -1
    x543      c1009               -1   c1010                1
    x543      c1176               -1   c2747                1
    x544      c1011               -1   c1012                1
    x544      c1175                1   c2746               -1
    x545      c1013                1   c2695                1
    x545      c2696                1   c2697                1
    x545      c2698                1   c2699                1
    x545      c2700                1   c2701                1
    x545      c2702                1   c2703                1
    x545      c3280               -1   c3283               -1
    x545      c3284               -1
    x546      c1014                1   c1019                1
    x546      c1020                1   c1021                1
    x546      c3280               -1   c3282               -1
    x547      c1015                1   c1016                1
    x547      c1017                1   c1018                1
    x547      c3280               -1   c3281               -1
    x548      c1017                1   c3281               -1
    x549      c1020                1   c3282               -1
    x550      c1022                1   c1023               -1
    x550      c1024                1   c1025               -1
    x550      c1026                1   c1027               -1
    x550      c2704                1   c2705                1
    x550      c2706               -1   c2707               -1
    x550      c2708               -1   c2709               -1
    x551      c1024               -1   c1025                1
    x551      c1177               -1   c2747                1
    x552      c1026               -1   c1027                1
    x552      c1174                1   c2746               -1
    x553      c1028                1   c1029               -1
    x553      c1030                1   c1031               -1
    x553      c1032                1   c1033               -1
    x553      c1034                1   c1035               -1
    x554      c1028               -1   c1029                1
    x555      c1030               -1   c1031                1
    x555      c2705                1   c2706               -1
    x555      c2708               -1
    x556      c1032               -1   c1033                1
    x556      c2880                1   c2881               -1
    x556      c2883               -1
    x557      c1034               -1   c1035                1
    x557      c2048                1   c2050               -1
    x557      c3008               -1   c3009                1
    x558      c1036                1   c1037               -1
    x558      c1038                1   c1039               -1
    x558      c1040                1   c1041               -1
    x558      c1042                1   c1043               -1
    x558      c1044                1   c1045               -1
    x559      c1036               -1   c1037                1
    x559      c1249                1   c1250               -1
    x560      c1038               -1   c1039                1
    x561      c1040               -1   c1041                1
    x561      c2704                1   c2706               -1
    x561      c2707               -1
    x562      c1042               -1   c1043                1
    x562      c2879                1   c2881               -1
    x562      c2882               -1
    x563      c1044               -1   c1045                1
    x563      c2228                1   c2230               -1
    x563      c3097               -1   c3098                1
    x564      c1046                1   c1047               -1
    x564      c1048                1   c1049               -1
    x564      c1054                1   c1055                1
    x564      c2712               -1
    x565      c1048               -1   c1049                1
    x565      c1171                1   c2744               -1
    x565      c2745               -1
    x566      c1050               -1   c1052                1
    x566      c1102               -1   c1103                1
    x566      c2710                1   c2711               -1
    x567      c1050               -1   c1051               -1
    x567      c1055               -1   c2710                1
    x567      c2712                1
    x568      c1051                1   c1053               -1
    x568      c1058               -1   c1059                1
    x568      c2710               -1   c2711                1
    x569      c1052               -1   c1053               -1
    x569      c1054               -1   c2711                1
    x569      c2712                1
    x570      c1056                1   c1057               -1
    x570      c1058                1   c1059               -1
    x570      c2713               -1   c2714               -1
    x570      c2715                1   c2716                1
    x570      c2717                1   c2718                1
    x571      c1056               -1   c1057                1
    x571      c1188                1   c1189               -1
    x572      c1060                1   c1061               -1
    x572      c1062                1   c1063               -1
    x572      c1064                1   c1065               -1
    x572      c1066                1   c1067               -1
    x573      c1060               -1   c1061                1
    x574      c1062               -1   c1063                1
    x574      c2714               -1   c2715                1
    x574      c2717                1
    x575      c1064               -1   c1065                1
    x575      c2890               -1   c2891                1
    x575      c2893                1
    x576      c1066                1   c1067               -1
    x576      c1070               -1   c1071                1
    x577      c1068                1   c1069               -1
    x577      c1070                1   c1071               -1
    x577      c1072                1   c1073               -1
    x578      c1068               -1   c1069                1
    x579      c1072               -1   c1073                1
    x579      c3177                1   c3178               -1
    x579      c3179               -1   c3180                1
    x580      c1074                1   c1075               -1
    x580      c1076                1   c1077               -1
    x580      c1078                1   c1079               -1
    x580      c1080                1   c1081               -1
    x581      c1074               -1   c1075                1
    x582      c1076               -1   c1077                1
    x582      c2713               -1   c2715                1
    x582      c2716                1
    x583      c1078               -1   c1079                1
    x583      c2889               -1   c2891                1
    x583      c2892                1
    x584      c1080                1   c1081               -1
    x584      c1086               -1   c1087                1
    x585      c1082                1   c1083               -1
    x585      c1084                1   c1085               -1
    x585      c1086                1   c1087               -1
    x585      c1088                1   c1089               -1
    x586      c1082               -1   c1083                1
    x587      c1084               -1   c1085                1
    x587      c2245               -1   c2247                1
    x587      c3100                1   c3101               -1
    x588      c1088               -1   c1089                1
    x589      c1090                1   c1091               -1
    x589      c1092                1   c1093               -1
    x589      c1094                1   c1095               -1
    x589      c1096                1   c1097               -1
    x589      c1098                1   c1099               -1
    x589      c1100                1   c1101               -1
    x589      c1102                1   c1103               -1
    x589      c1104                1   c1105                1
    x589      c1106                1   c3285               -1
    x590      c1090               -1   c1091                1
    x591      c1092               -1   c1093                1
    x592      c1094               -1   c1095                1
    x592      c2328                1   c2330               -1
    x592      c3147               -1   c3148                1
    x593      c1096               -1   c1097                1
    x593      c1186                1   c1187               -1
    x594      c1098               -1   c1099                1
    x595      c1100               -1   c1101                1
    x595      c2885                1   c2886               -1
    x595      c2887                1   c2888               -1
    x596      c1104                1   c1110                1
    x596      c1111                1   c1112                1
    x596      c3285               -1   c3289               -1
    x597      c1105                1   c2719                1
    x597      c2720                1   c2721                1
    x597      c2722                1   c2723                1
    x597      c2724                1   c2725                1
    x597      c2726                1   c2727                1
    x597      c3285               -1   c3287               -1
    x597      c3288               -1
    x598      c1106                1   c1107                1
    x598      c1108                1   c1109                1
    x598      c3285               -1   c3286               -1
    x599      c1108                1   c3286               -1
    x600      c1111                1   c3289               -1
    x601      c1113                1   c1114               -1
    x601      c1115               -1   c1116               -1
    x601      c2728                1
    x602      c1113                1   c1114               -1
    x602      c2624                1   c3263               -1
    x603      c1115               -1   c1171                1
    x603      c2728                1   c2743                1
    x603      c2744               -1   c2745               -1
    x604      c1116               -1   c1117                1
    x604      c2728                1   c2729                1
    x604      c2730               -1   c2731               -1
    x605      c1117                1   c1118               -1
    x605      c1119                1   c2730               -1
    x605      c2731               -1
    x606      c1118                1   c1119               -1
    x606      c1120                1   c1121               -1
    x606      c1122                1   c1123               -1
    x607      c1120               -1   c1121                1
    x608      c1122                1   c1123               -1
    x608      c1134               -1   c1135                1
    x609      c1124                1   c1125               -1
    x609      c1126                1   c1127               -1
    x609      c1128                1   c1129               -1
    x609      c1130                1   c1131               -1
    x609      c1132                1   c1133               -1
    x609      c1134                1   c1135               -1
    x609      c1136                1   c1137               -1
    x609      c1138                1   c1139                1
    x609      c1140                1   c3290               -1
    x610      c1124               -1   c1125                1
    x611      c1126               -1   c1127                1
    x611      c3134                1   c3135               -1
    x611      c3136               -1   c3137                1
    x612      c1128               -1   c1129                1
    x613      c1130               -1   c1131                1
    x614      c1132               -1   c1133                1
    x615      c1136               -1   c1137                1
    x615      c1697               -1   c2896                1
    x615      c2897                1
    x616      c1138                1   c1144                1
    x616      c1145                1   c1146                1
    x616      c3290               -1   c3294               -1
    x617      c1139                1   c2732                1
    x617      c2733                1   c2734                1
    x617      c2735                1   c2736                1
    x617      c2737                1   c2738                1
    x617      c2739                1   c2740                1
    x617      c3290               -1   c3292               -1
    x617      c3293               -1
    x618      c1140                1   c1141                1
    x618      c1142                1   c1143                1
    x618      c3290               -1   c3291               -1
    x619      c1142                1   c3291               -1
    x620      c1145                1   c3294               -1
    x621      c1147               -1   c1153               -1
    x621      c1154                1   c2741                1
    x622      c1147               -1   c1148               -1
    x622      c2729                1   c2731               -1
    x622      c2741                1
    x623      c1149                1   c1150               -1
    x623      c1151                1   c1152               -1
    x623      c1153                1   c1154               -1
    x623      c1155                1   c1156               -1
    x624      c1149               -1   c1150                1
    x624      c2047               -1   c2049                1
    x624      c3008                1   c3009               -1
    x625      c1151               -1   c1152                1
    x626      c1155               -1   c1156                1
    x626      c1700                1   c1701               -1
    x627      c1157               -1   c1169               -1
    x627      c1170                1   c2742                1
    x628      c1157               -1   c1158               -1
    x628      c2729                1   c2730               -1
    x628      c2742                1
    x629      c1159                1   c1160               -1
    x629      c1161                1   c1162               -1
    x629      c1163                1   c1164               -1
    x629      c1165                1   c1166               -1
    x629      c1167                1   c1168               -1
    x629      c1169                1   c1170               -1
    x630      c1159               -1   c1160                1
    x630      c1858               -1   c3352                1
    x631      c1161               -1   c1162                1
    x631      c1381               -1   c3312                1
    x632      c1163               -1   c1164                1
    x632      c2419                1   c2421               -1
    x632      c3201               -1   c3202                1
    x633      c1165               -1   c1166                1
    x633      c1708                1   c1709               -1
    x634      c1167               -1   c1168                1
    x635      c1172                1   c1173               -1
    x635      c1174                1   c1175                1
    x635      c2746               -1
    x636      c1172                1   c1173               -1
    x636      c2743                1   c2745               -1
    x637      c1176               -1   c1177               -1
    x637      c2743                1   c2744               -1
    x637      c2747                1
    x638      c1178                1   c1188                1
    x638      c1189               -1   c2748               -1
    x639      c1178                1   c1179                1
    x639      c2623                1   c2748               -1
    x639      c3263               -1
    x640      c1179                1   c1182               -1
    x640      c1183                1   c2748               -1
    x641      c1180                1   c1181               -1
    x641      c1182                1   c1183               -1
    x641      c1184                1   c1185               -1
    x641      c1186                1   c1187               -1
    x642      c1180               -1   c1181                1
    x643      c1184               -1   c1185                1
    x643      c2877               -1   c3339                1
    x643      c3340                1
    x644      c1190                1   c1211                1
    x644      c1212                1   c1213                1
    x644      c1214                1   c3295               -1
    x644      c3418               -1
    x645      c1191                1   c1203                1
    x645      c1204                1   c1205                1
    x645      c1206                1   c3295               -1
    x645      c3417               -1
    x646      c1192                1   c1193                1
    x646      c1194                1   c1195                1
    x646      c1196                1   c3295               -1
    x646      c3416               -1
    x647      c1194                1   c1201                1
    x647      c1202               -1   c3416               -1
    x648      c1195                1   c1199               -1
    x648      c1200               -1   c2749                1
    x648      c3416               -1
    x649      c1196                1   c1197                1
    x649      c1198               -1   c3416               -1
    x650      c1204                1   c1209               -1
    x650      c1210               -1   c2751                1
    x650      c3417               -1
    x651      c1205                1   c1207               -1
    x651      c1208               -1   c2750                1
    x651      c3417               -1
    x652      c1214                1   c1215                1
    x652      c1216               -1   c3418               -1
    x653      c1217                1   c1363               -1
    x653      c2777               -1   c2778                1
    x653      c2779                1   c3296               -1
    x654      c1217                1   c1218                1
    x654      c1219                1   c2580               -1
    x654      c2582                1   c3296               -1
    x655      c1218                1   c1318               -1
    x655      c1319                1   c3296               -1
    x656      c1219                1   c1222               -1
    x656      c1223                1   c3296               -1
    x657      c1220                1   c1221               -1
    x657      c1222                1   c1223               -1
    x657      c1224                1   c1225               -1
    x658      c1220               -1   c1221                1
    x658      c1498                1   c2803               -1
    x659      c1224                1   c1225               -1
    x659      c1226               -1   c1227                1
    x660      c1226                1   c1227               -1
    x660      c1228                1   c1229               -1
    x660      c1230                1   c1231               -1
    x660      c1236                1   c1237                1
    x660      c2754               -1
    x661      c1228               -1   c1229                1
    x661      c1484               -1   c3420                1
    x662      c1230               -1   c1231                1
    x662      c1488               -1   c3326                1
    x663      c1232               -1   c1234                1
    x663      c1292               -1   c1293                1
    x663      c2752                1   c2753               -1
    x664      c1232               -1   c1233               -1
    x664      c1237               -1   c2752                1
    x664      c2754                1
    x665      c1233                1   c1235               -1
    x665      c1240               -1   c1241                1
    x665      c2752               -1   c2753                1
    x666      c1234               -1   c1235               -1
    x666      c1236               -1   c2753                1
    x666      c2754                1
    x667      c1238                1   c1239               -1
    x667      c1240                1   c1241               -1
    x667      c1242                1   c1243                1
    x667      c1244                1   c3297               -1
    x668      c1238               -1   c1239                1
    x668      c1499               -1   c2804                1
    x669      c1242                1   c1255               -1
    x669      c1256                1   c3297               -1
    x670      c1243                1   c1245               -1
    x670      c1246                1   c3297               -1
    x671      c1245                1   c1246               -1
    x671      c1247                1   c1248               -1
    x671      c1249                1   c1250               -1
    x672      c1247               -1   c1248                1
    x672      c1806                1   c3345               -1
    x673      c1251                1   c1252               -1
    x673      c1253                1   c1254               -1
    x673      c1255                1   c1256               -1
    x673      c1257                1   c1258               -1
    x673      c1259                1   c1260               -1
    x673      c1261                1   c1262               -1
    x673      c1263                1   c1264               -1
    x673      c1265                1   c1266               -1
    x673      c1267                1   c1268               -1
    x674      c1251               -1   c1252                1
    x674      c1864                1   c3353               -1
    x675      c1253               -1   c1254                1
    x675      c1455                1   c3325               -1
    x676      c1257               -1   c1258                1
    x676      c1296                1   c3299               -1
    x677      c1259               -1   c1260                1
    x677      c1805                1   c3345               -1
    x678      c1261               -1   c1262                1
    x678      c1892                1   c3355               -1
    x679      c1263               -1   c1264                1
    x679      c1838                1   c3348               -1
    x680      c1265               -1   c1266                1
    x680      c1881                1   c3354               -1
    x681      c1267                1   c1268               -1
    x681      c1273               -1   c1274                1
    x682      c1269                1   c1270               -1
    x682      c1271                1   c1272               -1
    x682      c1273                1   c1274               -1
    x682      c1275                1   c1276               -1
    x682      c1277                1   c1278               -1
    x682      c1279                1   c1280               -1
    x682      c1281                1   c1282               -1
    x682      c1283                1   c1284               -1
    x682      c1285                1   c1286               -1
    x682      c1287                1   c1288                1
    x682      c1289                1   c3298               -1
    x683      c1269               -1   c1270                1
    x683      c1417               -1   c3319                1
    x684      c1271               -1   c1272                1
    x684      c1341               -1   c3306                1
    x685      c1275               -1   c1276                1
    x685      c1831               -1   c3347                1
    x686      c1277               -1   c1278                1
    x686      c1324               -1   c3305                1
    x687      c1279               -1   c1280                1
    x687      c1387               -1   c3313                1
    x688      c1281               -1   c1282                1
    x688      c1857               -1   c3352                1
    x689      c1283               -1   c1284                1
    x689      c1380               -1   c3312                1
    x690      c1285               -1   c1286                1
    x690      c1812               -1   c3346                1
    x691      c1288                1   c1290                1
    x691      c1291               -1   c3298               -1
    x692      c1292                1   c1293               -1
    x692      c1294                1   c1295               -1
    x692      c1296                1   c1297                1
    x692      c1298                1   c3299               -1
    x693      c1294               -1   c1295                1
    x693      c1501                1   c1502               -1
    x694      c1297                1   c1299               -1
    x694      c1300                1   c3299               -1
    x695      c1299                1   c1300               -1
    x695      c1301                1   c1302               -1
    x695      c1303                1   c1304               -1
    x695      c1305                1   c1306               -1
    x695      c1307                1   c1308                1
    x695      c1309                1   c3300               -1
    x696      c1301               -1   c1302                1
    x696      c1815                1   c1816               -1
    x697      c1303               -1   c1304                1
    x697      c3068                1   c3069               -1
    x697      c3070               -1   c3071                1
    x698      c1305               -1   c1306                1
    x699      c1307                1   c2755                1
    x699      c2756                1   c2757                1
    x699      c2758                1   c2759                1
    x699      c2760                1   c2761                1
    x699      c2762                1   c2763                1
    x699      c3300               -1   c3303               -1
    x699      c3304               -1
    x700      c1308                1   c1313                1
    x700      c1314                1   c1315                1
    x700      c3300               -1   c3302               -1
    x701      c1309                1   c1310                1
    x701      c1311                1   c1312                1
    x701      c3300               -1   c3301               -1
    x702      c1311                1   c3301               -1
    x703      c1314                1   c3302               -1
    x704      c1316                1   c1317               -1
    x704      c1318                1   c1319               -1
    x704      c2764                1   c2765                1
    x704      c2766               -1   c2767               -1
    x705      c1316               -1   c1317                1
    x705      c1497                1   c2803               -1
    x706      c1320                1   c1321               -1
    x706      c1322                1   c1323               -1
    x706      c1324               -1   c1325               -1
    x706      c1326               -1   c3305                1
    x707      c1320               -1   c1321                1
    x707      c2764                1   c2765               -1
    x707      c2766               -1   c2767                1
    x708      c1322               -1   c1323                1
    x708      c1486                1   c1487               -1
    x709      c1325               -1   c1329               -1
    x709      c1330                1   c3305                1
    x710      c1327                1   c1328               -1
    x710      c1329                1   c1330               -1
    x710      c1331                1   c1332               -1
    x710      c1333                1   c1334               -1
    x710      c1335                1   c1336               -1
    x711      c1327               -1   c1328                1
    x711      c1832               -1   c3347                1
    x712      c1331               -1   c1332                1
    x713      c1333               -1   c1334                1
    x714      c1335               -1   c1336                1
    x714      c2418               -1   c2420                1
    x714      c3201                1   c3202               -1
    x715      c1337                1   c1338               -1
    x715      c1339                1   c1340               -1
    x715      c1341               -1   c1342               -1
    x715      c1343               -1   c3306                1
    x716      c1337               -1   c1338                1
    x716      c2764                1   c2765               -1
    x716      c2766                1   c2767               -1
    x717      c1339               -1   c1340                1
    x717      c1485               -1   c3420                1
    x718      c1342               -1   c1344                1
    x718      c1345               -1   c3306                1
    x719      c1344                1   c1345               -1
    x719      c1346               -1   c1347                1
    x720      c1346                1   c1347               -1
    x720      c1348                1   c1349               -1
    x720      c1350                1   c1351               -1
    x720      c1352                1   c1353               -1
    x720      c1354                1   c1355                1
    x720      c1356                1   c3307               -1
    x721      c1348               -1   c1349                1
    x721      c1839                1   c3348               -1
    x722      c1350               -1   c1351                1
    x722      c3055                1   c3056               -1
    x722      c3057               -1   c3058                1
    x723      c1352               -1   c1353                1
    x724      c1354                1   c1360                1
    x724      c1361                1   c1362                1
    x724      c3307               -1   c3311               -1
    x725      c1355                1   c2768                1
    x725      c2769                1   c2770                1
    x725      c2771                1   c2772                1
    x725      c2773                1   c2774                1
    x725      c2775                1   c2776                1
    x725      c3307               -1   c3309               -1
    x725      c3310               -1
    x726      c1356                1   c1357                1
    x726      c1358                1   c1359                1
    x726      c3307               -1   c3308               -1
    x727      c1358                1   c3308               -1
    x728      c1361                1   c3311               -1
    x729      c1363               -1   c1366               -1
    x729      c1367                1   c2778                1
    x729      c2779                1
    x730      c1364                1   c1365               -1
    x730      c1366                1   c1367               -1
    x730      c1368                1   c1369               -1
    x730      c1374                1   c1375                1
    x730      c2782               -1
    x731      c1364               -1   c1365                1
    x731      c1482               -1   c3420                1
    x732      c1368               -1   c1369                1
    x732      c1493               -1   c3421                1
    x733      c1370               -1   c1372                1
    x733      c1385               -1   c1386                1
    x733      c2780                1   c2781               -1
    x734      c1370               -1   c1371               -1
    x734      c1375               -1   c2780                1
    x734      c2782                1
    x735      c1371                1   c1373               -1
    x735      c1378               -1   c1379                1
    x735      c2780               -1   c2781                1
    x736      c1372               -1   c1373               -1
    x736      c1374               -1   c2781                1
    x736      c2782                1
    x737      c1376                1   c1377               -1
    x737      c1378                1   c1379               -1
    x737      c1380               -1   c1381               -1
    x737      c1382               -1   c3312                1
    x738      c1376               -1   c1377                1
    x738      c1491                1   c1492               -1
    x739      c1383                1   c1384               -1
    x739      c1385                1   c1386               -1
    x739      c1387               -1   c1388               -1
    x739      c1389               -1   c3313                1
    x740      c1383               -1   c1384                1
    x740      c1490               -1   c3326                1
    x741      c1388               -1   c1390                1
    x741      c1391               -1   c3313                1
    x742      c1390                1   c1391               -1
    x742      c1394               -1   c1395                1
    x743      c1392                1   c1393               -1
    x743      c1394                1   c1395               -1
    x743      c1396                1   c1397               -1
    x743      c1398                1   c1399               -1
    x743      c1400                1   c1401                1
    x743      c1402                1   c3314               -1
    x744      c1392               -1   c1393                1
    x744      c1865                1   c3353               -1
    x745      c1396               -1   c1397                1
    x745      c3068                1   c3069               -1
    x745      c3070                1   c3071               -1
    x746      c1398               -1   c1399                1
    x747      c1400                1   c1406                1
    x747      c1407                1   c1408                1
    x747      c3314               -1   c3318               -1
    x748      c1401                1   c2783                1
    x748      c2784                1   c2785                1
    x748      c2786                1   c2787                1
    x748      c2788                1   c2789                1
    x748      c2790                1   c2791                1
    x748      c3314               -1   c3316               -1
    x748      c3317               -1
    x749      c1402                1   c1403                1
    x749      c1404                1   c1405                1
    x749      c3314               -1   c3315               -1
    x750      c1404                1   c3315               -1
    x751      c1407                1   c3318               -1
    x752      c1409                1   c1445               -1
    x752      c1446                1   c2792               -1
    x753      c1409                1   c1410                1
    x753      c2777               -1   c2779                1
    x753      c2792               -1
    x754      c1410                1   c1411               -1
    x754      c1412                1   c2792               -1
    x755      c1411                1   c1412               -1
    x755      c1413                1   c1414               -1
    x755      c1415                1   c1416               -1
    x755      c1417               -1   c1418               -1
    x755      c1419               -1   c3319                1
    x756      c1413               -1   c1414                1
    x756      c1494               -1   c3421                1
    x757      c1415               -1   c1416                1
    x757      c1472               -1   c2802                1
    x758      c1418               -1   c1420               -1
    x758      c1421                1   c3319                1
    x759      c1420                1   c1421               -1
    x759      c1422                1   c1423               -1
    x759      c1424                1   c1425               -1
    x760      c1422               -1   c1423                1
    x761      c1424                1   c1425               -1
    x761      c1428               -1   c1429                1
    x762      c1426                1   c1427               -1
    x762      c1428                1   c1429               -1
    x762      c1430                1   c1431               -1
    x762      c1432                1   c1433               -1
    x762      c1434                1   c1435               -1
    x762      c1436                1   c1437                1
    x762      c1438                1   c3320               -1
    x763      c1426               -1   c1427                1
    x763      c1882                1   c3354               -1
    x764      c1430               -1   c1431                1
    x765      c1432               -1   c1433                1
    x765      c2358                1   c2360               -1
    x765      c3166               -1   c3167                1
    x766      c1434               -1   c1435                1
    x767      c1436                1   c1442                1
    x767      c1443                1   c1444                1
    x767      c3320               -1   c3324               -1
    x768      c1437                1   c2793                1
    x768      c2794                1   c2795                1
    x768      c2796                1   c2797                1
    x768      c2798                1   c2799                1
    x768      c2800                1   c2801                1
    x768      c3320               -1   c3322               -1
    x768      c3323               -1
    x769      c1438                1   c1439                1
    x769      c1440                1   c1441                1
    x769      c3320               -1   c3321               -1
    x770      c1440                1   c3321               -1
    x771      c1443                1   c3324               -1
    x772      c1445                1   c1446               -1
    x772      c1447                1   c1448               -1
    x772      c1449                1   c1450               -1
    x773      c1447               -1   c1448                1
    x773      c1473               -1   c2802                1
    x774      c1449                1   c1450               -1
    x774      c1451               -1   c1452                1
    x775      c1451                1   c1452               -1
    x775      c1453                1   c1454               -1
    x775      c1455                1   c1456                1
    x775      c1457                1   c3325               -1
    x776      c1453               -1   c1454                1
    x776      c1496               -1   c3421                1
    x777      c1456                1   c1458               -1
    x777      c1459                1   c3325               -1
    x778      c1458                1   c1459               -1
    x778      c1460                1   c1461               -1
    x778      c1462                1   c1463               -1
    x779      c1460               -1   c1461                1
    x779      c1893                1   c3355               -1
    x780      c1462                1   c1463               -1
    x780      c1464               -1   c1465                1
    x781      c1464                1   c1465               -1
    x781      c1466                1   c1467               -1
    x781      c1468                1   c1469               -1
    x782      c1466               -1   c1467                1
    x783      c1468               -1   c1469                1
    x783      c3204                1   c3205               -1
    x783      c3206               -1   c3207                1
    x784      c1470                1   c1471               -1
    x784      c1472               -1   c1473               -1
    x784      c2802                1
    x785      c1470                1   c1471               -1
    x785      c2777               -1   c2778                1
    x786      c1474                1   c1475               -1
    x786      c1476                1   c1477               -1
    x786      c1478               -1   c1479               -1
    x786      c1480               -1   c1481               -1
    x786      c3419                1
    x787      c1474               -1   c1475                1
    x787      c1503                1   c1504               -1
    x788      c1476               -1   c1477                1
    x788      c2580               -1   c2581                1
    x789      c1478               -1   c1499               -1
    x789      c1500               -1   c2804                1
    x789      c3419                1
    x790      c1479               -1   c1493               -1
    x790      c1494               -1   c1495               -1
    x790      c1496               -1   c3419                1
    x790      c3421                1
    x791      c1480               -1   c1488               -1
    x791      c1489               -1   c1490               -1
    x791      c3326                1   c3419                1
    x792      c1481               -1   c1482               -1
    x792      c1483               -1   c1484               -1
    x792      c1485               -1   c3419                1
    x792      c3420                1
    x793      c1483               -1   c1486                1
    x793      c1487               -1   c3420                1
    x794      c1489               -1   c1491                1
    x794      c1492               -1   c3326                1
    x795      c1495               -1   c1497                1
    x795      c1498                1   c2803               -1
    x795      c3421                1
    x796      c1500               -1   c1501                1
    x796      c1502               -1   c2804                1
    x797      c1503                1   c1504               -1
    x797      c2577               -1   c2579                1
    x798      c1505                1   c1506               -1
    x798      c1507                1   c1508               -1
    x798      c1515               -1   c1516               -1
    x798      c2810                1   c2811                1
    x798      c2812               -1
    x799      c1505               -1   c1506                1
    x799      c2554                1   c2558               -1
    x799      c2559               -1   c2564               -1
    x799      c2566               -1   c2568               -1
    x799      c2808                1   c2809               -1
    x799      c3228                1   c3230                1
    x799      c3233               -1
    x800      c1507               -1   c1508                1
    x800      c2555                1   c2556               -1
    x800      c2558               -1   c2560               -1
    x800      c2562               -1   c2806                1
    x800      c2807               -1   c3230               -1
    x800      c3233                1   c3234                1
    x800      c3236                1   c3237                1
    x801      c1509                1   c1510                1
    x801      c1517                1   c2805               -1
    x801      c2811               -1   c2812               -1
    x802      c1511                1   c1512               -1
    x802      c1513                1   c1514               -1
    x802      c1519               -1   c1520               -1
    x802      c2811                1   c2812               -1
    x802      c2813                1
    x803      c1511               -1   c1512                1
    x803      c2563               -1   c2567               -1
    x803      c2568               -1   c2571                1
    x803      c2575               -1   c2576               -1
    x803      c2808                1   c2809               -1
    x803      c3229                1   c3231                1
    x803      c3232               -1
    x804      c1513               -1   c1514                1
    x804      c2561               -1   c2562               -1
    x804      c2572                1   c2573               -1
    x804      c2575               -1   c2806                1
    x804      c2807               -1   c3231               -1
    x804      c3232                1   c3234                1
    x804      c3235                1   c3237                1
    x805      c1515               -1   c1521               -1
    x805      c1522                1   c2810                1
    x805      c2818                1   c2819               -1
    x806      c1517               -1   c1518               -1
    x806      c1527               -1   c2818               -1
    x806      c2819               -1   c3327                1
    x807      c1519               -1   c1530               -1
    x807      c1531                1   c2813                1
    x807      c2818                1   c2819               -1
    x808      c1521                1   c1522               -1
    x808      c1523                1   c1524               -1
    x808      c1525                1   c1526               -1
    x808      c1536               -1   c2820               -1
    x808      c2821                1   c2822                1
    x808      c2830                1   c2831               -1
    x809      c1523               -1   c1524                1
    x809      c2554                1   c2556               -1
    x809      c2557               -1   c2563               -1
    x809      c2565               -1   c2567               -1
    x809      c2816                1   c2817               -1
    x809      c3228                1   c3230                1
    x809      c3236               -1
    x810      c1525               -1   c1526                1
    x810      c2509                1   c2510               -1
    x810      c2814                1   c2815               -1
    x811      c1527                1   c1528                1
    x811      c1529                1   c1537                1
    x811      c2830               -1   c2831               -1
    x811      c3327               -1
    x812      c1529               -1   c2511               -1
    x812      c2814               -1   c2815               -1
    x812      c3327                1
    x813      c1530                1   c1531               -1
    x813      c1532                1   c1533               -1
    x813      c1534                1   c1535               -1
    x813      c1540               -1   c2830                1
    x813      c2831               -1   c2832               -1
    x813      c2833                1   c2834                1
    x814      c1532               -1   c1533                1
    x814      c2564               -1   c2565               -1
    x814      c2566               -1   c2571                1
    x814      c2573               -1   c2574               -1
    x814      c2816                1   c2817               -1
    x814      c3229                1   c3231                1
    x814      c3235               -1
    x815      c1534               -1   c1535                1
    x815      c2512                1   c2513               -1
    x815      c2814                1   c2815               -1
    x816      c1536               -1   c1541               -1
    x816      c2821                1   c2822                1
    x816      c2823               -1   c2825               -1
    x816      c2826               -1   c2828               -1
    x816      c2835               -1   c2836                1
    x816      c2837                1   c2841                1
    x816      c2842               -1
    x817      c1537               -1   c1542                1
    x817      c2829               -1   c2841               -1
    x817      c2842               -1
    x818      c1538               -1   c2823               -1
    x818      c2824               -1   c2825               -1
    x819      c1538                1   c1549               -1
    x819      c1550                1   c2820               -1
    x819      c2821                1   c2827               -1
    x819      c2829               -1   c2832               -1
    x819      c2833                1
    x820      c1539               -1   c2826               -1
    x820      c2827               -1   c2828               -1
    x821      c1539                1   c1901               -1
    x821      c1902                1   c2820               -1
    x821      c2822                1   c2824               -1
    x821      c2829               -1   c2832               -1
    x821      c2834                1
    x822      c1540               -1   c1546               -1
    x822      c2824               -1   c2825               -1
    x822      c2827               -1   c2828               -1
    x822      c2833                1   c2834                1
    x822      c2841                1   c2842               -1
    x822      c2843               -1   c2844                1
    x822      c2845                1
    x823      c1541               -1   c1544               -1
    x823      c1545               -1   c1546               -1
    x823      c1547               -1   c1548                1
    x823      c2836                1   c2837                1
    x823      c2844                1   c2845                1
    x823      c3329               -1
    x824      c1542               -1   c1543               -1
    x824      c1544               -1   c1781                1
    x824      c2922               -1   c2923               -1
    x825      c1543                1   c1897                1
    x825      c1898               -1   c2835               -1
    x825      c2836                1   c2839               -1
    x825      c2843               -1   c2844                1
    x825      c3328               -1   c3329               -1
    x825      c3330               -1
    x826      c1545               -1   c2838               -1
    x826      c2839               -1   c2840               -1
    x827      c1547                1   c1548               -1
    x827      c1549                1   c1550               -1
    x827      c1551               -1   c1552               -1
    x827      c1553               -1   c1554               -1
    x827      c3422                1
    x828      c1551               -1   c1749                1
    x828      c1750                1   c1751                1
    x828      c3342               -1   c3422                1
    x829      c1552               -1   c1620               -1
    x829      c1621               -1   c1622               -1
    x829      c1623               -1   c3422                1
    x829      c3423                1
    x830      c1553               -1   c1579               -1
    x830      c1580               -1   c1581               -1
    x830      c3333                1   c3422                1
    x831      c1554               -1   c1555               -1
    x831      c1556               -1   c2846                1
    x831      c3422                1
    x832      c1555               -1   c1570                1
    x832      c1571               -1   c2846                1
    x833      c1556               -1   c1557               -1
    x833      c1558                1   c2846                1
    x834      c1557                1   c1558               -1
    x834      c1559                1   c1560               -1
    x834      c1561               -1   c1562               -1
    x834      c1563               -1   c3331                1
    x835      c1559               -1   c1560                1
    x835      c1614               -1   c1616                1
    x835      c2847                1   c2848               -1
    x836      c1562               -1   c1564               -1
    x836      c1565                1   c3331                1
    x837      c1564                1   c1565               -1
    x837      c1566                1   c1567               -1
    x837      c1568                1   c1569               -1
    x838      c1566               -1   c1567                1
    x839      c1570                1   c1571               -1
    x839      c1572               -1   c1573                1
    x840      c1572                1   c1573               -1
    x840      c1574                1   c1575               -1
    x840      c1576               -1   c1577               -1
    x840      c1578               -1   c3332                1
    x841      c1574               -1   c1575                1
    x841      c1615                1   c1617               -1
    x841      c2847               -1   c2848                1
    x842      c1579               -1   c1606               -1
    x842      c1607                1   c3333                1
    x843      c1580               -1   c1595                1
    x843      c1596               -1   c3333                1
    x844      c1581               -1   c1582               -1
    x844      c1583                1   c3333                1
    x845      c1582                1   c1583               -1
    x845      c1584                1   c1585               -1
    x845      c1586               -1   c1587               -1
    x845      c1588               -1   c3334                1
    x846      c1584               -1   c1585                1
    x846      c2859                1   c2860               -1
    x846      c2861                1   c2862               -1
    x847      c1587               -1   c1589               -1
    x847      c1590                1   c3334                1
    x848      c1589                1   c1590               -1
    x848      c1591                1   c1592               -1
    x848      c1593                1   c1594               -1
    x849      c1591               -1   c1592                1
    x850      c1595                1   c1596               -1
    x850      c1599               -1   c1600                1
    x851      c1597                1   c1598               -1
    x851      c1599                1   c1600               -1
    x851      c1601               -1   c1602               -1
    x851      c1603               -1   c3335                1
    x852      c1597               -1   c1598                1
    x852      c2859                1   c2860               -1
    x852      c2861               -1   c2862                1
    x853      c1604                1   c1605               -1
    x853      c1606                1   c1607               -1
    x853      c1608                1   c1609               -1
    x853      c1610                1   c1611               -1
    x853      c1612                1   c1613               -1
    x853      c1618                1   c1619                1
    x853      c2849               -1
    x854      c1604               -1   c1605                1
    x854      c1757               -1   c2919                1
    x855      c1608               -1   c1609                1
    x855      c1766               -1   c2920                1
    x856      c1610               -1   c1611                1
    x856      c1623               -1   c3423                1
    x857      c1612               -1   c1613                1
    x857      c1776                1   c1777               -1
    x858      c1614               -1   c1615               -1
    x858      c1619               -1   c2847                1
    x858      c2849                1
    x859      c1616               -1   c1617               -1
    x859      c1618               -1   c2848                1
    x859      c2849                1
    x860      c1620               -1   c1721               -1
    x860      c1722                1   c3423                1
    x861      c1621               -1   c1675               -1
    x861      c2877               -1   c2878               -1
    x861      c3337                1   c3338                1
    x861      c3339                1   c3340                1
    x861      c3423                1
    x862      c1622               -1   c1624                1
    x862      c1625                1   c1626                1
    x862      c3336               -1   c3423                1
    x863      c1624                1   c1645               -1
    x863      c1646                1   c3336               -1
    x864      c1625                1   c1639               -1
    x864      c1640                1   c3336               -1
    x865      c1626                1   c1631                1
    x865      c1632                1   c2852               -1
    x865      c3336               -1
    x866      c1627               -1   c1628               -1
    x866      c1632               -1   c2850                1
    x866      c2852                1
    x867      c1628                1   c1630               -1
    x867      c1633               -1   c1634                1
    x867      c2850               -1   c2851                1
    x868      c1629               -1   c1630               -1
    x868      c1631               -1   c2851                1
    x868      c2852                1
    x869      c1633                1   c1634               -1
    x869      c1635                1   c1636               -1
    x869      c2853               -1   c2854               -1
    x869      c2855                1   c2856                1
    x869      c2857                1   c2858                1
    x870      c1635               -1   c1636                1
    x870      c1770               -1   c2921                1
    x871      c1637                1   c1638               -1
    x871      c1639                1   c1640               -1
    x871      c1641                1   c1642               -1
    x871      c1643                1   c1644               -1
    x871      c2859                1   c2860                1
    x871      c2861               -1   c2862               -1
    x872      c1637               -1   c1638                1
    x872      c1772                1   c3426               -1
    x873      c1641               -1   c1642                1
    x873      c1768                1   c1769               -1
    x874      c1643               -1   c1644                1
    x874      c1752                1   c3424               -1
    x875      c1645                1   c1646               -1
    x875      c1647                1   c1648               -1
    x875      c2863                1   c2864                1
    x875      c2865               -1   c2866               -1
    x876      c1647               -1   c1648                1
    x876      c1760                1   c3425               -1
    x877      c1649                1   c1650               -1
    x877      c1651                1   c1652               -1
    x877      c1653                1   c2867                1
    x877      c2868               -1   c2869               -1
    x878      c1649               -1   c1650                1
    x878      c2863                1   c2864               -1
    x878      c2865               -1   c2866                1
    x879      c1651               -1   c1652                1
    x879      c1758                1   c1759               -1
    x880      c1654               -1   c1655               -1
    x880      c2867                1   c2869               -1
    x880      c2870                1
    x881      c1656               -1   c1657               -1
    x881      c2867                1   c2868               -1
    x881      c2871                1
    x882      c1658                1   c1659               -1
    x882      c1660                1   c1661               -1
    x882      c1662                1   c2872                1
    x882      c2873               -1   c2874               -1
    x883      c1658               -1   c1659                1
    x883      c2863                1   c2864               -1
    x883      c2865                1   c2866               -1
    x884      c1660               -1   c1661                1
    x884      c1755                1   c3424               -1
    x885      c1663               -1   c1665               -1
    x885      c1666                1   c2875                1
    x886      c1663               -1   c1664               -1
    x886      c2872                1   c2874               -1
    x886      c2875                1
    x887      c1665                1   c1666               -1
    x887      c1667                1   c1668               -1
    x887      c1669                1   c1670               -1
    x887      c1671                1   c1672               -1
    x888      c1667               -1   c1668                1
    x888      c1673               -1   c2876                1
    x889      c1669               -1   c1670                1
    x890      c1673               -1   c1674               -1
    x890      c2872                1   c2873               -1
    x890      c2876                1
    x891      c1675               -1   c1676               -1
    x891      c1677               -1   c1678               -1
    x891      c3337                1   c3338                1
    x891      c3339                1   c3340                1
    x891      c3341                1
    x892      c1676               -1   c1689               -1
    x892      c1690                1   c3341                1
    x893      c1677               -1   c1679               -1
    x893      c1680                1   c3341                1
    x894      c1679                1   c1680               -1
    x894      c1681                1   c1682               -1
    x894      c1683                1   c1684               -1
    x895      c1681               -1   c1682                1
    x895      c1714                1   c2904               -1
    x896      c1683                1   c1684               -1
    x896      c1687               -1   c1688                1
    x897      c1685                1   c1686               -1
    x897      c1687                1   c1688               -1
    x897      c2879                1   c2880                1
    x897      c2881               -1   c2882               -1
    x897      c2883               -1   c2884               -1
    x898      c1685               -1   c1686                1
    x898      c1711                1   c2903               -1
    x899      c1689                1   c1690               -1
    x899      c1691                1   c1692               -1
    x899      c2885                1   c2886                1
    x899      c2887               -1   c2888               -1
    x900      c1691               -1   c1692                1
    x900      c1710               -1   c2901                1
    x900      c2902                1
    x901      c1693                1   c1694               -1
    x901      c1695                1   c1696               -1
    x901      c2889               -1   c2890               -1
    x901      c2891                1   c2892                1
    x901      c2893                1   c2894                1
    x902      c1693               -1   c1694                1
    x902      c1715                1   c1716               -1
    x903      c1695               -1   c1696                1
    x903      c2885                1   c2886               -1
    x903      c2887               -1   c2888                1
    x904      c1697               -1   c2878               -1
    x904      c2895               -1   c2896                1
    x904      c2897                1   c3338                1
    x904      c3340                1
    x905      c1698                1   c1700                1
    x905      c1701               -1   c2898               -1
    x906      c1698                1   c1699                1
    x906      c2895               -1   c2897                1
    x906      c2898               -1
    x907      c1702                1   c1704               -1
    x907      c1705                1   c2899               -1
    x908      c1702                1   c1703                1
    x908      c2895               -1   c2896                1
    x908      c2899               -1
    x909      c1704                1   c1705               -1
    x909      c1706                1   c1707               -1
    x909      c1708                1   c1709               -1
    x910      c1706               -1   c1707                1
    x911      c1710               -1   c2878               -1
    x911      c2900               -1   c2901                1
    x911      c2902                1   c3337                1
    x911      c3339                1
    x912      c1711                1   c1712                1
    x912      c2900               -1   c2902                1
    x912      c2903               -1
    x913      c1713                1   c1714                1
    x913      c2900               -1   c2901                1
    x913      c2904               -1
    x914      c1715                1   c1716               -1
    x914      c2877               -1   c3337                1
    x914      c3338                1
    x915      c1717                1   c1718               -1
    x915      c1719                1   c1720               -1
    x915      c1721                1   c1722               -1
    x915      c2905                1   c2906                1
    x915      c2907               -1   c2908               -1
    x916      c1717               -1   c1718                1
    x916      c1756               -1   c2919                1
    x917      c1719               -1   c1720                1
    x917      c1764                1   c1765               -1
    x918      c1723                1   c1724               -1
    x918      c1725                1   c1726               -1
    x918      c1727               -1   c2909               -1
    x918      c2910                1   c2911                1
    x919      c1723               -1   c1724                1
    x919      c1773                1   c3426               -1
    x920      c1725               -1   c1726                1
    x920      c2905                1   c2906               -1
    x920      c2907               -1   c2908                1
    x921      c1728                1   c1729                1
    x921      c2909               -1   c2911                1
    x921      c2912               -1
    x922      c1730                1   c1731                1
    x922      c2909               -1   c2910                1
    x922      c2913               -1
    x923      c1732                1   c1733               -1
    x923      c1734                1   c1735               -1
    x923      c1736                1   c2914                1
    x923      c2915               -1   c2916               -1
    x924      c1732               -1   c1733                1
    x924      c1775                1   c3426               -1
    x925      c1734               -1   c1735                1
    x925      c2905                1   c2906               -1
    x925      c2907                1   c2908               -1
    x926      c1737               -1   c1741               -1
    x926      c1742                1   c2917                1
    x927      c1737               -1   c1738               -1
    x927      c2914                1   c2916               -1
    x927      c2917                1
    x928      c1739                1   c1740               -1
    x928      c1741                1   c1742               -1
    x928      c1743                1   c1744               -1
    x928      c1745                1   c1746               -1
    x929      c1739               -1   c1740                1
    x929      c1747               -1   c2918                1
    x930      c1743               -1   c1744                1
    x931      c1747               -1   c1748               -1
    x931      c2914                1   c2915               -1
    x931      c2918                1
    x932      c1749                1   c1772                1
    x932      c1773                1   c1774                1
    x932      c1775                1   c3342               -1
    x932      c3426               -1
    x933      c1750                1   c1760                1
    x933      c1761                1   c1762                1
    x933      c1763                1   c3342               -1
    x933      c3425               -1
    x934      c1751                1   c1752                1
    x934      c1753                1   c1754                1
    x934      c1755                1   c3342               -1
    x934      c3424               -1
    x935      c1753                1   c1758                1
    x935      c1759               -1   c3424               -1
    x936      c1754                1   c1756               -1
    x936      c1757               -1   c2919                1
    x936      c3424               -1
    x937      c1761                1   c1770               -1
    x937      c1771               -1   c2921                1
    x937      c3425               -1
    x938      c1762                1   c1766               -1
    x938      c1767               -1   c2920                1
    x938      c3425               -1
    x939      c1763                1   c1764                1
    x939      c1765               -1   c3425               -1
    x940      c1767               -1   c1768                1
    x940      c1769               -1   c2920                1
    x941      c1774                1   c1776                1
    x941      c1777               -1   c3426               -1
    x942      c1778                1   c1841               -1
    x942      c2930               -1   c2931                1
    x942      c2932                1   c2936                1
    x942      c2937               -1   c3343               -1
    x943      c1778                1   c1779                1
    x943      c1780                1   c2835               -1
    x943      c2837                1   c2839                1
    x943      c2840                1   c2922                1
    x943      c2923               -1   c3328               -1
    x943      c3330               -1   c3343               -1
    x944      c1779                1   c1783                1
    x944      c1785                1   c1817               -1
    x944      c1818                1   c3343               -1
    x944      c3344               -1
    x945      c1780                1   c1782                1
    x945      c1786                1   c1789               -1
    x945      c1790                1   c3343               -1
    x945      c3344               -1
    x946      c1781               -1   c1782               -1
    x946      c1783               -1   c1842                1
    x946      c2936               -1   c2937               -1
    x947      c1784                1   c1846               -1
    x947      c2936                1   c2937               -1
    x947      c2938               -1   c2939                1
    x947      c2940                1   c3344               -1
    x948      c1784                1   c1785                1
    x948      c1786                1   c2838                1
    x948      c2840                1   c2843               -1
    x948      c2845                1   c2922                1
    x948      c2923               -1   c3329               -1
    x948      c3330               -1   c3344               -1
    x949      c1787                1   c1788               -1
    x949      c1789                1   c1790               -1
    x949      c1791                1   c1792               -1
    x949      c1793                1   c1794               -1
    x949      c1799                1   c1800                1
    x949      c2926               -1
    x950      c1787               -1   c1788                1
    x950      c1905                1   c3358               -1
    x951      c1791               -1   c1792                1
    x951      c1916                1   c1917               -1
    x952      c1793               -1   c1794                1
    x952      c1925                1   c2952               -1
    x953      c1795               -1   c1797                1
    x953      c1810               -1   c1811                1
    x953      c2924                1   c2925               -1
    x954      c1795               -1   c1796               -1
    x954      c1800               -1   c2924                1
    x954      c2926                1
    x955      c1796                1   c1798               -1
    x955      c1803               -1   c1804                1
    x955      c2924               -1   c2925                1
    x956      c1797               -1   c1798               -1
    x956      c1799               -1   c2925                1
    x956      c2926                1
    x957      c1801                1   c1802               -1
    x957      c1803                1   c1804               -1
    x957      c1805                1   c1806                1
    x957      c1807                1   c3345               -1
    x958      c1801               -1   c1802                1
    x958      c2950                1   c3356               -1
    x959      c1808                1   c1809               -1
    x959      c1810                1   c1811               -1
    x959      c1812               -1   c1813               -1
    x959      c1814               -1   c3346                1
    x960      c1808               -1   c1809                1
    x960      c2950                1   c3357               -1
    x961      c1813               -1   c1815                1
    x961      c1816               -1   c3346                1
    x962      c1817                1   c1818               -1
    x962      c1819                1   c1820               -1
    x962      c1825                1   c1826                1
    x962      c2929               -1
    x963      c1819               -1   c1820                1
    x963      c1924                1   c2952               -1
    x964      c1821               -1   c1823                1
    x964      c1836               -1   c1837                1
    x964      c2927                1   c2928               -1
    x965      c1821               -1   c1822               -1
    x965      c1826               -1   c2927                1
    x965      c2929                1
    x966      c1822                1   c1824               -1
    x966      c1827               -1   c1828                1
    x966      c2927               -1   c2928                1
    x967      c1823               -1   c1824               -1
    x967      c1825               -1   c2928                1
    x967      c2929                1
    x968      c1827                1   c1828               -1
    x968      c1829                1   c1830               -1
    x968      c1831               -1   c1832               -1
    x968      c1833               -1   c3347                1
    x969      c1829               -1   c1830                1
    x969      c1918                1   c1919               -1
    x970      c1834                1   c1835               -1
    x970      c1836                1   c1837               -1
    x970      c1838                1   c1839                1
    x970      c1840                1   c3348               -1
    x971      c1834               -1   c1835                1
    x971      c1914                1   c1915               -1
    x972      c1841               -1   c1844               -1
    x972      c1845               -1   c1846               -1
    x972      c1851               -1   c1852                1
    x972      c2931                1   c2932                1
    x972      c2939                1   c2940                1
    x972      c3350               -1
    x973      c1842               -1   c1843               -1
    x973      c1844               -1   c2946               -1
    x973      c2947               -1
    x974      c1843                1   c1895                1
    x974      c1896                1   c2930               -1
    x974      c2931                1   c2934               -1
    x974      c2938               -1   c2939                1
    x974      c2949               -1   c3349               -1
    x974      c3350               -1   c3351               -1
    x975      c1845               -1   c2933               -1
    x975      c2934               -1   c2935               -1
    x976      c1847                1   c1848               -1
    x976      c1849                1   c1850               -1
    x976      c1851                1   c1852               -1
    x976      c2941                1   c2942                1
    x976      c2943               -1   c2944               -1
    x977      c1847               -1   c1848                1
    x977      c1910               -1   c3427                1
    x978      c1849               -1   c1850                1
    x978      c1920               -1   c3428                1
    x979      c1853                1   c1854               -1
    x979      c1855                1   c1856               -1
    x979      c1857               -1   c1858               -1
    x979      c1859               -1   c3352                1
    x980      c1853               -1   c1854                1
    x980      c2941                1   c2942               -1
    x980      c2943               -1   c2944                1
    x981      c1855               -1   c1856                1
    x981      c1906                1   c3358               -1
    x982      c1860                1   c1861               -1
    x982      c1862                1   c1863               -1
    x982      c1864                1   c1865                1
    x982      c1866                1   c3353               -1
    x983      c1860               -1   c1861                1
    x983      c2941                1   c2942               -1
    x983      c2943                1   c2944               -1
    x984      c1862               -1   c1863                1
    x984      c1907                1   c3358               -1
    x985      c1867                1   c1868                1
    x985      c2930               -1   c2932                1
    x985      c2934                1   c2935                1
    x985      c2945               -1   c2946                1
    x985      c2947               -1   c3349               -1
    x985      c3351               -1
    x986      c1868                1   c1870                1
    x986      c1873               -1   c1874                1
    x986      c2945               -1   c2948               -1
    x987      c1869                1   c1870                1
    x987      c2933                1   c2935                1
    x987      c2938               -1   c2940                1
    x987      c2946                1   c2947               -1
    x987      c2948               -1   c3350               -1
    x987      c3351               -1
    x988      c1871               -1   c1872                1
    x988      c1921               -1   c3428                1
    x989      c1877                1   c1878               -1
    x989      c1879                1   c1880               -1
    x989      c1881                1   c1882                1
    x989      c1883                1   c3354               -1
    x990      c1879               -1   c1880                1
    x990      c1895                1   c2949               -1
    x991      c1886                1   c1887               -1
    x991      c1888                1   c1889               -1
    x991      c1890                1   c1891               -1
    x991      c1892                1   c1893                1
    x991      c1894                1   c3355               -1
    x992      c1886               -1   c1887                1
    x992      c1923               -1   c3428                1
    x993      c1890               -1   c1891                1
    x993      c1896                1   c2949               -1
    x994      c1897                1   c1898               -1
    x994      c1899               -1   c1900                1
    x995      c1899                1   c1900               -1
    x995      c1901                1   c1902               -1
    x995      c1903                1   c1904                1
    x995      c2950                1   c3356               -1
    x995      c3357               -1
    x996      c1903                1   c1908               -1
    x996      c1909               -1   c2951                1
    x996      c3356               -1   c3357               -1
    x997      c1904                1   c1905                1
    x997      c1906                1   c1907                1
    x997      c3356               -1   c3357               -1
    x997      c3358               -1
    x998      c1908               -1   c1920               -1
    x998      c1921               -1   c1922               -1
    x998      c1923               -1   c2951                1
    x998      c3428                1
    x999      c1909               -1   c1910               -1
    x999      c1911               -1   c1912               -1
    x999      c1913               -1   c2951                1
    x999      c3427                1
    x1000     c1911               -1   c1918                1
    x1000     c1919               -1   c3427                1
    x1001     c1912               -1   c1916                1
    x1001     c1917               -1   c3427                1
    x1002     c1913               -1   c1914                1
    x1002     c1915               -1   c3427                1
    x1003     c1922               -1   c1924                1
    x1003     c1925                1   c2952               -1
    x1003     c3428                1
    x1004     c1926                1   c1927               -1
    x1004     c2528                1   c2529               -1
    x1004     c2531               -1   c2533               -1
    x1004     c2535               -1   c2541               -1
    x1004     c2953                1   c2954               -1
    x1004     c3225                1
    x1005     c1929                1   c1930               -1
    x1005     c2532               -1   c2533               -1
    x1005     c2534               -1   c2540               -1
    x1005     c2545                1   c2546               -1
    x1005     c2953                1   c2954               -1
    x1005     c3226                1
    x1006     c1931               -1   c1933                1
    x1006     c1940                1   c1941               -1
    x1006     c2955                1   c2956               -1
    x1006     c2958                1   c2959               -1
    x1007     c1931               -1   c1932               -1
    x1007     c1936               -1   c2955                1
    x1007     c2957                1
    x1008     c1932                1   c1934               -1
    x1008     c1937                1   c1938               -1
    x1008     c2955               -1   c2956                1
    x1008     c2958                1   c2959               -1
    x1009     c1933               -1   c1934               -1
    x1009     c1935               -1   c2956                1
    x1009     c2957                1
    x1010     c1935                1   c1936                1
    x1010     c2516               -1   c2957               -1
    x1010     c3434                1
    x1011     c1937                1   c1938               -1
    x1011     c1942                1   c1943               -1
    x1011     c2960                1   c2961               -1
    x1012     c1939               -1   c1944                1
    x1012     c2960               -1   c2961               -1
    x1013     c1939                1   c2958               -1
    x1013     c2959               -1   c3224                1
    x1014     c1940                1   c1941               -1
    x1014     c1945                1   c1946               -1
    x1014     c2960                1   c2961               -1
    x1015     c1942                1   c1943               -1
    x1015     c1947               -1   c1948                1
    x1015     c2965                1   c2966               -1
    x1016     c1944               -1   c1951               -1
    x1016     c2962                1   c2965               -1
    x1016     c2966               -1
    x1017     c1945                1   c1946               -1
    x1017     c1953               -1   c1954                1
    x1017     c2965                1   c2966               -1
    x1018     c1947                1   c1948               -1
    x1018     c1949                1   c1950               -1
    x1018     c1957               -1   c1958               -1
    x1018     c2967                1   c2968                1
    x1018     c2969               -1
    x1019     c1949               -1   c1950                1
    x1019     c2498                1   c2499               -1
    x1019     c2963                1   c2964               -1
    x1020     c1951                1   c1952                1
    x1020     c1959                1   c2962               -1
    x1020     c2968               -1   c2969               -1
    x1021     c1952               -1   c2500               -1
    x1021     c2962                1   c2963               -1
    x1021     c2964               -1
    x1022     c1953                1   c1954               -1
    x1022     c1955                1   c1956               -1
    x1022     c1961               -1   c1962               -1
    x1022     c2968                1   c2969               -1
    x1022     c2970                1
    x1023     c1955               -1   c1956                1
    x1023     c2501                1   c2502               -1
    x1023     c2963                1   c2964               -1
    x1024     c1957               -1   c1960               -1
    x1024     c1961               -1   c2424               -1
    x1024     c2425                1   c2967                1
    x1024     c2970                1
    x1025     c1958               -1   c1963                1
    x1025     c1964                1   c1965                1
    x1025     c1966                1   c2967                1
    x1025     c2971                1   c2972               -1
    x1025     c3429               -1
    x1026     c1959               -1   c1960               -1
    x1026     c1967                1   c2971               -1
    x1026     c2972               -1
    x1027     c1962               -1   c1971                1
    x1027     c1972                1   c1973                1
    x1027     c1974                1   c2970                1
    x1027     c2971                1   c2972               -1
    x1027     c3430               -1
    x1028     c1963                1   c1970                1
    x1028     c1971                1   c2363               -1
    x1028     c2364                1   c3429               -1
    x1028     c3430               -1
    x1029     c1964                1   c1969                1
    x1029     c1972                1   c2053                1
    x1029     c2054               -1   c3429               -1
    x1029     c3430               -1
    x1030     c1965                1   c1968                1
    x1030     c1973                1   c1975               -1
    x1030     c1976                1   c3429               -1
    x1030     c3430               -1
    x1031     c1975                1   c1976               -1
    x1031     c1977                1   c1978               -1
    x1031     c1979                1   c1980                1
    x1031     c2973               -1
    x1032     c1977               -1   c1978                1
    x1033     c1979                1   c1985                1
    x1033     c1986                1   c2973               -1
    x1033     c2976               -1
    x1034     c1980                1   c2973               -1
    x1035     c1981               -1   c1983                1
    x1035     c2045                1   c2046                1
    x1035     c2974                1   c2975               -1
    x1035     c3007               -1
    x1036     c1981               -1   c1982               -1
    x1036     c1986               -1   c2974                1
    x1036     c2976                1
    x1037     c1982                1   c1984               -1
    x1037     c1987                1   c1988                1
    x1037     c2974               -1   c2975                1
    x1037     c2977               -1
    x1038     c1983               -1   c1984               -1
    x1038     c1985               -1   c2975                1
    x1038     c2976                1
    x1039     c1987                1   c2039                1
    x1039     c2040               -1   c2977               -1
    x1040     c1988                1   c2977               -1
    x1040     c2978                1   c2979                1
    x1040     c2980                1   c2981                1
    x1040     c2982                1   c2983                1
    x1040     c2984                1   c2985                1
    x1040     c2986                1   c3359               -1
    x1040     c3360               -1
    x1041     c1989                1   c1990               -1
    x1041     c1991                1   c1992               -1
    x1041     c1993                1   c1994               -1
    x1041     c1999                1   c2000                1
    x1041     c2989               -1
    x1042     c1989               -1   c1990                1
    x1042     c2031                1   c2032               -1
    x1043     c1991               -1   c1992                1
    x1043     c2998               -1   c3001               -1
    x1043     c3004               -1   c3362                1
    x1044     c1993               -1   c1994                1
    x1044     c2980                1   c2983                1
    x1044     c2986                1   c3360               -1
    x1045     c1995               -1   c1997                1
    x1045     c2987                1   c2988               -1
    x1046     c1995               -1   c1996               -1
    x1046     c2000               -1   c2987                1
    x1046     c2989                1
    x1047     c1996                1   c1998               -1
    x1047     c2987               -1   c2988                1
    x1048     c1997               -1   c1998               -1
    x1048     c1999               -1   c2988                1
    x1048     c2989                1
    x1049     c2001                1   c2002               -1
    x1049     c2003                1   c2004               -1
    x1049     c2005                1   c2006               -1
    x1049     c2007                1   c2008               -1
    x1049     c2013                1   c2014                1
    x1049     c2992               -1
    x1050     c2001               -1   c2002                1
    x1050     c3002               -1   c3003               -1
    x1050     c3004               -1   c3361                1
    x1051     c2003               -1   c2004                1
    x1051     c2997               -1   c3000               -1
    x1051     c3003               -1   c3362                1
    x1052     c2005               -1   c2006                1
    x1052     c2984                1   c2985                1
    x1052     c2986                1   c3359               -1
    x1053     c2007               -1   c2008                1
    x1053     c2979                1   c2982                1
    x1053     c2985                1   c3360               -1
    x1054     c2009               -1   c2011                1
    x1054     c2990                1   c2991               -1
    x1055     c2009               -1   c2010               -1
    x1055     c2014               -1   c2990                1
    x1055     c2992                1
    x1056     c2010                1   c2012               -1
    x1056     c2990               -1   c2991                1
    x1057     c2011               -1   c2012               -1
    x1057     c2013               -1   c2991                1
    x1057     c2992                1
    x1058     c2015                1   c2016               -1
    x1058     c2017                1   c2018               -1
    x1058     c2019                1   c2020               -1
    x1058     c2025                1   c2026                1
    x1058     c2995               -1
    x1059     c2015               -1   c2016                1
    x1059     c2037                1   c2038               -1
    x1060     c2017               -1   c2018                1
    x1060     c2996               -1   c2997               -1
    x1060     c2998               -1   c3361                1
    x1061     c2019               -1   c2020                1
    x1061     c2978                1   c2981                1
    x1061     c2984                1   c3360               -1
    x1062     c2021               -1   c2023                1
    x1062     c2993                1   c2994               -1
    x1063     c2021               -1   c2022               -1
    x1063     c2026               -1   c2993                1
    x1063     c2995                1
    x1064     c2022                1   c2024               -1
    x1064     c2993               -1   c2994                1
    x1065     c2023               -1   c2024               -1
    x1065     c2025               -1   c2994                1
    x1065     c2995                1
    x1066     c2027                1   c2028               -1
    x1066     c2029                1   c2030               -1
    x1066     c2031                1   c2032               -1
    x1067     c2027               -1   c2028                1
    x1067     c2999               -1   c3000               -1
    x1067     c3001               -1   c3361                1
    x1068     c2029               -1   c2030                1
    x1068     c2981                1   c2982                1
    x1068     c2983                1   c3359               -1
    x1069     c2033                1   c2034               -1
    x1069     c2035                1   c2036               -1
    x1069     c2037                1   c2038               -1
    x1070     c2033               -1   c2034                1
    x1070     c2996               -1   c2999               -1
    x1070     c3002               -1   c3362                1
    x1071     c2035               -1   c2036                1
    x1071     c2978                1   c2979                1
    x1071     c2980                1   c3359               -1
    x1072     c2039                1   c2040               -1
    x1072     c2996               -1   c2997               -1
    x1072     c2998               -1   c2999               -1
    x1072     c3000               -1   c3001               -1
    x1072     c3002               -1   c3003               -1
    x1072     c3004               -1   c3361                1
    x1072     c3362                1
    x1073     c2041               -1   c2043                1
    x1073     c3005                1   c3006               -1
    x1073     c3011                1   c3012                1
    x1073     c3013               -1   c3014               -1
    x1074     c2041               -1   c2042               -1
    x1074     c2046               -1   c3005                1
    x1074     c3007                1
    x1075     c2042                1   c2044               -1
    x1075     c2051                1   c2052                1
    x1075     c3005               -1   c3006                1
    x1075     c3010               -1
    x1076     c2043               -1   c2044               -1
    x1076     c2045               -1   c3006                1
    x1076     c3007                1
    x1077     c2047               -1   c2048               -1
    x1077     c2052               -1   c3008                1
    x1077     c3010                1
    x1078     c2049               -1   c2050               -1
    x1078     c2051               -1   c3009                1
    x1078     c3010                1
    x1079     c2053                1   c2054               -1
    x1079     c2055                1   c2056                1
    x1079     c2057                1   c3363               -1
    x1080     c2055                1   c2278               -1
    x1080     c2279                1   c3363               -1
    x1081     c2056                1   c2207               -1
    x1081     c2208                1   c3363               -1
    x1082     c2057                1   c2060               -1
    x1082     c2061                1   c3363               -1
    x1083     c2058                1   c2059               -1
    x1083     c2060                1   c2061               -1
    x1083     c2062                1   c3015                1
    x1083     c3016                1   c3364               -1
    x1083     c3365               -1   c3366               -1
    x1083     c3367               -1
    x1084     c2058               -1   c2059                1
    x1085     c2062                1   c2063               -1
    x1085     c2064                1   c3364               -1
    x1085     c3365               -1   c3366               -1
    x1085     c3367               -1
    x1086     c2063                1   c2064               -1
    x1086     c2065                1   c2066               -1
    x1086     c2067                1   c2068                1
    x1086     c3017               -1
    x1087     c2065               -1   c2066                1
    x1087     c2281                1   c3120               -1
    x1088     c2067                1   c2069               -1
    x1088     c2070                1   c3017               -1
    x1089     c2068                1   c2071               -1
    x1089     c2072                1   c3017               -1
    x1090     c2069                1   c2070               -1
    x1090     c2071                1   c2072               -1
    x1091     c2073                1   c2074               -1
    x1091     c2077               -1   c2078                1
    x1092     c2073                1   c2074               -1
    x1092     c3016                1   c3365               -1
    x1092     c3367               -1
    x1093     c2075                1   c2076               -1
    x1093     c2077                1   c2078               -1
    x1093     c2083                1   c2084                1
    x1093     c3020               -1
    x1094     c2075               -1   c2076                1
    x1094     c3015                1   c3364               -1
    x1094     c3365               -1
    x1095     c2079               -1   c2081                1
    x1095     c2111                1   c2112                1
    x1095     c3018                1   c3019               -1
    x1095     c3044               -1
    x1096     c2079               -1   c2080               -1
    x1096     c2084               -1   c3018                1
    x1096     c3020                1
    x1097     c2080                1   c2082               -1
    x1097     c3018               -1   c3019                1
    x1097     c3021                1   c3022                1
    x1097     c3023               -1   c3024               -1
    x1098     c2081               -1   c2082               -1
    x1098     c2083               -1   c3019                1
    x1098     c3020                1
    x1099     c2085                1   c2086               -1
    x1099     c2087                1   c2088               -1
    x1099     c2089                1   c3025                1
    x1099     c3026                1   c3368               -1
    x1099     c3369               -1   c3370               -1
    x1099     c3371               -1
    x1100     c2085               -1   c2086                1
    x1101     c2087               -1   c2088                1
    x1101     c3021                1   c3022               -1
    x1101     c3023               -1   c3024                1
    x1102     c2089                1   c3027               -1
    x1102     c3028               -1   c3029                1
    x1102     c3030                1   c3031                1
    x1102     c3032                1   c3368               -1
    x1102     c3369               -1   c3370               -1
    x1102     c3371               -1
    x1103     c2090                1   c2091               -1
    x1103     c2092                1   c2093               -1
    x1103     c2094                1   c2095               -1
    x1103     c2096                1   c2097               -1
    x1103     c2098                1   c2099                1
    x1103     c2100                1   c3372               -1
    x1104     c2090               -1   c2091                1
    x1104     c3021                1   c3022               -1
    x1104     c3023                1   c3024               -1
    x1105     c2092               -1   c2093                1
    x1106     c2094               -1   c2095                1
    x1107     c2096               -1   c2097                1
    x1108     c2098                1   c2104                1
    x1108     c2105                1   c2106                1
    x1108     c3372               -1   c3376               -1
    x1109     c2099                1   c3033                1
    x1109     c3034                1   c3035                1
    x1109     c3036                1   c3037                1
    x1109     c3038                1   c3039                1
    x1109     c3040                1   c3041                1
    x1109     c3372               -1   c3374               -1
    x1109     c3375               -1
    x1110     c2100                1   c2101                1
    x1110     c2102                1   c2103                1
    x1110     c3372               -1   c3373               -1
    x1111     c2102                1   c3373               -1
    x1112     c2105                1   c3376               -1
    x1113     c2107               -1   c2108               -1
    x1113     c2112               -1   c3042                1
    x1113     c3044                1
    x1114     c2108                1   c2110               -1
    x1114     c2113               -1   c2114                1
    x1114     c3042               -1   c3043                1
    x1115     c2109               -1   c2110               -1
    x1115     c2111               -1   c3043                1
    x1115     c3044                1
    x1116     c2113                1   c2114               -1
    x1116     c2115                1   c2116               -1
    x1116     c2117                1   c2118               -1
    x1116     c2119                1   c2120                1
    x1116     c2121                1   c2122                1
    x1116     c3431               -1
    x1117     c2115               -1   c2116                1
    x1118     c2117               -1   c2118                1
    x1119     c2119                1   c2132                1
    x1119     c2133                1   c2134                1
    x1119     c3380               -1   c3431               -1
    x1120     c2120                1   c2129                1
    x1120     c2130                1   c2131                1
    x1120     c3379               -1   c3431               -1
    x1121     c2121                1   c2126                1
    x1121     c2127                1   c2128                1
    x1121     c3378               -1   c3431               -1
    x1122     c2122                1   c2123                1
    x1122     c2124                1   c2125                1
    x1122     c3377               -1   c3431               -1
    x1123     c2124                1   c3377               -1
    x1124     c2127                1   c3378               -1
    x1125     c2130                1   c3379               -1
    x1126     c2133                1   c3380               -1
    x1127     c2135                1   c2136               -1
    x1127     c2137                1   c2138               -1
    x1127     c2139               -1   c2140               -1
    x1127     c3045                1
    x1128     c2135               -1   c2136                1
    x1128     c2203                1   c2204               -1
    x1129     c2137               -1   c2138                1
    x1129     c3016                1   c3364               -1
    x1129     c3366               -1
    x1130     c2139               -1   c2201                1
    x1130     c2202               -1   c3045                1
    x1131     c2140               -1   c3045                1
    x1131     c3046               -1   c3047               -1
    x1131     c3048               -1   c3049               -1
    x1131     c3050               -1   c3051               -1
    x1131     c3052               -1   c3053               -1
    x1131     c3054               -1   c3381                1
    x1131     c3382                1
    x1132     c2141                1   c2142               -1
    x1132     c2143                1   c2144               -1
    x1132     c2145                1   c2146               -1
    x1132     c3055                1   c3056                1
    x1132     c3057               -1   c3058               -1
    x1133     c2141               -1   c2142                1
    x1133     c3086                1   c3089                1
    x1133     c3092                1   c3394               -1
    x1134     c2143               -1   c2144                1
    x1134     c3048               -1   c3051               -1
    x1134     c3054               -1   c3382                1
    x1135     c2145               -1   c2146                1
    x1135     c2199                1   c2200               -1
    x1136     c2147                1   c2153                1
    x1136     c2154                1   c2155                1
    x1136     c3383               -1   c3387               -1
    x1137     c2147                1   c2148                1
    x1137     c2149                1   c3055                1
    x1137     c3056               -1   c3057                1
    x1137     c3058               -1   c3383               -1
    x1138     c2148                1   c3059                1
    x1138     c3060                1   c3061                1
    x1138     c3062                1   c3063                1
    x1138     c3064                1   c3065                1
    x1138     c3066                1   c3067                1
    x1138     c3383               -1   c3385               -1
    x1138     c3386               -1
    x1139     c2149                1   c2150                1
    x1139     c2151                1   c2152                1
    x1139     c3383               -1   c3384               -1
    x1140     c2151                1   c3384               -1
    x1141     c2154                1   c3387               -1
    x1142     c2156                1   c2157               -1
    x1142     c2158                1   c2159               -1
    x1142     c2160                1   c2161               -1
    x1142     c2162                1   c2163               -1
    x1142     c3068                1   c3069                1
    x1142     c3070               -1   c3071               -1
    x1143     c2156               -1   c2157                1
    x1143     c3090                1   c3091                1
    x1143     c3092                1   c3393               -1
    x1144     c2158               -1   c2159                1
    x1144     c3085                1   c3088                1
    x1144     c3091                1   c3394               -1
    x1145     c2160               -1   c2161                1
    x1145     c3052               -1   c3053               -1
    x1145     c3054               -1   c3381                1
    x1146     c2162               -1   c2163                1
    x1146     c3047               -1   c3050               -1
    x1146     c3053               -1   c3382                1
    x1147     c2164                1   c2165               -1
    x1147     c2166                1   c2167               -1
    x1147     c2168                1   c2169               -1
    x1148     c2164               -1   c2165                1
    x1148     c3084                1   c3085                1
    x1148     c3086                1   c3393               -1
    x1149     c2166               -1   c2167                1
    x1149     c3046               -1   c3049               -1
    x1149     c3052               -1   c3382                1
    x1150     c2168                1   c2169               -1
    x1150     c2170               -1   c2171                1
    x1151     c2170                1   c2171               -1
    x1151     c2172                1   c2173               -1
    x1151     c2174                1   c2175               -1
    x1151     c2180                1   c2181                1
    x1151     c3074               -1
    x1152     c2172               -1   c2173                1
    x1152     c3084                1   c3087                1
    x1152     c3090                1   c3394               -1
    x1153     c2174               -1   c2175                1
    x1153     c3046               -1   c3047               -1
    x1153     c3048               -1   c3381                1
    x1154     c2176               -1   c2178                1
    x1154     c2184               -1   c2185                1
    x1154     c3072                1   c3073               -1
    x1155     c2176               -1   c2177               -1
    x1155     c2181               -1   c3072                1
    x1155     c3074                1
    x1156     c2178               -1   c2179               -1
    x1156     c2180               -1   c3073                1
    x1156     c3074                1
    x1157     c2182                1   c2183               -1
    x1157     c2184                1   c2185               -1
    x1157     c2186                1   c2187                1
    x1157     c2188                1   c3388               -1
    x1158     c2182               -1   c2183                1
    x1159     c2186                1   c2192                1
    x1159     c2193                1   c2194                1
    x1159     c3388               -1   c3392               -1
    x1160     c2187                1   c3075                1
    x1160     c3076                1   c3077                1
    x1160     c3078                1   c3079                1
    x1160     c3080                1   c3081                1
    x1160     c3082                1   c3083                1
    x1160     c3388               -1   c3390               -1
    x1160     c3391               -1
    x1161     c2188                1   c2189                1
    x1161     c2190                1   c2191                1
    x1161     c3388               -1   c3389               -1
    x1162     c2190                1   c3389               -1
    x1163     c2193                1   c3392               -1
    x1164     c2195                1   c2196               -1
    x1164     c2197                1   c2198               -1
    x1164     c2199                1   c2200               -1
    x1165     c2195               -1   c2196                1
    x1165     c3087                1   c3088                1
    x1165     c3089                1   c3393               -1
    x1166     c2197               -1   c2198                1
    x1166     c3049               -1   c3050               -1
    x1166     c3051               -1   c3381                1
    x1167     c2201                1   c2202               -1
    x1167     c3084                1   c3085                1
    x1167     c3086                1   c3087                1
    x1167     c3088                1   c3089                1
    x1167     c3090                1   c3091                1
    x1167     c3092                1   c3393               -1
    x1167     c3394               -1
    x1168     c2203                1   c2204               -1
    x1168     c3015                1   c3366               -1
    x1168     c3367               -1
    x1169     c2205                1   c2206               -1
    x1169     c2207                1   c2208               -1
    x1169     c3093                1   c3094                1
    x1169     c3095               -1   c3096               -1
    x1170     c2205               -1   c2206                1
    x1171     c2209                1   c2263                1
    x1171     c2264                1   c2265                1
    x1171     c3395               -1   c3399               -1
    x1172     c2209                1   c2210                1
    x1172     c2211                1   c3093                1
    x1172     c3094               -1   c3095               -1
    x1172     c3096                1   c3395               -1
    x1173     c2210                1   c3107                1
    x1173     c3108                1   c3109                1
    x1173     c3110                1   c3111                1
    x1173     c3112                1   c3113                1
    x1173     c3114                1   c3115                1
    x1173     c3395               -1   c3397               -1
    x1173     c3398               -1
    x1174     c2211                1   c2212                1
    x1174     c2213                1   c2214                1
    x1174     c3395               -1   c3396               -1
    x1175     c2212                1   c2253               -1
    x1175     c2254                1   c3396               -1
    x1176     c2213                1   c2233               -1
    x1176     c2234                1   c3396               -1
    x1177     c2214                1   c2217               -1
    x1177     c2218                1   c3396               -1
    x1178     c2215                1   c2216               -1
    x1178     c2217                1   c2218               -1
    x1178     c2219                1   c2220               -1
    x1179     c2215               -1   c2216                1
    x1179     c3110                1   c3111                1
    x1179     c3112                1   c3397               -1
    x1180     c2219                1   c2220               -1
    x1180     c2221               -1   c2222                1
    x1181     c2221                1   c2222               -1
    x1181     c2223                1   c2224               -1
    x1181     c2225                1   c2226               -1
    x1181     c2231                1   c2232                1
    x1181     c3099               -1
    x1182     c2223               -1   c2224                1
    x1182     c3109                1   c3112                1
    x1182     c3115                1   c3398               -1
    x1183     c2225               -1   c2226                1
    x1183     c2264                1   c3399               -1
    x1184     c2227               -1   c2229                1
    x1184     c3097                1   c3098               -1
    x1185     c2227               -1   c2228               -1
    x1185     c2232               -1   c3097                1
    x1185     c3099                1
    x1186     c2229               -1   c2230               -1
    x1186     c2231               -1   c3098                1
    x1186     c3099                1
    x1187     c2233                1   c2234               -1
    x1187     c2235                1   c2236               -1
    x1187     c2237                1   c2238               -1
    x1188     c2235               -1   c2236                1
    x1188     c2265                1   c3399               -1
    x1189     c2237                1   c2238               -1
    x1189     c2239               -1   c2240                1
    x1190     c2239                1   c2240               -1
    x1190     c2241                1   c2242               -1
    x1190     c2243                1   c2244               -1
    x1190     c2249                1   c2250                1
    x1190     c3102               -1
    x1191     c2241               -1   c2242                1
    x1191     c3113                1   c3114                1
    x1191     c3115                1   c3397               -1
    x1192     c2243               -1   c2244                1
    x1192     c3108                1   c3111                1
    x1192     c3114                1   c3398               -1
    x1193     c2245               -1   c2246               -1
    x1193     c2250               -1   c3100                1
    x1193     c3102                1
    x1194     c2247               -1   c2248               -1
    x1194     c2249               -1   c3101                1
    x1194     c3102                1
    x1195     c2251                1   c2252               -1
    x1195     c2253                1   c2254               -1
    x1195     c2255                1   c2256               -1
    x1196     c2251               -1   c2252                1
    x1196     c3107                1   c3110                1
    x1196     c3113                1   c3398               -1
    x1197     c2255                1   c2256               -1
    x1197     c2257               -1   c2258                1
    x1198     c2257                1   c2258               -1
    x1198     c2259                1   c2260               -1
    x1198     c2261                1   c2262               -1
    x1198     c3103                1   c3104                1
    x1198     c3105               -1   c3106               -1
    x1199     c2259               -1   c2260                1
    x1199     c3107                1   c3108                1
    x1199     c3109                1   c3397               -1
    x1200     c2261               -1   c2262                1
    x1200     c2263                1   c3399               -1
    x1201     c2266                1   c2267               -1
    x1201     c2268                1   c2269               -1
    x1201     c2270                1   c2271               -1
    x1202     c2266               -1   c2267                1
    x1203     c2268               -1   c2269                1
    x1204     c2270               -1   c2271                1
    x1204     c3116                1   c3117               -1
    x1204     c3118               -1   c3119                1
    x1205     c2272                1   c2273               -1
    x1205     c2274                1   c2275               -1
    x1206     c2272               -1   c2273                1
    x1207     c2274               -1   c2275                1
    x1207     c3116                1   c3117               -1
    x1207     c3118                1   c3119               -1
    x1208     c2276                1   c2277               -1
    x1208     c2278                1   c2279               -1
    x1208     c2280                1   c2281                1
    x1208     c3120               -1
    x1209     c2276               -1   c2277                1
    x1210     c2280                1   c2286                1
    x1210     c2287                1   c3120               -1
    x1210     c3123               -1
    x1211     c2282               -1   c2284                1
    x1211     c3121                1   c3122               -1
    x1211     c3162                1   c3163                1
    x1211     c3164               -1   c3165               -1
    x1212     c2282               -1   c2283               -1
    x1212     c2287               -1   c3121                1
    x1212     c3123                1
    x1213     c2283                1   c2285               -1
    x1213     c2288               -1   c2289               -1
    x1213     c3121               -1   c3122                1
    x1213     c3124                1
    x1214     c2284               -1   c2285               -1
    x1214     c2286               -1   c3122                1
    x1214     c3123                1
    x1215     c2288               -1   c3124                1
    x1215     c3153               -1   c3154               -1
    x1215     c3155               -1   c3156               -1
    x1215     c3157               -1   c3158               -1
    x1215     c3159               -1   c3160               -1
    x1215     c3161               -1   c3407                1
    x1215     c3408                1
    x1216     c2289               -1   c3124                1
    x1216     c3125               -1   c3126               -1
    x1216     c3127               -1   c3128               -1
    x1216     c3129               -1   c3130               -1
    x1216     c3131               -1   c3132               -1
    x1216     c3133               -1   c3400                1
    x1216     c3401                1
    x1217     c2290                1   c2291               -1
    x1217     c2292                1   c2293               -1
    x1217     c2294                1   c2295               -1
    x1217     c3134                1   c3135                1
    x1217     c3136               -1   c3137               -1
    x1218     c2290               -1   c2291                1
    x1218     c3127               -1   c3130               -1
    x1218     c3133               -1   c3401                1
    x1219     c2292               -1   c2293                1
    x1219     c2355                1   c2356               -1
    x1220     c2294               -1   c2295                1
    x1220     c3156               -1   c3157               -1
    x1220     c3158               -1   c3407                1
    x1221     c2296                1   c2297               -1
    x1221     c2298                1   c2299               -1
    x1221     c2300                1   c2301               -1
    x1221     c2302                1   c2303               -1
    x1221     c2304                1   c2305               -1
    x1221     c2306                1   c2307                1
    x1221     c2308                1   c3402               -1
    x1222     c2296               -1   c2297                1
    x1222     c3134                1   c3135               -1
    x1222     c3136                1   c3137               -1
    x1223     c2298               -1   c2299                1
    x1224     c2300               -1   c2301                1
    x1225     c2302               -1   c2303                1
    x1226     c2304               -1   c2305                1
    x1227     c2306                1   c2312                1
    x1227     c2313                1   c2314                1
    x1227     c3402               -1   c3406               -1
    x1228     c2307                1   c3138                1
    x1228     c3139                1   c3140                1
    x1228     c3141                1   c3142                1
    x1228     c3143                1   c3144                1
    x1228     c3145                1   c3146                1
    x1228     c3402               -1   c3404               -1
    x1228     c3405               -1
    x1229     c2308                1   c2309                1
    x1229     c2310                1   c2311                1
    x1229     c3402               -1   c3403               -1
    x1230     c2310                1   c3403               -1
    x1231     c2313                1   c3406               -1
    x1232     c2315                1   c2316               -1
    x1232     c2317                1   c2318               -1
    x1232     c2319                1   c2320               -1
    x1233     c2315               -1   c2316                1
    x1233     c3131               -1   c3132               -1
    x1233     c3133               -1   c3400                1
    x1234     c2317               -1   c2318                1
    x1234     c3126               -1   c3129               -1
    x1234     c3132               -1   c3401                1
    x1235     c2319                1   c2320               -1
    x1235     c2321               -1   c2322                1
    x1236     c2321                1   c2322               -1
    x1236     c2323                1   c2324               -1
    x1236     c2325                1   c2326               -1
    x1236     c2331                1   c2332                1
    x1236     c3149               -1
    x1237     c2323               -1   c2324                1
    x1237     c3159               -1   c3160               -1
    x1237     c3161               -1   c3407                1
    x1238     c2325               -1   c2326                1
    x1238     c3154               -1   c3157               -1
    x1238     c3160               -1   c3408                1
    x1239     c2327               -1   c2328               -1
    x1239     c2332               -1   c3147                1
    x1239     c3149                1
    x1240     c2329               -1   c2330               -1
    x1240     c2331               -1   c3148                1
    x1240     c3149                1
    x1241     c2333                1   c2334               -1
    x1241     c2335                1   c2336               -1
    x1241     c2337                1   c2338               -1
    x1242     c2333               -1   c2334                1
    x1242     c3125               -1   c3128               -1
    x1242     c3131               -1   c3401                1
    x1243     c2335               -1   c2336                1
    x1243     c3153               -1   c3156               -1
    x1243     c3159               -1   c3408                1
    x1244     c2337                1   c2338               -1
    x1244     c2341               -1   c2342                1
    x1245     c2339                1   c2340               -1
    x1245     c2341                1   c2342               -1
    x1245     c2343                1   c2344               -1
    x1245     c2349                1   c2350                1
    x1245     c3152               -1
    x1246     c2339               -1   c2340                1
    x1246     c3125               -1   c3126               -1
    x1246     c3127               -1   c3400                1
    x1247     c2343               -1   c2344                1
    x1247     c3153               -1   c3154               -1
    x1247     c3155               -1   c3407                1
    x1248     c2345               -1   c2346               -1
    x1248     c2350               -1   c3150                1
    x1248     c3152                1
    x1249     c2347               -1   c2348               -1
    x1249     c2349               -1   c3151                1
    x1249     c3152                1
    x1250     c2351                1   c2352               -1
    x1250     c2353                1   c2354               -1
    x1250     c2355                1   c2356               -1
    x1251     c2351               -1   c2352                1
    x1251     c3128               -1   c3129               -1
    x1251     c3130               -1   c3400                1
    x1252     c2353               -1   c2354                1
    x1252     c3155               -1   c3158               -1
    x1252     c3161               -1   c3408                1
    x1253     c2357               -1   c2358               -1
    x1253     c2362               -1   c3166                1
    x1253     c3168                1
    x1254     c2359               -1   c2360               -1
    x1254     c2361               -1   c3167                1
    x1254     c3168                1
    x1255     c2361                1   c2362                1
    x1255     c3162                1   c3163               -1
    x1255     c3164               -1   c3165                1
    x1255     c3168               -1
    x1256     c2363                1   c2364               -1
    x1256     c2365                1   c2366               -1
    x1256     c3173                1   c3174                1
    x1256     c3175               -1   c3176               -1
    x1257     c2365               -1   c2366                1
    x1258     c2367               -1   c2415               -1
    x1258     c2416               -1   c2417               -1
    x1258     c3409                1   c3413                1
    x1259     c2367               -1   c2368               -1
    x1259     c2369               -1   c3173                1
    x1259     c3174               -1   c3175               -1
    x1259     c3176                1   c3409                1
    x1260     c2368               -1   c3188               -1
    x1260     c3189               -1   c3190               -1
    x1260     c3191               -1   c3192               -1
    x1260     c3193               -1   c3194               -1
    x1260     c3195               -1   c3196               -1
    x1260     c3409                1   c3411                1
    x1260     c3412                1
    x1261     c2369               -1   c2370               -1
    x1261     c2371               -1   c2372               -1
    x1261     c3409                1   c3410                1
    x1262     c2370               -1   c2397               -1
    x1262     c2398                1   c3410                1
    x1263     c2371               -1   c2385               -1
    x1263     c2386                1   c3410                1
    x1264     c2372               -1   c2373               -1
    x1264     c2374                1   c3410                1
    x1265     c2373                1   c2374               -1
    x1265     c2375                1   c2376               -1
    x1265     c2377                1   c2378               -1
    x1266     c2375               -1   c2376                1
    x1266     c3191               -1   c3192               -1
    x1266     c3193               -1   c3411                1
    x1267     c2377                1   c2378               -1
    x1267     c2383               -1   c2384                1
    x1268     c2379                1   c2380               -1
    x1268     c2381                1   c2382               -1
    x1268     c2383                1   c2384               -1
    x1268     c3177                1   c3178                1
    x1268     c3179               -1   c3180               -1
    x1269     c2379               -1   c2380                1
    x1269     c2416               -1   c3413                1
    x1270     c2381               -1   c2382                1
    x1270     c3190               -1   c3193               -1
    x1270     c3196               -1   c3412                1
    x1271     c2385                1   c2386               -1
    x1271     c2387                1   c2388               -1
    x1271     c2389                1   c2390               -1
    x1272     c2387               -1   c2388                1
    x1272     c2417               -1   c3413                1
    x1273     c2389                1   c2390               -1
    x1273     c2395               -1   c2396                1
    x1274     c2391                1   c2392               -1
    x1274     c2393                1   c2394               -1
    x1274     c2395                1   c2396               -1
    x1274     c3181                1   c3182                1
    x1274     c3183               -1   c3184               -1
    x1275     c2391               -1   c2392                1
    x1275     c3194               -1   c3195               -1
    x1275     c3196               -1   c3411                1
    x1276     c2393               -1   c2394                1
    x1276     c3189               -1   c3192               -1
    x1276     c3195               -1   c3412                1
    x1277     c2397                1   c2398               -1
    x1277     c2399                1   c2400               -1
    x1277     c2401                1   c2402               -1
    x1278     c2399               -1   c2400                1
    x1278     c3188               -1   c3191               -1
    x1278     c3194               -1   c3412                1
    x1279     c2401                1   c2402               -1
    x1279     c2407               -1   c2408                1
    x1280     c2403                1   c2404               -1
    x1280     c2405                1   c2406               -1
    x1280     c2407                1   c2408               -1
    x1280     c2413                1   c2414                1
    x1280     c3187               -1
    x1281     c2403               -1   c2404                1
    x1281     c2415               -1   c3413                1
    x1282     c2405               -1   c2406                1
    x1282     c3188               -1   c3189               -1
    x1282     c3190               -1   c3411                1
    x1283     c2409               -1   c2410               -1
    x1283     c2414               -1   c3185                1
    x1283     c3187                1
    x1284     c2411               -1   c2412               -1
    x1284     c2413               -1   c3186                1
    x1284     c3187                1
    x1285     c2418               -1   c2419               -1
    x1285     c2423               -1   c3201                1
    x1285     c3203                1
    x1286     c2420               -1   c2421               -1
    x1286     c2422               -1   c3202                1
    x1286     c3203                1
    x1287     c2422                1   c2423                1
    x1287     c3197                1   c3198               -1
    x1287     c3199               -1   c3200                1
    x1287     c3203               -1
    x1288     c2424                1   c2425               -1
    x1288     c2426                1   c2427               -1
    x1288     c2428                1   c2429               -1
    x1289     c2426               -1   c2427                1
    x1290     c2428                1   c2429               -1
    x1290     c2434               -1   c2435                1
    x1291     c2430                1   c2431               -1
    x1291     c2432                1   c2433               -1
    x1291     c2434                1   c2435               -1
    x1291     c3208               -1   c3209               -1
    x1291     c3210                1   c3211                1
    x1291     c3212                1   c3213                1
    x1292     c2430               -1   c2431                1
    x1293     c2432               -1   c2433                1
    x1294     c2436                1   c2437               -1
    x1294     c2438                1   c2439               -1
    x1294     c2440                1   c2441                1
    x1294     c2442                1   c2443                1
    x1294     c3432               -1
    x1295     c2436               -1   c2437                1
    x1296     c2438               -1   c2439                1
    x1296     c3209               -1   c3211                1
    x1296     c3213                1
    x1297     c2440                1   c2456               -1
    x1297     c2457                1   c3432               -1
    x1298     c2441                1   c2452               -1
    x1298     c2453                1   c3432               -1
    x1299     c2442                1   c2448               -1
    x1299     c2449                1   c3432               -1
    x1300     c2443                1   c2444               -1
    x1300     c2445                1   c3432               -1
    x1301     c2444                1   c2445               -1
    x1301     c2446                1   c2447               -1
    x1302     c2446               -1   c2447                1
    x1303     c2448                1   c2449               -1
    x1303     c2450                1   c2451               -1
    x1304     c2450               -1   c2451                1
    x1305     c2452                1   c2453               -1
    x1305     c2454                1   c2455               -1
    x1306     c2454               -1   c2455                1
    x1307     c2456                1   c2457               -1
    x1307     c2458                1   c2459               -1
    x1308     c2458               -1   c2459                1
    x1309     c2460                1   c2461               -1
    x1309     c2462                1   c2463               -1
    x1310     c2460               -1   c2461                1
    x1310     c3209               -1   c3210                1
    x1310     c3212                1
    x1311     c2462               -1   c2463                1
    x1312     c2464                1   c2465               -1
    x1312     c2466                1   c2467               -1
    x1312     c2468                1   c2469                1
    x1312     c2470                1   c2471                1
    x1312     c3433               -1
    x1313     c2464               -1   c2465                1
    x1314     c2466               -1   c2467                1
    x1314     c3208               -1   c3212                1
    x1314     c3213                1
    x1315     c2468                1   c2484               -1
    x1315     c2485                1   c3433               -1
    x1316     c2469                1   c2480               -1
    x1316     c2481                1   c3433               -1
    x1317     c2470                1   c2476               -1
    x1317     c2477                1   c3433               -1
    x1318     c2471                1   c2472               -1
    x1318     c2473                1   c3433               -1
    x1319     c2472                1   c2473               -1
    x1319     c2474                1   c2475               -1
    x1320     c2474               -1   c2475                1
    x1321     c2476                1   c2477               -1
    x1321     c2478                1   c2479               -1
    x1322     c2478               -1   c2479                1
    x1323     c2480                1   c2481               -1
    x1323     c2482                1   c2483               -1
    x1324     c2482               -1   c2483                1
    x1325     c2484                1   c2485               -1
    x1325     c2486                1   c2487               -1
    x1326     c2486               -1   c2487                1
    x1327     c2488                1   c2489               -1
    x1327     c2490                1   c2491               -1
    x1328     c2488               -1   c2489                1
    x1328     c3208               -1   c3210                1
    x1328     c3211                1
    x1329     c2490               -1   c2491                1
    x1330     c2492               -1   c2494                1
    x1330     c2501                1   c2502               -1
    x1330     c3214                1   c3215               -1
    x1330     c3217                1   c3218               -1
    x1331     c2492               -1   c2493               -1
    x1331     c2497               -1   c3214                1
    x1331     c3216                1
    x1332     c2493                1   c2495               -1
    x1332     c2498                1   c2499               -1
    x1332     c3214               -1   c3215                1
    x1332     c3217                1   c3218               -1
    x1333     c2494               -1   c2495               -1
    x1333     c2496               -1   c3215                1
    x1333     c3216                1
    x1334     c2496                1   c2497                1
    x1334     c2515               -1   c3216               -1
    x1334     c3434                1
    x1335     c2500                1   c3217               -1
    x1335     c3218               -1   c3224                1
    x1336     c2503               -1   c2505                1
    x1336     c2512                1   c2513               -1
    x1336     c3219                1   c3220               -1
    x1336     c3222                1   c3223               -1
    x1337     c2503               -1   c2504               -1
    x1337     c2508               -1   c3219                1
    x1337     c3221                1
    x1338     c2504                1   c2506               -1
    x1338     c2509                1   c2510               -1
    x1338     c3219               -1   c3220                1
    x1338     c3222                1   c3223               -1
    x1339     c2505               -1   c2506               -1
    x1339     c2507               -1   c3220                1
    x1339     c3221                1
    x1340     c2507                1   c2508                1
    x1340     c2514               -1   c3221               -1
    x1340     c3434                1
    x1341     c2511                1   c3222               -1
    x1341     c3223               -1   c3224                1
    x1342     c2560               -1   c2561               -1
    x1342     c2562               -1   c3228               -1
    x1342     c3229               -1
    x1343     c2560               -1   c3229               -1
    x1344     c2585                1   c2588                1
    x1344     c2591                1   c3244               -1
    x1345     c2587                1   c2588                1
    x1345     c2589                1   c3243               -1
    x1346     c2595                1   c2598                1
    x1346     c2601                1   c3248               -1
    x1347     c2597                1   c2598                1
    x1347     c2599                1   c3247               -1
    x1348     c2604                1   c2607                1
    x1348     c2610                1   c3254               -1
    x1349     c2606                1   c2607                1
    x1349     c2608                1   c3253               -1
    x1350     c2615                1   c2616                1
    x1350     c3260               -1
    x1351     c2634                1   c2637                1
    x1351     c2640                1   c3267               -1
    x1352     c2636                1   c2637                1
    x1352     c2638                1   c3266               -1
    x1353     c2662                1   c2665                1
    x1353     c2668                1   c3272               -1
    x1354     c2664                1   c2665                1
    x1354     c2666                1   c3271               -1
    x1355     c2687                1   c2690                1
    x1355     c2693                1   c3277               -1
    x1356     c2689                1   c2690                1
    x1356     c2691                1   c3276               -1
    x1357     c2696                1   c2699                1
    x1357     c2702                1   c3284               -1
    x1358     c2698                1   c2699                1
    x1358     c2700                1   c3283               -1
    x1359     c2720                1   c2723                1
    x1359     c2726                1   c3288               -1
    x1360     c2722                1   c2723                1
    x1360     c2724                1   c3287               -1
    x1361     c2733                1   c2736                1
    x1361     c2739                1   c3293               -1
    x1362     c2735                1   c2736                1
    x1362     c2737                1   c3292               -1
    x1363     c2756                1   c2759                1
    x1363     c2762                1   c3304               -1
    x1364     c2758                1   c2759                1
    x1364     c2760                1   c3303               -1
    x1365     c2769                1   c2772                1
    x1365     c2775                1   c3310               -1
    x1366     c2771                1   c2772                1
    x1366     c2773                1   c3309               -1
    x1367     c2784                1   c2787                1
    x1367     c2790                1   c3317               -1
    x1368     c2786                1   c2787                1
    x1368     c2788                1   c3316               -1
    x1369     c2794                1   c2797                1
    x1369     c2800                1   c3323               -1
    x1370     c2796                1   c2797                1
    x1370     c2798                1   c3322               -1
    x1371     c2823               -1
    x1372     c2826               -1
    x1373     c2838               -1
    x1374     c2933               -1
    x1375     c3011                1   c3012               -1
    x1375     c3013               -1   c3014                1
    x1376     c3011                1   c3012               -1
    x1376     c3013                1   c3014               -1
    x1377     c3034                1   c3037                1
    x1377     c3040                1   c3375               -1
    x1378     c3036                1   c3037                1
    x1378     c3038                1   c3374               -1
    x1379     c3060                1   c3063                1
    x1379     c3066                1   c3386               -1
    x1380     c3062                1   c3063                1
    x1380     c3064                1   c3385               -1
    x1381     c3076                1   c3079                1
    x1381     c3082                1   c3391               -1
    x1382     c3078                1   c3079                1
    x1382     c3080                1   c3390               -1
    x1383     c3093                1   c3094               -1
    x1383     c3095                1   c3096               -1
    x1383     c3116                1   c3117                1
    x1383     c3118               -1   c3119               -1
    x1384     c3139                1   c3142                1
    x1384     c3145                1   c3405               -1
    x1385     c3141                1   c3142                1
    x1385     c3143                1   c3404               -1
    x1386     c3162                1   c3163               -1
    x1386     c3164                1   c3165               -1
    x1386     c3169                1   c3170                1
    x1386     c3171               -1   c3172               -1
    x1387     c3173                1   c3174               -1
    x1387     c3175                1   c3176               -1
    x1387     c3197                1   c3198                1
    x1387     c3199               -1   c3200               -1
    x1388     c3177                1   c3178               -1
    x1388     c3179                1   c3180               -1
    x1389     c3197                1   c3198               -1
    x1389     c3199                1   c3200               -1
    x1389     c3204                1   c3205                1
    x1389     c3206               -1   c3207               -1
    x1390     c3328               -1   c3329               -1
    x1390     c3330               -1
    x1391     c3328               -1
    x1392     c3349               -1   c3350               -1
    x1392     c3351               -1
    x1393     c3349               -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       c1                   1   c3                   1
    rhs       c4                   1   c6                   1
    rhs       c9                   1   c10                 -1
    rhs       c11                 -1   c12                  1
    rhs       c13                  1   c14                 -1
    rhs       c21                 -1   c24                 -1
    rhs       c27                  1   c28                 -1
    rhs       c30                  1   c31                 -1
    rhs       c42                  1   c46                  1
    rhs       c65                 -1   c70                 -1
    rhs       c71                 -1   c76                 -1
    rhs       c77                 -1   c78                 -1
    rhs       c79                 -1   c80                 -1
    rhs       c81                 -1   c82                  1
    rhs       c83                 -1   c88                  1
    rhs       c89                  1   c90                  1
    rhs       c147                 1   c148                 1
    rhs       c149                 1   c154                 1
    rhs       c155                -1   c164                 1
    rhs       c165                 1   c166                 1
    rhs       c167                 1   c168                 1
    rhs       c169                 1   c210                 1
    rhs       c211                -1   c300                 1
    rhs       c301                 1   c302                 1
    rhs       c339                 1   c340                -1
    rhs       c345                -1   c346                -1
    rhs       c347                 1   c348                -1
    rhs       c357                 1   c358                 1
    rhs       c359                 1   c360                 1
    rhs       c361                 1   c362                 1
    rhs       c363                 1   c364                 1
    rhs       c365                 1   c380                 1
    rhs       c381                 1   c382                 1
    rhs       c383                 1   c384                 1
    rhs       c385                 1   c426                 1
    rhs       c427                -1   c512                 1
    rhs       c513                 1   c514                 1
    rhs       c555                 1   c556                -1
    rhs       c577                 1   c578                 1
    rhs       c579                 1   c580                 1
    rhs       c581                -1   c590                -1
    rhs       c591                -1   c592                -1
    rhs       c593                 1   c594                -1
    rhs       c599                 1   c600                 1
    rhs       c601                 1   c612                 1
    rhs       c613                 1   c614                 1
    rhs       c615                 1   c616                 1
    rhs       c617                 1   c618                 1
    rhs       c619                 1   c620                 1
    rhs       c621                 1   c622                -1
    rhs       c627                -1   c628                -1
    rhs       c629                -1   c688                 1
    rhs       c689                -1   c716                 1
    rhs       c717                -1   c724                 1
    rhs       c725                -1   c732                -1
    rhs       c733                 1   c734                 1
    rhs       c735                 1   c736                 1
    rhs       c737                -1   c742                 1
    rhs       c743                -1   c750                -1
    rhs       c753                -1   c756                 1
    rhs       c757                -1   c758                -1
    rhs       c759                -1   c766                 1
    rhs       c767                -1   c784                 1
    rhs       c785                 1   c786                 1
    rhs       c787                 1   c788                 1
    rhs       c789                 1   c790                 1
    rhs       c791                 1   c792                 1
    rhs       c803                 1   c804                -1
    rhs       c815                 1   c816                -1
    rhs       c825                 1   c826                 1
    rhs       c831                -1   c834                -1
    rhs       c841                 1   c842                -1
    rhs       c843                -1   c852                -1
    rhs       c853                -1   c870                -1
    rhs       c871                 1   c872                 1
    rhs       c887                 1   c888                 1
    rhs       c889                 1   c890                 1
    rhs       c891                 1   c892                 1
    rhs       c893                 1   c894                 1
    rhs       c895                 1   c896                 1
    rhs       c897                 1   c902                 1
    rhs       c903                -1   c908                -1
    rhs       c911                -1   c918                -1
    rhs       c919                 1   c920                 1
    rhs       c927                 1   c928                -1
    rhs       c935                 1   c936                 1
    rhs       c941                 1   c942                -1
    rhs       c955                -1   c956                -1
    rhs       c971                 1   c972                 1
    rhs       c973                 1   c974                 1
    rhs       c975                 1   c976                 1
    rhs       c977                 1   c978                 1
    rhs       c979                 1   c980                 1
    rhs       c981                 1   c982                 1
    rhs       c989                 1   c990                -1
    rhs       c1013                1   c1014                1
    rhs       c1015                1   c1016                1
    rhs       c1017                1   c1018                1
    rhs       c1019                1   c1020                1
    rhs       c1021                1   c1050               -1
    rhs       c1053               -1   c1066                1
    rhs       c1067               -1   c1080                1
    rhs       c1081               -1   c1104                1
    rhs       c1105                1   c1106                1
    rhs       c1107                1   c1108                1
    rhs       c1109                1   c1110                1
    rhs       c1111                1   c1112                1
    rhs       c1113                1   c1114               -1
    rhs       c1115               -1   c1116               -1
    rhs       c1117                1   c1122                1
    rhs       c1123               -1   c1138                1
    rhs       c1139                1   c1140                1
    rhs       c1141                1   c1142                1
    rhs       c1143                1   c1144                1
    rhs       c1145                1   c1146                1
    rhs       c1147               -1   c1148               -1
    rhs       c1157               -1   c1158               -1
    rhs       c1171                1   c1172                1
    rhs       c1173               -1   c1174                1
    rhs       c1175                1   c1176               -1
    rhs       c1177               -1   c1178                1
    rhs       c1179                1   c1186                1
    rhs       c1187               -1   c1188                1
    rhs       c1189               -1   c1190                1
    rhs       c1191                1   c1192                1
    rhs       c1193                1   c1194                1
    rhs       c1195                1   c1196                1
    rhs       c1197                1   c1198               -1
    rhs       c1199               -1   c1200               -1
    rhs       c1201                1   c1202               -1
    rhs       c1203                1   c1204                1
    rhs       c1205                1   c1206                1
    rhs       c1207               -1   c1208               -1
    rhs       c1209               -1   c1210               -1
    rhs       c1211                1   c1212                1
    rhs       c1213                1   c1214                1
    rhs       c1215                1   c1216               -1
    rhs       c1217                1   c1218                1
    rhs       c1219                1   c1224                1
    rhs       c1225               -1   c1232               -1
    rhs       c1235               -1   c1242                1
    rhs       c1243                1   c1244                1
    rhs       c1249                1   c1250               -1
    rhs       c1267                1   c1268               -1
    rhs       c1287                1   c1288                1
    rhs       c1289                1   c1290                1
    rhs       c1291               -1   c1296                1
    rhs       c1297                1   c1298                1
    rhs       c1307                1   c1308                1
    rhs       c1309                1   c1310                1
    rhs       c1311                1   c1312                1
    rhs       c1313                1   c1314                1
    rhs       c1315                1   c1324               -1
    rhs       c1325               -1   c1326               -1
    rhs       c1341               -1   c1342               -1
    rhs       c1343               -1   c1344                1
    rhs       c1345               -1   c1354                1
    rhs       c1355                1   c1356                1
    rhs       c1357                1   c1358                1
    rhs       c1359                1   c1360                1
    rhs       c1361                1   c1362                1
    rhs       c1363               -1   c1370               -1
    rhs       c1373               -1   c1380               -1
    rhs       c1381               -1   c1382               -1
    rhs       c1387               -1   c1388               -1
    rhs       c1389               -1   c1390                1
    rhs       c1391               -1   c1400                1
    rhs       c1401                1   c1402                1
    rhs       c1403                1   c1404                1
    rhs       c1405                1   c1406                1
    rhs       c1407                1   c1408                1
    rhs       c1409                1   c1410                1
    rhs       c1417               -1   c1418               -1
    rhs       c1419               -1   c1424                1
    rhs       c1425               -1   c1436                1
    rhs       c1437                1   c1438                1
    rhs       c1439                1   c1440                1
    rhs       c1441                1   c1442                1
    rhs       c1443                1   c1444                1
    rhs       c1449                1   c1450               -1
    rhs       c1455                1   c1456                1
    rhs       c1457                1   c1462                1
    rhs       c1463               -1   c1470                1
    rhs       c1471               -1   c1472               -1
    rhs       c1473               -1   c1478               -1
    rhs       c1479               -1   c1480               -1
    rhs       c1481               -1   c1482               -1
    rhs       c1483               -1   c1484               -1
    rhs       c1485               -1   c1486                1
    rhs       c1487               -1   c1488               -1
    rhs       c1489               -1   c1490               -1
    rhs       c1491                1   c1492               -1
    rhs       c1493               -1   c1494               -1
    rhs       c1495               -1   c1496               -1
    rhs       c1497                1   c1498                1
    rhs       c1499               -1   c1500               -1
    rhs       c1501                1   c1502               -1
    rhs       c1503                1   c1504               -1
    rhs       c1515               -1   c1516               -1
    rhs       c1518               -1   c1519               -1
    rhs       c1520               -1   c1536               -1
    rhs       c1540               -1   c1541               -1
    rhs       c1544               -1   c1545               -1
    rhs       c1546               -1   c1551               -1
    rhs       c1552               -1   c1553               -1
    rhs       c1554               -1   c1555               -1
    rhs       c1556               -1   c1561               -1
    rhs       c1562               -1   c1563               -1
    rhs       c1568                1   c1569               -1
    rhs       c1570                1   c1571               -1
    rhs       c1576               -1   c1577               -1
    rhs       c1578               -1   c1579               -1
    rhs       c1580               -1   c1581               -1
    rhs       c1586               -1   c1587               -1
    rhs       c1588               -1   c1593                1
    rhs       c1594               -1   c1595                1
    rhs       c1596               -1   c1601               -1
    rhs       c1602               -1   c1603               -1
    rhs       c1614               -1   c1617               -1
    rhs       c1620               -1   c1621               -1
    rhs       c1622               -1   c1623               -1
    rhs       c1624                1   c1625                1
    rhs       c1626                1   c1627               -1
    rhs       c1630               -1   c1653                1
    rhs       c1654               -1   c1655               -1
    rhs       c1656               -1   c1657               -1
    rhs       c1662                1   c1663               -1
    rhs       c1664               -1   c1671                1
    rhs       c1672               -1   c1673               -1
    rhs       c1674               -1   c1675               -1
    rhs       c1676               -1   c1677               -1
    rhs       c1678               -1   c1683                1
    rhs       c1684               -1   c1697               -1
    rhs       c1698                1   c1699                1
    rhs       c1700                1   c1701               -1
    rhs       c1702                1   c1703                1
    rhs       c1708                1   c1709               -1
    rhs       c1710               -1   c1711                1
    rhs       c1712                1   c1713                1
    rhs       c1714                1   c1715                1
    rhs       c1716               -1   c1727               -1
    rhs       c1728                1   c1729                1
    rhs       c1730                1   c1731                1
    rhs       c1736                1   c1737               -1
    rhs       c1738               -1   c1745                1
    rhs       c1746               -1   c1747               -1
    rhs       c1748               -1   c1749                1
    rhs       c1750                1   c1751                1
    rhs       c1752                1   c1753                1
    rhs       c1754                1   c1755                1
    rhs       c1756               -1   c1757               -1
    rhs       c1758                1   c1759               -1
    rhs       c1760                1   c1761                1
    rhs       c1762                1   c1763                1
    rhs       c1764                1   c1765               -1
    rhs       c1766               -1   c1767               -1
    rhs       c1768                1   c1769               -1
    rhs       c1770               -1   c1771               -1
    rhs       c1772                1   c1773                1
    rhs       c1774                1   c1775                1
    rhs       c1776                1   c1777               -1
    rhs       c1778                1   c1779                1
    rhs       c1780                1   c1784                1
    rhs       c1785                1   c1786                1
    rhs       c1795               -1   c1798               -1
    rhs       c1805                1   c1806                1
    rhs       c1807                1   c1812               -1
    rhs       c1813               -1   c1814               -1
    rhs       c1815                1   c1816               -1
    rhs       c1821               -1   c1824               -1
    rhs       c1831               -1   c1832               -1
    rhs       c1833               -1   c1838                1
    rhs       c1839                1   c1840                1
    rhs       c1841               -1   c1844               -1
    rhs       c1845               -1   c1846               -1
    rhs       c1857               -1   c1858               -1
    rhs       c1859               -1   c1864                1
    rhs       c1865                1   c1866                1
    rhs       c1867                1   c1868                1
    rhs       c1869                1   c1870                1
    rhs       c1875                1   c1876               -1
    rhs       c1881                1   c1882                1
    rhs       c1883                1   c1884                1
    rhs       c1885               -1   c1892                1
    rhs       c1893                1   c1894                1
    rhs       c1895                1   c1896                1
    rhs       c1897                1   c1898               -1
    rhs       c1903                1   c1904                1
    rhs       c1905                1   c1906                1
    rhs       c1907                1   c1908               -1
    rhs       c1909               -1   c1910               -1
    rhs       c1911               -1   c1912               -1
    rhs       c1913               -1   c1914                1
    rhs       c1915               -1   c1916                1
    rhs       c1917               -1   c1918                1
    rhs       c1919               -1   c1920               -1
    rhs       c1921               -1   c1922               -1
    rhs       c1923               -1   c1924                1
    rhs       c1925                1   c1926                1
    rhs       c1927               -1   c1929                1
    rhs       c1930               -1   c1931               -1
    rhs       c1934               -1   c1937                1
    rhs       c1938               -1   c1940                1
    rhs       c1941               -1   c1942                1
    rhs       c1943               -1   c1945                1
    rhs       c1946               -1   c1957               -1
    rhs       c1958               -1   c1960               -1
    rhs       c1961               -1   c1962               -1
    rhs       c1963                1   c1964                1
    rhs       c1965                1   c1966                1
    rhs       c1971                1   c1972                1
    rhs       c1973                1   c1974                1
    rhs       c1979                1   c1980                1
    rhs       c1981               -1   c1984               -1
    rhs       c1987                1   c1988                1
    rhs       c1995               -1   c1998               -1
    rhs       c2009               -1   c2012               -1
    rhs       c2021               -1   c2024               -1
    rhs       c2031                1   c2032               -1
    rhs       c2037                1   c2038               -1
    rhs       c2039                1   c2040               -1
    rhs       c2041               -1   c2044               -1
    rhs       c2047               -1   c2050               -1
    rhs       c2053                1   c2054               -1
    rhs       c2055                1   c2056                1
    rhs       c2057                1   c2062                1
    rhs       c2067                1   c2068                1
    rhs       c2073                1   c2074               -1
    rhs       c2079               -1   c2082               -1
    rhs       c2089                1   c2098                1
    rhs       c2099                1   c2100                1
    rhs       c2101                1   c2102                1
    rhs       c2103                1   c2104                1
    rhs       c2105                1   c2106                1
    rhs       c2107               -1   c2110               -1
    rhs       c2119                1   c2120                1
    rhs       c2121                1   c2122                1
    rhs       c2123                1   c2124                1
    rhs       c2125                1   c2126                1
    rhs       c2127                1   c2128                1
    rhs       c2129                1   c2130                1
    rhs       c2131                1   c2132                1
    rhs       c2133                1   c2134                1
    rhs       c2139               -1   c2140               -1
    rhs       c2147                1   c2148                1
    rhs       c2149                1   c2150                1
    rhs       c2151                1   c2152                1
    rhs       c2153                1   c2154                1
    rhs       c2155                1   c2168                1
    rhs       c2169               -1   c2176               -1
    rhs       c2179               -1   c2186                1
    rhs       c2187                1   c2188                1
    rhs       c2189                1   c2190                1
    rhs       c2191                1   c2192                1
    rhs       c2193                1   c2194                1
    rhs       c2199                1   c2200               -1
    rhs       c2201                1   c2202               -1
    rhs       c2203                1   c2204               -1
    rhs       c2209                1   c2210                1
    rhs       c2211                1   c2212                1
    rhs       c2213                1   c2214                1
    rhs       c2219                1   c2220               -1
    rhs       c2227               -1   c2230               -1
    rhs       c2237                1   c2238               -1
    rhs       c2245               -1   c2248               -1
    rhs       c2255                1   c2256               -1
    rhs       c2263                1   c2264                1
    rhs       c2265                1   c2280                1
    rhs       c2281                1   c2282               -1
    rhs       c2285               -1   c2288               -1
    rhs       c2289               -1   c2306                1
    rhs       c2307                1   c2308                1
    rhs       c2309                1   c2310                1
    rhs       c2311                1   c2312                1
    rhs       c2313                1   c2314                1
    rhs       c2319                1   c2320               -1
    rhs       c2327               -1   c2330               -1
    rhs       c2337                1   c2338               -1
    rhs       c2345               -1   c2348               -1
    rhs       c2355                1   c2356               -1
    rhs       c2357               -1   c2360               -1
    rhs       c2367               -1   c2368               -1
    rhs       c2369               -1   c2370               -1
    rhs       c2371               -1   c2372               -1
    rhs       c2377                1   c2378               -1
    rhs       c2389                1   c2390               -1
    rhs       c2401                1   c2402               -1
    rhs       c2409               -1   c2412               -1
    rhs       c2415               -1   c2416               -1
    rhs       c2417               -1   c2418               -1
    rhs       c2421               -1   c2428                1
    rhs       c2429               -1   c2440                1
    rhs       c2441                1   c2442                1
    rhs       c2443                1   c2468                1
    rhs       c2469                1   c2470                1
    rhs       c2471                1   c2492               -1
    rhs       c2495               -1   c2498                1
    rhs       c2499               -1   c2501                1
    rhs       c2502               -1   c2503               -1
    rhs       c2506               -1   c2509                1
    rhs       c2510               -1   c2512                1
    rhs       c2513               -1   c2522               -2
    rhs       c2525               -2   c2527               -2
    rhs       c2528                1   c2529               -2
    rhs       c2530               -2   c2531               -2
    rhs       c2532               -2   c2533               -2
    rhs       c2534               -2   c2535               -2
    rhs       c2536               -2   c2537               -1
    rhs       c2538               -1   c2540               -1
    rhs       c2541               -1   c2544               -2
    rhs       c2545                1   c2546               -2
    rhs       c2547               -2   c2549               -2
    rhs       c2551               -2   c2553               -2
    rhs       c2554                1   c2555                1
    rhs       c2556               -2   c2557               -2
    rhs       c2558               -2   c2559               -2
    rhs       c2560               -2   c2561               -2
    rhs       c2562               -2   c2563               -2
    rhs       c2564               -2   c2565               -2
    rhs       c2566               -2   c2567               -2
    rhs       c2568               -2   c2570               -2
    rhs       c2571                1   c2572                1
    rhs       c2573               -2   c2574               -2
    rhs       c2575               -2   c2576               -2
    rhs       c2577               -2   c2578                1
    rhs       c2579                1   c2580               -2
    rhs       c2581                1   c2582                1
    rhs       c2583                1   c2584                1
    rhs       c2585                1   c2586                1
    rhs       c2587                1   c2588                1
    rhs       c2589                1   c2590                1
    rhs       c2591                1   c2592                1
    rhs       c2593                1   c2594                1
    rhs       c2595                1   c2596                1
    rhs       c2597                1   c2598                1
    rhs       c2599                1   c2600                1
    rhs       c2601                1   c2602                1
    rhs       c2603                1   c2604                1
    rhs       c2605                1   c2606                1
    rhs       c2607                1   c2608                1
    rhs       c2609                1   c2610                1
    rhs       c2611                1   c2612               -2
    rhs       c2613                1   c2614                1
    rhs       c2615                1   c2616                1
    rhs       c2617                1   c2618                1
    rhs       c2619                1   c2620               -1
    rhs       c2621               -1   c2622               -1
    rhs       c2623                1   c2624                1
    rhs       c2625                1   c2626               -2
    rhs       c2627                1   c2628                1
    rhs       c2632                1   c2633                1
    rhs       c2634                1   c2635                1
    rhs       c2636                1   c2637                1
    rhs       c2638                1   c2639                1
    rhs       c2640                1   c2641                1
    rhs       c2642               -2   c2643               -2
    rhs       c2644                1   c2645                1
    rhs       c2646                1   c2647                1
    rhs       c2648               -2   c2652                1
    rhs       c2653               -2   c2654               -2
    rhs       c2655                1   c2656                1
    rhs       c2657               -2   c2658                1
    rhs       c2659                1   c2660               -2
    rhs       c2661                1   c2662                1
    rhs       c2663                1   c2664                1
    rhs       c2665                1   c2666                1
    rhs       c2667                1   c2668                1
    rhs       c2669                1   c2670               -2
    rhs       c2674               -2   c2675                1
    rhs       c2676                1   c2677               -2
    rhs       c2678               -2   c2679                1
    rhs       c2680               -2   c2681               -2
    rhs       c2682                1   c2683                1
    rhs       c2684                1   c2685                1
    rhs       c2686                1   c2687                1
    rhs       c2688                1   c2689                1
    rhs       c2690                1   c2691                1
    rhs       c2692                1   c2693                1
    rhs       c2694                1   c2695                1
    rhs       c2696                1   c2697                1
    rhs       c2698                1   c2699                1
    rhs       c2700                1   c2701                1
    rhs       c2702                1   c2703                1
    rhs       c2704                1   c2705                1
    rhs       c2706               -2   c2707               -2
    rhs       c2708               -2   c2709               -2
    rhs       c2713               -2   c2714               -2
    rhs       c2715                1   c2716                1
    rhs       c2717                1   c2718                1
    rhs       c2719                1   c2720                1
    rhs       c2721                1   c2722                1
    rhs       c2723                1   c2724                1
    rhs       c2725                1   c2726                1
    rhs       c2727                1   c2728                1
    rhs       c2729                1   c2730               -2
    rhs       c2731               -2   c2732                1
    rhs       c2733                1   c2734                1
    rhs       c2735                1   c2736                1
    rhs       c2737                1   c2738                1
    rhs       c2739                1   c2740                1
    rhs       c2741                1   c2742                1
    rhs       c2743                1   c2744               -2
    rhs       c2745               -2   c2746               -2
    rhs       c2747                1   c2748               -2
    rhs       c2749                1   c2750                1
    rhs       c2751                1   c2755                1
    rhs       c2756                1   c2757                1
    rhs       c2758                1   c2759                1
    rhs       c2760                1   c2761                1
    rhs       c2762                1   c2763                1
    rhs       c2764                1   c2765               -1
    rhs       c2766               -1   c2767               -1
    rhs       c2768                1   c2769                1
    rhs       c2770                1   c2771                1
    rhs       c2772                1   c2773                1
    rhs       c2774                1   c2775                1
    rhs       c2776                1   c2777               -2
    rhs       c2778                1   c2779                1
    rhs       c2783                1   c2784                1
    rhs       c2785                1   c2786                1
    rhs       c2787                1   c2788                1
    rhs       c2789                1   c2790                1
    rhs       c2791                1   c2792               -2
    rhs       c2793                1   c2794                1
    rhs       c2795                1   c2796                1
    rhs       c2797                1   c2798                1
    rhs       c2799                1   c2800                1
    rhs       c2801                1   c2802                1
    rhs       c2803               -2   c2804                1
    rhs       c2807               -2   c2809               -2
    rhs       c2810                1   c2812               -2
    rhs       c2813                1   c2815               -2
    rhs       c2817               -2   c2819               -2
    rhs       c2820               -2   c2821                1
    rhs       c2822                1   c2823               -2
    rhs       c2824               -2   c2825               -2
    rhs       c2826               -2   c2827               -2
    rhs       c2828               -2   c2829               -2
    rhs       c2831               -2   c2832               -2
    rhs       c2833                1   c2834                1
    rhs       c2835               -2   c2836                1
    rhs       c2837                1   c2838               -1
    rhs       c2839               -1   c2842               -2
    rhs       c2843               -2   c2844                1
    rhs       c2845                1   c2846                1
    rhs       c2853               -2   c2854               -2
    rhs       c2855                1   c2856                1
    rhs       c2857                1   c2858                1
    rhs       c2859                1   c2860               -1
    rhs       c2861               -1   c2862               -1
    rhs       c2863                1   c2864               -1
    rhs       c2865               -1   c2866               -1
    rhs       c2867                1   c2868               -2
    rhs       c2869               -2   c2870                1
    rhs       c2871                1   c2872                1
    rhs       c2873               -2   c2874               -2
    rhs       c2875                1   c2876                1
    rhs       c2877               -2   c2878               -2
    rhs       c2879                1   c2880                1
    rhs       c2881               -2   c2882               -2
    rhs       c2883               -2   c2884               -2
    rhs       c2885                1   c2886               -1
    rhs       c2887               -1   c2888               -1
    rhs       c2889               -2   c2890               -2
    rhs       c2891                1   c2892                1
    rhs       c2893                1   c2894                1
    rhs       c2895               -2   c2896                1
    rhs       c2897                1   c2898               -2
    rhs       c2899               -2   c2900               -2
    rhs       c2901                1   c2902                1
    rhs       c2903               -2   c2904               -2
    rhs       c2905                1   c2906               -1
    rhs       c2907               -1   c2908               -1
    rhs       c2909               -2   c2910                1
    rhs       c2911                1   c2912               -2
    rhs       c2913               -2   c2914                1
    rhs       c2915               -2   c2916               -2
    rhs       c2917                1   c2918                1
    rhs       c2919                1   c2920                1
    rhs       c2921                1   c2923               -2
    rhs       c2930               -2   c2931                1
    rhs       c2932                1   c2933               -1
    rhs       c2934               -1   c2937               -2
    rhs       c2938               -2   c2939                1
    rhs       c2940                1   c2941                1
    rhs       c2942               -1   c2943               -1
    rhs       c2944               -1   c2945               -2
    rhs       c2947               -2   c2948               -2
    rhs       c2949               -2   c2950                1
    rhs       c2951                1   c2952               -2
    rhs       c2954               -2   c2959               -2
    rhs       c2961               -2   c2964               -2
    rhs       c2966               -2   c2967                1
    rhs       c2969               -2   c2970                1
    rhs       c2972               -2   c2973               -2
    rhs       c2977               -2   c2978                1
    rhs       c2979                1   c2980                1
    rhs       c2981                1   c2982                1
    rhs       c2983                1   c2984                1
    rhs       c2985                1   c2986                1
    rhs       c2996               -2   c2997               -2
    rhs       c2998               -2   c2999               -2
    rhs       c3000               -2   c3001               -2
    rhs       c3002               -2   c3003               -2
    rhs       c3004               -2   c3011                1
    rhs       c3012               -1   c3013               -1
    rhs       c3014               -1   c3015                1
    rhs       c3016                1   c3017               -2
    rhs       c3021                1   c3022               -1
    rhs       c3023               -1   c3024               -1
    rhs       c3025                1   c3026                1
    rhs       c3027               -2   c3028               -2
    rhs       c3029                1   c3030                1
    rhs       c3031                1   c3032                1
    rhs       c3033                1   c3034                1
    rhs       c3035                1   c3036                1
    rhs       c3037                1   c3038                1
    rhs       c3039                1   c3040                1
    rhs       c3041                1   c3045                1
    rhs       c3046               -2   c3047               -2
    rhs       c3048               -2   c3049               -2
    rhs       c3050               -2   c3051               -2
    rhs       c3052               -2   c3053               -2
    rhs       c3054               -2   c3055                1
    rhs       c3056               -1   c3057               -1
    rhs       c3058               -1   c3059                1
    rhs       c3060                1   c3061                1
    rhs       c3062                1   c3063                1
    rhs       c3064                1   c3065                1
    rhs       c3066                1   c3067                1
    rhs       c3068                1   c3069               -1
    rhs       c3070               -1   c3071               -1
    rhs       c3075                1   c3076                1
    rhs       c3077                1   c3078                1
    rhs       c3079                1   c3080                1
    rhs       c3081                1   c3082                1
    rhs       c3083                1   c3084                1
    rhs       c3085                1   c3086                1
    rhs       c3087                1   c3088                1
    rhs       c3089                1   c3090                1
    rhs       c3091                1   c3092                1
    rhs       c3093                1   c3094               -1
    rhs       c3095               -1   c3096               -1
    rhs       c3103                1   c3104               -1
    rhs       c3105               -1   c3106               -1
    rhs       c3107                1   c3108                1
    rhs       c3109                1   c3110                1
    rhs       c3111                1   c3112                1
    rhs       c3113                1   c3114                1
    rhs       c3115                1   c3116                1
    rhs       c3117               -1   c3118               -1
    rhs       c3119               -1   c3120               -2
    rhs       c3124                1   c3125               -2
    rhs       c3126               -2   c3127               -2
    rhs       c3128               -2   c3129               -2
    rhs       c3130               -2   c3131               -2
    rhs       c3132               -2   c3133               -2
    rhs       c3134                1   c3135               -1
    rhs       c3136               -1   c3137               -1
    rhs       c3138                1   c3139                1
    rhs       c3140                1   c3141                1
    rhs       c3142                1   c3143                1
    rhs       c3144                1   c3145                1
    rhs       c3146                1   c3153               -2
    rhs       c3154               -2   c3155               -2
    rhs       c3156               -2   c3157               -2
    rhs       c3158               -2   c3159               -2
    rhs       c3160               -2   c3161               -2
    rhs       c3162                1   c3163               -1
    rhs       c3164               -1   c3165               -1
    rhs       c3169                1   c3170               -1
    rhs       c3171               -1   c3172               -1
    rhs       c3173                1   c3174               -1
    rhs       c3175               -1   c3176               -1
    rhs       c3177                1   c3178               -1
    rhs       c3179               -1   c3180               -1
    rhs       c3181                1   c3182               -1
    rhs       c3183               -1   c3184               -1
    rhs       c3188               -2   c3189               -2
    rhs       c3190               -2   c3191               -2
    rhs       c3192               -2   c3193               -2
    rhs       c3194               -2   c3195               -2
    rhs       c3196               -2   c3197                1
    rhs       c3198               -1   c3199               -1
    rhs       c3200               -1   c3204                1
    rhs       c3205               -1   c3206               -1
    rhs       c3207               -1   c3208               -2
    rhs       c3209               -2   c3210                1
    rhs       c3211                1   c3212                1
    rhs       c3213                1   c3218               -2
    rhs       c3223               -2   c3224                1
    rhs       c3225               -1   c3226               -1
    rhs       c3228               -1   c3229               -1
    rhs       c3230               -1   c3231               -1
    rhs       c3232               -1   c3233               -1
    rhs       c3235               -1   c3236               -1
    rhs       c3238               -3   c3239               -3
    rhs       c3240               -3   c3241               -3
    rhs       c3242               -3   c3243               -3
    rhs       c3244               -3   c3245               -3
    rhs       c3246               -3   c3247               -3
    rhs       c3248               -3   c3249               -3
    rhs       c3250               -3   c3251               -3
    rhs       c3252               -3   c3253               -3
    rhs       c3254               -3   c3255               -3
    rhs       c3256                1   c3257               -3
    rhs       c3258               -3   c3259               -3
    rhs       c3260               -3   c3261               -3
    rhs       c3262                1   c3263               -3
    rhs       c3264               -3   c3265               -3
    rhs       c3266               -3   c3267               -3
    rhs       c3268               -3   c3269               -3
    rhs       c3270               -3   c3271               -3
    rhs       c3272               -3   c3273               -3
    rhs       c3274               -3   c3275               -3
    rhs       c3276               -3   c3277               -3
    rhs       c3278               -3   c3279               -3
    rhs       c3280               -3   c3281               -3
    rhs       c3282               -3   c3283               -3
    rhs       c3284               -3   c3285               -3
    rhs       c3286               -3   c3287               -3
    rhs       c3288               -3   c3289               -3
    rhs       c3290               -3   c3291               -3
    rhs       c3292               -3   c3293               -3
    rhs       c3294               -3   c3295               -3
    rhs       c3296               -3   c3297               -3
    rhs       c3298               -3   c3299               -3
    rhs       c3300               -3   c3301               -3
    rhs       c3302               -3   c3303               -3
    rhs       c3304               -3   c3305                1
    rhs       c3306                1   c3307               -3
    rhs       c3308               -3   c3309               -3
    rhs       c3310               -3   c3311               -3
    rhs       c3312                1   c3313                1
    rhs       c3314               -3   c3315               -3
    rhs       c3316               -3   c3317               -3
    rhs       c3318               -3   c3319                1
    rhs       c3320               -3   c3321               -3
    rhs       c3322               -3   c3323               -3
    rhs       c3324               -3   c3325               -3
    rhs       c3326                1   c3328               -3
    rhs       c3329               -3   c3330               -3
    rhs       c3331                1   c3332                1
    rhs       c3333                1   c3334                1
    rhs       c3335                1   c3336               -3
    rhs       c3337                1   c3338                1
    rhs       c3339                1   c3340                1
    rhs       c3341                1   c3342               -3
    rhs       c3343               -3   c3344               -3
    rhs       c3345               -3   c3346                1
    rhs       c3347                1   c3348               -3
    rhs       c3349               -3   c3350               -3
    rhs       c3351               -3   c3352                1
    rhs       c3353               -3   c3354               -3
    rhs       c3355               -3   c3356               -3
    rhs       c3357               -3   c3358               -3
    rhs       c3359               -3   c3360               -3
    rhs       c3361                1   c3362                1
    rhs       c3363               -3   c3364               -3
    rhs       c3365               -3   c3366               -3
    rhs       c3367               -3   c3368               -3
    rhs       c3369               -3   c3370               -3
    rhs       c3371               -3   c3372               -3
    rhs       c3373               -3   c3374               -3
    rhs       c3375               -3   c3376               -3
    rhs       c3377               -3   c3378               -3
    rhs       c3379               -3   c3380               -3
    rhs       c3381                1   c3382                1
    rhs       c3383               -3   c3384               -3
    rhs       c3385               -3   c3386               -3
    rhs       c3387               -3   c3388               -3
    rhs       c3389               -3   c3390               -3
    rhs       c3391               -3   c3392               -3
    rhs       c3393               -3   c3394               -3
    rhs       c3395               -3   c3396               -3
    rhs       c3397               -3   c3398               -3
    rhs       c3399               -3   c3400                1
    rhs       c3401                1   c3402               -3
    rhs       c3403               -3   c3404               -3
    rhs       c3405               -3   c3406               -3
    rhs       c3407                1   c3408                1
    rhs       c3409                1   c3410                1
    rhs       c3411                1   c3412                1
    rhs       c3413                1   c3414                1
    rhs       c3415               -4   c3416               -4
    rhs       c3417               -4   c3418               -4
    rhs       c3419                1   c3420                1
    rhs       c3421                1   c3422                1
    rhs       c3423                1   c3424               -4
    rhs       c3425               -4   c3426               -4
    rhs       c3427                1   c3428                1
    rhs       c3429               -4   c3430               -4
    rhs       c3431               -4   c3432               -4
    rhs       c3433               -4
BOUNDS
 UP bnd       x1                   1
 UP bnd       x2                   1
 UP bnd       x3                   1
 UP bnd       x4                   1
 UP bnd       x5                   1
 UP bnd       x6                   1
 UP bnd       x7                   1
 UP bnd       x8                   1
 UP bnd       x9                   1
 UP bnd       x10                  1
 UP bnd       x11                  1
 UP bnd       x12                  1
 UP bnd       x13                  1
 UP bnd       x14                  1
 UP bnd       x15                  1
 UP bnd       x16                  1
 UP bnd       x17                  1
 UP bnd       x18                  1
 UP bnd       x19                  1
 UP bnd       x20                  1
 UP bnd       x21                  1
 UP bnd       x22                  1
 UP bnd       x23                  1
 UP bnd       x24                  1
 UP bnd       x25                  1
 UP bnd       x26                  1
 UP bnd       x27                  1
 UP bnd       x28                  1
 UP bnd       x29                  1
 UP bnd       x30                  1
 UP bnd       x31                  1
 UP bnd       x32                  1
 UP bnd       x33                  1
 UP bnd       x34                  1
 UP bnd       x35                  1
 UP bnd       x36                  1
 UP bnd       x37                  1
 UP bnd       x38                  1
 UP bnd       x39                  1
 UP bnd       x40                  1
 UP bnd       x41                  1
 UP bnd       x42                  1
 UP bnd       x43                  1
 UP bnd       x44                  1
 UP bnd       x45                  1
 UP bnd       x46                  1
 UP bnd       x47                  1
 UP bnd       x48                  1
 UP bnd       x49                  1
 UP bnd       x50                  1
 UP bnd       x51                  1
 UP bnd       x52                  1
 UP bnd       x53                  1
 UP bnd       x54                  1
 UP bnd       x55                  1
 UP bnd       x56                  1
 UP bnd       x57                  1
 UP bnd       x58                  1
 UP bnd       x59                  1
 UP bnd       x60                  1
 UP bnd       x61                  1
 UP bnd       x62                  1
 UP bnd       x63                  1
 UP bnd       x64                  1
 UP bnd       x65                  1
 UP bnd       x66                  1
 UP bnd       x67                  1
 UP bnd       x68                  1
 UP bnd       x69                  1
 UP bnd       x70                  1
 UP bnd       x71                  1
 UP bnd       x72                  1
 UP bnd       x73                  1
 UP bnd       x74                  1
 UP bnd       x75                  1
 UP bnd       x76                  1
 UP bnd       x77                  1
 UP bnd       x78                  1
 UP bnd       x79                  1
 UP bnd       x80                  1
 UP bnd       x81                  1
 UP bnd       x82                  1
 UP bnd       x83                  1
 UP bnd       x84                  1
 UP bnd       x85                  1
 UP bnd       x86                  1
 UP bnd       x87                  1
 UP bnd       x88                  1
 UP bnd       x89                  1
 UP bnd       x90                  1
 UP bnd       x91                  1
 UP bnd       x92                  1
 UP bnd       x93                  1
 UP bnd       x94                  1
 UP bnd       x95                  1
 UP bnd       x96                  1
 UP bnd       x97                  1
 UP bnd       x98                  1
 UP bnd       x99                  1
 UP bnd       x100                 1
 UP bnd       x101                 1
 UP bnd       x102                 1
 UP bnd       x103                 1
 UP bnd       x104                 1
 UP bnd       x105                 1
 UP bnd       x106                 1
 UP bnd       x107                 1
 UP bnd       x108                 1
 UP bnd       x109                 1
 UP bnd       x110                 1
 UP bnd       x111                 1
 UP bnd       x112                 1
 UP bnd       x113                 1
 UP bnd       x114                 1
 UP bnd       x115                 1
 UP bnd       x116                 1
 UP bnd       x117                 1
 UP bnd       x118                 1
 UP bnd       x119                 1
 UP bnd       x120                 1
 UP bnd       x121                 1
 UP bnd       x122                 1
 UP bnd       x123                 1
 UP bnd       x124                 1
 UP bnd       x125                 1
 UP bnd       x126                 1
 UP bnd       x127                 1
 UP bnd       x128                 1
 UP bnd       x129                 1
 UP bnd       x130                 1
 UP bnd       x131                 1
 UP bnd       x132                 1
 UP bnd       x133                 1
 UP bnd       x134                 1
 UP bnd       x135                 1
 UP bnd       x136                 1
 UP bnd       x137                 1
 UP bnd       x138                 1
 UP bnd       x139                 1
 UP bnd       x140                 1
 UP bnd       x141                 1
 UP bnd       x142                 1
 UP bnd       x143                 1
 UP bnd       x144                 1
 UP bnd       x145                 1
 UP bnd       x146                 1
 UP bnd       x147                 1
 UP bnd       x148                 1
 UP bnd       x149                 1
 UP bnd       x150                 1
 UP bnd       x151                 1
 UP bnd       x152                 1
 UP bnd       x153                 1
 UP bnd       x154                 1
 UP bnd       x155                 1
 UP bnd       x156                 1
 UP bnd       x157                 1
 UP bnd       x158                 1
 UP bnd       x159                 1
 UP bnd       x160                 1
 UP bnd       x161                 1
 UP bnd       x162                 1
 UP bnd       x163                 1
 UP bnd       x164                 1
 UP bnd       x165                 1
 UP bnd       x166                 1
 UP bnd       x167                 1
 UP bnd       x168                 1
 UP bnd       x169                 1
 UP bnd       x170                 1
 UP bnd       x171                 1
 UP bnd       x172                 1
 UP bnd       x173                 1
 UP bnd       x174                 1
 UP bnd       x175                 1
 UP bnd       x176                 1
 UP bnd       x177                 1
 UP bnd       x178                 1
 UP bnd       x179                 1
 UP bnd       x180                 1
 UP bnd       x181                 1
 UP bnd       x182                 1
 UP bnd       x183                 1
 UP bnd       x184                 1
 UP bnd       x185                 1
 UP bnd       x186                 1
 UP bnd       x187                 1
 UP bnd       x188                 1
 UP bnd       x189                 1
 UP bnd       x190                 1
 UP bnd       x191                 1
 UP bnd       x192                 1
 UP bnd       x193                 1
 UP bnd       x194                 1
 UP bnd       x195                 1
 UP bnd       x196                 1
 UP bnd       x197                 1
 UP bnd       x198                 1
 UP bnd       x199                 1
 UP bnd       x200                 1
 UP bnd       x201                 1
 UP bnd       x202                 1
 UP bnd       x203                 1
 UP bnd       x204                 1
 UP bnd       x205                 1
 UP bnd       x206                 1
 UP bnd       x207                 1
 UP bnd       x208                 1
 UP bnd       x209                 1
 UP bnd       x210                 1
 UP bnd       x211                 1
 UP bnd       x212                 1
 UP bnd       x213                 1
 UP bnd       x214                 1
 UP bnd       x215                 1
 UP bnd       x216                 1
 UP bnd       x217                 1
 UP bnd       x218                 1
 UP bnd       x219                 1
 UP bnd       x220                 1
 UP bnd       x221                 1
 UP bnd       x222                 1
 UP bnd       x223                 1
 UP bnd       x224                 1
 UP bnd       x225                 1
 UP bnd       x226                 1
 UP bnd       x227                 1
 UP bnd       x228                 1
 UP bnd       x229                 1
 UP bnd       x230                 1
 UP bnd       x231                 1
 UP bnd       x232                 1
 UP bnd       x233                 1
 UP bnd       x234                 1
 UP bnd       x235                 1
 UP bnd       x236                 1
 UP bnd       x237                 1
 UP bnd       x238                 1
 UP bnd       x239                 1
 UP bnd       x240                 1
 UP bnd       x241                 1
 UP bnd       x242                 1
 UP bnd       x243                 1
 UP bnd       x244                 1
 UP bnd       x245                 1
 UP bnd       x246                 1
 UP bnd       x247                 1
 UP bnd       x248                 1
 UP bnd       x249                 1
 UP bnd       x250                 1
 UP bnd       x251                 1
 UP bnd       x252                 1
 UP bnd       x253                 1
 UP bnd       x254                 1
 UP bnd       x255                 1
 UP bnd       x256                 1
 UP bnd       x257                 1
 UP bnd       x258                 1
 UP bnd       x259                 1
 UP bnd       x260                 1
 UP bnd       x261                 1
 UP bnd       x262                 1
 UP bnd       x263                 1
 UP bnd       x264                 1
 UP bnd       x265                 1
 UP bnd       x266                 1
 UP bnd       x267                 1
 UP bnd       x268                 1
 UP bnd       x269                 1
 UP bnd       x270                 1
 UP bnd       x271                 1
 UP bnd       x272                 1
 UP bnd       x273                 1
 UP bnd       x274                 1
 UP bnd       x275                 1
 UP bnd       x276                 1
 UP bnd       x277                 1
 UP bnd       x278                 1
 UP bnd       x279                 1
 UP bnd       x280                 1
 UP bnd       x281                 1
 UP bnd       x282                 1
 UP bnd       x283                 1
 UP bnd       x284                 1
 UP bnd       x285                 1
 UP bnd       x286                 1
 UP bnd       x287                 1
 UP bnd       x288                 1
 UP bnd       x289                 1
 UP bnd       x290                 1
 UP bnd       x291                 1
 UP bnd       x292                 1
 UP bnd       x293                 1
 UP bnd       x294                 1
 UP bnd       x295                 1
 UP bnd       x296                 1
 UP bnd       x297                 1
 UP bnd       x298                 1
 UP bnd       x299                 1
 UP bnd       x300                 1
 UP bnd       x301                 1
 UP bnd       x302                 1
 UP bnd       x303                 1
 UP bnd       x304                 1
 UP bnd       x305                 1
 UP bnd       x306                 1
 UP bnd       x307                 1
 UP bnd       x308                 1
 UP bnd       x309                 1
 UP bnd       x310                 1
 UP bnd       x311                 1
 UP bnd       x312                 1
 UP bnd       x313                 1
 UP bnd       x314                 1
 UP bnd       x315                 1
 UP bnd       x316                 1
 UP bnd       x317                 1
 UP bnd       x318                 1
 UP bnd       x319                 1
 UP bnd       x320                 1
 UP bnd       x321                 1
 UP bnd       x322                 1
 UP bnd       x323                 1
 UP bnd       x324                 1
 UP bnd       x325                 1
 UP bnd       x326                 1
 UP bnd       x327                 1
 UP bnd       x328                 1
 UP bnd       x329                 1
 UP bnd       x330                 1
 UP bnd       x331                 1
 UP bnd       x332                 1
 UP bnd       x333                 1
 UP bnd       x334                 1
 UP bnd       x335                 1
 UP bnd       x336                 1
 UP bnd       x337                 1
 UP bnd       x338                 1
 UP bnd       x339                 1
 UP bnd       x340                 1
 UP bnd       x341                 1
 UP bnd       x342                 1
 UP bnd       x343                 1
 UP bnd       x344                 1
 UP bnd       x345                 1
 UP bnd       x346                 1
 UP bnd       x347                 1
 UP bnd       x348                 1
 UP bnd       x349                 1
 UP bnd       x350                 1
 UP bnd       x351                 1
 UP bnd       x352                 1
 UP bnd       x353                 1
 UP bnd       x354                 1
 UP bnd       x355                 1
 UP bnd       x356                 1
 UP bnd       x357                 1
 UP bnd       x358                 1
 UP bnd       x359                 1
 UP bnd       x360                 1
 UP bnd       x361                 1
 UP bnd       x362                 1
 UP bnd       x363                 1
 UP bnd       x364                 1
 UP bnd       x365                 1
 UP bnd       x366                 1
 UP bnd       x367                 1
 UP bnd       x368                 1
 UP bnd       x369                 1
 UP bnd       x370                 1
 UP bnd       x371                 1
 UP bnd       x372                 1
 UP bnd       x373                 1
 UP bnd       x374                 1
 UP bnd       x375                 1
 UP bnd       x376                 1
 UP bnd       x377                 1
 UP bnd       x378                 1
 UP bnd       x379                 1
 UP bnd       x380                 1
 UP bnd       x381                 1
 UP bnd       x382                 1
 UP bnd       x383                 1
 UP bnd       x384                 1
 UP bnd       x385                 1
 UP bnd       x386                 1
 UP bnd       x387                 1
 UP bnd       x388                 1
 UP bnd       x389                 1
 UP bnd       x390                 1
 UP bnd       x391                 1
 UP bnd       x392                 1
 UP bnd       x393                 1
 UP bnd       x394                 1
 UP bnd       x395                 1
 UP bnd       x396                 1
 UP bnd       x397                 1
 UP bnd       x398                 1
 UP bnd       x399                 1
 UP bnd       x400                 1
 UP bnd       x401                 1
 UP bnd       x402                 1
 UP bnd       x403                 1
 UP bnd       x404                 1
 UP bnd       x405                 1
 UP bnd       x406                 1
 UP bnd       x407                 1
 UP bnd       x408                 1
 UP bnd       x409                 1
 UP bnd       x410                 1
 UP bnd       x411                 1
 UP bnd       x412                 1
 UP bnd       x413                 1
 UP bnd       x414                 1
 UP bnd       x415                 1
 UP bnd       x416                 1
 UP bnd       x417                 1
 UP bnd       x418                 1
 UP bnd       x419                 1
 UP bnd       x420                 1
 UP bnd       x421                 1
 UP bnd       x422                 1
 UP bnd       x423                 1
 UP bnd       x424                 1
 UP bnd       x425                 1
 UP bnd       x426                 1
 UP bnd       x427                 1
 UP bnd       x428                 1
 UP bnd       x429                 1
 UP bnd       x430                 1
 UP bnd       x431                 1
 UP bnd       x432                 1
 UP bnd       x433                 1
 UP bnd       x434                 1
 UP bnd       x435                 1
 UP bnd       x436                 1
 UP bnd       x437                 1
 UP bnd       x438                 1
 UP bnd       x439                 1
 UP bnd       x440                 1
 UP bnd       x441                 1
 UP bnd       x442                 1
 UP bnd       x443                 1
 UP bnd       x444                 1
 UP bnd       x445                 1
 UP bnd       x446                 1
 UP bnd       x447                 1
 UP bnd       x448                 1
 UP bnd       x449                 1
 UP bnd       x450                 1
 UP bnd       x451                 1
 UP bnd       x452                 1
 UP bnd       x453                 1
 UP bnd       x454                 1
 UP bnd       x455                 1
 UP bnd       x456                 1
 UP bnd       x457                 1
 UP bnd       x458                 1
 UP bnd       x459                 1
 UP bnd       x460                 1
 UP bnd       x461                 1
 UP bnd       x462                 1
 UP bnd       x463                 1
 UP bnd       x464                 1
 UP bnd       x465                 1
 UP bnd       x466                 1
 UP bnd       x467                 1
 UP bnd       x468                 1
 UP bnd       x469                 1
 UP bnd       x470                 1
 UP bnd       x471                 1
 UP bnd       x472                 1
 UP bnd       x473                 1
 UP bnd       x474                 1
 UP bnd       x475                 1
 UP bnd       x476                 1
 UP bnd       x477                 1
 UP bnd       x478                 1
 UP bnd       x479                 1
 UP bnd       x480                 1
 UP bnd       x481                 1
 UP bnd       x482                 1
 UP bnd       x483                 1
 UP bnd       x484                 1
 UP bnd       x485                 1
 UP bnd       x486                 1
 UP bnd       x487                 1
 UP bnd       x488                 1
 UP bnd       x489                 1
 UP bnd       x490                 1
 UP bnd       x491                 1
 UP bnd       x492                 1
 UP bnd       x493                 1
 UP bnd       x494                 1
 UP bnd       x495                 1
 UP bnd       x496                 1
 UP bnd       x497                 1
 UP bnd       x498                 1
 UP bnd       x499                 1
 UP bnd       x500                 1
 UP bnd       x501                 1
 UP bnd       x502                 1
 UP bnd       x503                 1
 UP bnd       x504                 1
 UP bnd       x505                 1
 UP bnd       x506                 1
 UP bnd       x507                 1
 UP bnd       x508                 1
 UP bnd       x509                 1
 UP bnd       x510                 1
 UP bnd       x511                 1
 UP bnd       x512                 1
 UP bnd       x513                 1
 UP bnd       x514                 1
 UP bnd       x515                 1
 UP bnd       x516                 1
 UP bnd       x517                 1
 UP bnd       x518                 1
 UP bnd       x519                 1
 UP bnd       x520                 1
 UP bnd       x521                 1
 UP bnd       x522                 1
 UP bnd       x523                 1
 UP bnd       x524                 1
 UP bnd       x525                 1
 UP bnd       x526                 1
 UP bnd       x527                 1
 UP bnd       x528                 1
 UP bnd       x529                 1
 UP bnd       x530                 1
 UP bnd       x531                 1
 UP bnd       x532                 1
 UP bnd       x533                 1
 UP bnd       x534                 1
 UP bnd       x535                 1
 UP bnd       x536                 1
 UP bnd       x537                 1
 UP bnd       x538                 1
 UP bnd       x539                 1
 UP bnd       x540                 1
 UP bnd       x541                 1
 UP bnd       x542                 1
 UP bnd       x543                 1
 UP bnd       x544                 1
 UP bnd       x545                 1
 UP bnd       x546                 1
 UP bnd       x547                 1
 UP bnd       x548                 1
 UP bnd       x549                 1
 UP bnd       x550                 1
 UP bnd       x551                 1
 UP bnd       x552                 1
 UP bnd       x553                 1
 UP bnd       x554                 1
 UP bnd       x555                 1
 UP bnd       x556                 1
 UP bnd       x557                 1
 UP bnd       x558                 1
 UP bnd       x559                 1
 UP bnd       x560                 1
 UP bnd       x561                 1
 UP bnd       x562                 1
 UP bnd       x563                 1
 UP bnd       x564                 1
 UP bnd       x565                 1
 UP bnd       x566                 1
 UP bnd       x567                 1
 UP bnd       x568                 1
 UP bnd       x569                 1
 UP bnd       x570                 1
 UP bnd       x571                 1
 UP bnd       x572                 1
 UP bnd       x573                 1
 UP bnd       x574                 1
 UP bnd       x575                 1
 UP bnd       x576                 1
 UP bnd       x577                 1
 UP bnd       x578                 1
 UP bnd       x579                 1
 UP bnd       x580                 1
 UP bnd       x581                 1
 UP bnd       x582                 1
 UP bnd       x583                 1
 UP bnd       x584                 1
 UP bnd       x585                 1
 UP bnd       x586                 1
 UP bnd       x587                 1
 UP bnd       x588                 1
 UP bnd       x589                 1
 UP bnd       x590                 1
 UP bnd       x591                 1
 UP bnd       x592                 1
 UP bnd       x593                 1
 UP bnd       x594                 1
 UP bnd       x595                 1
 UP bnd       x596                 1
 UP bnd       x597                 1
 UP bnd       x598                 1
 UP bnd       x599                 1
 UP bnd       x600                 1
 UP bnd       x601                 1
 UP bnd       x602                 1
 UP bnd       x603                 1
 UP bnd       x604                 1
 UP bnd       x605                 1
 UP bnd       x606                 1
 UP bnd       x607                 1
 UP bnd       x608                 1
 UP bnd       x609                 1
 UP bnd       x610                 1
 UP bnd       x611                 1
 UP bnd       x612                 1
 UP bnd       x613                 1
 UP bnd       x614                 1
 UP bnd       x615                 1
 UP bnd       x616                 1
 UP bnd       x617                 1
 UP bnd       x618                 1
 UP bnd       x619                 1
 UP bnd       x620                 1
 UP bnd       x621                 1
 UP bnd       x622                 1
 UP bnd       x623                 1
 UP bnd       x624                 1
 UP bnd       x625                 1
 UP bnd       x626                 1
 UP bnd       x627                 1
 UP bnd       x628                 1
 UP bnd       x629                 1
 UP bnd       x630                 1
 UP bnd       x631                 1
 UP bnd       x632                 1
 UP bnd       x633                 1
 UP bnd       x634                 1
 UP bnd       x635                 1
 UP bnd       x636                 1
 UP bnd       x637                 1
 UP bnd       x638                 1
 UP bnd       x639                 1
 UP bnd       x640                 1
 UP bnd       x641                 1
 UP bnd       x642                 1
 UP bnd       x643                 1
 UP bnd       x644                 1
 UP bnd       x645                 1
 UP bnd       x646                 1
 UP bnd       x647                 1
 UP bnd       x648                 1
 UP bnd       x649                 1
 UP bnd       x650                 1
 UP bnd       x651                 1
 UP bnd       x652                 1
 UP bnd       x653                 1
 UP bnd       x654                 1
 UP bnd       x655                 1
 UP bnd       x656                 1
 UP bnd       x657                 1
 UP bnd       x658                 1
 UP bnd       x659                 1
 UP bnd       x660                 1
 UP bnd       x661                 1
 UP bnd       x662                 1
 UP bnd       x663                 1
 UP bnd       x664                 1
 UP bnd       x665                 1
 UP bnd       x666                 1
 UP bnd       x667                 1
 UP bnd       x668                 1
 UP bnd       x669                 1
 UP bnd       x670                 1
 UP bnd       x671                 1
 UP bnd       x672                 1
 UP bnd       x673                 1
 UP bnd       x674                 1
 UP bnd       x675                 1
 UP bnd       x676                 1
 UP bnd       x677                 1
 UP bnd       x678                 1
 UP bnd       x679                 1
 UP bnd       x680                 1
 UP bnd       x681                 1
 UP bnd       x682                 1
 UP bnd       x683                 1
 UP bnd       x684                 1
 UP bnd       x685                 1
 UP bnd       x686                 1
 UP bnd       x687                 1
 UP bnd       x688                 1
 UP bnd       x689                 1
 UP bnd       x690                 1
 UP bnd       x691                 1
 UP bnd       x692                 1
 UP bnd       x693                 1
 UP bnd       x694                 1
 UP bnd       x695                 1
 UP bnd       x696                 1
 UP bnd       x697                 1
 UP bnd       x698                 1
 UP bnd       x699                 1
 UP bnd       x700                 1
 UP bnd       x701                 1
 UP bnd       x702                 1
 UP bnd       x703                 1
 UP bnd       x704                 1
 UP bnd       x705                 1
 UP bnd       x706                 1
 UP bnd       x707                 1
 UP bnd       x708                 1
 UP bnd       x709                 1
 UP bnd       x710                 1
 UP bnd       x711                 1
 UP bnd       x712                 1
 UP bnd       x713                 1
 UP bnd       x714                 1
 UP bnd       x715                 1
 UP bnd       x716                 1
 UP bnd       x717                 1
 UP bnd       x718                 1
 UP bnd       x719                 1
 UP bnd       x720                 1
 UP bnd       x721                 1
 UP bnd       x722                 1
 UP bnd       x723                 1
 UP bnd       x724                 1
 UP bnd       x725                 1
 UP bnd       x726                 1
 UP bnd       x727                 1
 UP bnd       x728                 1
 UP bnd       x729                 1
 UP bnd       x730                 1
 UP bnd       x731                 1
 UP bnd       x732                 1
 UP bnd       x733                 1
 UP bnd       x734                 1
 UP bnd       x735                 1
 UP bnd       x736                 1
 UP bnd       x737                 1
 UP bnd       x738                 1
 UP bnd       x739                 1
 UP bnd       x740                 1
 UP bnd       x741                 1
 UP bnd       x742                 1
 UP bnd       x743                 1
 UP bnd       x744                 1
 UP bnd       x745                 1
 UP bnd       x746                 1
 UP bnd       x747                 1
 UP bnd       x748                 1
 UP bnd       x749                 1
 UP bnd       x750                 1
 UP bnd       x751                 1
 UP bnd       x752                 1
 UP bnd       x753                 1
 UP bnd       x754                 1
 UP bnd       x755                 1
 UP bnd       x756                 1
 UP bnd       x757                 1
 UP bnd       x758                 1
 UP bnd       x759                 1
 UP bnd       x760                 1
 UP bnd       x761                 1
 UP bnd       x762                 1
 UP bnd       x763                 1
 UP bnd       x764                 1
 UP bnd       x765                 1
 UP bnd       x766                 1
 UP bnd       x767                 1
 UP bnd       x768                 1
 UP bnd       x769                 1
 UP bnd       x770                 1
 UP bnd       x771                 1
 UP bnd       x772                 1
 UP bnd       x773                 1
 UP bnd       x774                 1
 UP bnd       x775                 1
 UP bnd       x776                 1
 UP bnd       x777                 1
 UP bnd       x778                 1
 UP bnd       x779                 1
 UP bnd       x780                 1
 UP bnd       x781                 1
 UP bnd       x782                 1
 UP bnd       x783                 1
 UP bnd       x784                 1
 UP bnd       x785                 1
 UP bnd       x786                 1
 UP bnd       x787                 1
 UP bnd       x788                 1
 UP bnd       x789                 1
 UP bnd       x790                 1
 UP bnd       x791                 1
 UP bnd       x792                 1
 UP bnd       x793                 1
 UP bnd       x794                 1
 UP bnd       x795                 1
 UP bnd       x796                 1
 UP bnd       x797                 1
 UP bnd       x798                 1
 UP bnd       x799                 1
 UP bnd       x800                 1
 UP bnd       x801                 1
 UP bnd       x802                 1
 UP bnd       x803                 1
 UP bnd       x804                 1
 UP bnd       x805                 1
 UP bnd       x806                 1
 UP bnd       x807                 1
 UP bnd       x808                 1
 UP bnd       x809                 1
 UP bnd       x810                 1
 UP bnd       x811                 1
 UP bnd       x812                 1
 UP bnd       x813                 1
 UP bnd       x814                 1
 UP bnd       x815                 1
 UP bnd       x816                 1
 UP bnd       x817                 1
 UP bnd       x818                 1
 UP bnd       x819                 1
 UP bnd       x820                 1
 UP bnd       x821                 1
 UP bnd       x822                 1
 UP bnd       x823                 1
 UP bnd       x824                 1
 UP bnd       x825                 1
 UP bnd       x826                 1
 UP bnd       x827                 1
 UP bnd       x828                 1
 UP bnd       x829                 1
 UP bnd       x830                 1
 UP bnd       x831                 1
 UP bnd       x832                 1
 UP bnd       x833                 1
 UP bnd       x834                 1
 UP bnd       x835                 1
 UP bnd       x836                 1
 UP bnd       x837                 1
 UP bnd       x838                 1
 UP bnd       x839                 1
 UP bnd       x840                 1
 UP bnd       x841                 1
 UP bnd       x842                 1
 UP bnd       x843                 1
 UP bnd       x844                 1
 UP bnd       x845                 1
 UP bnd       x846                 1
 UP bnd       x847                 1
 UP bnd       x848                 1
 UP bnd       x849                 1
 UP bnd       x850                 1
 UP bnd       x851                 1
 UP bnd       x852                 1
 UP bnd       x853                 1
 UP bnd       x854                 1
 UP bnd       x855                 1
 UP bnd       x856                 1
 UP bnd       x857                 1
 UP bnd       x858                 1
 UP bnd       x859                 1
 UP bnd       x860                 1
 UP bnd       x861                 1
 UP bnd       x862                 1
 UP bnd       x863                 1
 UP bnd       x864                 1
 UP bnd       x865                 1
 UP bnd       x866                 1
 UP bnd       x867                 1
 UP bnd       x868                 1
 UP bnd       x869                 1
 UP bnd       x870                 1
 UP bnd       x871                 1
 UP bnd       x872                 1
 UP bnd       x873                 1
 UP bnd       x874                 1
 UP bnd       x875                 1
 UP bnd       x876                 1
 UP bnd       x877                 1
 UP bnd       x878                 1
 UP bnd       x879                 1
 UP bnd       x880                 1
 UP bnd       x881                 1
 UP bnd       x882                 1
 UP bnd       x883                 1
 UP bnd       x884                 1
 UP bnd       x885                 1
 UP bnd       x886                 1
 UP bnd       x887                 1
 UP bnd       x888                 1
 UP bnd       x889                 1
 UP bnd       x890                 1
 UP bnd       x891                 1
 UP bnd       x892                 1
 UP bnd       x893                 1
 UP bnd       x894                 1
 UP bnd       x895                 1
 UP bnd       x896                 1
 UP bnd       x897                 1
 UP bnd       x898                 1
 UP bnd       x899                 1
 UP bnd       x900                 1
 UP bnd       x901                 1
 UP bnd       x902                 1
 UP bnd       x903                 1
 UP bnd       x904                 1
 UP bnd       x905                 1
 UP bnd       x906                 1
 UP bnd       x907                 1
 UP bnd       x908                 1
 UP bnd       x909                 1
 UP bnd       x910                 1
 UP bnd       x911                 1
 UP bnd       x912                 1
 UP bnd       x913                 1
 UP bnd       x914                 1
 UP bnd       x915                 1
 UP bnd       x916                 1
 UP bnd       x917                 1
 UP bnd       x918                 1
 UP bnd       x919                 1
 UP bnd       x920                 1
 UP bnd       x921                 1
 UP bnd       x922                 1
 UP bnd       x923                 1
 UP bnd       x924                 1
 UP bnd       x925                 1
 UP bnd       x926                 1
 UP bnd       x927                 1
 UP bnd       x928                 1
 UP bnd       x929                 1
 UP bnd       x930                 1
 UP bnd       x931                 1
 UP bnd       x932                 1
 UP bnd       x933                 1
 UP bnd       x934                 1
 UP bnd       x935                 1
 UP bnd       x936                 1
 UP bnd       x937                 1
 UP bnd       x938                 1
 UP bnd       x939                 1
 UP bnd       x940                 1
 UP bnd       x941                 1
 UP bnd       x942                 1
 UP bnd       x943                 1
 UP bnd       x944                 1
 UP bnd       x945                 1
 UP bnd       x946                 1
 UP bnd       x947                 1
 UP bnd       x948                 1
 UP bnd       x949                 1
 UP bnd       x950                 1
 UP bnd       x951                 1
 UP bnd       x952                 1
 UP bnd       x953                 1
 UP bnd       x954                 1
 UP bnd       x955                 1
 UP bnd       x956                 1
 UP bnd       x957                 1
 UP bnd       x958                 1
 UP bnd       x959                 1
 UP bnd       x960                 1
 UP bnd       x961                 1
 UP bnd       x962                 1
 UP bnd       x963                 1
 UP bnd       x964                 1
 UP bnd       x965                 1
 UP bnd       x966                 1
 UP bnd       x967                 1
 UP bnd       x968                 1
 UP bnd       x969                 1
 UP bnd       x970                 1
 UP bnd       x971                 1
 UP bnd       x972                 1
 UP bnd       x973                 1
 UP bnd       x974                 1
 UP bnd       x975                 1
 UP bnd       x976                 1
 UP bnd       x977                 1
 UP bnd       x978                 1
 UP bnd       x979                 1
 UP bnd       x980                 1
 UP bnd       x981                 1
 UP bnd       x982                 1
 UP bnd       x983                 1
 UP bnd       x984                 1
 UP bnd       x985                 1
 UP bnd       x986                 1
 UP bnd       x987                 1
 UP bnd       x988                 1
 UP bnd       x989                 1
 UP bnd       x990                 1
 UP bnd       x991                 1
 UP bnd       x992                 1
 UP bnd       x993                 1
 UP bnd       x994                 1
 UP bnd       x995                 1
 UP bnd       x996                 1
 UP bnd       x997                 1
 UP bnd       x998                 1
 UP bnd       x999                 1
 UP bnd       x1000                1
 UP bnd       x1001                1
 UP bnd       x1002                1
 UP bnd       x1003                1
 UP bnd       x1004                1
 UP bnd       x1005                1
 UP bnd       x1006                1
 UP bnd       x1007                1
 UP bnd       x1008                1
 UP bnd       x1009                1
 UP bnd       x1010                1
 UP bnd       x1011                1
 UP bnd       x1012                1
 UP bnd       x1013                1
 UP bnd       x1014                1
 UP bnd       x1015                1
 UP bnd       x1016                1
 UP bnd       x1017                1
 UP bnd       x1018                1
 UP bnd       x1019                1
 UP bnd       x1020                1
 UP bnd       x1021                1
 UP bnd       x1022                1
 UP bnd       x1023                1
 UP bnd       x1024                1
 UP bnd       x1025                1
 UP bnd       x1026                1
 UP bnd       x1027                1
 UP bnd       x1028                1
 UP bnd       x1029                1
 UP bnd       x1030                1
 UP bnd       x1031                1
 UP bnd       x1032                1
 UP bnd       x1033                1
 UP bnd       x1034                1
 UP bnd       x1035                1
 UP bnd       x1036                1
 UP bnd       x1037                1
 UP bnd       x1038                1
 UP bnd       x1039                1
 UP bnd       x1040                1
 UP bnd       x1041                1
 UP bnd       x1042                1
 UP bnd       x1043                1
 UP bnd       x1044                1
 UP bnd       x1045                1
 UP bnd       x1046                1
 UP bnd       x1047                1
 UP bnd       x1048                1
 UP bnd       x1049                1
 UP bnd       x1050                1
 UP bnd       x1051                1
 UP bnd       x1052                1
 UP bnd       x1053                1
 UP bnd       x1054                1
 UP bnd       x1055                1
 UP bnd       x1056                1
 UP bnd       x1057                1
 UP bnd       x1058                1
 UP bnd       x1059                1
 UP bnd       x1060                1
 UP bnd       x1061                1
 UP bnd       x1062                1
 UP bnd       x1063                1
 UP bnd       x1064                1
 UP bnd       x1065                1
 UP bnd       x1066                1
 UP bnd       x1067                1
 UP bnd       x1068                1
 UP bnd       x1069                1
 UP bnd       x1070                1
 UP bnd       x1071                1
 UP bnd       x1072                1
 UP bnd       x1073                1
 UP bnd       x1074                1
 UP bnd       x1075                1
 UP bnd       x1076                1
 UP bnd       x1077                1
 UP bnd       x1078                1
 UP bnd       x1079                1
 UP bnd       x1080                1
 UP bnd       x1081                1
 UP bnd       x1082                1
 UP bnd       x1083                1
 UP bnd       x1084                1
 UP bnd       x1085                1
 UP bnd       x1086                1
 UP bnd       x1087                1
 UP bnd       x1088                1
 UP bnd       x1089                1
 UP bnd       x1090                1
 UP bnd       x1091                1
 UP bnd       x1092                1
 UP bnd       x1093                1
 UP bnd       x1094                1
 UP bnd       x1095                1
 UP bnd       x1096                1
 UP bnd       x1097                1
 UP bnd       x1098                1
 UP bnd       x1099                1
 UP bnd       x1100                1
 UP bnd       x1101                1
 UP bnd       x1102                1
 UP bnd       x1103                1
 UP bnd       x1104                1
 UP bnd       x1105                1
 UP bnd       x1106                1
 UP bnd       x1107                1
 UP bnd       x1108                1
 UP bnd       x1109                1
 UP bnd       x1110                1
 UP bnd       x1111                1
 UP bnd       x1112                1
 UP bnd       x1113                1
 UP bnd       x1114                1
 UP bnd       x1115                1
 UP bnd       x1116                1
 UP bnd       x1117                1
 UP bnd       x1118                1
 UP bnd       x1119                1
 UP bnd       x1120                1
 UP bnd       x1121                1
 UP bnd       x1122                1
 UP bnd       x1123                1
 UP bnd       x1124                1
 UP bnd       x1125                1
 UP bnd       x1126                1
 UP bnd       x1127                1
 UP bnd       x1128                1
 UP bnd       x1129                1
 UP bnd       x1130                1
 UP bnd       x1131                1
 UP bnd       x1132                1
 UP bnd       x1133                1
 UP bnd       x1134                1
 UP bnd       x1135                1
 UP bnd       x1136                1
 UP bnd       x1137                1
 UP bnd       x1138                1
 UP bnd       x1139                1
 UP bnd       x1140                1
 UP bnd       x1141                1
 UP bnd       x1142                1
 UP bnd       x1143                1
 UP bnd       x1144                1
 UP bnd       x1145                1
 UP bnd       x1146                1
 UP bnd       x1147                1
 UP bnd       x1148                1
 UP bnd       x1149                1
 UP bnd       x1150                1
 UP bnd       x1151                1
 UP bnd       x1152                1
 UP bnd       x1153                1
 UP bnd       x1154                1
 UP bnd       x1155                1
 UP bnd       x1156                1
 UP bnd       x1157                1
 UP bnd       x1158                1
 UP bnd       x1159                1
 UP bnd       x1160                1
 UP bnd       x1161                1
 UP bnd       x1162                1
 UP bnd       x1163                1
 UP bnd       x1164                1
 UP bnd       x1165                1
 UP bnd       x1166                1
 UP bnd       x1167                1
 UP bnd       x1168                1
 UP bnd       x1169                1
 UP bnd       x1170                1
 UP bnd       x1171                1
 UP bnd       x1172                1
 UP bnd       x1173                1
 UP bnd       x1174                1
 UP bnd       x1175                1
 UP bnd       x1176                1
 UP bnd       x1177                1
 UP bnd       x1178                1
 UP bnd       x1179                1
 UP bnd       x1180                1
 UP bnd       x1181                1
 UP bnd       x1182                1
 UP bnd       x1183                1
 UP bnd       x1184                1
 UP bnd       x1185                1
 UP bnd       x1186                1
 UP bnd       x1187                1
 UP bnd       x1188                1
 UP bnd       x1189                1
 UP bnd       x1190                1
 UP bnd       x1191                1
 UP bnd       x1192                1
 UP bnd       x1193                1
 UP bnd       x1194                1
 UP bnd       x1195                1
 UP bnd       x1196                1
 UP bnd       x1197                1
 UP bnd       x1198                1
 UP bnd       x1199                1
 UP bnd       x1200                1
 UP bnd       x1201                1
 UP bnd       x1202                1
 UP bnd       x1203                1
 UP bnd       x1204                1
 UP bnd       x1205                1
 UP bnd       x1206                1
 UP bnd       x1207                1
 UP bnd       x1208                1
 UP bnd       x1209                1
 UP bnd       x1210                1
 UP bnd       x1211                1
 UP bnd       x1212                1
 UP bnd       x1213                1
 UP bnd       x1214                1
 UP bnd       x1215                1
 UP bnd       x1216                1
 UP bnd       x1217                1
 UP bnd       x1218                1
 UP bnd       x1219                1
 UP bnd       x1220                1
 UP bnd       x1221                1
 UP bnd       x1222                1
 UP bnd       x1223                1
 UP bnd       x1224                1
 UP bnd       x1225                1
 UP bnd       x1226                1
 UP bnd       x1227                1
 UP bnd       x1228                1
 UP bnd       x1229                1
 UP bnd       x1230                1
 UP bnd       x1231                1
 UP bnd       x1232                1
 UP bnd       x1233                1
 UP bnd       x1234                1
 UP bnd       x1235                1
 UP bnd       x1236                1
 UP bnd       x1237                1
 UP bnd       x1238                1
 UP bnd       x1239                1
 UP bnd       x1240                1
 UP bnd       x1241                1
 UP bnd       x1242                1
 UP bnd       x1243                1
 UP bnd       x1244                1
 UP bnd       x1245                1
 UP bnd       x1246                1
 UP bnd       x1247                1
 UP bnd       x1248                1
 UP bnd       x1249                1
 UP bnd       x1250                1
 UP bnd       x1251                1
 UP bnd       x1252                1
 UP bnd       x1253                1
 UP bnd       x1254                1
 UP bnd       x1255                1
 UP bnd       x1256                1
 UP bnd       x1257                1
 UP bnd       x1258                1
 UP bnd       x1259                1
 UP bnd       x1260                1
 UP bnd       x1261                1
 UP bnd       x1262                1
 UP bnd       x1263                1
 UP bnd       x1264                1
 UP bnd       x1265                1
 UP bnd       x1266                1
 UP bnd       x1267                1
 UP bnd       x1268                1
 UP bnd       x1269                1
 UP bnd       x1270                1
 UP bnd       x1271                1
 UP bnd       x1272                1
 UP bnd       x1273                1
 UP bnd       x1274                1
 UP bnd       x1275                1
 UP bnd       x1276                1
 UP bnd       x1277                1
 UP bnd       x1278                1
 UP bnd       x1279                1
 UP bnd       x1280                1
 UP bnd       x1281                1
 UP bnd       x1282                1
 UP bnd       x1283                1
 UP bnd       x1284                1
 UP bnd       x1285                1
 UP bnd       x1286                1
 UP bnd       x1287                1
 UP bnd       x1288                1
 UP bnd       x1289                1
 UP bnd       x1290                1
 UP bnd       x1291                1
 UP bnd       x1292                1
 UP bnd       x1293                1
 UP bnd       x1294                1
 UP bnd       x1295                1
 UP bnd       x1296                1
 UP bnd       x1297                1
 UP bnd       x1298                1
 UP bnd       x1299                1
 UP bnd       x1300                1
 UP bnd       x1301                1
 UP bnd       x1302                1
 UP bnd       x1303                1
 UP bnd       x1304                1
 UP bnd       x1305                1
 UP bnd       x1306                1
 UP bnd       x1307                1
 UP bnd       x1308                1
 UP bnd       x1309                1
 UP bnd       x1310                1
 UP bnd       x1311                1
 UP bnd       x1312                1
 UP bnd       x1313                1
 UP bnd       x1314                1
 UP bnd       x1315                1
 UP bnd       x1316                1
 UP bnd       x1317                1
 UP bnd       x1318                1
 UP bnd       x1319                1
 UP bnd       x1320                1
 UP bnd       x1321                1
 UP bnd       x1322                1
 UP bnd       x1323                1
 UP bnd       x1324                1
 UP bnd       x1325                1
 UP bnd       x1326                1
 UP bnd       x1327                1
 UP bnd       x1328                1
 UP bnd       x1329                1
 UP bnd       x1330                1
 UP bnd       x1331                1
 UP bnd       x1332                1
 UP bnd       x1333                1
 UP bnd       x1334                1
 UP bnd       x1335                1
 UP bnd       x1336                1
 UP bnd       x1337                1
 UP bnd       x1338                1
 UP bnd       x1339                1
 UP bnd       x1340                1
 UP bnd       x1341                1
 UP bnd       x1342                1
 UP bnd       x1343                1
 UP bnd       x1344                1
 UP bnd       x1345                1
 UP bnd       x1346                1
 UP bnd       x1347                1
 UP bnd       x1348                1
 UP bnd       x1349                1
 UP bnd       x1350                1
 UP bnd       x1351                1
 UP bnd       x1352                1
 UP bnd       x1353                1
 UP bnd       x1354                1
 UP bnd       x1355                1
 UP bnd       x1356                1
 UP bnd       x1357                1
 UP bnd       x1358                1
 UP bnd       x1359                1
 UP bnd       x1360                1
 UP bnd       x1361                1
 UP bnd       x1362                1
 UP bnd       x1363                1
 UP bnd       x1364                1
 UP bnd       x1365                1
 UP bnd       x1366                1
 UP bnd       x1367                1
 UP bnd       x1368                1
 UP bnd       x1369                1
 UP bnd       x1370                1
 UP bnd       x1371                1
 UP bnd       x1372                1
 UP bnd       x1373                1
 UP bnd       x1374                1
 UP bnd       x1375                1
 UP bnd       x1376                1
 UP bnd       x1377                1
 UP bnd       x1378                1
 UP bnd       x1379                1
 UP bnd       x1380                1
 UP bnd       x1381                1
 UP bnd       x1382                1
 UP bnd       x1383                1
 UP bnd       x1384                1
 UP bnd       x1385                1
 UP bnd       x1386                1
 UP bnd       x1387                1
 UP bnd       x1388                1
 UP bnd       x1389                1
 UP bnd       x1390                1
 UP bnd       x1391                1
 UP bnd       x1392                1
 UP bnd       x1393                1
ENDATA
