NAME           
ROWS
 N  obj     
 G  c1      
 G  c2      
 G  c3      
 G  c4      
 G  c5      
 G  c6      
 G  c7      
 G  c8      
 G  c9      
 G  c10     
 G  c11     
 G  c12     
 G  c13     
 G  c14     
 G  c15     
 G  c16     
 G  c17     
 G  c18     
 G  c19     
 G  c20     
 G  c21     
 G  c22     
 G  c23     
 G  c24     
 G  c25     
 G  c26     
 G  c27     
 G  c28     
 G  c29     
 G  c30     
 G  c31     
 G  c32     
 G  c33     
 G  c34     
 G  c35     
 G  c36     
 G  c37     
 G  c38     
 G  c39     
 G  c40     
 G  c41     
 G  c42     
 G  c43     
 G  c44     
 G  c45     
 G  c46     
 G  c47     
 G  c48     
 G  c49     
 G  c50     
 G  c51     
 G  c52     
 G  c53     
 G  c54     
 G  c55     
 G  c56     
 G  c57     
 G  c58     
 G  c59     
 G  c60     
 G  c61     
 G  c62     
 G  c63     
 G  c64     
 G  c65     
 G  c66     
 G  c67     
 G  c68     
 G  c69     
 G  c70     
 G  c71     
 G  c72     
 G  c73     
 G  c74     
 G  c75     
 G  c76     
 G  c77     
 G  c78     
 G  c79     
 G  c80     
 G  c81     
 G  c82     
 G  c83     
 G  c84     
 G  c85     
 G  c86     
 G  c87     
 G  c88     
 G  c89     
 G  c90     
 G  c91     
 G  c92     
 G  c93     
 G  c94     
 G  c95     
 G  c96     
 G  c97     
 G  c98     
 G  c99     
 G  c100    
 G  c101    
 G  c102    
 G  c103    
 G  c104    
 G  c105    
 G  c106    
 G  c107    
 G  c108    
 G  c109    
 G  c110    
 G  c111    
 G  c112    
 G  c113    
 G  c114    
 G  c115    
 G  c116    
 G  c117    
 G  c118    
 G  c119    
 G  c120    
 G  c121    
 G  c122    
 G  c123    
 G  c124    
 G  c125    
 G  c126    
 G  c127    
 G  c128    
 G  c129    
 G  c130    
 G  c131    
 G  c132    
 G  c133    
 G  c134    
 G  c135    
 G  c136    
 G  c137    
 G  c138    
 G  c139    
 G  c140    
 G  c141    
 G  c142    
 G  c143    
 G  c144    
 G  c145    
 G  c146    
 G  c147    
 G  c148    
 G  c149    
 G  c150    
 G  c151    
 G  c152    
 G  c153    
 G  c154    
 G  c155    
 G  c156    
 G  c157    
 G  c158    
 G  c159    
 G  c160    
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x1        c1                   1   c2                   1
    x1        c4                  -1   c6                  -1
    x2        c1                   1   c3                   1
    x2        c4                   1   c7                  -1
    x2        c8                  -1
    x3        c1                   1   c2                  -1
    x3        c3                  -1   c12                  1
    x3        c14                 -1
    x4        c2                   1   c3                  -1
    x4        c62                  1   c63                 -1
    x4        c64                 -1
    x5        c4                   1   c5                  -1
    x5        c6                  -1   c66                  1
    x6        c5                   1   c9                   1
    x6        c10                  1   c12                 -1
    x6        c13                 -1   c14                 -1
    x7        c5                   1   c6                  -1
    x7        c118                -1   c124                 1
    x7        c153                -1
    x8        c7                   1   c8                  -1
    x8        c89                  1   c96                 -1
    x8        c113                -1
    x9        c7                   1   c9                   1
    x9        c10                 -1   c11                 -1
    x10       c8                   1   c9                  -1
    x10       c15                  1   c16                 -1
    x10       c67                 -1
    x11       c10                  1   c11                 -1
    x11       c42                  1   c45                 -1
    x12       c11                  1   c13                  1
    x12       c14                  1   c18                 -1
    x12       c39                 -1
    x13       c12                  1   c13                 -1
    x13       c63                  1   c102                -1
    x14       c15                  1   c16                  1
    x14       c17                 -1   c98                 -1
    x15       c15                  1   c17                  1
    x15       c29                 -1   c31                 -1
    x16       c16                  1   c17                  1
    x16       c18                 -1   c20                 -1
    x16       c22                 -1
    x17       c18                  1   c19                 -1
    x17       c21                 -1   c22                 -1
    x17       c67                  1
    x18       c19                  1   c20                 -1
    x18       c75                  1   c76                 -1
    x18       c77                 -1   c79                  1
    x18       c104                 1   c123                -1
    x19       c19                  1   c20                  1
    x19       c21                 -1   c22                 -1
    x19       c158                -1
    x20       c21                  1   c69                 -1
    x20       c71                 -1   c81                  1
    x21       c23                  1   c24                  1
    x21       c25                 -1   c26                 -1
    x21       c60                  1
    x22       c23                  1   c24                 -1
    x22       c67                  1   c104                -1
    x23       c23                  1   c24                  1
    x23       c26                  1   c30                 -1
    x23       c129                -1
    x24       c25                  1   c33                  1
    x24       c34                  1   c36                  1
    x24       c38                 -1   c40                 -1
    x25       c25                  1   c26                 -1
    x25       c46                  1   c47                 -1
    x25       c48                 -1   c137                 1
    x26       c27                  1   c29                  1
    x26       c30                 -1   c31                 -1
    x26       c150                -1   c156                 1
    x27       c27                  1   c28                  1
    x27       c29                 -1   c91                 -1
    x27       c92                 -1
    x28       c27                  1   c28                 -1
    x28       c53                  1   c54                 -1
    x28       c148                -1
    x29       c28                  1   c32                 -1
    x29       c35                 -1   c37                 -1
    x29       c125                 1
    x30       c30                  1   c31                 -1
    x30       c69                 -1   c112                 1
    x30       c114                 1
    x31       c32                  1   c36                 -1
    x31       c37                 -1   c62                  1
    x31       c109                -1
    x32       c32                  1   c33                 -1
    x32       c65                 -1   c151                 1
    x33       c33                  1   c34                 -1
    x33       c35                 -1   c110                 1
    x33       c128                 1
    x34       c34                  1   c35                 -1
    x34       c75                  1   c97                 -1
    x35       c36                  1   c37                 -1
    x35       c63                  1   c64                 -1
    x35       c78                  1   c146                -1
    x36       c38                  1   c39                 -1
    x36       c68                 -1   c147                 1
    x37       c38                  1   c39                  1
    x37       c40                 -1   c41                 -1
    x37       c49                 -1
    x38       c40                  1   c41                 -1
    x38       c46                 -1   c122                 1
    x39       c41                  1   c42                 -1
    x39       c45                 -1   c49                 -1
    x39       c160                 1
    x40       c42                  1   c43                  1
    x40       c46                 -1   c48                 -1
    x41       c43                  1   c44                  1
    x41       c45                 -1   c121                 1
    x41       c137                -1
    x42       c43                  1   c44                 -1
    x42       c94                  1   c115                -1
    x42       c140                -1
    x43       c44                  1   c47                  1
    x43       c49                 -1   c72                 -1
    x44       c47                  1   c48                 -1
    x44       c106                -1   c125                 1
    x45       c50                  1   c52                  1
    x45       c53                 -1   c54                 -1
    x45       c72                  1   c99                  1
    x45       c100                 1
    x46       c50                  1   c51                  1
    x46       c111                -1   c141                -1
    x47       c50                  1   c51                  1
    x47       c73                 -1   c74                 -1
    x48       c51                  1   c61                 -1
    x48       c79                 -1   c94                  1
    x48       c113                -1   c124                -1
    x49       c52                  1   c56                 -1
    x49       c66                 -1   c105                -1
    x49       c110                 1
    x50       c52                 -1   c53                 -1
    x50       c54                 -1   c75                  1
    x50       c76                  1   c110                 1
    x50       c132                -1
    x51       c55                  1   c131                 1
    x51       c146                -1   c160                -1
    x52       c55                  1   c95                 -1
    x52       c124                -1   c153                 1
    x53       c55                 -1   c80                 -1
    x53       c121                 1   c147                 1
    x53       c155                 1   c159                 1
    x54       c56                  1   c70                 -1
    x54       c71                 -1   c122                 1
    x55       c56                  1   c60                 -1
    x55       c61                 -1   c108                 1
    x56       c57                  1   c58                 -1
    x56       c88                 -1   c90                  1
    x57       c57                  1   c58                  1
    x57       c81                 -1   c93                  1
    x57       c129                -1   c133                -1
    x58       c57                 -1   c59                 -1
    x58       c96                  1   c159                 1
    x59       c58                 -1   c70                  1
    x59       c90                  1   c91                 -1
    x59       c107                 1
    x60       c59                 -1   c117                 1
    x60       c143                -1   c151                 1
    x61       c59                  1   c80                  1
    x61       c91                  1   c92                 -1
    x61       c137                -1   c153                -1
    x62       c60                  1   c61                 -1
    x62       c87                  1   c88                 -1
    x62       c143                -1
    x63       c62                  1   c64                  1
    x63       c135                -1   c154                -1
    x64       c65                  1   c86                  1
    x64       c118                -1   c144                -1
    x64       c160                -1
    x65       c65                  1   c129                -1
    x65       c149                 1   c151                -1
    x65       c155                 1
    x66       c66                 -1   c68                 -1
    x66       c95                  1   c152                 1
    x67       c68                  1   c97                  1
    x67       c103                -1   c136                -1
    x67       c157                -1   c158                 1
    x68       c69                 -1   c76                 -1
    x68       c82                  1   c85                  1
    x68       c99                  1   c152                 1
    x69       c70                 -1   c71                 -1
    x69       c123                 1   c142                 1
    x70       c72                  1   c86                  1
    x70       c95                  1   c102                -1
    x70       c154                -1
    x71       c73                 -1   c74                 -1
    x71       c112                 1   c142                 1
    x72       c73                  1   c74                 -1
    x72       c94                 -1   c103                 1
    x72       c138                -1
    x73       c77                 -1   c101                 1
    x73       c107                 1   c112                -1
    x73       c120                -1
    x74       c77                  1   c83                  1
    x74       c84                 -1   c85                 -1
    x75       c78                 -1   c93                  1
    x75       c130                -1   c149                 1
    x76       c78                  1   c84                  1
    x76       c126                -1   c150                -1
    x77       c79                 -1   c114                -1
    x77       c115                 1   c139                 1
    x78       c80                 -1   c104                 1
    x78       c133                -1   c139                 1
    x79       c81                 -1   c101                -1
    x79       c108                 1   c120                 1
    x80       c82                  1   c83                 -1
    x80       c93                 -1   c109                 1
    x80       c111                 1   c154                 1
    x81       c82                  1   c83                  1
    x81       c118                -1   c159                -1
    x82       c84                  1   c85                 -1
    x82       c96                  1   c103                 1
    x82       c116                -1   c126                -1
    x82       c134                -1
    x83       c86                 -1   c117                 1
    x83       c120                -1   c125                 1
    x83       c130                 1   c139                -1
    x83       c148                -1
    x84       c87                 -1   c100                -1
    x84       c113                 1   c157                 1
    x85       c87                 -1   c88                 -1
    x85       c122                 1   c156                 1
    x86       c89                 -1   c132                 1
    x86       c133                -1   c145                 1
    x87       c89                  1   c97                  1
    x87       c148                -1   c156                -1
    x87       c157                -1
    x88       c90                  1   c92                  1
    x88       c134                -1   c140                -1
    x89       c98                 -1   c101                 1
    x89       c102                -1   c119                 1
    x90       c98                  1   c121                -1
    x90       c134                -1   c142                 1
    x91       c99                  1   c100                -1
    x91       c108                -1   c131                -1
    x91       c135                 1   c150                 1
    x92       c105                 1   c106                 1
    x92       c107                 1   c126                -1
    x92       c131                -1   c158                -1
    x93       c105                 1   c106                 1
    x93       c130                -1   c145                -1
    x94       c109                -1   c116                 1
    x94       c127                -1   c140                 1
    x95       c111                -1   c123                -1
    x95       c136                 1   c138                 1
    x96       c114                 1   c119                -1
    x96       c141                 1   c145                -1
    x97       c116                 1   c117                -1
    x97       c119                 1   c127                -1
    x97       c141                -1   c152                -1
    x98       c127                -1   c128                -1
    x98       c143                 1   c144                 1
    x98       c155                -1
    x99       c128                -1   c136                 1
    x99       c146                -1   c147                 1
    x100      c132                -1   c138                 1
    x100      c144                 1   c149                -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       c1                   1   c3                  -1
    rhs       c6                  -2   c8                  -1
    rhs       c11                 -1   c13                 -1
    rhs       c14                 -1   c15                  1
    rhs       c18                 -1   c20                 -1
    rhs       c21                 -1   c22                 -2
    rhs       c23                  1   c26                 -1
    rhs       c27                  1   c29                 -1
    rhs       c30                 -1   c31                 -2
    rhs       c35                 -2   c37                 -2
    rhs       c39                 -1   c40                 -1
    rhs       c41                 -1   c43                  1
    rhs       c45                 -2   c46                 -1
    rhs       c48                 -2   c49                 -2
    rhs       c50                  1   c51                  1
    rhs       c53                 -1   c54                 -2
    rhs       c58                 -1   c59                 -1
    rhs       c61                 -2   c62                  1
    rhs       c64                 -1   c66                 -1
    rhs       c68                 -1   c69                 -2
    rhs       c70                 -1   c71                 -2
    rhs       c73                 -1   c74                 -2
    rhs       c75                  1   c76                 -1
    rhs       c77                 -1   c79                 -1
    rhs       c80                 -1   c81                 -1
    rhs       c82                  1   c85                 -1
    rhs       c87                 -1   c88                 -2
    rhs       c90                  1   c91                 -1
    rhs       c92                 -1   c98                 -1
    rhs       c99                  1   c100                -1
    rhs       c102                -2   c107                 1
    rhs       c109                -1   c110                 1
    rhs       c111                -1   c113                -1
    rhs       c118                -2   c120                -1
    rhs       c122                 1   c123                -1
    rhs       c124                -1   c125                 1
    rhs       c126                -2   c127                -2
    rhs       c128                -1   c129                -2
    rhs       c130                -1   c131                -1
    rhs       c132                -1   c133                -2
    rhs       c134                -2   c137                -1
    rhs       c140                -1   c141                -1
    rhs       c142                 1   c143                -1
    rhs       c145                -1   c146                -2
    rhs       c147                 1   c148                -2
    rhs       c150                -1   c153                -1
    rhs       c154                -1   c157                -1
    rhs       c158                -1   c160                -1
BOUNDS
 UP bnd       x1                   1
 UP bnd       x2                   1
 UP bnd       x3                   1
 UP bnd       x4                   1
 UP bnd       x5                   1
 UP bnd       x6                   1
 UP bnd       x7                   1
 UP bnd       x8                   1
 UP bnd       x9                   1
 UP bnd       x10                  1
 UP bnd       x11                  1
 UP bnd       x12                  1
 UP bnd       x13                  1
 UP bnd       x14                  1
 UP bnd       x15                  1
 UP bnd       x16                  1
 UP bnd       x17                  1
 UP bnd       x18                  1
 UP bnd       x19                  1
 UP bnd       x20                  1
 UP bnd       x21                  1
 UP bnd       x22                  1
 UP bnd       x23                  1
 UP bnd       x24                  1
 UP bnd       x25                  1
 UP bnd       x26                  1
 UP bnd       x27                  1
 UP bnd       x28                  1
 UP bnd       x29                  1
 UP bnd       x30                  1
 UP bnd       x31                  1
 UP bnd       x32                  1
 UP bnd       x33                  1
 UP bnd       x34                  1
 UP bnd       x35                  1
 UP bnd       x36                  1
 UP bnd       x37                  1
 UP bnd       x38                  1
 UP bnd       x39                  1
 UP bnd       x40                  1
 UP bnd       x41                  1
 UP bnd       x42                  1
 UP bnd       x43                  1
 UP bnd       x44                  1
 UP bnd       x45                  1
 UP bnd       x46                  1
 UP bnd       x47                  1
 UP bnd       x48                  1
 UP bnd       x49                  1
 UP bnd       x50                  1
 UP bnd       x51                  1
 UP bnd       x52                  1
 UP bnd       x53                  1
 UP bnd       x54                  1
 UP bnd       x55                  1
 UP bnd       x56                  1
 UP bnd       x57                  1
 UP bnd       x58                  1
 UP bnd       x59                  1
 UP bnd       x60                  1
 UP bnd       x61                  1
 UP bnd       x62                  1
 UP bnd       x63                  1
 UP bnd       x64                  1
 UP bnd       x65                  1
 UP bnd       x66                  1
 UP bnd       x67                  1
 UP bnd       x68                  1
 UP bnd       x69                  1
 UP bnd       x70                  1
 UP bnd       x71                  1
 UP bnd       x72                  1
 UP bnd       x73                  1
 UP bnd       x74                  1
 UP bnd       x75                  1
 UP bnd       x76                  1
 UP bnd       x77                  1
 UP bnd       x78                  1
 UP bnd       x79                  1
 UP bnd       x80                  1
 UP bnd       x81                  1
 UP bnd       x82                  1
 UP bnd       x83                  1
 UP bnd       x84                  1
 UP bnd       x85                  1
 UP bnd       x86                  1
 UP bnd       x87                  1
 UP bnd       x88                  1
 UP bnd       x89                  1
 UP bnd       x90                  1
 UP bnd       x91                  1
 UP bnd       x92                  1
 UP bnd       x93                  1
 UP bnd       x94                  1
 UP bnd       x95                  1
 UP bnd       x96                  1
 UP bnd       x97                  1
 UP bnd       x98                  1
 UP bnd       x99                  1
 UP bnd       x100                 1
ENDATA
