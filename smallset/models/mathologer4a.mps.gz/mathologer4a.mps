NAME 
ROWS
 N  OBJ
 E  con1a   
 L  extended2
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    k         con1a     5
    z1        con1a     -1
    z1        extended2  1
    z2        con1a     -4
    z2        extended2  1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      con1a     -3
    RHS1      extended2  1
BOUNDS
* Note: variable lower bounds are 0 unless specified otherwise
 LI BND1      k         0
 BV BND1      z1      
 BV BND1      z2      
ENDATA
