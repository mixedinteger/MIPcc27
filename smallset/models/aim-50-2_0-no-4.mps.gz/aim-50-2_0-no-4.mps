NAME           
ROWS
 N  obj     
 G  c1      
 G  c2      
 G  c3      
 G  c4      
 G  c5      
 G  c6      
 G  c7      
 G  c8      
 G  c9      
 G  c10     
 G  c11     
 G  c12     
 G  c13     
 G  c14     
 G  c15     
 G  c16     
 G  c17     
 G  c18     
 G  c19     
 G  c20     
 G  c21     
 G  c22     
 G  c23     
 G  c24     
 G  c25     
 G  c26     
 G  c27     
 G  c28     
 G  c29     
 G  c30     
 G  c31     
 G  c32     
 G  c33     
 G  c34     
 G  c35     
 G  c36     
 G  c37     
 G  c38     
 G  c39     
 G  c40     
 G  c41     
 G  c42     
 G  c43     
 G  c44     
 G  c45     
 G  c46     
 G  c47     
 G  c48     
 G  c49     
 G  c50     
 G  c51     
 G  c52     
 G  c53     
 G  c54     
 G  c55     
 G  c56     
 G  c57     
 G  c58     
 G  c59     
 G  c60     
 G  c61     
 G  c62     
 G  c63     
 G  c64     
 G  c65     
 G  c66     
 G  c67     
 G  c68     
 G  c69     
 G  c70     
 G  c71     
 G  c72     
 G  c73     
 G  c74     
 G  c75     
 G  c76     
 G  c77     
 G  c78     
 G  c79     
 G  c80     
 G  c81     
 G  c82     
 G  c83     
 G  c84     
 G  c85     
 G  c86     
 G  c87     
 G  c88     
 G  c89     
 G  c90     
 G  c91     
 G  c92     
 G  c93     
 G  c94     
 G  c95     
 G  c96     
 G  c97     
 G  c98     
 G  c99     
 G  c100    
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x1        c1                   1   c2                   1
    x1        c3                   1   c4                  -1
    x1        c5                  -1   c6                  -1
    x2        c1                   1   c3                  -1
    x2        c15                  1   c16                  1
    x2        c17                 -1   c98                 -1
    x3        c1                   1   c2                   1
    x3        c10                  1   c11                 -1
    x3        c12                 -1   c13                 -1
    x4        c2                  -1   c19                  1
    x4        c20                  1   c21                  1
    x4        c23                 -1   c73                 -1
    x5        c3                   1   c7                   1
    x5        c8                   1   c9                  -1
    x5        c10                 -1   c75                 -1
    x6        c4                   1   c5                  -1
    x6        c65                  1   c66                  1
    x6        c70                 -1   c71                 -1
    x7        c4                   1   c5                   1
    x7        c6                  -1   c8                  -1
    x7        c54                 -1   c58                  1
    x8        c6                   1   c7                  -1
    x8        c68                  1   c78                 -1
    x8        c79                 -1   c97                  1
    x9        c7                   1   c8                  -1
    x9        c45                  1   c58                 -1
    x9        c64                  1   c89                 -1
    x10       c9                   1   c11                  1
    x10       c13                  1   c17                 -1
    x10       c18                 -1   c23                 -1
    x11       c9                   1   c10                 -1
    x11       c42                  1   c55                 -1
    x11       c57                 -1   c58                  1
    x12       c11                  1   c12                 -1
    x12       c53                  1   c54                 -1
    x12       c74                  1   c81                 -1
    x13       c12                  1   c13                 -1
    x13       c14                  1   c15                  1
    x13       c16                 -1   c28                 -1
    x14       c14                  1   c15                 -1
    x14       c29                 -1   c41                 -1
    x14       c69                  1   c90                  1
    x15       c14                  1   c16                  1
    x15       c17                  1   c22                 -1
    x15       c23                 -1   c79                 -1
    x16       c18                  1   c20                  1
    x16       c21                 -1   c22                 -1
    x16       c26                  1   c27                 -1
    x17       c18                  1   c19                 -1
    x17       c20                 -1   c75                 -1
    x17       c82                  1   c83                  1
    x18       c19                  1   c49                 -1
    x18       c50                 -1   c77                 -1
    x18       c85                  1   c89                  1
    x19       c21                  1   c22                 -1
    x19       c29                 -1   c48                  1
    x19       c51                 -1   c59                  1
    x20       c24                  1   c25                  1
    x20       c61                  1   c62                 -1
    x20       c63                 -1   c82                 -1
    x21       c24                 -1   c25                 -1
    x21       c40                 -1   c43                  1
    x21       c86                  1   c98                  1
    x22       c24                 -1   c39                  1
    x22       c40                  1   c78                 -1
    x22       c79                 -1   c95                  1
    x23       c25                 -1   c29                  1
    x23       c31                  1   c32                  1
    x23       c33                 -1   c34                 -1
    x24       c26                 -1   c27                 -1
    x24       c55                  1   c56                  1
    x24       c76                 -1   c77                  1
    x25       c26                  1   c27                  1
    x25       c60                  1   c74                 -1
    x25       c86                 -1   c91                 -1
    x26       c28                  1   c67                  1
    x26       c73                  1   c80                 -1
    x26       c83                 -1   c98                 -1
    x27       c28                 -1   c42                 -1
    x27       c48                 -1   c72                  1
    x27       c80                  1   c88                  1
    x28       c30                  1   c32                  1
    x28       c43                  1   c52                 -1
    x28       c56                 -1   c57                 -1
    x29       c30                 -1   c35                 -1
    x29       c36                 -1   c61                  1
    x29       c62                  1   c87                  1
    x30       c30                  1   c31                 -1
    x30       c34                 -1   c52                 -1
    x30       c62                  1   c66                  1
    x31       c31                  1   c32                 -1
    x31       c37                 -1   c38                 -1
    x31       c65                  1   c89                  1
    x32       c33                  1   c34                 -1
    x32       c46                  1   c47                 -1
    x32       c80                  1   c88                 -1
    x33       c33                 -1   c35                 -1
    x33       c44                  1   c45                 -1
    x33       c66                  1   c85                  1
    x34       c35                 -1   c36                 -1
    x34       c43                 -1   c49                  1
    x34       c53                  1   c54                  1
    x35       c36                 -1   c41                 -1
    x35       c50                 -1   c65                  1
    x35       c67                  1   c76                  1
    x36       c37                  1   c39                  1
    x36       c40                 -1   c42                 -1
    x36       c53                 -1   c92                  1
    x37       c37                  1   c38                 -1
    x37       c71                  1   c83                  1
    x37       c97                 -1   c100                -1
    x38       c38                  1   c39                 -1
    x38       c41                 -1   c44                  1
    x38       c48                  1   c92                 -1
    x39       c44                  1   c45                  1
    x39       c67                  1   c77                 -1
    x39       c91                 -1   c97                 -1
    x40       c46                 -1   c47                 -1
    x40       c68                  1   c69                 -1
    x40       c75                  1   c93                  1
    x41       c46                 -1   c47                 -1
    x41       c64                 -1   c94                  1
    x41       c95                  1
    x42       c49                 -1   c50                 -1
    x42       c78                 -1   c84                  1
    x42       c87                  1   c99                  1
    x43       c51                 -1   c52                 -1
    x43       c74                 -1   c81                  1
    x43       c84                  1   c87                  1
    x44       c51                  1   c59                  1
    x44       c60                  1   c86                 -1
    x44       c100                -1
    x45       c55                  1   c56                  1
    x45       c57                 -1   c71                  1
    x45       c81                 -1   c91                 -1
    x46       c59                 -1   c60                 -1
    x46       c72                 -1   c82                  1
    x46       c94                  1   c95                  1
    x47       c61                  1   c63                  1
    x47       c85                 -1   c92                 -1
    x48       c63                  1   c68                 -1
    x48       c69                 -1   c70                 -1
    x48       c72                  1   c76                  1
    x49       c64                 -1   c70                 -1
    x49       c73                 -1   c88                  1
    x49       c90                  1   c93                  1
    x50       c84                 -1   c90                  1
    x50       c93                 -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       c1                   1   c5                  -1
    rhs       c6                  -1   c8                  -1
    rhs       c10                 -1   c12                 -1
    rhs       c13                 -1   c14                  1
    rhs       c17                 -1   c22                 -2
    rhs       c23                 -2   c24                 -1
    rhs       c25                 -1   c27                 -1
    rhs       c28                 -1   c29                 -1
    rhs       c33                 -1   c34                 -2
    rhs       c35                 -2   c36                 -2
    rhs       c38                 -1   c40                 -1
    rhs       c41                 -2   c42                 -1
    rhs       c44                  1   c46                 -1
    rhs       c47                 -2   c49                 -1
    rhs       c50                 -2   c51                 -1
    rhs       c52                 -2   c54                 -1
    rhs       c57                 -2   c61                  1
    rhs       c64                 -1   c65                  1
    rhs       c66                  1   c67                  1
    rhs       c69                 -1   c70                 -2
    rhs       c73                 -1   c74                 -1
    rhs       c75                 -1   c77                 -1
    rhs       c78                 -2   c79                 -2
    rhs       c81                 -1   c86                 -1
    rhs       c87                  1   c90                  1
    rhs       c91                 -2   c92                 -1
    rhs       c94                  1   c95                  1
    rhs       c97                 -1   c98                 -1
    rhs       c100                -1
BOUNDS
 UP bnd       x1                   1
 UP bnd       x2                   1
 UP bnd       x3                   1
 UP bnd       x4                   1
 UP bnd       x5                   1
 UP bnd       x6                   1
 UP bnd       x7                   1
 UP bnd       x8                   1
 UP bnd       x9                   1
 UP bnd       x10                  1
 UP bnd       x11                  1
 UP bnd       x12                  1
 UP bnd       x13                  1
 UP bnd       x14                  1
 UP bnd       x15                  1
 UP bnd       x16                  1
 UP bnd       x17                  1
 UP bnd       x18                  1
 UP bnd       x19                  1
 UP bnd       x20                  1
 UP bnd       x21                  1
 UP bnd       x22                  1
 UP bnd       x23                  1
 UP bnd       x24                  1
 UP bnd       x25                  1
 UP bnd       x26                  1
 UP bnd       x27                  1
 UP bnd       x28                  1
 UP bnd       x29                  1
 UP bnd       x30                  1
 UP bnd       x31                  1
 UP bnd       x32                  1
 UP bnd       x33                  1
 UP bnd       x34                  1
 UP bnd       x35                  1
 UP bnd       x36                  1
 UP bnd       x37                  1
 UP bnd       x38                  1
 UP bnd       x39                  1
 UP bnd       x40                  1
 UP bnd       x41                  1
 UP bnd       x42                  1
 UP bnd       x43                  1
 UP bnd       x44                  1
 UP bnd       x45                  1
 UP bnd       x46                  1
 UP bnd       x47                  1
 UP bnd       x48                  1
 UP bnd       x49                  1
 UP bnd       x50                  1
ENDATA
