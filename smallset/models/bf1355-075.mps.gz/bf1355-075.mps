NAME           
ROWS
 N  obj     
 G  c1      
 G  c2      
 G  c3      
 G  c4      
 G  c5      
 G  c6      
 G  c7      
 G  c8      
 G  c9      
 G  c10     
 G  c11     
 G  c12     
 G  c13     
 G  c14     
 G  c15     
 G  c16     
 G  c17     
 G  c18     
 G  c19     
 G  c20     
 G  c21     
 G  c22     
 G  c23     
 G  c24     
 G  c25     
 G  c26     
 G  c27     
 G  c28     
 G  c29     
 G  c30     
 G  c31     
 G  c32     
 G  c33     
 G  c34     
 G  c35     
 G  c36     
 G  c37     
 G  c38     
 G  c39     
 G  c40     
 G  c41     
 G  c42     
 G  c43     
 G  c44     
 G  c45     
 G  c46     
 G  c47     
 G  c48     
 G  c49     
 G  c50     
 G  c51     
 G  c52     
 G  c53     
 G  c54     
 G  c55     
 G  c56     
 G  c57     
 G  c58     
 G  c59     
 G  c60     
 G  c61     
 G  c62     
 G  c63     
 G  c64     
 G  c65     
 G  c66     
 G  c67     
 G  c68     
 G  c69     
 G  c70     
 G  c71     
 G  c72     
 G  c73     
 G  c74     
 G  c75     
 G  c76     
 G  c77     
 G  c78     
 G  c79     
 G  c80     
 G  c81     
 G  c82     
 G  c83     
 G  c84     
 G  c85     
 G  c86     
 G  c87     
 G  c88     
 G  c89     
 G  c90     
 G  c91     
 G  c92     
 G  c93     
 G  c94     
 G  c95     
 G  c96     
 G  c97     
 G  c98     
 G  c99     
 G  c100    
 G  c101    
 G  c102    
 G  c103    
 G  c104    
 G  c105    
 G  c106    
 G  c107    
 G  c108    
 G  c109    
 G  c110    
 G  c111    
 G  c112    
 G  c113    
 G  c114    
 G  c115    
 G  c116    
 G  c117    
 G  c118    
 G  c119    
 G  c120    
 G  c121    
 G  c122    
 G  c123    
 G  c124    
 G  c125    
 G  c126    
 G  c127    
 G  c128    
 G  c129    
 G  c130    
 G  c131    
 G  c132    
 G  c133    
 G  c134    
 G  c135    
 G  c136    
 G  c137    
 G  c138    
 G  c139    
 G  c140    
 G  c141    
 G  c142    
 G  c143    
 G  c144    
 G  c145    
 G  c146    
 G  c147    
 G  c148    
 G  c149    
 G  c150    
 G  c151    
 G  c152    
 G  c153    
 G  c154    
 G  c155    
 G  c156    
 G  c157    
 G  c158    
 G  c159    
 G  c160    
 G  c161    
 G  c162    
 G  c163    
 G  c164    
 G  c165    
 G  c166    
 G  c167    
 G  c168    
 G  c169    
 G  c170    
 G  c171    
 G  c172    
 G  c173    
 G  c174    
 G  c175    
 G  c176    
 G  c177    
 G  c178    
 G  c179    
 G  c180    
 G  c181    
 G  c182    
 G  c183    
 G  c184    
 G  c185    
 G  c186    
 G  c187    
 G  c188    
 G  c189    
 G  c190    
 G  c191    
 G  c192    
 G  c193    
 G  c194    
 G  c195    
 G  c196    
 G  c197    
 G  c198    
 G  c199    
 G  c200    
 G  c201    
 G  c202    
 G  c203    
 G  c204    
 G  c205    
 G  c206    
 G  c207    
 G  c208    
 G  c209    
 G  c210    
 G  c211    
 G  c212    
 G  c213    
 G  c214    
 G  c215    
 G  c216    
 G  c217    
 G  c218    
 G  c219    
 G  c220    
 G  c221    
 G  c222    
 G  c223    
 G  c224    
 G  c225    
 G  c226    
 G  c227    
 G  c228    
 G  c229    
 G  c230    
 G  c231    
 G  c232    
 G  c233    
 G  c234    
 G  c235    
 G  c236    
 G  c237    
 G  c238    
 G  c239    
 G  c240    
 G  c241    
 G  c242    
 G  c243    
 G  c244    
 G  c245    
 G  c246    
 G  c247    
 G  c248    
 G  c249    
 G  c250    
 G  c251    
 G  c252    
 G  c253    
 G  c254    
 G  c255    
 G  c256    
 G  c257    
 G  c258    
 G  c259    
 G  c260    
 G  c261    
 G  c262    
 G  c263    
 G  c264    
 G  c265    
 G  c266    
 G  c267    
 G  c268    
 G  c269    
 G  c270    
 G  c271    
 G  c272    
 G  c273    
 G  c274    
 G  c275    
 G  c276    
 G  c277    
 G  c278    
 G  c279    
 G  c280    
 G  c281    
 G  c282    
 G  c283    
 G  c284    
 G  c285    
 G  c286    
 G  c287    
 G  c288    
 G  c289    
 G  c290    
 G  c291    
 G  c292    
 G  c293    
 G  c294    
 G  c295    
 G  c296    
 G  c297    
 G  c298    
 G  c299    
 G  c300    
 G  c301    
 G  c302    
 G  c303    
 G  c304    
 G  c305    
 G  c306    
 G  c307    
 G  c308    
 G  c309    
 G  c310    
 G  c311    
 G  c312    
 G  c313    
 G  c314    
 G  c315    
 G  c316    
 G  c317    
 G  c318    
 G  c319    
 G  c320    
 G  c321    
 G  c322    
 G  c323    
 G  c324    
 G  c325    
 G  c326    
 G  c327    
 G  c328    
 G  c329    
 G  c330    
 G  c331    
 G  c332    
 G  c333    
 G  c334    
 G  c335    
 G  c336    
 G  c337    
 G  c338    
 G  c339    
 G  c340    
 G  c341    
 G  c342    
 G  c343    
 G  c344    
 G  c345    
 G  c346    
 G  c347    
 G  c348    
 G  c349    
 G  c350    
 G  c351    
 G  c352    
 G  c353    
 G  c354    
 G  c355    
 G  c356    
 G  c357    
 G  c358    
 G  c359    
 G  c360    
 G  c361    
 G  c362    
 G  c363    
 G  c364    
 G  c365    
 G  c366    
 G  c367    
 G  c368    
 G  c369    
 G  c370    
 G  c371    
 G  c372    
 G  c373    
 G  c374    
 G  c375    
 G  c376    
 G  c377    
 G  c378    
 G  c379    
 G  c380    
 G  c381    
 G  c382    
 G  c383    
 G  c384    
 G  c385    
 G  c386    
 G  c387    
 G  c388    
 G  c389    
 G  c390    
 G  c391    
 G  c392    
 G  c393    
 G  c394    
 G  c395    
 G  c396    
 G  c397    
 G  c398    
 G  c399    
 G  c400    
 G  c401    
 G  c402    
 G  c403    
 G  c404    
 G  c405    
 G  c406    
 G  c407    
 G  c408    
 G  c409    
 G  c410    
 G  c411    
 G  c412    
 G  c413    
 G  c414    
 G  c415    
 G  c416    
 G  c417    
 G  c418    
 G  c419    
 G  c420    
 G  c421    
 G  c422    
 G  c423    
 G  c424    
 G  c425    
 G  c426    
 G  c427    
 G  c428    
 G  c429    
 G  c430    
 G  c431    
 G  c432    
 G  c433    
 G  c434    
 G  c435    
 G  c436    
 G  c437    
 G  c438    
 G  c439    
 G  c440    
 G  c441    
 G  c442    
 G  c443    
 G  c444    
 G  c445    
 G  c446    
 G  c447    
 G  c448    
 G  c449    
 G  c450    
 G  c451    
 G  c452    
 G  c453    
 G  c454    
 G  c455    
 G  c456    
 G  c457    
 G  c458    
 G  c459    
 G  c460    
 G  c461    
 G  c462    
 G  c463    
 G  c464    
 G  c465    
 G  c466    
 G  c467    
 G  c468    
 G  c469    
 G  c470    
 G  c471    
 G  c472    
 G  c473    
 G  c474    
 G  c475    
 G  c476    
 G  c477    
 G  c478    
 G  c479    
 G  c480    
 G  c481    
 G  c482    
 G  c483    
 G  c484    
 G  c485    
 G  c486    
 G  c487    
 G  c488    
 G  c489    
 G  c490    
 G  c491    
 G  c492    
 G  c493    
 G  c494    
 G  c495    
 G  c496    
 G  c497    
 G  c498    
 G  c499    
 G  c500    
 G  c501    
 G  c502    
 G  c503    
 G  c504    
 G  c505    
 G  c506    
 G  c507    
 G  c508    
 G  c509    
 G  c510    
 G  c511    
 G  c512    
 G  c513    
 G  c514    
 G  c515    
 G  c516    
 G  c517    
 G  c518    
 G  c519    
 G  c520    
 G  c521    
 G  c522    
 G  c523    
 G  c524    
 G  c525    
 G  c526    
 G  c527    
 G  c528    
 G  c529    
 G  c530    
 G  c531    
 G  c532    
 G  c533    
 G  c534    
 G  c535    
 G  c536    
 G  c537    
 G  c538    
 G  c539    
 G  c540    
 G  c541    
 G  c542    
 G  c543    
 G  c544    
 G  c545    
 G  c546    
 G  c547    
 G  c548    
 G  c549    
 G  c550    
 G  c551    
 G  c552    
 G  c553    
 G  c554    
 G  c555    
 G  c556    
 G  c557    
 G  c558    
 G  c559    
 G  c560    
 G  c561    
 G  c562    
 G  c563    
 G  c564    
 G  c565    
 G  c566    
 G  c567    
 G  c568    
 G  c569    
 G  c570    
 G  c571    
 G  c572    
 G  c573    
 G  c574    
 G  c575    
 G  c576    
 G  c577    
 G  c578    
 G  c579    
 G  c580    
 G  c581    
 G  c582    
 G  c583    
 G  c584    
 G  c585    
 G  c586    
 G  c587    
 G  c588    
 G  c589    
 G  c590    
 G  c591    
 G  c592    
 G  c593    
 G  c594    
 G  c595    
 G  c596    
 G  c597    
 G  c598    
 G  c599    
 G  c600    
 G  c601    
 G  c602    
 G  c603    
 G  c604    
 G  c605    
 G  c606    
 G  c607    
 G  c608    
 G  c609    
 G  c610    
 G  c611    
 G  c612    
 G  c613    
 G  c614    
 G  c615    
 G  c616    
 G  c617    
 G  c618    
 G  c619    
 G  c620    
 G  c621    
 G  c622    
 G  c623    
 G  c624    
 G  c625    
 G  c626    
 G  c627    
 G  c628    
 G  c629    
 G  c630    
 G  c631    
 G  c632    
 G  c633    
 G  c634    
 G  c635    
 G  c636    
 G  c637    
 G  c638    
 G  c639    
 G  c640    
 G  c641    
 G  c642    
 G  c643    
 G  c644    
 G  c645    
 G  c646    
 G  c647    
 G  c648    
 G  c649    
 G  c650    
 G  c651    
 G  c652    
 G  c653    
 G  c654    
 G  c655    
 G  c656    
 G  c657    
 G  c658    
 G  c659    
 G  c660    
 G  c661    
 G  c662    
 G  c663    
 G  c664    
 G  c665    
 G  c666    
 G  c667    
 G  c668    
 G  c669    
 G  c670    
 G  c671    
 G  c672    
 G  c673    
 G  c674    
 G  c675    
 G  c676    
 G  c677    
 G  c678    
 G  c679    
 G  c680    
 G  c681    
 G  c682    
 G  c683    
 G  c684    
 G  c685    
 G  c686    
 G  c687    
 G  c688    
 G  c689    
 G  c690    
 G  c691    
 G  c692    
 G  c693    
 G  c694    
 G  c695    
 G  c696    
 G  c697    
 G  c698    
 G  c699    
 G  c700    
 G  c701    
 G  c702    
 G  c703    
 G  c704    
 G  c705    
 G  c706    
 G  c707    
 G  c708    
 G  c709    
 G  c710    
 G  c711    
 G  c712    
 G  c713    
 G  c714    
 G  c715    
 G  c716    
 G  c717    
 G  c718    
 G  c719    
 G  c720    
 G  c721    
 G  c722    
 G  c723    
 G  c724    
 G  c725    
 G  c726    
 G  c727    
 G  c728    
 G  c729    
 G  c730    
 G  c731    
 G  c732    
 G  c733    
 G  c734    
 G  c735    
 G  c736    
 G  c737    
 G  c738    
 G  c739    
 G  c740    
 G  c741    
 G  c742    
 G  c743    
 G  c744    
 G  c745    
 G  c746    
 G  c747    
 G  c748    
 G  c749    
 G  c750    
 G  c751    
 G  c752    
 G  c753    
 G  c754    
 G  c755    
 G  c756    
 G  c757    
 G  c758    
 G  c759    
 G  c760    
 G  c761    
 G  c762    
 G  c763    
 G  c764    
 G  c765    
 G  c766    
 G  c767    
 G  c768    
 G  c769    
 G  c770    
 G  c771    
 G  c772    
 G  c773    
 G  c774    
 G  c775    
 G  c776    
 G  c777    
 G  c778    
 G  c779    
 G  c780    
 G  c781    
 G  c782    
 G  c783    
 G  c784    
 G  c785    
 G  c786    
 G  c787    
 G  c788    
 G  c789    
 G  c790    
 G  c791    
 G  c792    
 G  c793    
 G  c794    
 G  c795    
 G  c796    
 G  c797    
 G  c798    
 G  c799    
 G  c800    
 G  c801    
 G  c802    
 G  c803    
 G  c804    
 G  c805    
 G  c806    
 G  c807    
 G  c808    
 G  c809    
 G  c810    
 G  c811    
 G  c812    
 G  c813    
 G  c814    
 G  c815    
 G  c816    
 G  c817    
 G  c818    
 G  c819    
 G  c820    
 G  c821    
 G  c822    
 G  c823    
 G  c824    
 G  c825    
 G  c826    
 G  c827    
 G  c828    
 G  c829    
 G  c830    
 G  c831    
 G  c832    
 G  c833    
 G  c834    
 G  c835    
 G  c836    
 G  c837    
 G  c838    
 G  c839    
 G  c840    
 G  c841    
 G  c842    
 G  c843    
 G  c844    
 G  c845    
 G  c846    
 G  c847    
 G  c848    
 G  c849    
 G  c850    
 G  c851    
 G  c852    
 G  c853    
 G  c854    
 G  c855    
 G  c856    
 G  c857    
 G  c858    
 G  c859    
 G  c860    
 G  c861    
 G  c862    
 G  c863    
 G  c864    
 G  c865    
 G  c866    
 G  c867    
 G  c868    
 G  c869    
 G  c870    
 G  c871    
 G  c872    
 G  c873    
 G  c874    
 G  c875    
 G  c876    
 G  c877    
 G  c878    
 G  c879    
 G  c880    
 G  c881    
 G  c882    
 G  c883    
 G  c884    
 G  c885    
 G  c886    
 G  c887    
 G  c888    
 G  c889    
 G  c890    
 G  c891    
 G  c892    
 G  c893    
 G  c894    
 G  c895    
 G  c896    
 G  c897    
 G  c898    
 G  c899    
 G  c900    
 G  c901    
 G  c902    
 G  c903    
 G  c904    
 G  c905    
 G  c906    
 G  c907    
 G  c908    
 G  c909    
 G  c910    
 G  c911    
 G  c912    
 G  c913    
 G  c914    
 G  c915    
 G  c916    
 G  c917    
 G  c918    
 G  c919    
 G  c920    
 G  c921    
 G  c922    
 G  c923    
 G  c924    
 G  c925    
 G  c926    
 G  c927    
 G  c928    
 G  c929    
 G  c930    
 G  c931    
 G  c932    
 G  c933    
 G  c934    
 G  c935    
 G  c936    
 G  c937    
 G  c938    
 G  c939    
 G  c940    
 G  c941    
 G  c942    
 G  c943    
 G  c944    
 G  c945    
 G  c946    
 G  c947    
 G  c948    
 G  c949    
 G  c950    
 G  c951    
 G  c952    
 G  c953    
 G  c954    
 G  c955    
 G  c956    
 G  c957    
 G  c958    
 G  c959    
 G  c960    
 G  c961    
 G  c962    
 G  c963    
 G  c964    
 G  c965    
 G  c966    
 G  c967    
 G  c968    
 G  c969    
 G  c970    
 G  c971    
 G  c972    
 G  c973    
 G  c974    
 G  c975    
 G  c976    
 G  c977    
 G  c978    
 G  c979    
 G  c980    
 G  c981    
 G  c982    
 G  c983    
 G  c984    
 G  c985    
 G  c986    
 G  c987    
 G  c988    
 G  c989    
 G  c990    
 G  c991    
 G  c992    
 G  c993    
 G  c994    
 G  c995    
 G  c996    
 G  c997    
 G  c998    
 G  c999    
 G  c1000   
 G  c1001   
 G  c1002   
 G  c1003   
 G  c1004   
 G  c1005   
 G  c1006   
 G  c1007   
 G  c1008   
 G  c1009   
 G  c1010   
 G  c1011   
 G  c1012   
 G  c1013   
 G  c1014   
 G  c1015   
 G  c1016   
 G  c1017   
 G  c1018   
 G  c1019   
 G  c1020   
 G  c1021   
 G  c1022   
 G  c1023   
 G  c1024   
 G  c1025   
 G  c1026   
 G  c1027   
 G  c1028   
 G  c1029   
 G  c1030   
 G  c1031   
 G  c1032   
 G  c1033   
 G  c1034   
 G  c1035   
 G  c1036   
 G  c1037   
 G  c1038   
 G  c1039   
 G  c1040   
 G  c1041   
 G  c1042   
 G  c1043   
 G  c1044   
 G  c1045   
 G  c1046   
 G  c1047   
 G  c1048   
 G  c1049   
 G  c1050   
 G  c1051   
 G  c1052   
 G  c1053   
 G  c1054   
 G  c1055   
 G  c1056   
 G  c1057   
 G  c1058   
 G  c1059   
 G  c1060   
 G  c1061   
 G  c1062   
 G  c1063   
 G  c1064   
 G  c1065   
 G  c1066   
 G  c1067   
 G  c1068   
 G  c1069   
 G  c1070   
 G  c1071   
 G  c1072   
 G  c1073   
 G  c1074   
 G  c1075   
 G  c1076   
 G  c1077   
 G  c1078   
 G  c1079   
 G  c1080   
 G  c1081   
 G  c1082   
 G  c1083   
 G  c1084   
 G  c1085   
 G  c1086   
 G  c1087   
 G  c1088   
 G  c1089   
 G  c1090   
 G  c1091   
 G  c1092   
 G  c1093   
 G  c1094   
 G  c1095   
 G  c1096   
 G  c1097   
 G  c1098   
 G  c1099   
 G  c1100   
 G  c1101   
 G  c1102   
 G  c1103   
 G  c1104   
 G  c1105   
 G  c1106   
 G  c1107   
 G  c1108   
 G  c1109   
 G  c1110   
 G  c1111   
 G  c1112   
 G  c1113   
 G  c1114   
 G  c1115   
 G  c1116   
 G  c1117   
 G  c1118   
 G  c1119   
 G  c1120   
 G  c1121   
 G  c1122   
 G  c1123   
 G  c1124   
 G  c1125   
 G  c1126   
 G  c1127   
 G  c1128   
 G  c1129   
 G  c1130   
 G  c1131   
 G  c1132   
 G  c1133   
 G  c1134   
 G  c1135   
 G  c1136   
 G  c1137   
 G  c1138   
 G  c1139   
 G  c1140   
 G  c1141   
 G  c1142   
 G  c1143   
 G  c1144   
 G  c1145   
 G  c1146   
 G  c1147   
 G  c1148   
 G  c1149   
 G  c1150   
 G  c1151   
 G  c1152   
 G  c1153   
 G  c1154   
 G  c1155   
 G  c1156   
 G  c1157   
 G  c1158   
 G  c1159   
 G  c1160   
 G  c1161   
 G  c1162   
 G  c1163   
 G  c1164   
 G  c1165   
 G  c1166   
 G  c1167   
 G  c1168   
 G  c1169   
 G  c1170   
 G  c1171   
 G  c1172   
 G  c1173   
 G  c1174   
 G  c1175   
 G  c1176   
 G  c1177   
 G  c1178   
 G  c1179   
 G  c1180   
 G  c1181   
 G  c1182   
 G  c1183   
 G  c1184   
 G  c1185   
 G  c1186   
 G  c1187   
 G  c1188   
 G  c1189   
 G  c1190   
 G  c1191   
 G  c1192   
 G  c1193   
 G  c1194   
 G  c1195   
 G  c1196   
 G  c1197   
 G  c1198   
 G  c1199   
 G  c1200   
 G  c1201   
 G  c1202   
 G  c1203   
 G  c1204   
 G  c1205   
 G  c1206   
 G  c1207   
 G  c1208   
 G  c1209   
 G  c1210   
 G  c1211   
 G  c1212   
 G  c1213   
 G  c1214   
 G  c1215   
 G  c1216   
 G  c1217   
 G  c1218   
 G  c1219   
 G  c1220   
 G  c1221   
 G  c1222   
 G  c1223   
 G  c1224   
 G  c1225   
 G  c1226   
 G  c1227   
 G  c1228   
 G  c1229   
 G  c1230   
 G  c1231   
 G  c1232   
 G  c1233   
 G  c1234   
 G  c1235   
 G  c1236   
 G  c1237   
 G  c1238   
 G  c1239   
 G  c1240   
 G  c1241   
 G  c1242   
 G  c1243   
 G  c1244   
 G  c1245   
 G  c1246   
 G  c1247   
 G  c1248   
 G  c1249   
 G  c1250   
 G  c1251   
 G  c1252   
 G  c1253   
 G  c1254   
 G  c1255   
 G  c1256   
 G  c1257   
 G  c1258   
 G  c1259   
 G  c1260   
 G  c1261   
 G  c1262   
 G  c1263   
 G  c1264   
 G  c1265   
 G  c1266   
 G  c1267   
 G  c1268   
 G  c1269   
 G  c1270   
 G  c1271   
 G  c1272   
 G  c1273   
 G  c1274   
 G  c1275   
 G  c1276   
 G  c1277   
 G  c1278   
 G  c1279   
 G  c1280   
 G  c1281   
 G  c1282   
 G  c1283   
 G  c1284   
 G  c1285   
 G  c1286   
 G  c1287   
 G  c1288   
 G  c1289   
 G  c1290   
 G  c1291   
 G  c1292   
 G  c1293   
 G  c1294   
 G  c1295   
 G  c1296   
 G  c1297   
 G  c1298   
 G  c1299   
 G  c1300   
 G  c1301   
 G  c1302   
 G  c1303   
 G  c1304   
 G  c1305   
 G  c1306   
 G  c1307   
 G  c1308   
 G  c1309   
 G  c1310   
 G  c1311   
 G  c1312   
 G  c1313   
 G  c1314   
 G  c1315   
 G  c1316   
 G  c1317   
 G  c1318   
 G  c1319   
 G  c1320   
 G  c1321   
 G  c1322   
 G  c1323   
 G  c1324   
 G  c1325   
 G  c1326   
 G  c1327   
 G  c1328   
 G  c1329   
 G  c1330   
 G  c1331   
 G  c1332   
 G  c1333   
 G  c1334   
 G  c1335   
 G  c1336   
 G  c1337   
 G  c1338   
 G  c1339   
 G  c1340   
 G  c1341   
 G  c1342   
 G  c1343   
 G  c1344   
 G  c1345   
 G  c1346   
 G  c1347   
 G  c1348   
 G  c1349   
 G  c1350   
 G  c1351   
 G  c1352   
 G  c1353   
 G  c1354   
 G  c1355   
 G  c1356   
 G  c1357   
 G  c1358   
 G  c1359   
 G  c1360   
 G  c1361   
 G  c1362   
 G  c1363   
 G  c1364   
 G  c1365   
 G  c1366   
 G  c1367   
 G  c1368   
 G  c1369   
 G  c1370   
 G  c1371   
 G  c1372   
 G  c1373   
 G  c1374   
 G  c1375   
 G  c1376   
 G  c1377   
 G  c1378   
 G  c1379   
 G  c1380   
 G  c1381   
 G  c1382   
 G  c1383   
 G  c1384   
 G  c1385   
 G  c1386   
 G  c1387   
 G  c1388   
 G  c1389   
 G  c1390   
 G  c1391   
 G  c1392   
 G  c1393   
 G  c1394   
 G  c1395   
 G  c1396   
 G  c1397   
 G  c1398   
 G  c1399   
 G  c1400   
 G  c1401   
 G  c1402   
 G  c1403   
 G  c1404   
 G  c1405   
 G  c1406   
 G  c1407   
 G  c1408   
 G  c1409   
 G  c1410   
 G  c1411   
 G  c1412   
 G  c1413   
 G  c1414   
 G  c1415   
 G  c1416   
 G  c1417   
 G  c1418   
 G  c1419   
 G  c1420   
 G  c1421   
 G  c1422   
 G  c1423   
 G  c1424   
 G  c1425   
 G  c1426   
 G  c1427   
 G  c1428   
 G  c1429   
 G  c1430   
 G  c1431   
 G  c1432   
 G  c1433   
 G  c1434   
 G  c1435   
 G  c1436   
 G  c1437   
 G  c1438   
 G  c1439   
 G  c1440   
 G  c1441   
 G  c1442   
 G  c1443   
 G  c1444   
 G  c1445   
 G  c1446   
 G  c1447   
 G  c1448   
 G  c1449   
 G  c1450   
 G  c1451   
 G  c1452   
 G  c1453   
 G  c1454   
 G  c1455   
 G  c1456   
 G  c1457   
 G  c1458   
 G  c1459   
 G  c1460   
 G  c1461   
 G  c1462   
 G  c1463   
 G  c1464   
 G  c1465   
 G  c1466   
 G  c1467   
 G  c1468   
 G  c1469   
 G  c1470   
 G  c1471   
 G  c1472   
 G  c1473   
 G  c1474   
 G  c1475   
 G  c1476   
 G  c1477   
 G  c1478   
 G  c1479   
 G  c1480   
 G  c1481   
 G  c1482   
 G  c1483   
 G  c1484   
 G  c1485   
 G  c1486   
 G  c1487   
 G  c1488   
 G  c1489   
 G  c1490   
 G  c1491   
 G  c1492   
 G  c1493   
 G  c1494   
 G  c1495   
 G  c1496   
 G  c1497   
 G  c1498   
 G  c1499   
 G  c1500   
 G  c1501   
 G  c1502   
 G  c1503   
 G  c1504   
 G  c1505   
 G  c1506   
 G  c1507   
 G  c1508   
 G  c1509   
 G  c1510   
 G  c1511   
 G  c1512   
 G  c1513   
 G  c1514   
 G  c1515   
 G  c1516   
 G  c1517   
 G  c1518   
 G  c1519   
 G  c1520   
 G  c1521   
 G  c1522   
 G  c1523   
 G  c1524   
 G  c1525   
 G  c1526   
 G  c1527   
 G  c1528   
 G  c1529   
 G  c1530   
 G  c1531   
 G  c1532   
 G  c1533   
 G  c1534   
 G  c1535   
 G  c1536   
 G  c1537   
 G  c1538   
 G  c1539   
 G  c1540   
 G  c1541   
 G  c1542   
 G  c1543   
 G  c1544   
 G  c1545   
 G  c1546   
 G  c1547   
 G  c1548   
 G  c1549   
 G  c1550   
 G  c1551   
 G  c1552   
 G  c1553   
 G  c1554   
 G  c1555   
 G  c1556   
 G  c1557   
 G  c1558   
 G  c1559   
 G  c1560   
 G  c1561   
 G  c1562   
 G  c1563   
 G  c1564   
 G  c1565   
 G  c1566   
 G  c1567   
 G  c1568   
 G  c1569   
 G  c1570   
 G  c1571   
 G  c1572   
 G  c1573   
 G  c1574   
 G  c1575   
 G  c1576   
 G  c1577   
 G  c1578   
 G  c1579   
 G  c1580   
 G  c1581   
 G  c1582   
 G  c1583   
 G  c1584   
 G  c1585   
 G  c1586   
 G  c1587   
 G  c1588   
 G  c1589   
 G  c1590   
 G  c1591   
 G  c1592   
 G  c1593   
 G  c1594   
 G  c1595   
 G  c1596   
 G  c1597   
 G  c1598   
 G  c1599   
 G  c1600   
 G  c1601   
 G  c1602   
 G  c1603   
 G  c1604   
 G  c1605   
 G  c1606   
 G  c1607   
 G  c1608   
 G  c1609   
 G  c1610   
 G  c1611   
 G  c1612   
 G  c1613   
 G  c1614   
 G  c1615   
 G  c1616   
 G  c1617   
 G  c1618   
 G  c1619   
 G  c1620   
 G  c1621   
 G  c1622   
 G  c1623   
 G  c1624   
 G  c1625   
 G  c1626   
 G  c1627   
 G  c1628   
 G  c1629   
 G  c1630   
 G  c1631   
 G  c1632   
 G  c1633   
 G  c1634   
 G  c1635   
 G  c1636   
 G  c1637   
 G  c1638   
 G  c1639   
 G  c1640   
 G  c1641   
 G  c1642   
 G  c1643   
 G  c1644   
 G  c1645   
 G  c1646   
 G  c1647   
 G  c1648   
 G  c1649   
 G  c1650   
 G  c1651   
 G  c1652   
 G  c1653   
 G  c1654   
 G  c1655   
 G  c1656   
 G  c1657   
 G  c1658   
 G  c1659   
 G  c1660   
 G  c1661   
 G  c1662   
 G  c1663   
 G  c1664   
 G  c1665   
 G  c1666   
 G  c1667   
 G  c1668   
 G  c1669   
 G  c1670   
 G  c1671   
 G  c1672   
 G  c1673   
 G  c1674   
 G  c1675   
 G  c1676   
 G  c1677   
 G  c1678   
 G  c1679   
 G  c1680   
 G  c1681   
 G  c1682   
 G  c1683   
 G  c1684   
 G  c1685   
 G  c1686   
 G  c1687   
 G  c1688   
 G  c1689   
 G  c1690   
 G  c1691   
 G  c1692   
 G  c1693   
 G  c1694   
 G  c1695   
 G  c1696   
 G  c1697   
 G  c1698   
 G  c1699   
 G  c1700   
 G  c1701   
 G  c1702   
 G  c1703   
 G  c1704   
 G  c1705   
 G  c1706   
 G  c1707   
 G  c1708   
 G  c1709   
 G  c1710   
 G  c1711   
 G  c1712   
 G  c1713   
 G  c1714   
 G  c1715   
 G  c1716   
 G  c1717   
 G  c1718   
 G  c1719   
 G  c1720   
 G  c1721   
 G  c1722   
 G  c1723   
 G  c1724   
 G  c1725   
 G  c1726   
 G  c1727   
 G  c1728   
 G  c1729   
 G  c1730   
 G  c1731   
 G  c1732   
 G  c1733   
 G  c1734   
 G  c1735   
 G  c1736   
 G  c1737   
 G  c1738   
 G  c1739   
 G  c1740   
 G  c1741   
 G  c1742   
 G  c1743   
 G  c1744   
 G  c1745   
 G  c1746   
 G  c1747   
 G  c1748   
 G  c1749   
 G  c1750   
 G  c1751   
 G  c1752   
 G  c1753   
 G  c1754   
 G  c1755   
 G  c1756   
 G  c1757   
 G  c1758   
 G  c1759   
 G  c1760   
 G  c1761   
 G  c1762   
 G  c1763   
 G  c1764   
 G  c1765   
 G  c1766   
 G  c1767   
 G  c1768   
 G  c1769   
 G  c1770   
 G  c1771   
 G  c1772   
 G  c1773   
 G  c1774   
 G  c1775   
 G  c1776   
 G  c1777   
 G  c1778   
 G  c1779   
 G  c1780   
 G  c1781   
 G  c1782   
 G  c1783   
 G  c1784   
 G  c1785   
 G  c1786   
 G  c1787   
 G  c1788   
 G  c1789   
 G  c1790   
 G  c1791   
 G  c1792   
 G  c1793   
 G  c1794   
 G  c1795   
 G  c1796   
 G  c1797   
 G  c1798   
 G  c1799   
 G  c1800   
 G  c1801   
 G  c1802   
 G  c1803   
 G  c1804   
 G  c1805   
 G  c1806   
 G  c1807   
 G  c1808   
 G  c1809   
 G  c1810   
 G  c1811   
 G  c1812   
 G  c1813   
 G  c1814   
 G  c1815   
 G  c1816   
 G  c1817   
 G  c1818   
 G  c1819   
 G  c1820   
 G  c1821   
 G  c1822   
 G  c1823   
 G  c1824   
 G  c1825   
 G  c1826   
 G  c1827   
 G  c1828   
 G  c1829   
 G  c1830   
 G  c1831   
 G  c1832   
 G  c1833   
 G  c1834   
 G  c1835   
 G  c1836   
 G  c1837   
 G  c1838   
 G  c1839   
 G  c1840   
 G  c1841   
 G  c1842   
 G  c1843   
 G  c1844   
 G  c1845   
 G  c1846   
 G  c1847   
 G  c1848   
 G  c1849   
 G  c1850   
 G  c1851   
 G  c1852   
 G  c1853   
 G  c1854   
 G  c1855   
 G  c1856   
 G  c1857   
 G  c1858   
 G  c1859   
 G  c1860   
 G  c1861   
 G  c1862   
 G  c1863   
 G  c1864   
 G  c1865   
 G  c1866   
 G  c1867   
 G  c1868   
 G  c1869   
 G  c1870   
 G  c1871   
 G  c1872   
 G  c1873   
 G  c1874   
 G  c1875   
 G  c1876   
 G  c1877   
 G  c1878   
 G  c1879   
 G  c1880   
 G  c1881   
 G  c1882   
 G  c1883   
 G  c1884   
 G  c1885   
 G  c1886   
 G  c1887   
 G  c1888   
 G  c1889   
 G  c1890   
 G  c1891   
 G  c1892   
 G  c1893   
 G  c1894   
 G  c1895   
 G  c1896   
 G  c1897   
 G  c1898   
 G  c1899   
 G  c1900   
 G  c1901   
 G  c1902   
 G  c1903   
 G  c1904   
 G  c1905   
 G  c1906   
 G  c1907   
 G  c1908   
 G  c1909   
 G  c1910   
 G  c1911   
 G  c1912   
 G  c1913   
 G  c1914   
 G  c1915   
 G  c1916   
 G  c1917   
 G  c1918   
 G  c1919   
 G  c1920   
 G  c1921   
 G  c1922   
 G  c1923   
 G  c1924   
 G  c1925   
 G  c1926   
 G  c1927   
 G  c1928   
 G  c1929   
 G  c1930   
 G  c1931   
 G  c1932   
 G  c1933   
 G  c1934   
 G  c1935   
 G  c1936   
 G  c1937   
 G  c1938   
 G  c1939   
 G  c1940   
 G  c1941   
 G  c1942   
 G  c1943   
 G  c1944   
 G  c1945   
 G  c1946   
 G  c1947   
 G  c1948   
 G  c1949   
 G  c1950   
 G  c1951   
 G  c1952   
 G  c1953   
 G  c1954   
 G  c1955   
 G  c1956   
 G  c1957   
 G  c1958   
 G  c1959   
 G  c1960   
 G  c1961   
 G  c1962   
 G  c1963   
 G  c1964   
 G  c1965   
 G  c1966   
 G  c1967   
 G  c1968   
 G  c1969   
 G  c1970   
 G  c1971   
 G  c1972   
 G  c1973   
 G  c1974   
 G  c1975   
 G  c1976   
 G  c1977   
 G  c1978   
 G  c1979   
 G  c1980   
 G  c1981   
 G  c1982   
 G  c1983   
 G  c1984   
 G  c1985   
 G  c1986   
 G  c1987   
 G  c1988   
 G  c1989   
 G  c1990   
 G  c1991   
 G  c1992   
 G  c1993   
 G  c1994   
 G  c1995   
 G  c1996   
 G  c1997   
 G  c1998   
 G  c1999   
 G  c2000   
 G  c2001   
 G  c2002   
 G  c2003   
 G  c2004   
 G  c2005   
 G  c2006   
 G  c2007   
 G  c2008   
 G  c2009   
 G  c2010   
 G  c2011   
 G  c2012   
 G  c2013   
 G  c2014   
 G  c2015   
 G  c2016   
 G  c2017   
 G  c2018   
 G  c2019   
 G  c2020   
 G  c2021   
 G  c2022   
 G  c2023   
 G  c2024   
 G  c2025   
 G  c2026   
 G  c2027   
 G  c2028   
 G  c2029   
 G  c2030   
 G  c2031   
 G  c2032   
 G  c2033   
 G  c2034   
 G  c2035   
 G  c2036   
 G  c2037   
 G  c2038   
 G  c2039   
 G  c2040   
 G  c2041   
 G  c2042   
 G  c2043   
 G  c2044   
 G  c2045   
 G  c2046   
 G  c2047   
 G  c2048   
 G  c2049   
 G  c2050   
 G  c2051   
 G  c2052   
 G  c2053   
 G  c2054   
 G  c2055   
 G  c2056   
 G  c2057   
 G  c2058   
 G  c2059   
 G  c2060   
 G  c2061   
 G  c2062   
 G  c2063   
 G  c2064   
 G  c2065   
 G  c2066   
 G  c2067   
 G  c2068   
 G  c2069   
 G  c2070   
 G  c2071   
 G  c2072   
 G  c2073   
 G  c2074   
 G  c2075   
 G  c2076   
 G  c2077   
 G  c2078   
 G  c2079   
 G  c2080   
 G  c2081   
 G  c2082   
 G  c2083   
 G  c2084   
 G  c2085   
 G  c2086   
 G  c2087   
 G  c2088   
 G  c2089   
 G  c2090   
 G  c2091   
 G  c2092   
 G  c2093   
 G  c2094   
 G  c2095   
 G  c2096   
 G  c2097   
 G  c2098   
 G  c2099   
 G  c2100   
 G  c2101   
 G  c2102   
 G  c2103   
 G  c2104   
 G  c2105   
 G  c2106   
 G  c2107   
 G  c2108   
 G  c2109   
 G  c2110   
 G  c2111   
 G  c2112   
 G  c2113   
 G  c2114   
 G  c2115   
 G  c2116   
 G  c2117   
 G  c2118   
 G  c2119   
 G  c2120   
 G  c2121   
 G  c2122   
 G  c2123   
 G  c2124   
 G  c2125   
 G  c2126   
 G  c2127   
 G  c2128   
 G  c2129   
 G  c2130   
 G  c2131   
 G  c2132   
 G  c2133   
 G  c2134   
 G  c2135   
 G  c2136   
 G  c2137   
 G  c2138   
 G  c2139   
 G  c2140   
 G  c2141   
 G  c2142   
 G  c2143   
 G  c2144   
 G  c2145   
 G  c2146   
 G  c2147   
 G  c2148   
 G  c2149   
 G  c2150   
 G  c2151   
 G  c2152   
 G  c2153   
 G  c2154   
 G  c2155   
 G  c2156   
 G  c2157   
 G  c2158   
 G  c2159   
 G  c2160   
 G  c2161   
 G  c2162   
 G  c2163   
 G  c2164   
 G  c2165   
 G  c2166   
 G  c2167   
 G  c2168   
 G  c2169   
 G  c2170   
 G  c2171   
 G  c2172   
 G  c2173   
 G  c2174   
 G  c2175   
 G  c2176   
 G  c2177   
 G  c2178   
 G  c2179   
 G  c2180   
 G  c2181   
 G  c2182   
 G  c2183   
 G  c2184   
 G  c2185   
 G  c2186   
 G  c2187   
 G  c2188   
 G  c2189   
 G  c2190   
 G  c2191   
 G  c2192   
 G  c2193   
 G  c2194   
 G  c2195   
 G  c2196   
 G  c2197   
 G  c2198   
 G  c2199   
 G  c2200   
 G  c2201   
 G  c2202   
 G  c2203   
 G  c2204   
 G  c2205   
 G  c2206   
 G  c2207   
 G  c2208   
 G  c2209   
 G  c2210   
 G  c2211   
 G  c2212   
 G  c2213   
 G  c2214   
 G  c2215   
 G  c2216   
 G  c2217   
 G  c2218   
 G  c2219   
 G  c2220   
 G  c2221   
 G  c2222   
 G  c2223   
 G  c2224   
 G  c2225   
 G  c2226   
 G  c2227   
 G  c2228   
 G  c2229   
 G  c2230   
 G  c2231   
 G  c2232   
 G  c2233   
 G  c2234   
 G  c2235   
 G  c2236   
 G  c2237   
 G  c2238   
 G  c2239   
 G  c2240   
 G  c2241   
 G  c2242   
 G  c2243   
 G  c2244   
 G  c2245   
 G  c2246   
 G  c2247   
 G  c2248   
 G  c2249   
 G  c2250   
 G  c2251   
 G  c2252   
 G  c2253   
 G  c2254   
 G  c2255   
 G  c2256   
 G  c2257   
 G  c2258   
 G  c2259   
 G  c2260   
 G  c2261   
 G  c2262   
 G  c2263   
 G  c2264   
 G  c2265   
 G  c2266   
 G  c2267   
 G  c2268   
 G  c2269   
 G  c2270   
 G  c2271   
 G  c2272   
 G  c2273   
 G  c2274   
 G  c2275   
 G  c2276   
 G  c2277   
 G  c2278   
 G  c2279   
 G  c2280   
 G  c2281   
 G  c2282   
 G  c2283   
 G  c2284   
 G  c2285   
 G  c2286   
 G  c2287   
 G  c2288   
 G  c2289   
 G  c2290   
 G  c2291   
 G  c2292   
 G  c2293   
 G  c2294   
 G  c2295   
 G  c2296   
 G  c2297   
 G  c2298   
 G  c2299   
 G  c2300   
 G  c2301   
 G  c2302   
 G  c2303   
 G  c2304   
 G  c2305   
 G  c2306   
 G  c2307   
 G  c2308   
 G  c2309   
 G  c2310   
 G  c2311   
 G  c2312   
 G  c2313   
 G  c2314   
 G  c2315   
 G  c2316   
 G  c2317   
 G  c2318   
 G  c2319   
 G  c2320   
 G  c2321   
 G  c2322   
 G  c2323   
 G  c2324   
 G  c2325   
 G  c2326   
 G  c2327   
 G  c2328   
 G  c2329   
 G  c2330   
 G  c2331   
 G  c2332   
 G  c2333   
 G  c2334   
 G  c2335   
 G  c2336   
 G  c2337   
 G  c2338   
 G  c2339   
 G  c2340   
 G  c2341   
 G  c2342   
 G  c2343   
 G  c2344   
 G  c2345   
 G  c2346   
 G  c2347   
 G  c2348   
 G  c2349   
 G  c2350   
 G  c2351   
 G  c2352   
 G  c2353   
 G  c2354   
 G  c2355   
 G  c2356   
 G  c2357   
 G  c2358   
 G  c2359   
 G  c2360   
 G  c2361   
 G  c2362   
 G  c2363   
 G  c2364   
 G  c2365   
 G  c2366   
 G  c2367   
 G  c2368   
 G  c2369   
 G  c2370   
 G  c2371   
 G  c2372   
 G  c2373   
 G  c2374   
 G  c2375   
 G  c2376   
 G  c2377   
 G  c2378   
 G  c2379   
 G  c2380   
 G  c2381   
 G  c2382   
 G  c2383   
 G  c2384   
 G  c2385   
 G  c2386   
 G  c2387   
 G  c2388   
 G  c2389   
 G  c2390   
 G  c2391   
 G  c2392   
 G  c2393   
 G  c2394   
 G  c2395   
 G  c2396   
 G  c2397   
 G  c2398   
 G  c2399   
 G  c2400   
 G  c2401   
 G  c2402   
 G  c2403   
 G  c2404   
 G  c2405   
 G  c2406   
 G  c2407   
 G  c2408   
 G  c2409   
 G  c2410   
 G  c2411   
 G  c2412   
 G  c2413   
 G  c2414   
 G  c2415   
 G  c2416   
 G  c2417   
 G  c2418   
 G  c2419   
 G  c2420   
 G  c2421   
 G  c2422   
 G  c2423   
 G  c2424   
 G  c2425   
 G  c2426   
 G  c2427   
 G  c2428   
 G  c2429   
 G  c2430   
 G  c2431   
 G  c2432   
 G  c2433   
 G  c2434   
 G  c2435   
 G  c2436   
 G  c2437   
 G  c2438   
 G  c2439   
 G  c2440   
 G  c2441   
 G  c2442   
 G  c2443   
 G  c2444   
 G  c2445   
 G  c2446   
 G  c2447   
 G  c2448   
 G  c2449   
 G  c2450   
 G  c2451   
 G  c2452   
 G  c2453   
 G  c2454   
 G  c2455   
 G  c2456   
 G  c2457   
 G  c2458   
 G  c2459   
 G  c2460   
 G  c2461   
 G  c2462   
 G  c2463   
 G  c2464   
 G  c2465   
 G  c2466   
 G  c2467   
 G  c2468   
 G  c2469   
 G  c2470   
 G  c2471   
 G  c2472   
 G  c2473   
 G  c2474   
 G  c2475   
 G  c2476   
 G  c2477   
 G  c2478   
 G  c2479   
 G  c2480   
 G  c2481   
 G  c2482   
 G  c2483   
 G  c2484   
 G  c2485   
 G  c2486   
 G  c2487   
 G  c2488   
 G  c2489   
 G  c2490   
 G  c2491   
 G  c2492   
 G  c2493   
 G  c2494   
 G  c2495   
 G  c2496   
 G  c2497   
 G  c2498   
 G  c2499   
 G  c2500   
 G  c2501   
 G  c2502   
 G  c2503   
 G  c2504   
 G  c2505   
 G  c2506   
 G  c2507   
 G  c2508   
 G  c2509   
 G  c2510   
 G  c2511   
 G  c2512   
 G  c2513   
 G  c2514   
 G  c2515   
 G  c2516   
 G  c2517   
 G  c2518   
 G  c2519   
 G  c2520   
 G  c2521   
 G  c2522   
 G  c2523   
 G  c2524   
 G  c2525   
 G  c2526   
 G  c2527   
 G  c2528   
 G  c2529   
 G  c2530   
 G  c2531   
 G  c2532   
 G  c2533   
 G  c2534   
 G  c2535   
 G  c2536   
 G  c2537   
 G  c2538   
 G  c2539   
 G  c2540   
 G  c2541   
 G  c2542   
 G  c2543   
 G  c2544   
 G  c2545   
 G  c2546   
 G  c2547   
 G  c2548   
 G  c2549   
 G  c2550   
 G  c2551   
 G  c2552   
 G  c2553   
 G  c2554   
 G  c2555   
 G  c2556   
 G  c2557   
 G  c2558   
 G  c2559   
 G  c2560   
 G  c2561   
 G  c2562   
 G  c2563   
 G  c2564   
 G  c2565   
 G  c2566   
 G  c2567   
 G  c2568   
 G  c2569   
 G  c2570   
 G  c2571   
 G  c2572   
 G  c2573   
 G  c2574   
 G  c2575   
 G  c2576   
 G  c2577   
 G  c2578   
 G  c2579   
 G  c2580   
 G  c2581   
 G  c2582   
 G  c2583   
 G  c2584   
 G  c2585   
 G  c2586   
 G  c2587   
 G  c2588   
 G  c2589   
 G  c2590   
 G  c2591   
 G  c2592   
 G  c2593   
 G  c2594   
 G  c2595   
 G  c2596   
 G  c2597   
 G  c2598   
 G  c2599   
 G  c2600   
 G  c2601   
 G  c2602   
 G  c2603   
 G  c2604   
 G  c2605   
 G  c2606   
 G  c2607   
 G  c2608   
 G  c2609   
 G  c2610   
 G  c2611   
 G  c2612   
 G  c2613   
 G  c2614   
 G  c2615   
 G  c2616   
 G  c2617   
 G  c2618   
 G  c2619   
 G  c2620   
 G  c2621   
 G  c2622   
 G  c2623   
 G  c2624   
 G  c2625   
 G  c2626   
 G  c2627   
 G  c2628   
 G  c2629   
 G  c2630   
 G  c2631   
 G  c2632   
 G  c2633   
 G  c2634   
 G  c2635   
 G  c2636   
 G  c2637   
 G  c2638   
 G  c2639   
 G  c2640   
 G  c2641   
 G  c2642   
 G  c2643   
 G  c2644   
 G  c2645   
 G  c2646   
 G  c2647   
 G  c2648   
 G  c2649   
 G  c2650   
 G  c2651   
 G  c2652   
 G  c2653   
 G  c2654   
 G  c2655   
 G  c2656   
 G  c2657   
 G  c2658   
 G  c2659   
 G  c2660   
 G  c2661   
 G  c2662   
 G  c2663   
 G  c2664   
 G  c2665   
 G  c2666   
 G  c2667   
 G  c2668   
 G  c2669   
 G  c2670   
 G  c2671   
 G  c2672   
 G  c2673   
 G  c2674   
 G  c2675   
 G  c2676   
 G  c2677   
 G  c2678   
 G  c2679   
 G  c2680   
 G  c2681   
 G  c2682   
 G  c2683   
 G  c2684   
 G  c2685   
 G  c2686   
 G  c2687   
 G  c2688   
 G  c2689   
 G  c2690   
 G  c2691   
 G  c2692   
 G  c2693   
 G  c2694   
 G  c2695   
 G  c2696   
 G  c2697   
 G  c2698   
 G  c2699   
 G  c2700   
 G  c2701   
 G  c2702   
 G  c2703   
 G  c2704   
 G  c2705   
 G  c2706   
 G  c2707   
 G  c2708   
 G  c2709   
 G  c2710   
 G  c2711   
 G  c2712   
 G  c2713   
 G  c2714   
 G  c2715   
 G  c2716   
 G  c2717   
 G  c2718   
 G  c2719   
 G  c2720   
 G  c2721   
 G  c2722   
 G  c2723   
 G  c2724   
 G  c2725   
 G  c2726   
 G  c2727   
 G  c2728   
 G  c2729   
 G  c2730   
 G  c2731   
 G  c2732   
 G  c2733   
 G  c2734   
 G  c2735   
 G  c2736   
 G  c2737   
 G  c2738   
 G  c2739   
 G  c2740   
 G  c2741   
 G  c2742   
 G  c2743   
 G  c2744   
 G  c2745   
 G  c2746   
 G  c2747   
 G  c2748   
 G  c2749   
 G  c2750   
 G  c2751   
 G  c2752   
 G  c2753   
 G  c2754   
 G  c2755   
 G  c2756   
 G  c2757   
 G  c2758   
 G  c2759   
 G  c2760   
 G  c2761   
 G  c2762   
 G  c2763   
 G  c2764   
 G  c2765   
 G  c2766   
 G  c2767   
 G  c2768   
 G  c2769   
 G  c2770   
 G  c2771   
 G  c2772   
 G  c2773   
 G  c2774   
 G  c2775   
 G  c2776   
 G  c2777   
 G  c2778   
 G  c2779   
 G  c2780   
 G  c2781   
 G  c2782   
 G  c2783   
 G  c2784   
 G  c2785   
 G  c2786   
 G  c2787   
 G  c2788   
 G  c2789   
 G  c2790   
 G  c2791   
 G  c2792   
 G  c2793   
 G  c2794   
 G  c2795   
 G  c2796   
 G  c2797   
 G  c2798   
 G  c2799   
 G  c2800   
 G  c2801   
 G  c2802   
 G  c2803   
 G  c2804   
 G  c2805   
 G  c2806   
 G  c2807   
 G  c2808   
 G  c2809   
 G  c2810   
 G  c2811   
 G  c2812   
 G  c2813   
 G  c2814   
 G  c2815   
 G  c2816   
 G  c2817   
 G  c2818   
 G  c2819   
 G  c2820   
 G  c2821   
 G  c2822   
 G  c2823   
 G  c2824   
 G  c2825   
 G  c2826   
 G  c2827   
 G  c2828   
 G  c2829   
 G  c2830   
 G  c2831   
 G  c2832   
 G  c2833   
 G  c2834   
 G  c2835   
 G  c2836   
 G  c2837   
 G  c2838   
 G  c2839   
 G  c2840   
 G  c2841   
 G  c2842   
 G  c2843   
 G  c2844   
 G  c2845   
 G  c2846   
 G  c2847   
 G  c2848   
 G  c2849   
 G  c2850   
 G  c2851   
 G  c2852   
 G  c2853   
 G  c2854   
 G  c2855   
 G  c2856   
 G  c2857   
 G  c2858   
 G  c2859   
 G  c2860   
 G  c2861   
 G  c2862   
 G  c2863   
 G  c2864   
 G  c2865   
 G  c2866   
 G  c2867   
 G  c2868   
 G  c2869   
 G  c2870   
 G  c2871   
 G  c2872   
 G  c2873   
 G  c2874   
 G  c2875   
 G  c2876   
 G  c2877   
 G  c2878   
 G  c2879   
 G  c2880   
 G  c2881   
 G  c2882   
 G  c2883   
 G  c2884   
 G  c2885   
 G  c2886   
 G  c2887   
 G  c2888   
 G  c2889   
 G  c2890   
 G  c2891   
 G  c2892   
 G  c2893   
 G  c2894   
 G  c2895   
 G  c2896   
 G  c2897   
 G  c2898   
 G  c2899   
 G  c2900   
 G  c2901   
 G  c2902   
 G  c2903   
 G  c2904   
 G  c2905   
 G  c2906   
 G  c2907   
 G  c2908   
 G  c2909   
 G  c2910   
 G  c2911   
 G  c2912   
 G  c2913   
 G  c2914   
 G  c2915   
 G  c2916   
 G  c2917   
 G  c2918   
 G  c2919   
 G  c2920   
 G  c2921   
 G  c2922   
 G  c2923   
 G  c2924   
 G  c2925   
 G  c2926   
 G  c2927   
 G  c2928   
 G  c2929   
 G  c2930   
 G  c2931   
 G  c2932   
 G  c2933   
 G  c2934   
 G  c2935   
 G  c2936   
 G  c2937   
 G  c2938   
 G  c2939   
 G  c2940   
 G  c2941   
 G  c2942   
 G  c2943   
 G  c2944   
 G  c2945   
 G  c2946   
 G  c2947   
 G  c2948   
 G  c2949   
 G  c2950   
 G  c2951   
 G  c2952   
 G  c2953   
 G  c2954   
 G  c2955   
 G  c2956   
 G  c2957   
 G  c2958   
 G  c2959   
 G  c2960   
 G  c2961   
 G  c2962   
 G  c2963   
 G  c2964   
 G  c2965   
 G  c2966   
 G  c2967   
 G  c2968   
 G  c2969   
 G  c2970   
 G  c2971   
 G  c2972   
 G  c2973   
 G  c2974   
 G  c2975   
 G  c2976   
 G  c2977   
 G  c2978   
 G  c2979   
 G  c2980   
 G  c2981   
 G  c2982   
 G  c2983   
 G  c2984   
 G  c2985   
 G  c2986   
 G  c2987   
 G  c2988   
 G  c2989   
 G  c2990   
 G  c2991   
 G  c2992   
 G  c2993   
 G  c2994   
 G  c2995   
 G  c2996   
 G  c2997   
 G  c2998   
 G  c2999   
 G  c3000   
 G  c3001   
 G  c3002   
 G  c3003   
 G  c3004   
 G  c3005   
 G  c3006   
 G  c3007   
 G  c3008   
 G  c3009   
 G  c3010   
 G  c3011   
 G  c3012   
 G  c3013   
 G  c3014   
 G  c3015   
 G  c3016   
 G  c3017   
 G  c3018   
 G  c3019   
 G  c3020   
 G  c3021   
 G  c3022   
 G  c3023   
 G  c3024   
 G  c3025   
 G  c3026   
 G  c3027   
 G  c3028   
 G  c3029   
 G  c3030   
 G  c3031   
 G  c3032   
 G  c3033   
 G  c3034   
 G  c3035   
 G  c3036   
 G  c3037   
 G  c3038   
 G  c3039   
 G  c3040   
 G  c3041   
 G  c3042   
 G  c3043   
 G  c3044   
 G  c3045   
 G  c3046   
 G  c3047   
 G  c3048   
 G  c3049   
 G  c3050   
 G  c3051   
 G  c3052   
 G  c3053   
 G  c3054   
 G  c3055   
 G  c3056   
 G  c3057   
 G  c3058   
 G  c3059   
 G  c3060   
 G  c3061   
 G  c3062   
 G  c3063   
 G  c3064   
 G  c3065   
 G  c3066   
 G  c3067   
 G  c3068   
 G  c3069   
 G  c3070   
 G  c3071   
 G  c3072   
 G  c3073   
 G  c3074   
 G  c3075   
 G  c3076   
 G  c3077   
 G  c3078   
 G  c3079   
 G  c3080   
 G  c3081   
 G  c3082   
 G  c3083   
 G  c3084   
 G  c3085   
 G  c3086   
 G  c3087   
 G  c3088   
 G  c3089   
 G  c3090   
 G  c3091   
 G  c3092   
 G  c3093   
 G  c3094   
 G  c3095   
 G  c3096   
 G  c3097   
 G  c3098   
 G  c3099   
 G  c3100   
 G  c3101   
 G  c3102   
 G  c3103   
 G  c3104   
 G  c3105   
 G  c3106   
 G  c3107   
 G  c3108   
 G  c3109   
 G  c3110   
 G  c3111   
 G  c3112   
 G  c3113   
 G  c3114   
 G  c3115   
 G  c3116   
 G  c3117   
 G  c3118   
 G  c3119   
 G  c3120   
 G  c3121   
 G  c3122   
 G  c3123   
 G  c3124   
 G  c3125   
 G  c3126   
 G  c3127   
 G  c3128   
 G  c3129   
 G  c3130   
 G  c3131   
 G  c3132   
 G  c3133   
 G  c3134   
 G  c3135   
 G  c3136   
 G  c3137   
 G  c3138   
 G  c3139   
 G  c3140   
 G  c3141   
 G  c3142   
 G  c3143   
 G  c3144   
 G  c3145   
 G  c3146   
 G  c3147   
 G  c3148   
 G  c3149   
 G  c3150   
 G  c3151   
 G  c3152   
 G  c3153   
 G  c3154   
 G  c3155   
 G  c3156   
 G  c3157   
 G  c3158   
 G  c3159   
 G  c3160   
 G  c3161   
 G  c3162   
 G  c3163   
 G  c3164   
 G  c3165   
 G  c3166   
 G  c3167   
 G  c3168   
 G  c3169   
 G  c3170   
 G  c3171   
 G  c3172   
 G  c3173   
 G  c3174   
 G  c3175   
 G  c3176   
 G  c3177   
 G  c3178   
 G  c3179   
 G  c3180   
 G  c3181   
 G  c3182   
 G  c3183   
 G  c3184   
 G  c3185   
 G  c3186   
 G  c3187   
 G  c3188   
 G  c3189   
 G  c3190   
 G  c3191   
 G  c3192   
 G  c3193   
 G  c3194   
 G  c3195   
 G  c3196   
 G  c3197   
 G  c3198   
 G  c3199   
 G  c3200   
 G  c3201   
 G  c3202   
 G  c3203   
 G  c3204   
 G  c3205   
 G  c3206   
 G  c3207   
 G  c3208   
 G  c3209   
 G  c3210   
 G  c3211   
 G  c3212   
 G  c3213   
 G  c3214   
 G  c3215   
 G  c3216   
 G  c3217   
 G  c3218   
 G  c3219   
 G  c3220   
 G  c3221   
 G  c3222   
 G  c3223   
 G  c3224   
 G  c3225   
 G  c3226   
 G  c3227   
 G  c3228   
 G  c3229   
 G  c3230   
 G  c3231   
 G  c3232   
 G  c3233   
 G  c3234   
 G  c3235   
 G  c3236   
 G  c3237   
 G  c3238   
 G  c3239   
 G  c3240   
 G  c3241   
 G  c3242   
 G  c3243   
 G  c3244   
 G  c3245   
 G  c3246   
 G  c3247   
 G  c3248   
 G  c3249   
 G  c3250   
 G  c3251   
 G  c3252   
 G  c3253   
 G  c3254   
 G  c3255   
 G  c3256   
 G  c3257   
 G  c3258   
 G  c3259   
 G  c3260   
 G  c3261   
 G  c3262   
 G  c3263   
 G  c3264   
 G  c3265   
 G  c3266   
 G  c3267   
 G  c3268   
 G  c3269   
 G  c3270   
 G  c3271   
 G  c3272   
 G  c3273   
 G  c3274   
 G  c3275   
 G  c3276   
 G  c3277   
 G  c3278   
 G  c3279   
 G  c3280   
 G  c3281   
 G  c3282   
 G  c3283   
 G  c3284   
 G  c3285   
 G  c3286   
 G  c3287   
 G  c3288   
 G  c3289   
 G  c3290   
 G  c3291   
 G  c3292   
 G  c3293   
 G  c3294   
 G  c3295   
 G  c3296   
 G  c3297   
 G  c3298   
 G  c3299   
 G  c3300   
 G  c3301   
 G  c3302   
 G  c3303   
 G  c3304   
 G  c3305   
 G  c3306   
 G  c3307   
 G  c3308   
 G  c3309   
 G  c3310   
 G  c3311   
 G  c3312   
 G  c3313   
 G  c3314   
 G  c3315   
 G  c3316   
 G  c3317   
 G  c3318   
 G  c3319   
 G  c3320   
 G  c3321   
 G  c3322   
 G  c3323   
 G  c3324   
 G  c3325   
 G  c3326   
 G  c3327   
 G  c3328   
 G  c3329   
 G  c3330   
 G  c3331   
 G  c3332   
 G  c3333   
 G  c3334   
 G  c3335   
 G  c3336   
 G  c3337   
 G  c3338   
 G  c3339   
 G  c3340   
 G  c3341   
 G  c3342   
 G  c3343   
 G  c3344   
 G  c3345   
 G  c3346   
 G  c3347   
 G  c3348   
 G  c3349   
 G  c3350   
 G  c3351   
 G  c3352   
 G  c3353   
 G  c3354   
 G  c3355   
 G  c3356   
 G  c3357   
 G  c3358   
 G  c3359   
 G  c3360   
 G  c3361   
 G  c3362   
 G  c3363   
 G  c3364   
 G  c3365   
 G  c3366   
 G  c3367   
 G  c3368   
 G  c3369   
 G  c3370   
 G  c3371   
 G  c3372   
 G  c3373   
 G  c3374   
 G  c3375   
 G  c3376   
 G  c3377   
 G  c3378   
 G  c3379   
 G  c3380   
 G  c3381   
 G  c3382   
 G  c3383   
 G  c3384   
 G  c3385   
 G  c3386   
 G  c3387   
 G  c3388   
 G  c3389   
 G  c3390   
 G  c3391   
 G  c3392   
 G  c3393   
 G  c3394   
 G  c3395   
 G  c3396   
 G  c3397   
 G  c3398   
 G  c3399   
 G  c3400   
 G  c3401   
 G  c3402   
 G  c3403   
 G  c3404   
 G  c3405   
 G  c3406   
 G  c3407   
 G  c3408   
 G  c3409   
 G  c3410   
 G  c3411   
 G  c3412   
 G  c3413   
 G  c3414   
 G  c3415   
 G  c3416   
 G  c3417   
 G  c3418   
 G  c3419   
 G  c3420   
 G  c3421   
 G  c3422   
 G  c3423   
 G  c3424   
 G  c3425   
 G  c3426   
 G  c3427   
 G  c3428   
 G  c3429   
 G  c3430   
 G  c3431   
 G  c3432   
 G  c3433   
 G  c3434   
 G  c3435   
 G  c3436   
 G  c3437   
 G  c3438   
 G  c3439   
 G  c3440   
 G  c3441   
 G  c3442   
 G  c3443   
 G  c3444   
 G  c3445   
 G  c3446   
 G  c3447   
 G  c3448   
 G  c3449   
 G  c3450   
 G  c3451   
 G  c3452   
 G  c3453   
 G  c3454   
 G  c3455   
 G  c3456   
 G  c3457   
 G  c3458   
 G  c3459   
 G  c3460   
 G  c3461   
 G  c3462   
 G  c3463   
 G  c3464   
 G  c3465   
 G  c3466   
 G  c3467   
 G  c3468   
 G  c3469   
 G  c3470   
 G  c3471   
 G  c3472   
 G  c3473   
 G  c3474   
 G  c3475   
 G  c3476   
 G  c3477   
 G  c3478   
 G  c3479   
 G  c3480   
 G  c3481   
 G  c3482   
 G  c3483   
 G  c3484   
 G  c3485   
 G  c3486   
 G  c3487   
 G  c3488   
 G  c3489   
 G  c3490   
 G  c3491   
 G  c3492   
 G  c3493   
 G  c3494   
 G  c3495   
 G  c3496   
 G  c3497   
 G  c3498   
 G  c3499   
 G  c3500   
 G  c3501   
 G  c3502   
 G  c3503   
 G  c3504   
 G  c3505   
 G  c3506   
 G  c3507   
 G  c3508   
 G  c3509   
 G  c3510   
 G  c3511   
 G  c3512   
 G  c3513   
 G  c3514   
 G  c3515   
 G  c3516   
 G  c3517   
 G  c3518   
 G  c3519   
 G  c3520   
 G  c3521   
 G  c3522   
 G  c3523   
 G  c3524   
 G  c3525   
 G  c3526   
 G  c3527   
 G  c3528   
 G  c3529   
 G  c3530   
 G  c3531   
 G  c3532   
 G  c3533   
 G  c3534   
 G  c3535   
 G  c3536   
 G  c3537   
 G  c3538   
 G  c3539   
 G  c3540   
 G  c3541   
 G  c3542   
 G  c3543   
 G  c3544   
 G  c3545   
 G  c3546   
 G  c3547   
 G  c3548   
 G  c3549   
 G  c3550   
 G  c3551   
 G  c3552   
 G  c3553   
 G  c3554   
 G  c3555   
 G  c3556   
 G  c3557   
 G  c3558   
 G  c3559   
 G  c3560   
 G  c3561   
 G  c3562   
 G  c3563   
 G  c3564   
 G  c3565   
 G  c3566   
 G  c3567   
 G  c3568   
 G  c3569   
 G  c3570   
 G  c3571   
 G  c3572   
 G  c3573   
 G  c3574   
 G  c3575   
 G  c3576   
 G  c3577   
 G  c3578   
 G  c3579   
 G  c3580   
 G  c3581   
 G  c3582   
 G  c3583   
 G  c3584   
 G  c3585   
 G  c3586   
 G  c3587   
 G  c3588   
 G  c3589   
 G  c3590   
 G  c3591   
 G  c3592   
 G  c3593   
 G  c3594   
 G  c3595   
 G  c3596   
 G  c3597   
 G  c3598   
 G  c3599   
 G  c3600   
 G  c3601   
 G  c3602   
 G  c3603   
 G  c3604   
 G  c3605   
 G  c3606   
 G  c3607   
 G  c3608   
 G  c3609   
 G  c3610   
 G  c3611   
 G  c3612   
 G  c3613   
 G  c3614   
 G  c3615   
 G  c3616   
 G  c3617   
 G  c3618   
 G  c3619   
 G  c3620   
 G  c3621   
 G  c3622   
 G  c3623   
 G  c3624   
 G  c3625   
 G  c3626   
 G  c3627   
 G  c3628   
 G  c3629   
 G  c3630   
 G  c3631   
 G  c3632   
 G  c3633   
 G  c3634   
 G  c3635   
 G  c3636   
 G  c3637   
 G  c3638   
 G  c3639   
 G  c3640   
 G  c3641   
 G  c3642   
 G  c3643   
 G  c3644   
 G  c3645   
 G  c3646   
 G  c3647   
 G  c3648   
 G  c3649   
 G  c3650   
 G  c3651   
 G  c3652   
 G  c3653   
 G  c3654   
 G  c3655   
 G  c3656   
 G  c3657   
 G  c3658   
 G  c3659   
 G  c3660   
 G  c3661   
 G  c3662   
 G  c3663   
 G  c3664   
 G  c3665   
 G  c3666   
 G  c3667   
 G  c3668   
 G  c3669   
 G  c3670   
 G  c3671   
 G  c3672   
 G  c3673   
 G  c3674   
 G  c3675   
 G  c3676   
 G  c3677   
 G  c3678   
 G  c3679   
 G  c3680   
 G  c3681   
 G  c3682   
 G  c3683   
 G  c3684   
 G  c3685   
 G  c3686   
 G  c3687   
 G  c3688   
 G  c3689   
 G  c3690   
 G  c3691   
 G  c3692   
 G  c3693   
 G  c3694   
 G  c3695   
 G  c3696   
 G  c3697   
 G  c3698   
 G  c3699   
 G  c3700   
 G  c3701   
 G  c3702   
 G  c3703   
 G  c3704   
 G  c3705   
 G  c3706   
 G  c3707   
 G  c3708   
 G  c3709   
 G  c3710   
 G  c3711   
 G  c3712   
 G  c3713   
 G  c3714   
 G  c3715   
 G  c3716   
 G  c3717   
 G  c3718   
 G  c3719   
 G  c3720   
 G  c3721   
 G  c3722   
 G  c3723   
 G  c3724   
 G  c3725   
 G  c3726   
 G  c3727   
 G  c3728   
 G  c3729   
 G  c3730   
 G  c3731   
 G  c3732   
 G  c3733   
 G  c3734   
 G  c3735   
 G  c3736   
 G  c3737   
 G  c3738   
 G  c3739   
 G  c3740   
 G  c3741   
 G  c3742   
 G  c3743   
 G  c3744   
 G  c3745   
 G  c3746   
 G  c3747   
 G  c3748   
 G  c3749   
 G  c3750   
 G  c3751   
 G  c3752   
 G  c3753   
 G  c3754   
 G  c3755   
 G  c3756   
 G  c3757   
 G  c3758   
 G  c3759   
 G  c3760   
 G  c3761   
 G  c3762   
 G  c3763   
 G  c3764   
 G  c3765   
 G  c3766   
 G  c3767   
 G  c3768   
 G  c3769   
 G  c3770   
 G  c3771   
 G  c3772   
 G  c3773   
 G  c3774   
 G  c3775   
 G  c3776   
 G  c3777   
 G  c3778   
 G  c3779   
 G  c3780   
 G  c3781   
 G  c3782   
 G  c3783   
 G  c3784   
 G  c3785   
 G  c3786   
 G  c3787   
 G  c3788   
 G  c3789   
 G  c3790   
 G  c3791   
 G  c3792   
 G  c3793   
 G  c3794   
 G  c3795   
 G  c3796   
 G  c3797   
 G  c3798   
 G  c3799   
 G  c3800   
 G  c3801   
 G  c3802   
 G  c3803   
 G  c3804   
 G  c3805   
 G  c3806   
 G  c3807   
 G  c3808   
 G  c3809   
 G  c3810   
 G  c3811   
 G  c3812   
 G  c3813   
 G  c3814   
 G  c3815   
 G  c3816   
 G  c3817   
 G  c3818   
 G  c3819   
 G  c3820   
 G  c3821   
 G  c3822   
 G  c3823   
 G  c3824   
 G  c3825   
 G  c3826   
 G  c3827   
 G  c3828   
 G  c3829   
 G  c3830   
 G  c3831   
 G  c3832   
 G  c3833   
 G  c3834   
 G  c3835   
 G  c3836   
 G  c3837   
 G  c3838   
 G  c3839   
 G  c3840   
 G  c3841   
 G  c3842   
 G  c3843   
 G  c3844   
 G  c3845   
 G  c3846   
 G  c3847   
 G  c3848   
 G  c3849   
 G  c3850   
 G  c3851   
 G  c3852   
 G  c3853   
 G  c3854   
 G  c3855   
 G  c3856   
 G  c3857   
 G  c3858   
 G  c3859   
 G  c3860   
 G  c3861   
 G  c3862   
 G  c3863   
 G  c3864   
 G  c3865   
 G  c3866   
 G  c3867   
 G  c3868   
 G  c3869   
 G  c3870   
 G  c3871   
 G  c3872   
 G  c3873   
 G  c3874   
 G  c3875   
 G  c3876   
 G  c3877   
 G  c3878   
 G  c3879   
 G  c3880   
 G  c3881   
 G  c3882   
 G  c3883   
 G  c3884   
 G  c3885   
 G  c3886   
 G  c3887   
 G  c3888   
 G  c3889   
 G  c3890   
 G  c3891   
 G  c3892   
 G  c3893   
 G  c3894   
 G  c3895   
 G  c3896   
 G  c3897   
 G  c3898   
 G  c3899   
 G  c3900   
 G  c3901   
 G  c3902   
 G  c3903   
 G  c3904   
 G  c3905   
 G  c3906   
 G  c3907   
 G  c3908   
 G  c3909   
 G  c3910   
 G  c3911   
 G  c3912   
 G  c3913   
 G  c3914   
 G  c3915   
 G  c3916   
 G  c3917   
 G  c3918   
 G  c3919   
 G  c3920   
 G  c3921   
 G  c3922   
 G  c3923   
 G  c3924   
 G  c3925   
 G  c3926   
 G  c3927   
 G  c3928   
 G  c3929   
 G  c3930   
 G  c3931   
 G  c3932   
 G  c3933   
 G  c3934   
 G  c3935   
 G  c3936   
 G  c3937   
 G  c3938   
 G  c3939   
 G  c3940   
 G  c3941   
 G  c3942   
 G  c3943   
 G  c3944   
 G  c3945   
 G  c3946   
 G  c3947   
 G  c3948   
 G  c3949   
 G  c3950   
 G  c3951   
 G  c3952   
 G  c3953   
 G  c3954   
 G  c3955   
 G  c3956   
 G  c3957   
 G  c3958   
 G  c3959   
 G  c3960   
 G  c3961   
 G  c3962   
 G  c3963   
 G  c3964   
 G  c3965   
 G  c3966   
 G  c3967   
 G  c3968   
 G  c3969   
 G  c3970   
 G  c3971   
 G  c3972   
 G  c3973   
 G  c3974   
 G  c3975   
 G  c3976   
 G  c3977   
 G  c3978   
 G  c3979   
 G  c3980   
 G  c3981   
 G  c3982   
 G  c3983   
 G  c3984   
 G  c3985   
 G  c3986   
 G  c3987   
 G  c3988   
 G  c3989   
 G  c3990   
 G  c3991   
 G  c3992   
 G  c3993   
 G  c3994   
 G  c3995   
 G  c3996   
 G  c3997   
 G  c3998   
 G  c3999   
 G  c4000   
 G  c4001   
 G  c4002   
 G  c4003   
 G  c4004   
 G  c4005   
 G  c4006   
 G  c4007   
 G  c4008   
 G  c4009   
 G  c4010   
 G  c4011   
 G  c4012   
 G  c4013   
 G  c4014   
 G  c4015   
 G  c4016   
 G  c4017   
 G  c4018   
 G  c4019   
 G  c4020   
 G  c4021   
 G  c4022   
 G  c4023   
 G  c4024   
 G  c4025   
 G  c4026   
 G  c4027   
 G  c4028   
 G  c4029   
 G  c4030   
 G  c4031   
 G  c4032   
 G  c4033   
 G  c4034   
 G  c4035   
 G  c4036   
 G  c4037   
 G  c4038   
 G  c4039   
 G  c4040   
 G  c4041   
 G  c4042   
 G  c4043   
 G  c4044   
 G  c4045   
 G  c4046   
 G  c4047   
 G  c4048   
 G  c4049   
 G  c4050   
 G  c4051   
 G  c4052   
 G  c4053   
 G  c4054   
 G  c4055   
 G  c4056   
 G  c4057   
 G  c4058   
 G  c4059   
 G  c4060   
 G  c4061   
 G  c4062   
 G  c4063   
 G  c4064   
 G  c4065   
 G  c4066   
 G  c4067   
 G  c4068   
 G  c4069   
 G  c4070   
 G  c4071   
 G  c4072   
 G  c4073   
 G  c4074   
 G  c4075   
 G  c4076   
 G  c4077   
 G  c4078   
 G  c4079   
 G  c4080   
 G  c4081   
 G  c4082   
 G  c4083   
 G  c4084   
 G  c4085   
 G  c4086   
 G  c4087   
 G  c4088   
 G  c4089   
 G  c4090   
 G  c4091   
 G  c4092   
 G  c4093   
 G  c4094   
 G  c4095   
 G  c4096   
 G  c4097   
 G  c4098   
 G  c4099   
 G  c4100   
 G  c4101   
 G  c4102   
 G  c4103   
 G  c4104   
 G  c4105   
 G  c4106   
 G  c4107   
 G  c4108   
 G  c4109   
 G  c4110   
 G  c4111   
 G  c4112   
 G  c4113   
 G  c4114   
 G  c4115   
 G  c4116   
 G  c4117   
 G  c4118   
 G  c4119   
 G  c4120   
 G  c4121   
 G  c4122   
 G  c4123   
 G  c4124   
 G  c4125   
 G  c4126   
 G  c4127   
 G  c4128   
 G  c4129   
 G  c4130   
 G  c4131   
 G  c4132   
 G  c4133   
 G  c4134   
 G  c4135   
 G  c4136   
 G  c4137   
 G  c4138   
 G  c4139   
 G  c4140   
 G  c4141   
 G  c4142   
 G  c4143   
 G  c4144   
 G  c4145   
 G  c4146   
 G  c4147   
 G  c4148   
 G  c4149   
 G  c4150   
 G  c4151   
 G  c4152   
 G  c4153   
 G  c4154   
 G  c4155   
 G  c4156   
 G  c4157   
 G  c4158   
 G  c4159   
 G  c4160   
 G  c4161   
 G  c4162   
 G  c4163   
 G  c4164   
 G  c4165   
 G  c4166   
 G  c4167   
 G  c4168   
 G  c4169   
 G  c4170   
 G  c4171   
 G  c4172   
 G  c4173   
 G  c4174   
 G  c4175   
 G  c4176   
 G  c4177   
 G  c4178   
 G  c4179   
 G  c4180   
 G  c4181   
 G  c4182   
 G  c4183   
 G  c4184   
 G  c4185   
 G  c4186   
 G  c4187   
 G  c4188   
 G  c4189   
 G  c4190   
 G  c4191   
 G  c4192   
 G  c4193   
 G  c4194   
 G  c4195   
 G  c4196   
 G  c4197   
 G  c4198   
 G  c4199   
 G  c4200   
 G  c4201   
 G  c4202   
 G  c4203   
 G  c4204   
 G  c4205   
 G  c4206   
 G  c4207   
 G  c4208   
 G  c4209   
 G  c4210   
 G  c4211   
 G  c4212   
 G  c4213   
 G  c4214   
 G  c4215   
 G  c4216   
 G  c4217   
 G  c4218   
 G  c4219   
 G  c4220   
 G  c4221   
 G  c4222   
 G  c4223   
 G  c4224   
 G  c4225   
 G  c4226   
 G  c4227   
 G  c4228   
 G  c4229   
 G  c4230   
 G  c4231   
 G  c4232   
 G  c4233   
 G  c4234   
 G  c4235   
 G  c4236   
 G  c4237   
 G  c4238   
 G  c4239   
 G  c4240   
 G  c4241   
 G  c4242   
 G  c4243   
 G  c4244   
 G  c4245   
 G  c4246   
 G  c4247   
 G  c4248   
 G  c4249   
 G  c4250   
 G  c4251   
 G  c4252   
 G  c4253   
 G  c4254   
 G  c4255   
 G  c4256   
 G  c4257   
 G  c4258   
 G  c4259   
 G  c4260   
 G  c4261   
 G  c4262   
 G  c4263   
 G  c4264   
 G  c4265   
 G  c4266   
 G  c4267   
 G  c4268   
 G  c4269   
 G  c4270   
 G  c4271   
 G  c4272   
 G  c4273   
 G  c4274   
 G  c4275   
 G  c4276   
 G  c4277   
 G  c4278   
 G  c4279   
 G  c4280   
 G  c4281   
 G  c4282   
 G  c4283   
 G  c4284   
 G  c4285   
 G  c4286   
 G  c4287   
 G  c4288   
 G  c4289   
 G  c4290   
 G  c4291   
 G  c4292   
 G  c4293   
 G  c4294   
 G  c4295   
 G  c4296   
 G  c4297   
 G  c4298   
 G  c4299   
 G  c4300   
 G  c4301   
 G  c4302   
 G  c4303   
 G  c4304   
 G  c4305   
 G  c4306   
 G  c4307   
 G  c4308   
 G  c4309   
 G  c4310   
 G  c4311   
 G  c4312   
 G  c4313   
 G  c4314   
 G  c4315   
 G  c4316   
 G  c4317   
 G  c4318   
 G  c4319   
 G  c4320   
 G  c4321   
 G  c4322   
 G  c4323   
 G  c4324   
 G  c4325   
 G  c4326   
 G  c4327   
 G  c4328   
 G  c4329   
 G  c4330   
 G  c4331   
 G  c4332   
 G  c4333   
 G  c4334   
 G  c4335   
 G  c4336   
 G  c4337   
 G  c4338   
 G  c4339   
 G  c4340   
 G  c4341   
 G  c4342   
 G  c4343   
 G  c4344   
 G  c4345   
 G  c4346   
 G  c4347   
 G  c4348   
 G  c4349   
 G  c4350   
 G  c4351   
 G  c4352   
 G  c4353   
 G  c4354   
 G  c4355   
 G  c4356   
 G  c4357   
 G  c4358   
 G  c4359   
 G  c4360   
 G  c4361   
 G  c4362   
 G  c4363   
 G  c4364   
 G  c4365   
 G  c4366   
 G  c4367   
 G  c4368   
 G  c4369   
 G  c4370   
 G  c4371   
 G  c4372   
 G  c4373   
 G  c4374   
 G  c4375   
 G  c4376   
 G  c4377   
 G  c4378   
 G  c4379   
 G  c4380   
 G  c4381   
 G  c4382   
 G  c4383   
 G  c4384   
 G  c4385   
 G  c4386   
 G  c4387   
 G  c4388   
 G  c4389   
 G  c4390   
 G  c4391   
 G  c4392   
 G  c4393   
 G  c4394   
 G  c4395   
 G  c4396   
 G  c4397   
 G  c4398   
 G  c4399   
 G  c4400   
 G  c4401   
 G  c4402   
 G  c4403   
 G  c4404   
 G  c4405   
 G  c4406   
 G  c4407   
 G  c4408   
 G  c4409   
 G  c4410   
 G  c4411   
 G  c4412   
 G  c4413   
 G  c4414   
 G  c4415   
 G  c4416   
 G  c4417   
 G  c4418   
 G  c4419   
 G  c4420   
 G  c4421   
 G  c4422   
 G  c4423   
 G  c4424   
 G  c4425   
 G  c4426   
 G  c4427   
 G  c4428   
 G  c4429   
 G  c4430   
 G  c4431   
 G  c4432   
 G  c4433   
 G  c4434   
 G  c4435   
 G  c4436   
 G  c4437   
 G  c4438   
 G  c4439   
 G  c4440   
 G  c4441   
 G  c4442   
 G  c4443   
 G  c4444   
 G  c4445   
 G  c4446   
 G  c4447   
 G  c4448   
 G  c4449   
 G  c4450   
 G  c4451   
 G  c4452   
 G  c4453   
 G  c4454   
 G  c4455   
 G  c4456   
 G  c4457   
 G  c4458   
 G  c4459   
 G  c4460   
 G  c4461   
 G  c4462   
 G  c4463   
 G  c4464   
 G  c4465   
 G  c4466   
 G  c4467   
 G  c4468   
 G  c4469   
 G  c4470   
 G  c4471   
 G  c4472   
 G  c4473   
 G  c4474   
 G  c4475   
 G  c4476   
 G  c4477   
 G  c4478   
 G  c4479   
 G  c4480   
 G  c4481   
 G  c4482   
 G  c4483   
 G  c4484   
 G  c4485   
 G  c4486   
 G  c4487   
 G  c4488   
 G  c4489   
 G  c4490   
 G  c4491   
 G  c4492   
 G  c4493   
 G  c4494   
 G  c4495   
 G  c4496   
 G  c4497   
 G  c4498   
 G  c4499   
 G  c4500   
 G  c4501   
 G  c4502   
 G  c4503   
 G  c4504   
 G  c4505   
 G  c4506   
 G  c4507   
 G  c4508   
 G  c4509   
 G  c4510   
 G  c4511   
 G  c4512   
 G  c4513   
 G  c4514   
 G  c4515   
 G  c4516   
 G  c4517   
 G  c4518   
 G  c4519   
 G  c4520   
 G  c4521   
 G  c4522   
 G  c4523   
 G  c4524   
 G  c4525   
 G  c4526   
 G  c4527   
 G  c4528   
 G  c4529   
 G  c4530   
 G  c4531   
 G  c4532   
 G  c4533   
 G  c4534   
 G  c4535   
 G  c4536   
 G  c4537   
 G  c4538   
 G  c4539   
 G  c4540   
 G  c4541   
 G  c4542   
 G  c4543   
 G  c4544   
 G  c4545   
 G  c4546   
 G  c4547   
 G  c4548   
 G  c4549   
 G  c4550   
 G  c4551   
 G  c4552   
 G  c4553   
 G  c4554   
 G  c4555   
 G  c4556   
 G  c4557   
 G  c4558   
 G  c4559   
 G  c4560   
 G  c4561   
 G  c4562   
 G  c4563   
 G  c4564   
 G  c4565   
 G  c4566   
 G  c4567   
 G  c4568   
 G  c4569   
 G  c4570   
 G  c4571   
 G  c4572   
 G  c4573   
 G  c4574   
 G  c4575   
 G  c4576   
 G  c4577   
 G  c4578   
 G  c4579   
 G  c4580   
 G  c4581   
 G  c4582   
 G  c4583   
 G  c4584   
 G  c4585   
 G  c4586   
 G  c4587   
 G  c4588   
 G  c4589   
 G  c4590   
 G  c4591   
 G  c4592   
 G  c4593   
 G  c4594   
 G  c4595   
 G  c4596   
 G  c4597   
 G  c4598   
 G  c4599   
 G  c4600   
 G  c4601   
 G  c4602   
 G  c4603   
 G  c4604   
 G  c4605   
 G  c4606   
 G  c4607   
 G  c4608   
 G  c4609   
 G  c4610   
 G  c4611   
 G  c4612   
 G  c4613   
 G  c4614   
 G  c4615   
 G  c4616   
 G  c4617   
 G  c4618   
 G  c4619   
 G  c4620   
 G  c4621   
 G  c4622   
 G  c4623   
 G  c4624   
 G  c4625   
 G  c4626   
 G  c4627   
 G  c4628   
 G  c4629   
 G  c4630   
 G  c4631   
 G  c4632   
 G  c4633   
 G  c4634   
 G  c4635   
 G  c4636   
 G  c4637   
 G  c4638   
 G  c4639   
 G  c4640   
 G  c4641   
 G  c4642   
 G  c4643   
 G  c4644   
 G  c4645   
 G  c4646   
 G  c4647   
 G  c4648   
 G  c4649   
 G  c4650   
 G  c4651   
 G  c4652   
 G  c4653   
 G  c4654   
 G  c4655   
 G  c4656   
 G  c4657   
 G  c4658   
 G  c4659   
 G  c4660   
 G  c4661   
 G  c4662   
 G  c4663   
 G  c4664   
 G  c4665   
 G  c4666   
 G  c4667   
 G  c4668   
 G  c4669   
 G  c4670   
 G  c4671   
 G  c4672   
 G  c4673   
 G  c4674   
 G  c4675   
 G  c4676   
 G  c4677   
 G  c4678   
 G  c4679   
 G  c4680   
 G  c4681   
 G  c4682   
 G  c4683   
 G  c4684   
 G  c4685   
 G  c4686   
 G  c4687   
 G  c4688   
 G  c4689   
 G  c4690   
 G  c4691   
 G  c4692   
 G  c4693   
 G  c4694   
 G  c4695   
 G  c4696   
 G  c4697   
 G  c4698   
 G  c4699   
 G  c4700   
 G  c4701   
 G  c4702   
 G  c4703   
 G  c4704   
 G  c4705   
 G  c4706   
 G  c4707   
 G  c4708   
 G  c4709   
 G  c4710   
 G  c4711   
 G  c4712   
 G  c4713   
 G  c4714   
 G  c4715   
 G  c4716   
 G  c4717   
 G  c4718   
 G  c4719   
 G  c4720   
 G  c4721   
 G  c4722   
 G  c4723   
 G  c4724   
 G  c4725   
 G  c4726   
 G  c4727   
 G  c4728   
 G  c4729   
 G  c4730   
 G  c4731   
 G  c4732   
 G  c4733   
 G  c4734   
 G  c4735   
 G  c4736   
 G  c4737   
 G  c4738   
 G  c4739   
 G  c4740   
 G  c4741   
 G  c4742   
 G  c4743   
 G  c4744   
 G  c4745   
 G  c4746   
 G  c4747   
 G  c4748   
 G  c4749   
 G  c4750   
 G  c4751   
 G  c4752   
 G  c4753   
 G  c4754   
 G  c4755   
 G  c4756   
 G  c4757   
 G  c4758   
 G  c4759   
 G  c4760   
 G  c4761   
 G  c4762   
 G  c4763   
 G  c4764   
 G  c4765   
 G  c4766   
 G  c4767   
 G  c4768   
 G  c4769   
 G  c4770   
 G  c4771   
 G  c4772   
 G  c4773   
 G  c4774   
 G  c4775   
 G  c4776   
 G  c4777   
 G  c4778   
 G  c4779   
 G  c4780   
 G  c4781   
 G  c4782   
 G  c4783   
 G  c4784   
 G  c4785   
 G  c4786   
 G  c4787   
 G  c4788   
 G  c4789   
 G  c4790   
 G  c4791   
 G  c4792   
 G  c4793   
 G  c4794   
 G  c4795   
 G  c4796   
 G  c4797   
 G  c4798   
 G  c4799   
 G  c4800   
 G  c4801   
 G  c4802   
 G  c4803   
 G  c4804   
 G  c4805   
 G  c4806   
 G  c4807   
 G  c4808   
 G  c4809   
 G  c4810   
 G  c4811   
 G  c4812   
 G  c4813   
 G  c4814   
 G  c4815   
 G  c4816   
 G  c4817   
 G  c4818   
 G  c4819   
 G  c4820   
 G  c4821   
 G  c4822   
 G  c4823   
 G  c4824   
 G  c4825   
 G  c4826   
 G  c4827   
 G  c4828   
 G  c4829   
 G  c4830   
 G  c4831   
 G  c4832   
 G  c4833   
 G  c4834   
 G  c4835   
 G  c4836   
 G  c4837   
 G  c4838   
 G  c4839   
 G  c4840   
 G  c4841   
 G  c4842   
 G  c4843   
 G  c4844   
 G  c4845   
 G  c4846   
 G  c4847   
 G  c4848   
 G  c4849   
 G  c4850   
 G  c4851   
 G  c4852   
 G  c4853   
 G  c4854   
 G  c4855   
 G  c4856   
 G  c4857   
 G  c4858   
 G  c4859   
 G  c4860   
 G  c4861   
 G  c4862   
 G  c4863   
 G  c4864   
 G  c4865   
 G  c4866   
 G  c4867   
 G  c4868   
 G  c4869   
 G  c4870   
 G  c4871   
 G  c4872   
 G  c4873   
 G  c4874   
 G  c4875   
 G  c4876   
 G  c4877   
 G  c4878   
 G  c4879   
 G  c4880   
 G  c4881   
 G  c4882   
 G  c4883   
 G  c4884   
 G  c4885   
 G  c4886   
 G  c4887   
 G  c4888   
 G  c4889   
 G  c4890   
 G  c4891   
 G  c4892   
 G  c4893   
 G  c4894   
 G  c4895   
 G  c4896   
 G  c4897   
 G  c4898   
 G  c4899   
 G  c4900   
 G  c4901   
 G  c4902   
 G  c4903   
 G  c4904   
 G  c4905   
 G  c4906   
 G  c4907   
 G  c4908   
 G  c4909   
 G  c4910   
 G  c4911   
 G  c4912   
 G  c4913   
 G  c4914   
 G  c4915   
 G  c4916   
 G  c4917   
 G  c4918   
 G  c4919   
 G  c4920   
 G  c4921   
 G  c4922   
 G  c4923   
 G  c4924   
 G  c4925   
 G  c4926   
 G  c4927   
 G  c4928   
 G  c4929   
 G  c4930   
 G  c4931   
 G  c4932   
 G  c4933   
 G  c4934   
 G  c4935   
 G  c4936   
 G  c4937   
 G  c4938   
 G  c4939   
 G  c4940   
 G  c4941   
 G  c4942   
 G  c4943   
 G  c4944   
 G  c4945   
 G  c4946   
 G  c4947   
 G  c4948   
 G  c4949   
 G  c4950   
 G  c4951   
 G  c4952   
 G  c4953   
 G  c4954   
 G  c4955   
 G  c4956   
 G  c4957   
 G  c4958   
 G  c4959   
 G  c4960   
 G  c4961   
 G  c4962   
 G  c4963   
 G  c4964   
 G  c4965   
 G  c4966   
 G  c4967   
 G  c4968   
 G  c4969   
 G  c4970   
 G  c4971   
 G  c4972   
 G  c4973   
 G  c4974   
 G  c4975   
 G  c4976   
 G  c4977   
 G  c4978   
 G  c4979   
 G  c4980   
 G  c4981   
 G  c4982   
 G  c4983   
 G  c4984   
 G  c4985   
 G  c4986   
 G  c4987   
 G  c4988   
 G  c4989   
 G  c4990   
 G  c4991   
 G  c4992   
 G  c4993   
 G  c4994   
 G  c4995   
 G  c4996   
 G  c4997   
 G  c4998   
 G  c4999   
 G  c5000   
 G  c5001   
 G  c5002   
 G  c5003   
 G  c5004   
 G  c5005   
 G  c5006   
 G  c5007   
 G  c5008   
 G  c5009   
 G  c5010   
 G  c5011   
 G  c5012   
 G  c5013   
 G  c5014   
 G  c5015   
 G  c5016   
 G  c5017   
 G  c5018   
 G  c5019   
 G  c5020   
 G  c5021   
 G  c5022   
 G  c5023   
 G  c5024   
 G  c5025   
 G  c5026   
 G  c5027   
 G  c5028   
 G  c5029   
 G  c5030   
 G  c5031   
 G  c5032   
 G  c5033   
 G  c5034   
 G  c5035   
 G  c5036   
 G  c5037   
 G  c5038   
 G  c5039   
 G  c5040   
 G  c5041   
 G  c5042   
 G  c5043   
 G  c5044   
 G  c5045   
 G  c5046   
 G  c5047   
 G  c5048   
 G  c5049   
 G  c5050   
 G  c5051   
 G  c5052   
 G  c5053   
 G  c5054   
 G  c5055   
 G  c5056   
 G  c5057   
 G  c5058   
 G  c5059   
 G  c5060   
 G  c5061   
 G  c5062   
 G  c5063   
 G  c5064   
 G  c5065   
 G  c5066   
 G  c5067   
 G  c5068   
 G  c5069   
 G  c5070   
 G  c5071   
 G  c5072   
 G  c5073   
 G  c5074   
 G  c5075   
 G  c5076   
 G  c5077   
 G  c5078   
 G  c5079   
 G  c5080   
 G  c5081   
 G  c5082   
 G  c5083   
 G  c5084   
 G  c5085   
 G  c5086   
 G  c5087   
 G  c5088   
 G  c5089   
 G  c5090   
 G  c5091   
 G  c5092   
 G  c5093   
 G  c5094   
 G  c5095   
 G  c5096   
 G  c5097   
 G  c5098   
 G  c5099   
 G  c5100   
 G  c5101   
 G  c5102   
 G  c5103   
 G  c5104   
 G  c5105   
 G  c5106   
 G  c5107   
 G  c5108   
 G  c5109   
 G  c5110   
 G  c5111   
 G  c5112   
 G  c5113   
 G  c5114   
 G  c5115   
 G  c5116   
 G  c5117   
 G  c5118   
 G  c5119   
 G  c5120   
 G  c5121   
 G  c5122   
 G  c5123   
 G  c5124   
 G  c5125   
 G  c5126   
 G  c5127   
 G  c5128   
 G  c5129   
 G  c5130   
 G  c5131   
 G  c5132   
 G  c5133   
 G  c5134   
 G  c5135   
 G  c5136   
 G  c5137   
 G  c5138   
 G  c5139   
 G  c5140   
 G  c5141   
 G  c5142   
 G  c5143   
 G  c5144   
 G  c5145   
 G  c5146   
 G  c5147   
 G  c5148   
 G  c5149   
 G  c5150   
 G  c5151   
 G  c5152   
 G  c5153   
 G  c5154   
 G  c5155   
 G  c5156   
 G  c5157   
 G  c5158   
 G  c5159   
 G  c5160   
 G  c5161   
 G  c5162   
 G  c5163   
 G  c5164   
 G  c5165   
 G  c5166   
 G  c5167   
 G  c5168   
 G  c5169   
 G  c5170   
 G  c5171   
 G  c5172   
 G  c5173   
 G  c5174   
 G  c5175   
 G  c5176   
 G  c5177   
 G  c5178   
 G  c5179   
 G  c5180   
 G  c5181   
 G  c5182   
 G  c5183   
 G  c5184   
 G  c5185   
 G  c5186   
 G  c5187   
 G  c5188   
 G  c5189   
 G  c5190   
 G  c5191   
 G  c5192   
 G  c5193   
 G  c5194   
 G  c5195   
 G  c5196   
 G  c5197   
 G  c5198   
 G  c5199   
 G  c5200   
 G  c5201   
 G  c5202   
 G  c5203   
 G  c5204   
 G  c5205   
 G  c5206   
 G  c5207   
 G  c5208   
 G  c5209   
 G  c5210   
 G  c5211   
 G  c5212   
 G  c5213   
 G  c5214   
 G  c5215   
 G  c5216   
 G  c5217   
 G  c5218   
 G  c5219   
 G  c5220   
 G  c5221   
 G  c5222   
 G  c5223   
 G  c5224   
 G  c5225   
 G  c5226   
 G  c5227   
 G  c5228   
 G  c5229   
 G  c5230   
 G  c5231   
 G  c5232   
 G  c5233   
 G  c5234   
 G  c5235   
 G  c5236   
 G  c5237   
 G  c5238   
 G  c5239   
 G  c5240   
 G  c5241   
 G  c5242   
 G  c5243   
 G  c5244   
 G  c5245   
 G  c5246   
 G  c5247   
 G  c5248   
 G  c5249   
 G  c5250   
 G  c5251   
 G  c5252   
 G  c5253   
 G  c5254   
 G  c5255   
 G  c5256   
 G  c5257   
 G  c5258   
 G  c5259   
 G  c5260   
 G  c5261   
 G  c5262   
 G  c5263   
 G  c5264   
 G  c5265   
 G  c5266   
 G  c5267   
 G  c5268   
 G  c5269   
 G  c5270   
 G  c5271   
 G  c5272   
 G  c5273   
 G  c5274   
 G  c5275   
 G  c5276   
 G  c5277   
 G  c5278   
 G  c5279   
 G  c5280   
 G  c5281   
 G  c5282   
 G  c5283   
 G  c5284   
 G  c5285   
 G  c5286   
 G  c5287   
 G  c5288   
 G  c5289   
 G  c5290   
 G  c5291   
 G  c5292   
 G  c5293   
 G  c5294   
 G  c5295   
 G  c5296   
 G  c5297   
 G  c5298   
 G  c5299   
 G  c5300   
 G  c5301   
 G  c5302   
 G  c5303   
 G  c5304   
 G  c5305   
 G  c5306   
 G  c5307   
 G  c5308   
 G  c5309   
 G  c5310   
 G  c5311   
 G  c5312   
 G  c5313   
 G  c5314   
 G  c5315   
 G  c5316   
 G  c5317   
 G  c5318   
 G  c5319   
 G  c5320   
 G  c5321   
 G  c5322   
 G  c5323   
 G  c5324   
 G  c5325   
 G  c5326   
 G  c5327   
 G  c5328   
 G  c5329   
 G  c5330   
 G  c5331   
 G  c5332   
 G  c5333   
 G  c5334   
 G  c5335   
 G  c5336   
 G  c5337   
 G  c5338   
 G  c5339   
 G  c5340   
 G  c5341   
 G  c5342   
 G  c5343   
 G  c5344   
 G  c5345   
 G  c5346   
 G  c5347   
 G  c5348   
 G  c5349   
 G  c5350   
 G  c5351   
 G  c5352   
 G  c5353   
 G  c5354   
 G  c5355   
 G  c5356   
 G  c5357   
 G  c5358   
 G  c5359   
 G  c5360   
 G  c5361   
 G  c5362   
 G  c5363   
 G  c5364   
 G  c5365   
 G  c5366   
 G  c5367   
 G  c5368   
 G  c5369   
 G  c5370   
 G  c5371   
 G  c5372   
 G  c5373   
 G  c5374   
 G  c5375   
 G  c5376   
 G  c5377   
 G  c5378   
 G  c5379   
 G  c5380   
 G  c5381   
 G  c5382   
 G  c5383   
 G  c5384   
 G  c5385   
 G  c5386   
 G  c5387   
 G  c5388   
 G  c5389   
 G  c5390   
 G  c5391   
 G  c5392   
 G  c5393   
 G  c5394   
 G  c5395   
 G  c5396   
 G  c5397   
 G  c5398   
 G  c5399   
 G  c5400   
 G  c5401   
 G  c5402   
 G  c5403   
 G  c5404   
 G  c5405   
 G  c5406   
 G  c5407   
 G  c5408   
 G  c5409   
 G  c5410   
 G  c5411   
 G  c5412   
 G  c5413   
 G  c5414   
 G  c5415   
 G  c5416   
 G  c5417   
 G  c5418   
 G  c5419   
 G  c5420   
 G  c5421   
 G  c5422   
 G  c5423   
 G  c5424   
 G  c5425   
 G  c5426   
 G  c5427   
 G  c5428   
 G  c5429   
 G  c5430   
 G  c5431   
 G  c5432   
 G  c5433   
 G  c5434   
 G  c5435   
 G  c5436   
 G  c5437   
 G  c5438   
 G  c5439   
 G  c5440   
 G  c5441   
 G  c5442   
 G  c5443   
 G  c5444   
 G  c5445   
 G  c5446   
 G  c5447   
 G  c5448   
 G  c5449   
 G  c5450   
 G  c5451   
 G  c5452   
 G  c5453   
 G  c5454   
 G  c5455   
 G  c5456   
 G  c5457   
 G  c5458   
 G  c5459   
 G  c5460   
 G  c5461   
 G  c5462   
 G  c5463   
 G  c5464   
 G  c5465   
 G  c5466   
 G  c5467   
 G  c5468   
 G  c5469   
 G  c5470   
 G  c5471   
 G  c5472   
 G  c5473   
 G  c5474   
 G  c5475   
 G  c5476   
 G  c5477   
 G  c5478   
 G  c5479   
 G  c5480   
 G  c5481   
 G  c5482   
 G  c5483   
 G  c5484   
 G  c5485   
 G  c5486   
 G  c5487   
 G  c5488   
 G  c5489   
 G  c5490   
 G  c5491   
 G  c5492   
 G  c5493   
 G  c5494   
 G  c5495   
 G  c5496   
 G  c5497   
 G  c5498   
 G  c5499   
 G  c5500   
 G  c5501   
 G  c5502   
 G  c5503   
 G  c5504   
 G  c5505   
 G  c5506   
 G  c5507   
 G  c5508   
 G  c5509   
 G  c5510   
 G  c5511   
 G  c5512   
 G  c5513   
 G  c5514   
 G  c5515   
 G  c5516   
 G  c5517   
 G  c5518   
 G  c5519   
 G  c5520   
 G  c5521   
 G  c5522   
 G  c5523   
 G  c5524   
 G  c5525   
 G  c5526   
 G  c5527   
 G  c5528   
 G  c5529   
 G  c5530   
 G  c5531   
 G  c5532   
 G  c5533   
 G  c5534   
 G  c5535   
 G  c5536   
 G  c5537   
 G  c5538   
 G  c5539   
 G  c5540   
 G  c5541   
 G  c5542   
 G  c5543   
 G  c5544   
 G  c5545   
 G  c5546   
 G  c5547   
 G  c5548   
 G  c5549   
 G  c5550   
 G  c5551   
 G  c5552   
 G  c5553   
 G  c5554   
 G  c5555   
 G  c5556   
 G  c5557   
 G  c5558   
 G  c5559   
 G  c5560   
 G  c5561   
 G  c5562   
 G  c5563   
 G  c5564   
 G  c5565   
 G  c5566   
 G  c5567   
 G  c5568   
 G  c5569   
 G  c5570   
 G  c5571   
 G  c5572   
 G  c5573   
 G  c5574   
 G  c5575   
 G  c5576   
 G  c5577   
 G  c5578   
 G  c5579   
 G  c5580   
 G  c5581   
 G  c5582   
 G  c5583   
 G  c5584   
 G  c5585   
 G  c5586   
 G  c5587   
 G  c5588   
 G  c5589   
 G  c5590   
 G  c5591   
 G  c5592   
 G  c5593   
 G  c5594   
 G  c5595   
 G  c5596   
 G  c5597   
 G  c5598   
 G  c5599   
 G  c5600   
 G  c5601   
 G  c5602   
 G  c5603   
 G  c5604   
 G  c5605   
 G  c5606   
 G  c5607   
 G  c5608   
 G  c5609   
 G  c5610   
 G  c5611   
 G  c5612   
 G  c5613   
 G  c5614   
 G  c5615   
 G  c5616   
 G  c5617   
 G  c5618   
 G  c5619   
 G  c5620   
 G  c5621   
 G  c5622   
 G  c5623   
 G  c5624   
 G  c5625   
 G  c5626   
 G  c5627   
 G  c5628   
 G  c5629   
 G  c5630   
 G  c5631   
 G  c5632   
 G  c5633   
 G  c5634   
 G  c5635   
 G  c5636   
 G  c5637   
 G  c5638   
 G  c5639   
 G  c5640   
 G  c5641   
 G  c5642   
 G  c5643   
 G  c5644   
 G  c5645   
 G  c5646   
 G  c5647   
 G  c5648   
 G  c5649   
 G  c5650   
 G  c5651   
 G  c5652   
 G  c5653   
 G  c5654   
 G  c5655   
 G  c5656   
 G  c5657   
 G  c5658   
 G  c5659   
 G  c5660   
 G  c5661   
 G  c5662   
 G  c5663   
 G  c5664   
 G  c5665   
 G  c5666   
 G  c5667   
 G  c5668   
 G  c5669   
 G  c5670   
 G  c5671   
 G  c5672   
 G  c5673   
 G  c5674   
 G  c5675   
 G  c5676   
 G  c5677   
 G  c5678   
 G  c5679   
 G  c5680   
 G  c5681   
 G  c5682   
 G  c5683   
 G  c5684   
 G  c5685   
 G  c5686   
 G  c5687   
 G  c5688   
 G  c5689   
 G  c5690   
 G  c5691   
 G  c5692   
 G  c5693   
 G  c5694   
 G  c5695   
 G  c5696   
 G  c5697   
 G  c5698   
 G  c5699   
 G  c5700   
 G  c5701   
 G  c5702   
 G  c5703   
 G  c5704   
 G  c5705   
 G  c5706   
 G  c5707   
 G  c5708   
 G  c5709   
 G  c5710   
 G  c5711   
 G  c5712   
 G  c5713   
 G  c5714   
 G  c5715   
 G  c5716   
 G  c5717   
 G  c5718   
 G  c5719   
 G  c5720   
 G  c5721   
 G  c5722   
 G  c5723   
 G  c5724   
 G  c5725   
 G  c5726   
 G  c5727   
 G  c5728   
 G  c5729   
 G  c5730   
 G  c5731   
 G  c5732   
 G  c5733   
 G  c5734   
 G  c5735   
 G  c5736   
 G  c5737   
 G  c5738   
 G  c5739   
 G  c5740   
 G  c5741   
 G  c5742   
 G  c5743   
 G  c5744   
 G  c5745   
 G  c5746   
 G  c5747   
 G  c5748   
 G  c5749   
 G  c5750   
 G  c5751   
 G  c5752   
 G  c5753   
 G  c5754   
 G  c5755   
 G  c5756   
 G  c5757   
 G  c5758   
 G  c5759   
 G  c5760   
 G  c5761   
 G  c5762   
 G  c5763   
 G  c5764   
 G  c5765   
 G  c5766   
 G  c5767   
 G  c5768   
 G  c5769   
 G  c5770   
 G  c5771   
 G  c5772   
 G  c5773   
 G  c5774   
 G  c5775   
 G  c5776   
 G  c5777   
 G  c5778   
 G  c5779   
 G  c5780   
 G  c5781   
 G  c5782   
 G  c5783   
 G  c5784   
 G  c5785   
 G  c5786   
 G  c5787   
 G  c5788   
 G  c5789   
 G  c5790   
 G  c5791   
 G  c5792   
 G  c5793   
 G  c5794   
 G  c5795   
 G  c5796   
 G  c5797   
 G  c5798   
 G  c5799   
 G  c5800   
 G  c5801   
 G  c5802   
 G  c5803   
 G  c5804   
 G  c5805   
 G  c5806   
 G  c5807   
 G  c5808   
 G  c5809   
 G  c5810   
 G  c5811   
 G  c5812   
 G  c5813   
 G  c5814   
 G  c5815   
 G  c5816   
 G  c5817   
 G  c5818   
 G  c5819   
 G  c5820   
 G  c5821   
 G  c5822   
 G  c5823   
 G  c5824   
 G  c5825   
 G  c5826   
 G  c5827   
 G  c5828   
 G  c5829   
 G  c5830   
 G  c5831   
 G  c5832   
 G  c5833   
 G  c5834   
 G  c5835   
 G  c5836   
 G  c5837   
 G  c5838   
 G  c5839   
 G  c5840   
 G  c5841   
 G  c5842   
 G  c5843   
 G  c5844   
 G  c5845   
 G  c5846   
 G  c5847   
 G  c5848   
 G  c5849   
 G  c5850   
 G  c5851   
 G  c5852   
 G  c5853   
 G  c5854   
 G  c5855   
 G  c5856   
 G  c5857   
 G  c5858   
 G  c5859   
 G  c5860   
 G  c5861   
 G  c5862   
 G  c5863   
 G  c5864   
 G  c5865   
 G  c5866   
 G  c5867   
 G  c5868   
 G  c5869   
 G  c5870   
 G  c5871   
 G  c5872   
 G  c5873   
 G  c5874   
 G  c5875   
 G  c5876   
 G  c5877   
 G  c5878   
 G  c5879   
 G  c5880   
 G  c5881   
 G  c5882   
 G  c5883   
 G  c5884   
 G  c5885   
 G  c5886   
 G  c5887   
 G  c5888   
 G  c5889   
 G  c5890   
 G  c5891   
 G  c5892   
 G  c5893   
 G  c5894   
 G  c5895   
 G  c5896   
 G  c5897   
 G  c5898   
 G  c5899   
 G  c5900   
 G  c5901   
 G  c5902   
 G  c5903   
 G  c5904   
 G  c5905   
 G  c5906   
 G  c5907   
 G  c5908   
 G  c5909   
 G  c5910   
 G  c5911   
 G  c5912   
 G  c5913   
 G  c5914   
 G  c5915   
 G  c5916   
 G  c5917   
 G  c5918   
 G  c5919   
 G  c5920   
 G  c5921   
 G  c5922   
 G  c5923   
 G  c5924   
 G  c5925   
 G  c5926   
 G  c5927   
 G  c5928   
 G  c5929   
 G  c5930   
 G  c5931   
 G  c5932   
 G  c5933   
 G  c5934   
 G  c5935   
 G  c5936   
 G  c5937   
 G  c5938   
 G  c5939   
 G  c5940   
 G  c5941   
 G  c5942   
 G  c5943   
 G  c5944   
 G  c5945   
 G  c5946   
 G  c5947   
 G  c5948   
 G  c5949   
 G  c5950   
 G  c5951   
 G  c5952   
 G  c5953   
 G  c5954   
 G  c5955   
 G  c5956   
 G  c5957   
 G  c5958   
 G  c5959   
 G  c5960   
 G  c5961   
 G  c5962   
 G  c5963   
 G  c5964   
 G  c5965   
 G  c5966   
 G  c5967   
 G  c5968   
 G  c5969   
 G  c5970   
 G  c5971   
 G  c5972   
 G  c5973   
 G  c5974   
 G  c5975   
 G  c5976   
 G  c5977   
 G  c5978   
 G  c5979   
 G  c5980   
 G  c5981   
 G  c5982   
 G  c5983   
 G  c5984   
 G  c5985   
 G  c5986   
 G  c5987   
 G  c5988   
 G  c5989   
 G  c5990   
 G  c5991   
 G  c5992   
 G  c5993   
 G  c5994   
 G  c5995   
 G  c5996   
 G  c5997   
 G  c5998   
 G  c5999   
 G  c6000   
 G  c6001   
 G  c6002   
 G  c6003   
 G  c6004   
 G  c6005   
 G  c6006   
 G  c6007   
 G  c6008   
 G  c6009   
 G  c6010   
 G  c6011   
 G  c6012   
 G  c6013   
 G  c6014   
 G  c6015   
 G  c6016   
 G  c6017   
 G  c6018   
 G  c6019   
 G  c6020   
 G  c6021   
 G  c6022   
 G  c6023   
 G  c6024   
 G  c6025   
 G  c6026   
 G  c6027   
 G  c6028   
 G  c6029   
 G  c6030   
 G  c6031   
 G  c6032   
 G  c6033   
 G  c6034   
 G  c6035   
 G  c6036   
 G  c6037   
 G  c6038   
 G  c6039   
 G  c6040   
 G  c6041   
 G  c6042   
 G  c6043   
 G  c6044   
 G  c6045   
 G  c6046   
 G  c6047   
 G  c6048   
 G  c6049   
 G  c6050   
 G  c6051   
 G  c6052   
 G  c6053   
 G  c6054   
 G  c6055   
 G  c6056   
 G  c6057   
 G  c6058   
 G  c6059   
 G  c6060   
 G  c6061   
 G  c6062   
 G  c6063   
 G  c6064   
 G  c6065   
 G  c6066   
 G  c6067   
 G  c6068   
 G  c6069   
 G  c6070   
 G  c6071   
 G  c6072   
 G  c6073   
 G  c6074   
 G  c6075   
 G  c6076   
 G  c6077   
 G  c6078   
 G  c6079   
 G  c6080   
 G  c6081   
 G  c6082   
 G  c6083   
 G  c6084   
 G  c6085   
 G  c6086   
 G  c6087   
 G  c6088   
 G  c6089   
 G  c6090   
 G  c6091   
 G  c6092   
 G  c6093   
 G  c6094   
 G  c6095   
 G  c6096   
 G  c6097   
 G  c6098   
 G  c6099   
 G  c6100   
 G  c6101   
 G  c6102   
 G  c6103   
 G  c6104   
 G  c6105   
 G  c6106   
 G  c6107   
 G  c6108   
 G  c6109   
 G  c6110   
 G  c6111   
 G  c6112   
 G  c6113   
 G  c6114   
 G  c6115   
 G  c6116   
 G  c6117   
 G  c6118   
 G  c6119   
 G  c6120   
 G  c6121   
 G  c6122   
 G  c6123   
 G  c6124   
 G  c6125   
 G  c6126   
 G  c6127   
 G  c6128   
 G  c6129   
 G  c6130   
 G  c6131   
 G  c6132   
 G  c6133   
 G  c6134   
 G  c6135   
 G  c6136   
 G  c6137   
 G  c6138   
 G  c6139   
 G  c6140   
 G  c6141   
 G  c6142   
 G  c6143   
 G  c6144   
 G  c6145   
 G  c6146   
 G  c6147   
 G  c6148   
 G  c6149   
 G  c6150   
 G  c6151   
 G  c6152   
 G  c6153   
 G  c6154   
 G  c6155   
 G  c6156   
 G  c6157   
 G  c6158   
 G  c6159   
 G  c6160   
 G  c6161   
 G  c6162   
 G  c6163   
 G  c6164   
 G  c6165   
 G  c6166   
 G  c6167   
 G  c6168   
 G  c6169   
 G  c6170   
 G  c6171   
 G  c6172   
 G  c6173   
 G  c6174   
 G  c6175   
 G  c6176   
 G  c6177   
 G  c6178   
 G  c6179   
 G  c6180   
 G  c6181   
 G  c6182   
 G  c6183   
 G  c6184   
 G  c6185   
 G  c6186   
 G  c6187   
 G  c6188   
 G  c6189   
 G  c6190   
 G  c6191   
 G  c6192   
 G  c6193   
 G  c6194   
 G  c6195   
 G  c6196   
 G  c6197   
 G  c6198   
 G  c6199   
 G  c6200   
 G  c6201   
 G  c6202   
 G  c6203   
 G  c6204   
 G  c6205   
 G  c6206   
 G  c6207   
 G  c6208   
 G  c6209   
 G  c6210   
 G  c6211   
 G  c6212   
 G  c6213   
 G  c6214   
 G  c6215   
 G  c6216   
 G  c6217   
 G  c6218   
 G  c6219   
 G  c6220   
 G  c6221   
 G  c6222   
 G  c6223   
 G  c6224   
 G  c6225   
 G  c6226   
 G  c6227   
 G  c6228   
 G  c6229   
 G  c6230   
 G  c6231   
 G  c6232   
 G  c6233   
 G  c6234   
 G  c6235   
 G  c6236   
 G  c6237   
 G  c6238   
 G  c6239   
 G  c6240   
 G  c6241   
 G  c6242   
 G  c6243   
 G  c6244   
 G  c6245   
 G  c6246   
 G  c6247   
 G  c6248   
 G  c6249   
 G  c6250   
 G  c6251   
 G  c6252   
 G  c6253   
 G  c6254   
 G  c6255   
 G  c6256   
 G  c6257   
 G  c6258   
 G  c6259   
 G  c6260   
 G  c6261   
 G  c6262   
 G  c6263   
 G  c6264   
 G  c6265   
 G  c6266   
 G  c6267   
 G  c6268   
 G  c6269   
 G  c6270   
 G  c6271   
 G  c6272   
 G  c6273   
 G  c6274   
 G  c6275   
 G  c6276   
 G  c6277   
 G  c6278   
 G  c6279   
 G  c6280   
 G  c6281   
 G  c6282   
 G  c6283   
 G  c6284   
 G  c6285   
 G  c6286   
 G  c6287   
 G  c6288   
 G  c6289   
 G  c6290   
 G  c6291   
 G  c6292   
 G  c6293   
 G  c6294   
 G  c6295   
 G  c6296   
 G  c6297   
 G  c6298   
 G  c6299   
 G  c6300   
 G  c6301   
 G  c6302   
 G  c6303   
 G  c6304   
 G  c6305   
 G  c6306   
 G  c6307   
 G  c6308   
 G  c6309   
 G  c6310   
 G  c6311   
 G  c6312   
 G  c6313   
 G  c6314   
 G  c6315   
 G  c6316   
 G  c6317   
 G  c6318   
 G  c6319   
 G  c6320   
 G  c6321   
 G  c6322   
 G  c6323   
 G  c6324   
 G  c6325   
 G  c6326   
 G  c6327   
 G  c6328   
 G  c6329   
 G  c6330   
 G  c6331   
 G  c6332   
 G  c6333   
 G  c6334   
 G  c6335   
 G  c6336   
 G  c6337   
 G  c6338   
 G  c6339   
 G  c6340   
 G  c6341   
 G  c6342   
 G  c6343   
 G  c6344   
 G  c6345   
 G  c6346   
 G  c6347   
 G  c6348   
 G  c6349   
 G  c6350   
 G  c6351   
 G  c6352   
 G  c6353   
 G  c6354   
 G  c6355   
 G  c6356   
 G  c6357   
 G  c6358   
 G  c6359   
 G  c6360   
 G  c6361   
 G  c6362   
 G  c6363   
 G  c6364   
 G  c6365   
 G  c6366   
 G  c6367   
 G  c6368   
 G  c6369   
 G  c6370   
 G  c6371   
 G  c6372   
 G  c6373   
 G  c6374   
 G  c6375   
 G  c6376   
 G  c6377   
 G  c6378   
 G  c6379   
 G  c6380   
 G  c6381   
 G  c6382   
 G  c6383   
 G  c6384   
 G  c6385   
 G  c6386   
 G  c6387   
 G  c6388   
 G  c6389   
 G  c6390   
 G  c6391   
 G  c6392   
 G  c6393   
 G  c6394   
 G  c6395   
 G  c6396   
 G  c6397   
 G  c6398   
 G  c6399   
 G  c6400   
 G  c6401   
 G  c6402   
 G  c6403   
 G  c6404   
 G  c6405   
 G  c6406   
 G  c6407   
 G  c6408   
 G  c6409   
 G  c6410   
 G  c6411   
 G  c6412   
 G  c6413   
 G  c6414   
 G  c6415   
 G  c6416   
 G  c6417   
 G  c6418   
 G  c6419   
 G  c6420   
 G  c6421   
 G  c6422   
 G  c6423   
 G  c6424   
 G  c6425   
 G  c6426   
 G  c6427   
 G  c6428   
 G  c6429   
 G  c6430   
 G  c6431   
 G  c6432   
 G  c6433   
 G  c6434   
 G  c6435   
 G  c6436   
 G  c6437   
 G  c6438   
 G  c6439   
 G  c6440   
 G  c6441   
 G  c6442   
 G  c6443   
 G  c6444   
 G  c6445   
 G  c6446   
 G  c6447   
 G  c6448   
 G  c6449   
 G  c6450   
 G  c6451   
 G  c6452   
 G  c6453   
 G  c6454   
 G  c6455   
 G  c6456   
 G  c6457   
 G  c6458   
 G  c6459   
 G  c6460   
 G  c6461   
 G  c6462   
 G  c6463   
 G  c6464   
 G  c6465   
 G  c6466   
 G  c6467   
 G  c6468   
 G  c6469   
 G  c6470   
 G  c6471   
 G  c6472   
 G  c6473   
 G  c6474   
 G  c6475   
 G  c6476   
 G  c6477   
 G  c6478   
 G  c6479   
 G  c6480   
 G  c6481   
 G  c6482   
 G  c6483   
 G  c6484   
 G  c6485   
 G  c6486   
 G  c6487   
 G  c6488   
 G  c6489   
 G  c6490   
 G  c6491   
 G  c6492   
 G  c6493   
 G  c6494   
 G  c6495   
 G  c6496   
 G  c6497   
 G  c6498   
 G  c6499   
 G  c6500   
 G  c6501   
 G  c6502   
 G  c6503   
 G  c6504   
 G  c6505   
 G  c6506   
 G  c6507   
 G  c6508   
 G  c6509   
 G  c6510   
 G  c6511   
 G  c6512   
 G  c6513   
 G  c6514   
 G  c6515   
 G  c6516   
 G  c6517   
 G  c6518   
 G  c6519   
 G  c6520   
 G  c6521   
 G  c6522   
 G  c6523   
 G  c6524   
 G  c6525   
 G  c6526   
 G  c6527   
 G  c6528   
 G  c6529   
 G  c6530   
 G  c6531   
 G  c6532   
 G  c6533   
 G  c6534   
 G  c6535   
 G  c6536   
 G  c6537   
 G  c6538   
 G  c6539   
 G  c6540   
 G  c6541   
 G  c6542   
 G  c6543   
 G  c6544   
 G  c6545   
 G  c6546   
 G  c6547   
 G  c6548   
 G  c6549   
 G  c6550   
 G  c6551   
 G  c6552   
 G  c6553   
 G  c6554   
 G  c6555   
 G  c6556   
 G  c6557   
 G  c6558   
 G  c6559   
 G  c6560   
 G  c6561   
 G  c6562   
 G  c6563   
 G  c6564   
 G  c6565   
 G  c6566   
 G  c6567   
 G  c6568   
 G  c6569   
 G  c6570   
 G  c6571   
 G  c6572   
 G  c6573   
 G  c6574   
 G  c6575   
 G  c6576   
 G  c6577   
 G  c6578   
 G  c6579   
 G  c6580   
 G  c6581   
 G  c6582   
 G  c6583   
 G  c6584   
 G  c6585   
 G  c6586   
 G  c6587   
 G  c6588   
 G  c6589   
 G  c6590   
 G  c6591   
 G  c6592   
 G  c6593   
 G  c6594   
 G  c6595   
 G  c6596   
 G  c6597   
 G  c6598   
 G  c6599   
 G  c6600   
 G  c6601   
 G  c6602   
 G  c6603   
 G  c6604   
 G  c6605   
 G  c6606   
 G  c6607   
 G  c6608   
 G  c6609   
 G  c6610   
 G  c6611   
 G  c6612   
 G  c6613   
 G  c6614   
 G  c6615   
 G  c6616   
 G  c6617   
 G  c6618   
 G  c6619   
 G  c6620   
 G  c6621   
 G  c6622   
 G  c6623   
 G  c6624   
 G  c6625   
 G  c6626   
 G  c6627   
 G  c6628   
 G  c6629   
 G  c6630   
 G  c6631   
 G  c6632   
 G  c6633   
 G  c6634   
 G  c6635   
 G  c6636   
 G  c6637   
 G  c6638   
 G  c6639   
 G  c6640   
 G  c6641   
 G  c6642   
 G  c6643   
 G  c6644   
 G  c6645   
 G  c6646   
 G  c6647   
 G  c6648   
 G  c6649   
 G  c6650   
 G  c6651   
 G  c6652   
 G  c6653   
 G  c6654   
 G  c6655   
 G  c6656   
 G  c6657   
 G  c6658   
 G  c6659   
 G  c6660   
 G  c6661   
 G  c6662   
 G  c6663   
 G  c6664   
 G  c6665   
 G  c6666   
 G  c6667   
 G  c6668   
 G  c6669   
 G  c6670   
 G  c6671   
 G  c6672   
 G  c6673   
 G  c6674   
 G  c6675   
 G  c6676   
 G  c6677   
 G  c6678   
 G  c6679   
 G  c6680   
 G  c6681   
 G  c6682   
 G  c6683   
 G  c6684   
 G  c6685   
 G  c6686   
 G  c6687   
 G  c6688   
 G  c6689   
 G  c6690   
 G  c6691   
 G  c6692   
 G  c6693   
 G  c6694   
 G  c6695   
 G  c6696   
 G  c6697   
 G  c6698   
 G  c6699   
 G  c6700   
 G  c6701   
 G  c6702   
 G  c6703   
 G  c6704   
 G  c6705   
 G  c6706   
 G  c6707   
 G  c6708   
 G  c6709   
 G  c6710   
 G  c6711   
 G  c6712   
 G  c6713   
 G  c6714   
 G  c6715   
 G  c6716   
 G  c6717   
 G  c6718   
 G  c6719   
 G  c6720   
 G  c6721   
 G  c6722   
 G  c6723   
 G  c6724   
 G  c6725   
 G  c6726   
 G  c6727   
 G  c6728   
 G  c6729   
 G  c6730   
 G  c6731   
 G  c6732   
 G  c6733   
 G  c6734   
 G  c6735   
 G  c6736   
 G  c6737   
 G  c6738   
 G  c6739   
 G  c6740   
 G  c6741   
 G  c6742   
 G  c6743   
 G  c6744   
 G  c6745   
 G  c6746   
 G  c6747   
 G  c6748   
 G  c6749   
 G  c6750   
 G  c6751   
 G  c6752   
 G  c6753   
 G  c6754   
 G  c6755   
 G  c6756   
 G  c6757   
 G  c6758   
 G  c6759   
 G  c6760   
 G  c6761   
 G  c6762   
 G  c6763   
 G  c6764   
 G  c6765   
 G  c6766   
 G  c6767   
 G  c6768   
 G  c6769   
 G  c6770   
 G  c6771   
 G  c6772   
 G  c6773   
 G  c6774   
 G  c6775   
 G  c6776   
 G  c6777   
 G  c6778   
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x1        c1                   1   c3                   1
    x1        c346                 1   c347                 1
    x1        c348                 1   c349                 1
    x1        c6736               -1
    x2        c2                   1   c3714                1
    x2        c3715                1   c3716                1
    x2        c3717                1   c3718                1
    x2        c3719                1   c3720                1
    x2        c3721                1   c3722                1
    x2        c3723                1   c3724                1
    x2        c3725                1   c3726                1
    x2        c3727                1   c3728                1
    x2        c3729                1   c3730                1
    x2        c3731                1   c3732                1
    x2        c3733                1   c3734                1
    x2        c3735                1   c3736                1
    x2        c3737                1   c3738                1
    x2        c3739                1   c3740                1
    x2        c3741                1   c3742                1
    x2        c3743                1   c3744                1
    x2        c3745                1   c6772               -1
    x3        c4                  -1   c8                   1
    x3        c9                  -1   c16                 -1
    x3        c17                  1   c20                  1
    x3        c21                 -1   c350                 1
    x3        c351                -1   c352                 1
    x3        c353                -1   c354                 1
    x3        c355                -1   c356                 1
    x3        c357                -1
    x4        c5                   1   c8                   1
    x4        c9                  -1   c14                  1
    x4        c15                 -1   c338                 1
    x4        c339                -1   c340                 1
    x4        c341                -1   c342                 1
    x4        c343                -1   c344                 1
    x4        c345                -1   c358                 1
    x4        c359                -1
    x5        c6                   1   c7                  -1
    x5        c14                  1   c15                 -1
    x5        c98                  1   c99                 -1
    x5        c100                 1   c101                -1
    x5        c102                 1   c103                -1
    x5        c104                 1   c105                -1
    x5        c106                 1   c107                -1
    x5        c108                 1   c109                -1
    x5        c110                 1   c111                -1
    x5        c112                 1   c113                -1
    x5        c3834                1   c3835                1
    x5        c3836               -1   c3837               -1
    x5        c3838               -1   c3839               -1
    x5        c3849                1   c3850               -1
    x6        c6                  -1   c7                   1
    x6        c18                 -1   c19                  1
    x6        c20                 -1   c21                  1
    x6        c122                 1   c123                -1
    x6        c124                 1   c125                -1
    x6        c126                 1   c127                -1
    x6        c128                 1   c129                -1
    x6        c130                 1   c131                -1
    x6        c132                 1   c133                -1
    x6        c134                 1   c135                -1
    x6        c136                 1   c137                -1
    x6        c3849                1   c3850               -1
    x6        c3851                1   c3852                1
    x6        c3853               -1   c3854               -1
    x6        c3855               -1   c3856               -1
    x7        c10                  1   c11                 -1
    x7        c12                  1   c13                 -1
    x7        c16                  1   c17                 -1
    x7        c18                  1   c19                 -1
    x7        c3746               -1   c3747               -1
    x7        c3748                1   c3749               -1
    x7        c3750               -1   c3751                1
    x7        c3752               -1   c3753               -1
    x7        c3754                1   c3755               -1
    x7        c3756               -1   c3757                1
    x8        c10                 -1   c11                  1
    x8        c12                 -1   c13                  1
    x8        c358                 1   c359                -1
    x8        c364                -1   c365                 1
    x9        c22                 -1   c24                  1
    x9        c3758                1   c3759               -1
    x9        c3776                1   c3777               -1
    x9        c3778                1   c3779                1
    x9        c3780               -1   c3781               -1
    x9        c3782               -1   c3783               -1
    x10       c22                 -1   c23                 -1
    x10       c27                 -1   c3758                1
    x10       c3760                1
    x11       c23                  1   c25                 -1
    x11       c3758               -1   c3759                1
    x11       c3761                1   c3762                1
    x11       c3763               -1   c3764               -1
    x11       c3765               -1   c3766               -1
    x11       c3776                1   c3777               -1
    x12       c24                 -1   c25                 -1
    x12       c26                 -1   c3759                1
    x12       c3760                1
    x13       c26                  1   c27                  1
    x13       c3745               -1   c3760               -1
    x13       c6760                1
    x14       c28                 -1   c31                 -1
    x14       c36                 -1   c3784                1
    x14       c3787               -1   c3788               -1
    x14       c6326               -1   c6327               -1
    x15       c28                  1   c29                  1
    x15       c30                  1   c3776               -1
    x15       c3777               -1   c6319                1
    x16       c29                 -1   c52                 -1
    x16       c3770               -1   c3771               -1
    x16       c3772               -1   c3793                1
    x16       c3796               -1   c3797               -1
    x16       c6323               -1   c6324               -1
    x16       c6325               -1
    x17       c30                 -1   c37                 -1
    x17       c3767               -1   c3768               -1
    x17       c3769               -1   c3784                1
    x17       c3785               -1   c3786               -1
    x17       c6320               -1   c6321               -1
    x17       c6322               -1
    x18       c31                 -1   c1870               -1
    x18       c1871                1   c3761                1
    x18       c3763               -1   c3764               -1
    x18       c3774               -1   c3778                1
    x18       c3780               -1   c3781               -1
    x18       c6320                1   c6321                1
    x18       c6322                1   c6323                1
    x18       c6324                1   c6325                1
    x18       c6328               -1
    x19       c32                  1   c33                 -1
    x19       c34                  1   c35                 -1
    x19       c42                 -1   c43                 -1
    x19       c3789                1   c3790                1
    x19       c3791               -1
    x20       c32                 -1   c33                  1
    x20       c3761                1   c3765               -1
    x20       c3766               -1   c3773               -1
    x20       c3775               -1   c3787                1
    x20       c3788               -1   c6321                1
    x20       c6322                1   c6324                1
    x20       c6325                1   c6326               -1
    x21       c34                 -1   c35                  1
    x21       c3762                1   c3764               -1
    x21       c3766               -1   c3768               -1
    x21       c3770               -1   c3772               -1
    x21       c3785                1   c3786               -1
    x21       c6321               -1   c6326                1
    x21       c6328                1
    x22       c36                  1   c37                  1
    x22       c44                  1   c3784               -1
    x22       c3790               -1   c3791               -1
    x23       c38                  1   c39                 -1
    x23       c40                  1   c41                 -1
    x23       c46                 -1   c47                 -1
    x23       c3790                1   c3791               -1
    x23       c3792                1
    x24       c38                 -1   c39                  1
    x24       c3774               -1   c3775               -1
    x24       c3778                1   c3782               -1
    x24       c3783               -1   c3787                1
    x24       c3788               -1   c6320                1
    x24       c6322                1   c6323                1
    x24       c6325                1   c6327               -1
    x25       c40                 -1   c41                  1
    x25       c3767               -1   c3771               -1
    x25       c3772               -1   c3779                1
    x25       c3781               -1   c3783               -1
    x25       c3785                1   c3786               -1
    x25       c6320               -1   c6327                1
    x25       c6329                1
    x26       c42                 -1   c45                 -1
    x26       c46                 -1   c1872               -1
    x26       c1873                1   c3789                1
    x26       c3792                1
    x27       c43                 -1   c50                 -1
    x27       c51                  1   c3789                1
    x27       c3794                1   c3795               -1
    x28       c44                 -1   c45                 -1
    x28       c53                 -1   c3793                1
    x28       c3794               -1   c3795               -1
    x29       c47                 -1   c56                 -1
    x29       c57                  1   c3792                1
    x29       c3794                1   c3795               -1
    x30       c48                  1   c49                 -1
    x30       c50                  1   c51                 -1
    x30       c58                  1   c59                  1
    x30       c3798               -1   c3799                1
    x30       c3800               -1
    x31       c48                 -1   c49                  1
    x31       c3762                1   c3763               -1
    x31       c3765               -1   c3767               -1
    x31       c3769               -1   c3771               -1
    x31       c3796                1   c3797               -1
    x31       c6324               -1   c6326                1
    x31       c6328                1
    x32       c52                  1   c53                  1
    x32       c60                  1   c3793               -1
    x32       c3799               -1   c3800               -1
    x33       c54                  1   c55                 -1
    x33       c56                  1   c57                 -1
    x33       c62                  1   c63                  1
    x33       c3799                1   c3800               -1
    x33       c3801               -1
    x34       c54                 -1   c55                  1
    x34       c3768               -1   c3769               -1
    x34       c3770               -1   c3779                1
    x34       c3780               -1   c3782               -1
    x34       c3796                1   c3797               -1
    x34       c6323               -1   c6327                1
    x34       c6329                1
    x35       c58                  1   c61                  1
    x35       c62                  1   c1137               -1
    x35       c1138                1   c3798               -1
    x35       c3801               -1
    x36       c59                  1   c64                 -1
    x36       c65                  1   c3798               -1
    x36       c3808                1   c3809               -1
    x37       c60                 -1   c61                 -1
    x37       c72                 -1   c3808               -1
    x37       c3809               -1   c6731                1
    x38       c63                  1   c76                 -1
    x38       c77                  1   c3801               -1
    x38       c3808                1   c3809               -1
    x39       c64                  1   c65                 -1
    x39       c66                  1   c67                 -1
    x39       c68                  1   c69                 -1
    x39       c70                  1   c71                 -1
    x39       c84                 -1   c85                 -1
    x39       c86                 -1   c87                 -1
    x39       c3816                1   c3817               -1
    x39       c6732                1
    x40       c66                 -1   c67                  1
    x40       c1923                1   c3806                1
    x40       c3807               -1   c4672               -1
    x41       c68                 -1   c69                  1
    x41       c1965                1   c3804                1
    x41       c3805               -1   c4716               -1
    x42       c70                 -1   c71                  1
    x42       c2007                1   c3802                1
    x42       c3803               -1   c4760               -1
    x43       c72                  1   c73                  1
    x43       c74                  1   c75                  1
    x43       c88                  1   c89                  1
    x43       c3816               -1   c3817               -1
    x43       c6731               -1
    x44       c73                 -1   c1924               -1
    x44       c1925               -1   c3806               -1
    x44       c3807               -1   c6731                1
    x45       c74                 -1   c1966               -1
    x45       c1967               -1   c3804               -1
    x45       c3805               -1   c6731                1
    x46       c75                 -1   c2008               -1
    x46       c2009               -1   c3802               -1
    x46       c3803               -1   c6731                1
    x47       c76                  1   c77                 -1
    x47       c78                  1   c79                 -1
    x47       c80                  1   c81                 -1
    x47       c82                  1   c83                 -1
    x47       c94                 -1   c95                 -1
    x47       c96                 -1   c97                 -1
    x47       c3816                1   c3817               -1
    x47       c6733                1
    x48       c78                 -1   c79                  1
    x48       c1927                1   c3806                1
    x48       c3807               -1   c4675               -1
    x49       c80                 -1   c81                  1
    x49       c1969                1   c3804                1
    x49       c3805               -1   c4719               -1
    x50       c82                 -1   c83                  1
    x50       c2011                1   c3802                1
    x50       c3803               -1   c4763               -1
    x51       c84                 -1   c91                 -1
    x51       c93                 -1   c94                 -1
    x51       c1788               -1   c1789                1
    x51       c6732                1   c6733                1
    x52       c85                 -1   c90                 -1
    x52       c92                 -1   c95                 -1
    x52       c1116               -1   c1117                1
    x52       c6732                1   c6733                1
    x53       c86                 -1   c560                 1
    x53       c561                 1   c3810               -1
    x53       c3812               -1   c3814               -1
    x53       c4079               -1   c4080                1
    x53       c4081               -1   c6732                1
    x54       c87                 -1   c110                -1
    x54       c111                 1   c3811               -1
    x54       c3813               -1   c3815               -1
    x54       c3820                1   c3821               -1
    x54       c6732                1
    x55       c88                 -1   c92                 -1
    x55       c93                 -1   c562                 1
    x55       c3813               -1   c3814               -1
    x55       c3815               -1   c4080               -1
    x55       c4081               -1
    x56       c89                 -1   c90                 -1
    x56       c91                 -1   c120                -1
    x56       c3810               -1   c3811               -1
    x56       c3812               -1   c3820               -1
    x56       c3821               -1   c6734                1
    x57       c96                 -1   c564                 1
    x57       c565                 1   c3811               -1
    x57       c3812               -1   c3813               -1
    x57       c4080                1   c4081               -1
    x57       c4082               -1   c6733                1
    x58       c97                 -1   c134                -1
    x58       c135                 1   c3810               -1
    x58       c3814               -1   c3815               -1
    x58       c3820                1   c3821               -1
    x58       c6733                1
    x59       c98                 -1   c99                  1
    x59       c2888               -1   c3832                1
    x59       c3833               -1   c5541               -1
    x59       c5543               -1   c5545               -1
    x59       c6752                1
    x60       c100                -1   c101                 1
    x60       c2113                1   c2114               -1
    x60       c3830                1   c3831               -1
    x61       c102                -1   c103                 1
    x61       c2587                1   c3828                1
    x61       c3829               -1   c5241                1
    x61       c5242                1   c5244               -1
    x61       c6745               -1
    x62       c104                -1   c105                 1
    x62       c3263                1   c3826                1
    x62       c3827               -1   c5895               -1
    x62       c5897                1   c5898                1
    x62       c5900               -1
    x63       c106                -1   c107                 1
    x63       c2861                1   c3824                1
    x63       c3825               -1   c5501                1
    x63       c5502                1   c5504               -1
    x63       c6750               -1
    x64       c108                -1   c109                 1
    x64       c3822                1   c3823               -1
    x64       c5473               -1   c5475               -1
    x64       c5477               -1   c5479               -1
    x64       c5480               -1   c5482               -1
    x64       c5487               -1   c6573                1
    x65       c112                -1   c113                 1
    x65       c3046                1   c3818                1
    x65       c3819               -1   c5689               -1
    x65       c5691                1   c5692                1
    x65       c5694               -1
    x66       c114                 1   c115                 1
    x66       c116                 1   c117                 1
    x66       c118                 1   c119                 1
    x66       c120                 1   c121                 1
    x66       c138                 1   c139                 1
    x66       c140                 1   c3849               -1
    x66       c3850               -1   c6768               -1
    x67       c114                -1   c2890               -1
    x67       c2894               -1   c2895               -1
    x67       c3832               -1   c3833               -1
    x67       c5544               -1   c5545               -1
    x67       c5546               -1   c6768                1
    x68       c115                -1   c2115               -1
    x68       c3830               -1   c3831               -1
    x68       c6768                1
    x69       c116                -1   c2589               -1
    x69       c2593               -1   c2594               -1
    x69       c3828               -1   c3829               -1
    x69       c5243               -1   c5244               -1
    x69       c5245               -1   c6768                1
    x70       c117                -1   c3265               -1
    x70       c3826               -1   c3827               -1
    x70       c5899               -1   c5900               -1
    x70       c5901               -1   c6768                1
    x71       c118                -1   c2863               -1
    x71       c2867               -1   c2868               -1
    x71       c3824               -1   c3825               -1
    x71       c5503               -1   c5504               -1
    x71       c5505               -1   c6734                1
    x72       c119                -1   c2854               -1
    x72       c2856               -1   c3822               -1
    x72       c3823               -1   c5474               -1
    x72       c5475               -1   c5476               -1
    x72       c5486               -1   c5487               -1
    x72       c5488               -1   c6734                1
    x73       c121                -1   c3048               -1
    x73       c3818               -1   c3819               -1
    x73       c5693               -1   c5694               -1
    x73       c5695               -1   c6734                1
    x74       c122                -1   c123                 1
    x74       c2898               -1   c3832                1
    x74       c3833               -1   c5542               -1
    x74       c5543               -1   c5544               -1
    x74       c6753                1
    x75       c124                -1   c125                 1
    x75       c2116                1   c2117               -1
    x75       c3830                1   c3831               -1
    x76       c126                -1   c127                 1
    x76       c2597                1   c3828                1
    x76       c3829               -1   c5240                1
    x76       c5242                1   c5243               -1
    x76       c6746               -1
    x77       c128                -1   c129                 1
    x77       c3267                1   c3826                1
    x77       c3827               -1   c5896                1
    x77       c5898                1   c5899               -1
    x77       c5904               -1
    x78       c130                -1   c131                 1
    x78       c2871                1   c3824                1
    x78       c3825               -1   c5500                1
    x78       c5502                1   c5503               -1
    x78       c6751               -1
    x79       c132                -1   c133                 1
    x79       c3822                1   c3823               -1
    x79       c5474               -1   c5478               -1
    x79       c5479               -1   c5481               -1
    x79       c5482               -1   c5486               -1
    x79       c5499               -1   c6574                1
    x80       c136                -1   c137                 1
    x80       c3050                1   c3818                1
    x80       c3819               -1   c5690                1
    x80       c5692                1   c5693               -1
    x80       c5698               -1
    x81       c138                -1   c141                -1
    x81       c146                -1   c3857                1
    x81       c3860               -1   c3861               -1
    x81       c6336               -1   c6337               -1
    x82       c139                -1   c163                -1
    x82       c3843               -1   c3844               -1
    x82       c3845               -1   c3866                1
    x82       c3867               -1   c3868               -1
    x82       c6333               -1   c6334               -1
    x82       c6335               -1
    x83       c140                -1   c147                -1
    x83       c3840               -1   c3841               -1
    x83       c3842               -1   c3857                1
    x83       c3858               -1   c3859               -1
    x83       c6330               -1   c6331               -1
    x83       c6332               -1
    x84       c141                -1   c494                -1
    x84       c495                 1   c3746               -1
    x84       c3747               -1   c3748                1
    x84       c3752               -1   c3753               -1
    x84       c3754                1   c3834                1
    x84       c3836               -1   c3837               -1
    x84       c3847               -1   c3851                1
    x84       c3853               -1   c3854               -1
    x84       c6330                1   c6331                1
    x84       c6332                1   c6333                1
    x84       c6334                1   c6335                1
    x84       c6338               -1
    x85       c142                 1   c143                -1
    x85       c144                 1   c145                -1
    x85       c152                -1   c153                -1
    x85       c3862                1   c3863                1
    x85       c3864               -1
    x86       c142                -1   c143                 1
    x86       c3748                1   c3749               -1
    x86       c3750               -1   c3834                1
    x86       c3838               -1   c3839               -1
    x86       c3846               -1   c3848               -1
    x86       c3860                1   c3861               -1
    x86       c6331                1   c6332                1
    x86       c6334                1   c6335                1
    x86       c6336               -1
    x87       c144                -1   c145                 1
    x87       c3747               -1   c3750               -1
    x87       c3751                1   c3835                1
    x87       c3837               -1   c3839               -1
    x87       c3841               -1   c3843               -1
    x87       c3845               -1   c3858                1
    x87       c3859               -1   c6331               -1
    x87       c6336                1   c6338                1
    x88       c146                 1   c147                 1
    x88       c154                 1   c3857               -1
    x88       c3863               -1   c3864               -1
    x89       c148                 1   c149                -1
    x89       c150                 1   c151                -1
    x89       c156                -1   c157                -1
    x89       c3863                1   c3864               -1
    x89       c3865                1
    x90       c148                -1   c149                 1
    x90       c3754                1   c3755               -1
    x90       c3756               -1   c3847               -1
    x90       c3848               -1   c3851                1
    x90       c3855               -1   c3856               -1
    x90       c3860                1   c3861               -1
    x90       c6330                1   c6332                1
    x90       c6333                1   c6335                1
    x90       c6337               -1
    x91       c150                -1   c151                 1
    x91       c3753               -1   c3756               -1
    x91       c3757                1   c3840               -1
    x91       c3844               -1   c3845               -1
    x91       c3852                1   c3854               -1
    x91       c3856               -1   c3858                1
    x91       c3859               -1   c6330               -1
    x91       c6337                1   c6339                1
    x92       c152                -1   c155                -1
    x92       c156                -1   c492                -1
    x92       c493                 1   c3862                1
    x92       c3865                1
    x93       c153                -1   c158                -1
    x93       c159                 1   c3862                1
    x93       c3869                1   c3870               -1
    x94       c154                -1   c155                -1
    x94       c162                -1   c3866                1
    x94       c3869               -1   c3870               -1
    x95       c157                -1   c164                -1
    x95       c165                 1   c3865                1
    x95       c3869                1   c3870               -1
    x96       c158                 1   c159                -1
    x96       c160                 1   c161                -1
    x96       c168                 1   c169                -1
    x96       c3871                1   c3872               -1
    x97       c160                -1   c161                 1
    x97       c3746               -1   c3749               -1
    x97       c3751                1   c3835                1
    x97       c3836               -1   c3838               -1
    x97       c3840               -1   c3842               -1
    x97       c3844               -1   c3867                1
    x97       c3868               -1   c6334               -1
    x97       c6336                1   c6338                1
    x98       c162                 1   c163                 1
    x98       c170                 1   c3866               -1
    x98       c3871               -1   c3872               -1
    x99       c164                 1   c165                -1
    x99       c166                 1   c167                -1
    x99       c171                 1   c172                -1
    x99       c3871                1   c3872               -1
    x100      c166                -1   c167                 1
    x100      c3752               -1   c3755               -1
    x100      c3757                1   c3841               -1
    x100      c3842               -1   c3843               -1
    x100      c3852                1   c3853               -1
    x100      c3855               -1   c3867                1
    x100      c3868               -1   c6333               -1
    x100      c6337                1   c6339                1
    x101      c168                 1   c169                -1
    x101      c3873                1   c3874                1
    x101      c3875               -1   c3876               -1
    x101      c3877               -1   c3878               -1
    x101      c3888                1   c3889               -1
    x102      c170                -1   c173                 1
    x102      c174                 1   c175                 1
    x102      c3888               -1   c3889               -1
    x103      c171                 1   c172                -1
    x103      c3888                1   c3889               -1
    x103      c3890                1   c3891                1
    x103      c3892               -1   c3893               -1
    x103      c3894               -1   c3895               -1
    x104      c173                -1   c176                -1
    x104      c181                -1   c3896                1
    x104      c3899               -1   c3900               -1
    x104      c6346               -1   c6347               -1
    x105      c174                -1   c198                -1
    x105      c3882               -1   c3883               -1
    x105      c3884               -1   c3905                1
    x105      c3906               -1   c3907               -1
    x105      c6343               -1   c6344               -1
    x105      c6345               -1
    x106      c175                -1   c182                -1
    x106      c3879               -1   c3880               -1
    x106      c3881               -1   c3896                1
    x106      c3897               -1   c3898               -1
    x106      c6340               -1   c6341               -1
    x106      c6342               -1
    x107      c176                -1   c472                -1
    x107      c473                 1   c3873                1
    x107      c3875               -1   c3876               -1
    x107      c3886               -1   c3890                1
    x107      c3892               -1   c3893               -1
    x107      c6340                1   c6341                1
    x107      c6342                1   c6343                1
    x107      c6344                1   c6345                1
    x107      c6348               -1
    x108      c177                 1   c178                -1
    x108      c179                 1   c180                -1
    x108      c187                -1   c188                -1
    x108      c3901                1   c3902                1
    x108      c3903               -1
    x109      c177                -1   c178                 1
    x109      c3873                1   c3877               -1
    x109      c3878               -1   c3885               -1
    x109      c3887               -1   c3899                1
    x109      c3900               -1   c6341                1
    x109      c6342                1   c6344                1
    x109      c6345                1   c6346               -1
    x110      c179                -1   c180                 1
    x110      c3874                1   c3876               -1
    x110      c3878               -1   c3880               -1
    x110      c3882               -1   c3884               -1
    x110      c3897                1   c3898               -1
    x110      c6341               -1   c6346                1
    x110      c6348                1
    x111      c181                 1   c182                 1
    x111      c189                 1   c3896               -1
    x111      c3902               -1   c3903               -1
    x112      c183                 1   c184                -1
    x112      c185                 1   c186                -1
    x112      c191                -1   c192                -1
    x112      c3902                1   c3903               -1
    x112      c3904                1
    x113      c183                -1   c184                 1
    x113      c3886               -1   c3887               -1
    x113      c3890                1   c3894               -1
    x113      c3895               -1   c3899                1
    x113      c3900               -1   c6340                1
    x113      c6342                1   c6343                1
    x113      c6345                1   c6347               -1
    x114      c185                -1   c186                 1
    x114      c3879               -1   c3883               -1
    x114      c3884               -1   c3891                1
    x114      c3893               -1   c3895               -1
    x114      c3897                1   c3898               -1
    x114      c6340               -1   c6347                1
    x114      c6349                1
    x115      c187                -1   c190                -1
    x115      c191                -1   c470                -1
    x115      c471                 1   c3901                1
    x115      c3904                1
    x116      c188                -1   c193                -1
    x116      c194                 1   c3901                1
    x116      c3908                1   c3909               -1
    x117      c189                -1   c190                -1
    x117      c197                -1   c3905                1
    x117      c3908               -1   c3909               -1
    x118      c192                -1   c199                -1
    x118      c200                 1   c3904                1
    x118      c3908                1   c3909               -1
    x119      c193                 1   c194                -1
    x119      c195                 1   c196                -1
    x119      c3910               -1   c3911               -1
    x119      c3912                1   c3913                1
    x119      c3914                1   c3915                1
    x119      c3925                1   c3926               -1
    x120      c195                -1   c196                 1
    x120      c3874                1   c3875               -1
    x120      c3877               -1   c3879               -1
    x120      c3881               -1   c3883               -1
    x120      c3906                1   c3907               -1
    x120      c6344               -1   c6346                1
    x120      c6348                1
    x121      c197                 1   c198                 1
    x121      c203                 1   c204                 1
    x121      c205                 1   c3905               -1
    x121      c3925               -1   c3926               -1
    x122      c199                 1   c200                -1
    x122      c201                 1   c202                -1
    x122      c3925                1   c3926               -1
    x122      c3927               -1   c3928               -1
    x122      c3929                1   c3930                1
    x122      c3931                1   c3932                1
    x123      c201                -1   c202                 1
    x123      c3880               -1   c3881               -1
    x123      c3882               -1   c3891                1
    x123      c3892               -1   c3894               -1
    x123      c3906                1   c3907               -1
    x123      c6343               -1   c6347                1
    x123      c6349                1
    x124      c203                -1   c206                -1
    x124      c211                -1   c3933                1
    x124      c3936               -1   c3937               -1
    x124      c6356               -1   c6357               -1
    x125      c204                -1   c231                -1
    x125      c3919               -1   c3920               -1
    x125      c3921               -1   c3948               -1
    x125      c3949               -1   c6353               -1
    x125      c6354               -1   c6355               -1
    x125      c6735                1
    x126      c205                -1   c212                -1
    x126      c3916               -1   c3917               -1
    x126      c3918               -1   c3933                1
    x126      c3934               -1   c3935               -1
    x126      c6350               -1   c6351               -1
    x126      c6352               -1
    x127      c206                 1   c382                -1
    x127      c383                 1   c3910               -1
    x127      c3912                1   c3913                1
    x127      c3923               -1   c3927               -1
    x127      c3929                1   c3930                1
    x127      c6350               -1   c6351               -1
    x127      c6352               -1   c6353               -1
    x127      c6354               -1   c6355               -1
    x127      c6358                1
    x128      c207                 1   c208                -1
    x128      c209                 1   c210                -1
    x128      c217                 1   c218                 1
    x128      c3938               -1   c3939                1
    x128      c3940               -1
    x129      c207                -1   c208                 1
    x129      c3910               -1   c3914                1
    x129      c3915                1   c3923                1
    x129      c3924                1   c3936                1
    x129      c3937               -1   c6350               -1
    x129      c6352               -1   c6353               -1
    x129      c6355               -1   c6356                1
    x130      c209                -1   c210                 1
    x130      c3911               -1   c3913                1
    x130      c3915                1   c3917               -1
    x130      c3920                1   c3921                1
    x130      c3934                1   c3935               -1
    x130      c6351               -1   c6356               -1
    x130      c6358               -1
    x131      c211                 1   c212                 1
    x131      c219                 1   c3933               -1
    x131      c3939               -1   c3940               -1
    x132      c213                 1   c214                -1
    x132      c215                 1   c216                -1
    x132      c221                 1   c222                 1
    x132      c3939                1   c3940               -1
    x132      c3941               -1
    x133      c213                -1   c214                 1
    x133      c3922                1   c3924                1
    x133      c3927               -1   c3931                1
    x133      c3932                1   c3936                1
    x133      c3937               -1   c6351               -1
    x133      c6352               -1   c6354               -1
    x133      c6355               -1   c6357                1
    x134      c215                -1   c216                 1
    x134      c3916               -1   c3919                1
    x134      c3921                1   c3928               -1
    x134      c3930                1   c3932                1
    x134      c3934                1   c3935               -1
    x134      c6350               -1   c6357               -1
    x134      c6359               -1
    x135      c217                 1   c220                 1
    x135      c221                 1   c384                -1
    x135      c385                 1   c3938               -1
    x135      c3941               -1
    x136      c218                 1   c225                -1
    x136      c226                 1   c3938               -1
    x136      c3946                1   c3947               -1
    x137      c219                -1   c220                -1
    x137      c232                -1   c3946               -1
    x137      c3947               -1   c6735                1
    x138      c222                 1   c237                -1
    x138      c238                 1   c3941               -1
    x138      c3946                1   c3947               -1
    x139      c223                 1   c224                -1
    x139      c225                 1   c226                -1
    x139      c227                 1   c228                -1
    x139      c229                 1   c230                -1
    x139      c243                 1   c244                -1
    x139      c3950                1   c3951               -1
    x140      c223                -1   c224                 1
    x140      c3911               -1   c3912                1
    x140      c3914                1   c3917                1
    x140      c3918                1   c3920               -1
    x140      c3948                1   c3949               -1
    x140      c6354               -1   c6356               -1
    x140      c6358               -1
    x141      c227                -1   c228                 1
    x141      c711                 1   c3944                1
    x141      c3945               -1   c4214               -1
    x142      c229                -1   c230                 1
    x142      c3942                1   c3943               -1
    x142      c4187               -1   c4188                1
    x142      c4190                1   c4193                1
    x142      c4194                1   c4196               -1
    x142      c6405               -1   c6407               -1
    x142      c6409               -1
    x143      c231                 1   c232                 1
    x143      c233                 1   c234                 1
    x143      c245                 1   c3950               -1
    x143      c3951               -1   c6735               -1
    x144      c233                -1   c712                -1
    x144      c713                -1   c3944               -1
    x144      c3945               -1   c6735                1
    x145      c234                -1   c697                -1
    x145      c3942               -1   c3943               -1
    x145      c4195               -1   c4196               -1
    x145      c4197               -1   c6404               -1
    x145      c6405               -1   c6406               -1
    x145      c6735                1
    x146      c235                 1   c236                -1
    x146      c237                 1   c238                -1
    x146      c239                 1   c240                -1
    x146      c241                 1   c242                -1
    x146      c246                 1   c247                -1
    x146      c3950                1   c3951               -1
    x147      c235                -1   c236                 1
    x147      c3916                1   c3918                1
    x147      c3919               -1   c3928               -1
    x147      c3929                1   c3931                1
    x147      c3948                1   c3949               -1
    x147      c6353               -1   c6357               -1
    x147      c6359               -1
    x148      c239                -1   c240                 1
    x148      c715                 1   c3944                1
    x148      c3945               -1   c4217               -1
    x149      c241                -1   c242                 1
    x149      c3942                1   c3943               -1
    x149      c4192                1   c4194                1
    x149      c4195               -1   c4204               -1
    x149      c4205                1   c4207                1
    x149      c6404               -1   c6408               -1
    x149      c6410               -1
    x150      c243                 1   c244                -1
    x150      c3952               -1   c3953               -1
    x150      c3954                1   c3955                1
    x150      c3956                1   c3957                1
    x150      c3967                1   c3968               -1
    x151      c245                -1   c248                 1
    x151      c249                 1   c250                 1
    x151      c3967               -1   c3968               -1
    x152      c246                 1   c247                -1
    x152      c3967                1   c3968               -1
    x152      c3969               -1   c3970               -1
    x152      c3971                1   c3972                1
    x152      c3973                1   c3974                1
    x153      c248                -1   c312                -1
    x153      c3964               -1   c3965               -1
    x153      c3966               -1   c3991                1
    x153      c3994               -1   c3995               -1
    x153      c6367               -1   c6368               -1
    x153      c6369               -1
    x154      c249                -1   c256                -1
    x154      c3961               -1   c3962               -1
    x154      c3963               -1   c3975                1
    x154      c3978               -1   c3979               -1
    x154      c6364               -1   c6365               -1
    x154      c6366               -1
    x155      c250                -1   c251                -1
    x155      c257                -1   c3975                1
    x155      c3976               -1   c3977               -1
    x155      c6360               -1   c6361               -1
    x156      c251                 1   c268                -1
    x156      c269                 1   c3953               -1
    x156      c3954                1   c3956                1
    x156      c3959               -1   c3970               -1
    x156      c3971                1   c3973                1
    x156      c6362                1   c6364               -1
    x156      c6365               -1   c6366               -1
    x156      c6367               -1   c6368               -1
    x156      c6369               -1
    x157      c252                 1   c253                -1
    x157      c254                 1   c255                -1
    x157      c262                 1   c263                 1
    x157      c3980               -1   c3981                1
    x157      c3982               -1
    x158      c252                -1   c253                 1
    x158      c3952               -1   c3956                1
    x158      c3957                1   c3962               -1
    x158      c3965                1   c3966                1
    x158      c3978                1   c3979               -1
    x158      c6360               -1   c6362               -1
    x158      c6365               -1
    x159      c254                -1   c255                 1
    x159      c3953               -1   c3955                1
    x159      c3957                1   c3959                1
    x159      c3960                1   c3976                1
    x159      c3977               -1   c6360                1
    x159      c6364               -1   c6366               -1
    x159      c6367               -1   c6369               -1
    x160      c256                 1   c257                 1
    x160      c264                 1   c3975               -1
    x160      c3981               -1   c3982               -1
    x161      c258                 1   c259                -1
    x161      c260                 1   c261                -1
    x161      c266                 1   c267                 1
    x161      c3981                1   c3982               -1
    x161      c3983               -1
    x162      c258                -1   c259                 1
    x162      c3961               -1   c3964                1
    x162      c3966                1   c3969               -1
    x162      c3973                1   c3974                1
    x162      c3978                1   c3979               -1
    x162      c6361               -1   c6363               -1
    x162      c6364               -1
    x163      c260                -1   c261                 1
    x163      c3958                1   c3960                1
    x163      c3970               -1   c3972                1
    x163      c3974                1   c3976                1
    x163      c3977               -1   c6361                1
    x163      c6365               -1   c6366               -1
    x163      c6368               -1   c6369               -1
    x164      c262                 1   c310                -1
    x164      c311                 1   c3980               -1
    x164      c3992                1   c3993               -1
    x165      c263                 1   c265                 1
    x165      c267                 1   c270                -1
    x165      c271                 1   c3980               -1
    x165      c3983               -1
    x166      c264                -1   c265                -1
    x166      c313                -1   c3991                1
    x166      c3992               -1   c3993               -1
    x167      c266                 1   c316                -1
    x167      c317                 1   c3983               -1
    x167      c3992                1   c3993               -1
    x168      c268                 1   c269                -1
    x168      c270                 1   c271                -1
    x168      c3984                1   c3985                1
    x168      c3986               -1   c3987               -1
    x168      c3988               -1   c3989               -1
    x169      c272                 1   c273                -1
    x169      c274                 1   c275                -1
    x169      c276                -1   c277                -1
    x169      c3990                1
    x170      c272                -1   c273                 1
    x170      c3984                1   c3988               -1
    x170      c3989               -1
    x171      c274                -1   c275                 1
    x171      c3985                1   c3987               -1
    x171      c3989               -1
    x172      c276                -1   c298                -1
    x172      c299                 1   c3990                1
    x173      c277                -1   c284                -1
    x173      c285                 1   c3990                1
    x174      c278                 1   c279                -1
    x174      c280                 1   c281                -1
    x174      c282                 1   c283                -1
    x174      c284                 1   c285                -1
    x174      c286                 1   c287                -1
    x174      c288                 1   c289                -1
    x174      c290                 1   c291                -1
    x175      c278                -1   c279                 1
    x175      c2160               -1   c2163               -1
    x175      c2164               -1   c4880                1
    x175      c4883                1
    x176      c280                -1   c281                 1
    x176      c2149               -1   c4852                1
    x176      c4854               -1   c4855               -1
    x176      c4865               -1   c4869                1
    x176      c4871               -1   c4872               -1
    x176      c6451                1   c6452                1
    x176      c6453                1   c6454                1
    x176      c6455                1   c6456                1
    x176      c6459               -1
    x177      c282                -1   c283                 1
    x177      c3985                1   c3986               -1
    x177      c3988               -1
    x178      c286                -1   c287                 1
    x178      c4397                1   c4398               -1
    x178      c4400               -1
    x179      c288                -1   c289                 1
    x179      c1310               -1   c4402                1
    x180      c290                 1   c291                -1
    x181      c292                 1   c293                -1
    x181      c294                 1   c295                -1
    x181      c296                 1   c297                -1
    x181      c298                 1   c299                -1
    x181      c300                 1   c301                -1
    x182      c292                -1   c293                 1
    x182      c2191               -1   c4896                1
    x182      c4898               -1   c4899               -1
    x182      c4909               -1   c4913                1
    x182      c4915               -1   c4916               -1
    x182      c6461                1   c6462                1
    x182      c6463                1   c6464                1
    x182      c6465                1   c6466                1
    x182      c6469               -1
    x183      c294                -1   c295                 1
    x183      c2202               -1   c2205               -1
    x183      c2206               -1   c4924                1
    x183      c4927                1
    x184      c296                -1   c297                 1
    x184      c3984                1   c3986               -1
    x184      c3987               -1
    x185      c300                 1   c301                -1
    x185      c306                -1   c307                 1
    x186      c302                 1   c303                -1
    x186      c304                 1   c305                -1
    x186      c306                 1   c307                -1
    x187      c302                -1   c303                 1
    x187      c4525               -1   c4526                1
    x187      c4528                1
    x188      c304                -1   c305                 1
    x188      c1636                1   c4530               -1
    x189      c308                 1   c309                -1
    x189      c310                 1   c311                -1
    x189      c3996                1   c3997                1
    x189      c3998               -1   c3999               -1
    x189      c4000               -1   c4001               -1
    x189      c4011                1   c4012               -1
    x190      c308                -1   c309                 1
    x190      c3952               -1   c3954                1
    x190      c3955                1   c3962                1
    x190      c3963                1   c3965               -1
    x190      c3994                1   c3995               -1
    x190      c6360               -1   c6362               -1
    x190      c6368               -1
    x191      c312                 1   c313                 1
    x191      c318                 1   c319                 1
    x191      c320                 1   c3991               -1
    x191      c4011               -1   c4012               -1
    x192      c314                 1   c315                -1
    x192      c316                 1   c317                -1
    x192      c4011                1   c4012               -1
    x192      c4013                1   c4014                1
    x192      c4015               -1   c4016               -1
    x192      c4017               -1   c4018               -1
    x193      c314                -1   c315                 1
    x193      c3961                1   c3963                1
    x193      c3964               -1   c3969               -1
    x193      c3971                1   c3972                1
    x193      c3994                1   c3995               -1
    x193      c6361               -1   c6363               -1
    x193      c6367               -1
    x194      c318                -1   c321                -1
    x194      c326                -1   c4019                1
    x194      c4022               -1   c4023               -1
    x194      c6376               -1   c6377               -1
    x195      c319                -1   c348                -1
    x195      c4005               -1   c4006               -1
    x195      c4007               -1   c4030               -1
    x195      c4031               -1   c6373               -1
    x195      c6374               -1   c6375               -1
    x195      c6736                1
    x196      c320                -1   c327                -1
    x196      c4002               -1   c4003               -1
    x196      c4004               -1   c4019                1
    x196      c4020               -1   c4021               -1
    x196      c6370               -1   c6371               -1
    x196      c6372               -1
    x197      c321                -1   c370                -1
    x197      c371                 1   c3996                1
    x197      c3998               -1   c3999               -1
    x197      c4009               -1   c4013                1
    x197      c4015               -1   c4016               -1
    x197      c6370                1   c6371                1
    x197      c6372                1   c6373                1
    x197      c6374                1   c6375                1
    x197      c6378               -1
    x198      c322                 1   c323                -1
    x198      c324                 1   c325                -1
    x198      c332                -1   c333                -1
    x198      c4024                1   c4025                1
    x198      c4026               -1
    x199      c322                -1   c323                 1
    x199      c3996                1   c4000               -1
    x199      c4001               -1   c4008               -1
    x199      c4010               -1   c4022                1
    x199      c4023               -1   c6371                1
    x199      c6372                1   c6374                1
    x199      c6375                1   c6376               -1
    x200      c324                -1   c325                 1
    x200      c3997                1   c3999               -1
    x200      c4001               -1   c4003               -1
    x200      c4005               -1   c4007               -1
    x200      c4020                1   c4021               -1
    x200      c6371               -1   c6376                1
    x200      c6378                1
    x201      c326                 1   c327                 1
    x201      c334                 1   c4019               -1
    x201      c4025               -1   c4026               -1
    x202      c328                 1   c329                -1
    x202      c330                 1   c331                -1
    x202      c336                -1   c337                -1
    x202      c4025                1   c4026               -1
    x202      c4027                1
    x203      c328                -1   c329                 1
    x203      c4009               -1   c4010               -1
    x203      c4013                1   c4017               -1
    x203      c4018               -1   c4022                1
    x203      c4023               -1   c6370                1
    x203      c6372                1   c6373                1
    x203      c6375                1   c6377               -1
    x204      c330                -1   c331                 1
    x204      c4002               -1   c4006               -1
    x204      c4007               -1   c4014                1
    x204      c4016               -1   c4018               -1
    x204      c4020                1   c4021               -1
    x204      c6370               -1   c6377                1
    x204      c6379                1
    x205      c332                -1   c335                -1
    x205      c336                -1   c372                -1
    x205      c373                 1   c4024                1
    x205      c4027                1
    x206      c333                -1   c344                -1
    x206      c345                 1   c4024                1
    x206      c4028                1   c4029               -1
    x207      c334                -1   c335                -1
    x207      c349                -1   c4028               -1
    x207      c4029               -1   c6736                1
    x208      c337                -1   c356                -1
    x208      c357                 1   c4027                1
    x208      c4028                1   c4029               -1
    x209      c338                -1   c339                 1
    x209      c2032               -1   c4034                1
    x209      c4035               -1   c4798                1
    x209      c4799               -1   c4801               -1
    x209      c4803               -1
    x210      c340                -1   c341                 1
    x210      c4032                1   c4033               -1
    x210      c4767                1   c4769               -1
    x210      c4770               -1   c4779               -1
    x210      c4781               -1   c4783               -1
    x210      c6443                1   c6445                1
    x210      c6449               -1
    x211      c342                -1   c343                 1
    x211      c3997                1   c3998               -1
    x211      c4000               -1   c4002               -1
    x211      c4004               -1   c4006               -1
    x211      c4030                1   c4031               -1
    x211      c6374               -1   c6376                1
    x211      c6378                1
    x212      c346                -1   c2034               -1
    x212      c4034               -1   c4035               -1
    x212      c4802               -1   c4803               -1
    x212      c4804               -1   c6736                1
    x213      c347                -1   c2018               -1
    x213      c4032               -1   c4033               -1
    x213      c4782               -1   c4783               -1
    x213      c4784               -1   c6449               -1
    x213      c6450               -1   c6736                1
    x214      c350                -1   c351                 1
    x214      c2036               -1   c4034                1
    x214      c4035               -1   c4800               -1
    x214      c4801               -1   c4802               -1
    x214      c4807                1
    x215      c352                -1   c353                 1
    x215      c4032                1   c4033               -1
    x215      c4780               -1   c4781               -1
    x215      c4782               -1   c4787                1
    x215      c4789               -1   c4790               -1
    x215      c6444                1   c6446                1
    x215      c6450               -1
    x216      c354                -1   c355                 1
    x216      c4003               -1   c4004               -1
    x216      c4005               -1   c4014                1
    x216      c4015               -1   c4017               -1
    x216      c4030                1   c4031               -1
    x216      c6373               -1   c6377                1
    x216      c6379                1
    x217      c360                 1   c361                -1
    x217      c362                 1   c363                -1
    x217      c364                 1   c365                -1
    x218      c360                -1   c361                 1
    x218      c4461               -1   c4462                1
    x218      c4464                1
    x219      c362                -1   c363                 1
    x219      c1472                1   c4466               -1
    x220      c366                 1   c367                -1
    x220      c368                 1   c369                -1
    x220      c370                 1   c371                -1
    x220      c372                 1   c373                -1
    x220      c374                 1   c375                -1
    x221      c366                -1   c367                 1
    x221      c2233               -1   c4940                1
    x221      c4942               -1   c4943               -1
    x221      c4953               -1   c4957                1
    x221      c4959               -1   c4960               -1
    x221      c6471                1   c6472                1
    x221      c6473                1   c6474                1
    x221      c6475                1   c6476                1
    x221      c6479               -1
    x222      c368                -1   c369                 1
    x222      c2244               -1   c2247               -1
    x222      c2248               -1   c4968                1
    x222      c4971                1
    x223      c374                 1   c375                -1
    x223      c376                -1   c377                 1
    x224      c376                 1   c377                -1
    x224      c378                 1   c379                -1
    x224      c380                 1   c381                -1
    x225      c378                -1   c379                 1
    x225      c4568               -1   c4569                1
    x225      c4571                1
    x226      c380                -1   c381                 1
    x226      c1730                1   c4573               -1
    x227      c382                 1   c383                -1
    x227      c384                 1   c385                -1
    x227      c386                 1   c387                -1
    x227      c4036                1   c4037                1
    x227      c4038               -1   c4039               -1
    x227      c4040               -1   c4041               -1
    x228      c386                -1   c387                 1
    x228      c944                 1   c945                -1
    x229      c388                 1   c389                -1
    x229      c390                 1   c391                -1
    x229      c392                -1   c393                -1
    x229      c4042                1
    x230      c388                -1   c389                 1
    x230      c4036                1   c4040               -1
    x230      c4041               -1
    x231      c390                -1   c391                 1
    x231      c4037                1   c4039               -1
    x231      c4041               -1
    x232      c392                -1   c438                -1
    x232      c439                 1   c4042                1
    x233      c393                -1   c396                -1
    x233      c397                 1   c4042                1
    x234      c394                 1   c395                -1
    x234      c396                 1   c397                -1
    x234      c398                 1   c399                -1
    x235      c394                -1   c395                 1
    x235      c4037                1   c4038               -1
    x235      c4040               -1
    x236      c398                 1   c399                -1
    x236      c4043                1   c4044                1
    x236      c4045               -1   c4046               -1
    x236      c4047               -1   c4048               -1
    x237      c400                 1   c401                -1
    x237      c402                 1   c403                -1
    x237      c404                -1   c405                -1
    x237      c4049                1
    x238      c400                -1   c401                 1
    x238      c4043                1   c4047               -1
    x238      c4048               -1
    x239      c402                -1   c403                 1
    x239      c4044                1   c4046               -1
    x239      c4048               -1
    x240      c404                -1   c426                -1
    x240      c427                 1   c4049                1
    x241      c405                -1   c412                -1
    x241      c413                 1   c4049                1
    x242      c406                 1   c407                -1
    x242      c408                 1   c409                -1
    x242      c410                 1   c411                -1
    x242      c412                 1   c413                -1
    x242      c414                 1   c415                -1
    x242      c416                 1   c417                -1
    x242      c418                 1   c419                -1
    x243      c406                -1   c407                 1
    x243      c2542               -1   c2545               -1
    x243      c2546               -1   c5217                1
    x243      c5220                1
    x244      c408                -1   c409                 1
    x244      c2531               -1   c5189                1
    x244      c5191               -1   c5192               -1
    x244      c5202               -1   c5206                1
    x244      c5208               -1   c5209               -1
    x244      c6522                1   c6523                1
    x244      c6524                1   c6525                1
    x244      c6526                1   c6527                1
    x244      c6530               -1
    x245      c410                -1   c411                 1
    x245      c4044                1   c4045               -1
    x245      c4047               -1
    x246      c414                -1   c415                 1
    x246      c4396                1   c4398               -1
    x246      c4399               -1
    x247      c416                -1   c417                 1
    x247      c1309               -1   c4402                1
    x248      c418                 1   c419                -1
    x249      c420                 1   c421                -1
    x249      c422                 1   c423                -1
    x249      c424                 1   c425                -1
    x249      c426                 1   c427                -1
    x249      c428                 1   c429                -1
    x250      c420                -1   c421                 1
    x250      c2728               -1   c2731               -1
    x250      c2732               -1   c5378                1
    x250      c5381                1
    x251      c422                -1   c423                 1
    x251      c2717               -1   c5350                1
    x251      c5352               -1   c5353               -1
    x251      c5363               -1   c5367                1
    x251      c5369               -1   c5370               -1
    x251      c6553                1   c6554                1
    x251      c6555                1   c6556                1
    x251      c6557                1   c6558                1
    x251      c6561               -1
    x252      c424                -1   c425                 1
    x252      c4043                1   c4045               -1
    x252      c4046               -1
    x253      c428                 1   c429                -1
    x253      c434                -1   c435                 1
    x254      c430                 1   c431                -1
    x254      c432                 1   c433                -1
    x254      c434                 1   c435                -1
    x255      c430                -1   c431                 1
    x255      c4524               -1   c4526                1
    x255      c4527                1
    x256      c432                -1   c433                 1
    x256      c1635                1   c4530               -1
    x257      c436                 1   c437                -1
    x257      c438                 1   c439                -1
    x257      c4050               -1   c4051               -1
    x257      c4052                1   c4053                1
    x257      c4054                1   c4055                1
    x258      c436                -1   c437                 1
    x258      c4036                1   c4038               -1
    x258      c4039               -1
    x259      c440                 1   c441                -1
    x259      c442                 1   c443                -1
    x259      c444                 1   c445                 1
    x259      c4056               -1
    x260      c440                -1   c441                 1
    x260      c4050               -1   c4054                1
    x260      c4055                1
    x261      c442                -1   c443                 1
    x261      c4051               -1   c4053                1
    x261      c4055                1
    x262      c444                 1   c468                -1
    x262      c469                 1   c4056               -1
    x263      c445                 1   c452                -1
    x263      c453                 1   c4056               -1
    x264      c446                 1   c447                -1
    x264      c448                 1   c449                -1
    x264      c450                 1   c451                -1
    x264      c452                 1   c453                -1
    x264      c454                 1   c455                -1
    x264      c456                 1   c457                -1
    x265      c446                -1   c447                 1
    x265      c2613                1   c5253               -1
    x265      c5255                1   c5256                1
    x265      c5266               -1   c5270               -1
    x265      c5272                1   c5273                1
    x265      c6533               -1   c6534               -1
    x265      c6535               -1   c6536               -1
    x265      c6537               -1   c6538               -1
    x265      c6541                1
    x266      c448                -1   c449                 1
    x266      c2624                1   c2627                1
    x266      c2628                1   c5281               -1
    x266      c5284               -1
    x267      c450                -1   c451                 1
    x267      c4051               -1   c4052                1
    x267      c4054                1
    x268      c454                -1   c455                 1
    x268      c4460               -1   c4462                1
    x268      c4463                1
    x269      c456                -1   c457                 1
    x269      c1471                1   c4466               -1
    x270      c458                 1   c459                -1
    x270      c460                 1   c461                -1
    x270      c462                 1   c463                -1
    x270      c464                 1   c465                -1
    x270      c466                 1   c467                -1
    x270      c468                 1   c469                -1
    x271      c458                -1   c459                 1
    x271      c2686                1   c2689                1
    x271      c2690                1   c5334               -1
    x271      c5337               -1
    x272      c460                -1   c461                 1
    x272      c4567               -1   c4569                1
    x272      c4570                1
    x273      c462                -1   c463                 1
    x273      c1729                1   c4573               -1
    x274      c464                -1   c465                 1
    x274      c2675                1   c5306               -1
    x274      c5308                1   c5309                1
    x274      c5319               -1   c5323               -1
    x274      c5325                1   c5326                1
    x274      c6543               -1   c6544               -1
    x274      c6545               -1   c6546               -1
    x274      c6547               -1   c6548               -1
    x274      c6551                1
    x275      c466                -1   c467                 1
    x275      c4050               -1   c4052                1
    x275      c4053                1
    x276      c470                 1   c471                -1
    x276      c472                 1   c473                -1
    x276      c474                 1   c475                 1
    x276      c4057               -1
    x277      c474                 1   c4057               -1
    x278      c475                 1   c480                -1
    x278      c481                 1   c4057               -1
    x279      c476                 1   c477                -1
    x279      c478                 1   c479                -1
    x279      c480                 1   c481                -1
    x279      c482                 1   c483                -1
    x279      c484                 1   c485                -1
    x279      c486                 1   c487                -1
    x279      c488                 1   c489                -1
    x279      c490                 1   c491                -1
    x280      c476                -1   c477                 1
    x280      c1290                1   c4388               -1
    x281      c478                -1   c479                 1
    x281      c811                 1   c4239               -1
    x282      c482                -1   c483                 1
    x282      c1614                1   c4516               -1
    x283      c484                -1   c485                 1
    x283      c1041                1   c4303               -1
    x284      c486                -1   c487                 1
    x284      c1708                1   c4559               -1
    x285      c488                -1   c489                 1
    x285      c1450                1   c4452               -1
    x286      c490                -1   c491                 1
    x286      c1827                1   c4606               -1
    x287      c492                 1   c493                -1
    x287      c494                 1   c495                -1
    x287      c4058               -1   c4059               -1
    x287      c4060                1   c4061                1
    x287      c4062                1   c4063                1
    x288      c496                 1   c497                -1
    x288      c498                 1   c499                -1
    x288      c500                 1   c501                 1
    x288      c4064               -1
    x289      c496                -1   c497                 1
    x289      c4058               -1   c4062                1
    x289      c4063                1
    x290      c498                -1   c499                 1
    x290      c4059               -1   c4061                1
    x290      c4063                1
    x291      c500                 1   c534                -1
    x291      c535                 1   c4064               -1
    x292      c501                 1   c504                -1
    x292      c505                 1   c4064               -1
    x293      c502                 1   c503                -1
    x293      c504                 1   c505                -1
    x293      c506                 1   c507                -1
    x294      c502                -1   c503                 1
    x294      c4059               -1   c4060                1
    x294      c4062                1
    x295      c506                 1   c507                -1
    x295      c4065               -1   c4066               -1
    x295      c4067                1   c4068                1
    x295      c4069                1   c4070                1
    x296      c508                 1   c509                -1
    x296      c510                 1   c511                -1
    x296      c512                 1   c513                 1
    x296      c4071               -1
    x297      c508                -1   c509                 1
    x297      c4065               -1   c4069                1
    x297      c4070                1
    x298      c510                -1   c511                 1
    x298      c4066               -1   c4068                1
    x298      c4070                1
    x299      c512                 1   c528                -1
    x299      c529                 1   c4071               -1
    x300      c513                 1   c524                -1
    x300      c525                 1   c4071               -1
    x301      c514                 1   c515                -1
    x301      c516                 1   c517                -1
    x301      c518                 1   c519                -1
    x301      c520                 1   c521                -1
    x301      c522                 1   c523                -1
    x301      c524                 1   c525                -1
    x302      c514                -1   c515                 1
    x302      c4361               -1   c4362                1
    x302      c4364                1
    x303      c516                -1   c517                 1
    x303      c1208                1   c4366               -1
    x304      c518                -1   c519                 1
    x304      c3511                1   c3514                1
    x304      c3515                1   c6144               -1
    x304      c6147               -1
    x305      c520                -1   c521                 1
    x305      c3500                1   c6116               -1
    x305      c6118                1   c6119                1
    x305      c6129               -1   c6133               -1
    x305      c6135                1   c6136                1
    x305      c6690               -1   c6691               -1
    x305      c6692               -1   c6693               -1
    x305      c6694               -1   c6695               -1
    x305      c6698                1
    x306      c522                -1   c523                 1
    x306      c4066               -1   c4067                1
    x306      c4069                1
    x307      c526                 1   c527                -1
    x307      c528                 1   c529                -1
    x307      c530                 1   c531                -1
    x308      c526                -1   c527                 1
    x308      c4065               -1   c4067                1
    x308      c4068                1
    x309      c530                -1   c531                 1
    x309      c1427                1   c1428               -1
    x310      c532                 1   c533                -1
    x310      c534                 1   c535                -1
    x310      c536                 1   c537                -1
    x311      c532                -1   c533                 1
    x311      c4058               -1   c4060                1
    x311      c4061                1
    x312      c536                 1   c537                -1
    x312      c4072               -1   c4073               -1
    x312      c4074                1   c4075                1
    x312      c4076                1   c4077                1
    x313      c538                 1   c539                -1
    x313      c540                 1   c541                -1
    x313      c542                 1   c543                 1
    x313      c4078               -1
    x314      c538                -1   c539                 1
    x314      c4072               -1   c4076                1
    x314      c4077                1
    x315      c540                -1   c541                 1
    x315      c4073               -1   c4075                1
    x315      c4077                1
    x316      c542                 1   c556                -1
    x316      c557                 1   c4078               -1
    x317      c543                 1   c546                -1
    x317      c547                 1   c4078               -1
    x318      c544                 1   c545                -1
    x318      c546                 1   c547                -1
    x318      c548                 1   c549                -1
    x318      c550                 1   c551                -1
    x318      c552                 1   c553                -1
    x319      c544                -1   c545                 1
    x319      c4073               -1   c4074                1
    x319      c4076                1
    x320      c548                -1   c549                 1
    x320      c1267                1   c1268               -1
    x321      c550                -1   c551                 1
    x321      c3453                1   c6064               -1
    x321      c6066                1   c6067                1
    x321      c6077               -1   c6081               -1
    x321      c6083                1   c6084                1
    x321      c6680               -1   c6681               -1
    x321      c6682               -1   c6683               -1
    x321      c6684               -1   c6685               -1
    x321      c6688                1
    x322      c552                -1   c553                 1
    x322      c3464                1   c3467                1
    x322      c3468                1   c6092               -1
    x322      c6095               -1
    x323      c554                 1   c555                -1
    x323      c556                 1   c557                -1
    x323      c558                 1   c559                -1
    x324      c554                -1   c555                 1
    x324      c4072               -1   c4074                1
    x324      c4075                1
    x325      c558                -1   c559                 1
    x325      c1591                1   c1592               -1
    x326      c560                 1   c563                 1
    x326      c564                 1   c898                -1
    x326      c899                 1   c4079               -1
    x326      c4082               -1
    x327      c561                 1   c570                -1
    x327      c571                 1   c4079               -1
    x327      c4090                1   c4091               -1
    x328      c562                -1   c563                -1
    x328      c580                -1   c4090               -1
    x328      c4091               -1   c6769                1
    x329      c565                 1   c588                -1
    x329      c589                 1   c4082               -1
    x329      c4090                1   c4091               -1
    x330      c566                 1   c567                -1
    x330      c568                 1   c569                -1
    x330      c570                 1   c571                -1
    x330      c572                 1   c573                -1
    x330      c574                 1   c575                -1
    x330      c576                 1   c577                -1
    x330      c596                 1   c597                -1
    x330      c4096                1   c4097               -1
    x331      c566                -1   c567                 1
    x331      c3159                1   c4094                1
    x331      c4095               -1   c5793               -1
    x331      c5795                1   c5796                1
    x331      c5798               -1
    x332      c568                -1   c569                 1
    x332      c3433                1   c4092                1
    x332      c4093               -1   c6049               -1
    x332      c6051                1   c6052                1
    x332      c6054               -1
    x333      c572                -1   c573                 1
    x333      c2119                1   c4088                1
    x333      c4089               -1   c4845               -1
    x334      c574                -1   c575                 1
    x334      c2889               -1   c4086                1
    x334      c4087               -1   c5542               -1
    x334      c5544               -1   c5546               -1
    x334      c6752                1
    x335      c576                -1   c577                 1
    x335      c3598                1   c4084                1
    x335      c4085               -1   c6212               -1
    x335      c6214                1   c6215                1
    x335      c6217               -1
    x336      c578                 1   c579                 1
    x336      c580                 1   c581                 1
    x336      c582                 1   c583                 1
    x336      c598                 1   c4096               -1
    x336      c4097               -1   c6769               -1
    x337      c578                -1   c3161               -1
    x337      c4094               -1   c4095               -1
    x337      c5797               -1   c5798               -1
    x337      c5799               -1   c6769                1
    x338      c579                -1   c3435               -1
    x338      c4092               -1   c4093               -1
    x338      c6053               -1   c6054               -1
    x338      c6055               -1   c6769                1
    x339      c581                -1   c2120               -1
    x339      c2121               -1   c4088               -1
    x339      c4089               -1   c6769                1
    x340      c582                -1   c2891               -1
    x340      c2892               -1   c2893               -1
    x340      c4083                1   c4086               -1
    x340      c4087               -1   c5541               -1
    x340      c5542               -1   c5543               -1
    x341      c583                -1   c3600               -1
    x341      c4083                1   c4084               -1
    x341      c4085               -1   c6216               -1
    x341      c6217               -1   c6218               -1
    x342      c584                 1   c585                -1
    x342      c586                 1   c587                -1
    x342      c588                 1   c589                -1
    x342      c590                 1   c591                -1
    x342      c592                 1   c593                -1
    x342      c594                 1   c595                -1
    x342      c599                 1   c600                -1
    x342      c4096                1   c4097               -1
    x343      c584                -1   c585                 1
    x343      c3163                1   c4094                1
    x343      c4095               -1   c5794                1
    x343      c5796                1   c5797               -1
    x343      c5802               -1
    x344      c586                -1   c587                 1
    x344      c3437                1   c4092                1
    x344      c4093               -1   c6050                1
    x344      c6052                1   c6053               -1
    x344      c6058               -1
    x345      c590                -1   c591                 1
    x345      c2123                1   c4088                1
    x345      c4089               -1   c4848               -1
    x346      c592                -1   c593                 1
    x346      c2899               -1   c4086                1
    x346      c4087               -1   c5541               -1
    x346      c5545               -1   c5546               -1
    x346      c6753                1
    x347      c594                -1   c595                 1
    x347      c3602                1   c4084                1
    x347      c4085               -1   c6213                1
    x347      c6215                1   c6216               -1
    x347      c6221               -1
    x348      c596                 1   c597                -1
    x348      c601                -1   c602                 1
    x348      c4110                1   c4111               -1
    x349      c598                -1   c615                -1
    x349      c4110               -1   c4111               -1
    x349      c6770                1
    x350      c599                 1   c600                -1
    x350      c622                -1   c623                 1
    x350      c4110                1   c4111               -1
    x351      c601                 1   c602                -1
    x351      c603                 1   c604                -1
    x351      c605                 1   c606                -1
    x351      c607                 1   c608                -1
    x351      c609                 1   c610                -1
    x351      c611                 1   c612                -1
    x351      c613                 1   c614                -1
    x351      c4112               -1   c4113               -1
    x351      c4114                1   c4115                1
    x351      c4116                1   c4117                1
    x351      c4127                1   c4128               -1
    x352      c603                -1   c604                 1
    x352      c2332                1   c4108                1
    x352      c4109               -1   c5036               -1
    x352      c5039                1   c5040                1
    x352      c6743               -1
    x353      c605                -1   c606                 1
    x353      c2901               -1   c4106                1
    x353      c4107               -1   c5549                1
    x354      c607                -1   c608                 1
    x354      c2588                1   c4104                1
    x354      c4105               -1   c5241               -1
    x354      c5244                1   c5245                1
    x354      c6745               -1
    x355      c609                -1   c610                 1
    x355      c2791               -1   c4102                1
    x355      c4103               -1   c5433                1
    x355      c5434               -1   c5436               -1
    x355      c5438               -1
    x356      c611                -1   c612                 1
    x356      c2874                1   c4100                1
    x356      c4101               -1   c5508               -1
    x357      c613                -1   c614                 1
    x357      c2862                1   c4098                1
    x357      c4099               -1   c5501               -1
    x357      c5504                1   c5505                1
    x357      c6750               -1
    x358      c615                 1   c616                 1
    x358      c617                 1   c618                 1
    x358      c619                 1   c620                 1
    x358      c621                 1   c636                 1
    x358      c637                 1   c638                 1
    x358      c4127               -1   c4128               -1
    x358      c6770               -1
    x359      c616                -1   c2334               -1
    x359      c2335               -1   c2336               -1
    x359      c4108               -1   c4109               -1
    x359      c5035               -1   c5036               -1
    x359      c5037               -1   c6770                1
    x360      c617                -1   c2902               -1
    x360      c2903               -1   c4106               -1
    x360      c4107               -1   c6770                1
    x361      c618                -1   c2590               -1
    x361      c2591               -1   c2592               -1
    x361      c4104               -1   c4105               -1
    x361      c5240               -1   c5241               -1
    x361      c5242               -1   c6770                1
    x362      c619                -1   c2793               -1
    x362      c4102               -1   c4103               -1
    x362      c5437               -1   c5438               -1
    x362      c5439               -1   c6380                1
    x363      c620                -1   c2875               -1
    x363      c2876               -1   c4100               -1
    x363      c4101               -1   c6380                1
    x364      c621                -1   c2864               -1
    x364      c2865               -1   c2866               -1
    x364      c4098               -1   c4099               -1
    x364      c5500               -1   c5501               -1
    x364      c5502               -1   c6380                1
    x365      c622                 1   c623                -1
    x365      c624                 1   c625                -1
    x365      c626                 1   c627                -1
    x365      c628                 1   c629                -1
    x365      c630                 1   c631                -1
    x365      c632                 1   c633                -1
    x365      c634                 1   c635                -1
    x365      c4127                1   c4128               -1
    x365      c4129               -1   c4130               -1
    x365      c4131                1   c4132                1
    x365      c4133                1   c4134                1
    x366      c624                -1   c625                 1
    x366      c2342                1   c4108                1
    x366      c4109               -1   c5035               -1
    x366      c5038                1   c5040                1
    x366      c6744               -1
    x367      c626                -1   c627                 1
    x367      c2905               -1   c4106                1
    x367      c4107               -1   c5552                1
    x368      c628                -1   c629                 1
    x368      c2598                1   c4104                1
    x368      c4105               -1   c5240               -1
    x368      c5243                1   c5245                1
    x368      c6746               -1
    x369      c630                -1   c631                 1
    x369      c2795               -1   c4102                1
    x369      c4103               -1   c5435               -1
    x369      c5436               -1   c5437               -1
    x369      c5442                1
    x370      c632                -1   c633                 1
    x370      c2878                1   c4100                1
    x370      c4101               -1   c5511               -1
    x371      c634                -1   c635                 1
    x371      c2872                1   c4098                1
    x371      c4099               -1   c5500               -1
    x371      c5503                1   c5505                1
    x371      c6751               -1
    x372      c636                -1   c639                -1
    x372      c644                -1   c4135                1
    x372      c4138               -1   c4139               -1
    x372      c6387               -1   c6388               -1
    x373      c637                -1   c661                -1
    x373      c4121               -1   c4122               -1
    x373      c4123               -1   c4144                1
    x373      c4145               -1   c4146               -1
    x373      c6384               -1   c6385               -1
    x373      c6386               -1
    x374      c638                -1   c645                -1
    x374      c4118               -1   c4119               -1
    x374      c4120               -1   c4135                1
    x374      c4136               -1   c4137               -1
    x374      c6381               -1   c6382               -1
    x374      c6383               -1
    x375      c639                 1   c814                -1
    x375      c815                 1   c4112               -1
    x375      c4114                1   c4115                1
    x375      c4125               -1   c4129               -1
    x375      c4131                1   c4132                1
    x375      c6381               -1   c6382               -1
    x375      c6383               -1   c6384               -1
    x375      c6385               -1   c6386               -1
    x375      c6389                1
    x376      c640                 1   c641                -1
    x376      c642                 1   c643                -1
    x376      c650                 1   c651                 1
    x376      c4140               -1   c4141                1
    x376      c4142               -1
    x377      c640                -1   c641                 1
    x377      c4112               -1   c4116                1
    x377      c4117                1   c4125                1
    x377      c4126                1   c4138                1
    x377      c4139               -1   c6381               -1
    x377      c6383               -1   c6384               -1
    x377      c6386               -1   c6387                1
    x378      c642                -1   c643                 1
    x378      c4113               -1   c4115                1
    x378      c4117                1   c4119               -1
    x378      c4122                1   c4123                1
    x378      c4136                1   c4137               -1
    x378      c6382               -1   c6387               -1
    x378      c6389               -1
    x379      c644                 1   c645                 1
    x379      c652                 1   c4135               -1
    x379      c4141               -1   c4142               -1
    x380      c646                 1   c647                -1
    x380      c648                 1   c649                -1
    x380      c654                 1   c655                 1
    x380      c4141                1   c4142               -1
    x380      c4143               -1
    x381      c646                -1   c647                 1
    x381      c4124                1   c4126                1
    x381      c4129               -1   c4133                1
    x381      c4134                1   c4138                1
    x381      c4139               -1   c6382               -1
    x381      c6383               -1   c6385               -1
    x381      c6386               -1   c6388                1
    x382      c648                -1   c649                 1
    x382      c4118               -1   c4121                1
    x382      c4123                1   c4130               -1
    x382      c4132                1   c4134                1
    x382      c4136                1   c4137               -1
    x382      c6381               -1   c6388               -1
    x382      c6390               -1
    x383      c650                 1   c653                 1
    x383      c654                 1   c812                -1
    x383      c813                 1   c4140               -1
    x383      c4143               -1
    x384      c651                 1   c656                -1
    x384      c657                 1   c4140               -1
    x384      c4147                1   c4148               -1
    x385      c652                -1   c653                -1
    x385      c660                -1   c4144                1
    x385      c4147               -1   c4148               -1
    x386      c655                 1   c662                -1
    x386      c663                 1   c4143               -1
    x386      c4147                1   c4148               -1
    x387      c656                 1   c657                -1
    x387      c658                 1   c659                -1
    x387      c4149                1   c4150                1
    x387      c4151               -1   c4152               -1
    x387      c4153               -1   c4154               -1
    x387      c4164                1   c4165               -1
    x388      c658                -1   c659                 1
    x388      c4113               -1   c4114                1
    x388      c4116                1   c4119                1
    x388      c4120                1   c4122               -1
    x388      c4145                1   c4146               -1
    x388      c6385               -1   c6387               -1
    x388      c6389               -1
    x389      c660                 1   c661                 1
    x389      c666                 1   c667                 1
    x389      c668                 1   c4144               -1
    x389      c4164               -1   c4165               -1
    x390      c662                 1   c663                -1
    x390      c664                 1   c665                -1
    x390      c4164                1   c4165               -1
    x390      c4166                1   c4167                1
    x390      c4168               -1   c4169               -1
    x390      c4170               -1   c4171               -1
    x391      c664                -1   c665                 1
    x391      c4118                1   c4120                1
    x391      c4121               -1   c4130               -1
    x391      c4131                1   c4133                1
    x391      c4145                1   c4146               -1
    x391      c6384               -1   c6388               -1
    x391      c6390               -1
    x392      c666                -1   c669                -1
    x392      c674                -1   c4172                1
    x392      c4175               -1   c4176               -1
    x392      c6397               -1   c6398               -1
    x393      c667                -1   c691                -1
    x393      c4158               -1   c4159               -1
    x393      c4160               -1   c4181                1
    x393      c4182               -1   c4183               -1
    x393      c6394               -1   c6395               -1
    x393      c6396               -1
    x394      c668                -1   c675                -1
    x394      c4155               -1   c4156               -1
    x394      c4157               -1   c4172                1
    x394      c4173               -1   c4174               -1
    x394      c6391               -1   c6392               -1
    x394      c6393               -1
    x395      c669                -1   c808                -1
    x395      c809                 1   c4149                1
    x395      c4151               -1   c4152               -1
    x395      c4162               -1   c4166                1
    x395      c4168               -1   c4169               -1
    x395      c6391                1   c6392                1
    x395      c6393                1   c6394                1
    x395      c6395                1   c6396                1
    x395      c6399               -1
    x396      c670                 1   c671                -1
    x396      c672                 1   c673                -1
    x396      c680                -1   c681                -1
    x396      c4177                1   c4178                1
    x396      c4179               -1
    x397      c670                -1   c671                 1
    x397      c4149                1   c4153               -1
    x397      c4154               -1   c4161               -1
    x397      c4163               -1   c4175                1
    x397      c4176               -1   c6392                1
    x397      c6393                1   c6395                1
    x397      c6396                1   c6397               -1
    x398      c672                -1   c673                 1
    x398      c4150                1   c4152               -1
    x398      c4154               -1   c4156               -1
    x398      c4158               -1   c4160               -1
    x398      c4173                1   c4174               -1
    x398      c6392               -1   c6397                1
    x398      c6399                1
    x399      c674                 1   c675                 1
    x399      c682                 1   c4172               -1
    x399      c4178               -1   c4179               -1
    x400      c676                 1   c677                -1
    x400      c678                 1   c679                -1
    x400      c684                -1   c685                -1
    x400      c4178                1   c4179               -1
    x400      c4180                1
    x401      c676                -1   c677                 1
    x401      c4162               -1   c4163               -1
    x401      c4166                1   c4170               -1
    x401      c4171               -1   c4175                1
    x401      c4176               -1   c6391                1
    x401      c6393                1   c6394                1
    x401      c6396                1   c6398               -1
    x402      c678                -1   c679                 1
    x402      c4155               -1   c4159               -1
    x402      c4160               -1   c4167                1
    x402      c4169               -1   c4171               -1
    x402      c4173                1   c4174               -1
    x402      c6391               -1   c6398                1
    x402      c6400                1
    x403      c680                -1   c683                -1
    x403      c684                -1   c806                -1
    x403      c807                 1   c4177                1
    x403      c4180                1
    x404      c681                -1   c686                -1
    x404      c687                 1   c4177                1
    x404      c4184                1   c4185               -1
    x405      c682                -1   c683                -1
    x405      c690                -1   c4181                1
    x405      c4184               -1   c4185               -1
    x406      c685                -1   c692                -1
    x406      c693                 1   c4180                1
    x406      c4184                1   c4185               -1
    x407      c686                 1   c687                -1
    x407      c688                 1   c689                -1
    x407      c4186               -1   c4187               -1
    x407      c4188                1   c4189                1
    x407      c4190                1   c4191                1
    x407      c4201                1   c4202               -1
    x408      c688                -1   c689                 1
    x408      c4150                1   c4151               -1
    x408      c4153               -1   c4155               -1
    x408      c4157               -1   c4159               -1
    x408      c4182                1   c4183               -1
    x408      c6395               -1   c6397                1
    x408      c6399                1
    x409      c690                 1   c691                 1
    x409      c696                 1   c697                 1
    x409      c698                 1   c4181               -1
    x409      c4201               -1   c4202               -1
    x410      c692                 1   c693                -1
    x410      c694                 1   c695                -1
    x410      c4201                1   c4202               -1
    x410      c4203               -1   c4204               -1
    x410      c4205                1   c4206                1
    x410      c4207                1   c4208                1
    x411      c694                -1   c695                 1
    x411      c4156               -1   c4157               -1
    x411      c4158               -1   c4167                1
    x411      c4168               -1   c4170               -1
    x411      c4182                1   c4183               -1
    x411      c6394               -1   c6398                1
    x411      c6400                1
    x412      c696                -1   c699                -1
    x412      c704                -1   c4209                1
    x412      c4212               -1   c4213               -1
    x412      c6407               -1   c6408               -1
    x413      c698                -1   c705                -1
    x413      c4192               -1   c4193               -1
    x413      c4194               -1   c4209                1
    x413      c4210               -1   c4211               -1
    x413      c6401               -1   c6402               -1
    x413      c6403               -1
    x414      c699                 1   c718                -1
    x414      c719                 1   c4186               -1
    x414      c4188                1   c4189                1
    x414      c4199               -1   c4203               -1
    x414      c4205                1   c4206                1
    x414      c6401               -1   c6402               -1
    x414      c6403               -1   c6404               -1
    x414      c6405               -1   c6406               -1
    x414      c6409                1
    x415      c700                 1   c701                -1
    x415      c702                 1   c703                -1
    x415      c710                 1   c711                 1
    x415      c4214               -1   c4215                1
    x415      c4216               -1
    x416      c700                -1   c701                 1
    x416      c4186               -1   c4190                1
    x416      c4191                1   c4199                1
    x416      c4200                1   c4212                1
    x416      c4213               -1   c6401               -1
    x416      c6403               -1   c6404               -1
    x416      c6406               -1   c6407                1
    x417      c702                -1   c703                 1
    x417      c4187               -1   c4189                1
    x417      c4191                1   c4193               -1
    x417      c4196                1   c4197                1
    x417      c4210                1   c4211               -1
    x417      c6402               -1   c6407               -1
    x417      c6409               -1
    x418      c704                 1   c705                 1
    x418      c712                 1   c4209               -1
    x418      c4215               -1   c4216               -1
    x419      c706                 1   c707                -1
    x419      c708                 1   c709                -1
    x419      c714                 1   c715                 1
    x419      c4215                1   c4216               -1
    x419      c4217               -1
    x420      c706                -1   c707                 1
    x420      c4198                1   c4200                1
    x420      c4203               -1   c4207                1
    x420      c4208                1   c4212                1
    x420      c4213               -1   c6402               -1
    x420      c6403               -1   c6405               -1
    x420      c6406               -1   c6408                1
    x421      c708                -1   c709                 1
    x421      c4192               -1   c4195                1
    x421      c4197                1   c4204               -1
    x421      c4206                1   c4208                1
    x421      c4210                1   c4211               -1
    x421      c6401               -1   c6408               -1
    x421      c6410               -1
    x422      c710                 1   c713                 1
    x422      c714                 1   c716                -1
    x422      c717                 1   c4214               -1
    x422      c4217               -1
    x423      c716                 1   c717                -1
    x423      c718                 1   c719                -1
    x423      c720                 1   c721                -1
    x424      c720                 1   c721                -1
    x424      c722                -1   c723                 1
    x425      c722                 1   c723                -1
    x425      c724                 1   c725                -1
    x425      c726                 1   c727                -1
    x425      c4218               -1   c4219               -1
    x425      c4220                1   c4221                1
    x425      c4222                1   c4223                1
    x426      c724                -1   c725                 1
    x426      c1819               -1   c4605                1
    x427      c726                -1   c727                 1
    x427      c4600                1   c4601               -1
    x427      c4603               -1
    x428      c728                 1   c729                -1
    x428      c730                 1   c731                -1
    x428      c732                 1   c733                 1
    x428      c4224               -1
    x429      c728                -1   c729                 1
    x429      c4218               -1   c4222                1
    x429      c4223                1
    x430      c730                -1   c731                 1
    x430      c4219               -1   c4221                1
    x430      c4223                1
    x431      c732                 1   c768                -1
    x431      c769                 1   c4224               -1
    x432      c733                 1   c736                -1
    x432      c737                 1   c4224               -1
    x433      c734                 1   c735                -1
    x433      c736                 1   c737                -1
    x433      c738                 1   c739                -1
    x434      c734                -1   c735                 1
    x434      c4219               -1   c4220                1
    x434      c4222                1
    x435      c738                 1   c739                -1
    x435      c4225               -1   c4226               -1
    x435      c4227                1   c4228                1
    x435      c4229                1   c4230                1
    x436      c740                 1   c741                -1
    x436      c742                 1   c743                -1
    x436      c744                 1   c745                 1
    x436      c4231               -1
    x437      c740                -1   c741                 1
    x437      c4225               -1   c4229                1
    x437      c4230                1
    x438      c742                -1   c743                 1
    x438      c4226               -1   c4228                1
    x438      c4230                1
    x439      c744                 1   c764                -1
    x439      c765                 1   c4231               -1
    x440      c745                 1   c750                -1
    x440      c751                 1   c4231               -1
    x441      c746                 1   c747                -1
    x441      c748                 1   c749                -1
    x441      c750                 1   c751                -1
    x441      c752                 1   c753                -1
    x441      c754                 1   c755                -1
    x442      c746                -1   c747                 1
    x442      c1874                1   c1875               -1
    x443      c748                -1   c749                 1
    x443      c4226               -1   c4227                1
    x443      c4229                1
    x444      c752                -1   c753                 1
    x444      c1322                1   c4409               -1
    x445      c754                -1   c755                 1
    x445      c4404               -1   c4405                1
    x445      c4407                1
    x446      c756                 1   c757                -1
    x446      c758                 1   c759                -1
    x446      c760                 1   c761                -1
    x446      c762                 1   c763                -1
    x446      c764                 1   c765                -1
    x447      c756                -1   c757                 1
    x447      c1901                1   c1904                1
    x447      c1905                1   c4661               -1
    x447      c4664               -1
    x448      c758                -1   c759                 1
    x448      c1890                1   c4633               -1
    x448      c4635                1   c4636                1
    x448      c4646               -1   c4650               -1
    x448      c4652                1   c4653                1
    x448      c6413               -1   c6414               -1
    x448      c6415               -1   c6416               -1
    x448      c6417               -1   c6418               -1
    x448      c6421                1
    x449      c760                -1   c761                 1
    x449      c1651                1   c1652               -1
    x450      c762                -1   c763                 1
    x450      c4225               -1   c4227                1
    x450      c4228                1
    x451      c766                 1   c767                -1
    x451      c768                 1   c769                -1
    x451      c4232                1   c4233                1
    x451      c4234               -1   c4235               -1
    x451      c4236               -1   c4237               -1
    x452      c766                -1   c767                 1
    x452      c4218               -1   c4220                1
    x452      c4221                1
    x453      c770                 1   c771                -1
    x453      c772                 1   c773                -1
    x453      c774                -1   c775                -1
    x453      c4238                1
    x454      c770                -1   c771                 1
    x454      c4232                1   c4236               -1
    x454      c4237               -1
    x455      c772                -1   c773                 1
    x455      c4233                1   c4235               -1
    x455      c4237               -1
    x456      c774                -1   c798                -1
    x456      c799                 1   c4238                1
    x457      c775                -1   c782                -1
    x457      c783                 1   c4238                1
    x458      c776                 1   c777                -1
    x458      c778                 1   c779                -1
    x458      c780                 1   c781                -1
    x458      c782                 1   c783                -1
    x458      c784                 1   c785                -1
    x459      c776                -1   c777                 1
    x459      c1979               -1   c4723                1
    x459      c4725               -1   c4726               -1
    x459      c4736               -1   c4740                1
    x459      c4742               -1   c4743               -1
    x459      c6433                1   c6434                1
    x459      c6435                1   c6436                1
    x459      c6437                1   c6438                1
    x459      c6441               -1
    x460      c778                -1   c779                 1
    x460      c1990               -1   c1993               -1
    x460      c1994               -1   c4751                1
    x460      c4754                1
    x461      c780                -1   c781                 1
    x461      c4233                1   c4234               -1
    x461      c4236               -1
    x462      c784                 1   c785                -1
    x462      c790                -1   c791                 1
    x463      c786                 1   c787                -1
    x463      c788                 1   c789                -1
    x463      c790                 1   c791                -1
    x464      c786                -1   c787                 1
    x464      c4468               -1   c4469                1
    x464      c4471                1
    x465      c788                -1   c789                 1
    x465      c1484                1   c4473               -1
    x466      c792                 1   c793                -1
    x466      c794                 1   c795                -1
    x466      c796                 1   c797                -1
    x466      c798                 1   c799                -1
    x466      c800                 1   c801                -1
    x466      c802                 1   c803                -1
    x466      c804                 1   c805                -1
    x467      c792                -1   c793                 1
    x467      c1948               -1   c1951               -1
    x467      c1952               -1   c4707                1
    x467      c4710                1
    x468      c794                -1   c795                 1
    x468      c1937               -1   c4679                1
    x468      c4681               -1   c4682               -1
    x468      c4692               -1   c4696                1
    x468      c4698               -1   c4699               -1
    x468      c6423                1   c6424                1
    x468      c6425                1   c6426                1
    x468      c6427                1   c6428                1
    x468      c6431               -1
    x469      c796                -1   c797                 1
    x469      c4232                1   c4234               -1
    x469      c4235               -1
    x470      c800                -1   c801                 1
    x470      c4575                1   c4576               -1
    x470      c4578               -1
    x471      c802                -1   c803                 1
    x471      c1740               -1   c4580                1
    x472      c804                 1   c805                -1
    x473      c806                 1   c807                -1
    x473      c808                 1   c809                -1
    x473      c810                 1   c811                 1
    x473      c4239               -1
    x474      c810                 1   c4239               -1
    x475      c812                 1   c813                -1
    x475      c814                 1   c815                -1
    x475      c816                 1   c817                -1
    x476      c816                 1   c817                -1
    x476      c4240               -1   c4241               -1
    x476      c4242                1   c4243                1
    x476      c4244                1   c4245                1
    x477      c818                 1   c819                -1
    x477      c820                 1   c821                -1
    x477      c822                 1   c823                 1
    x477      c4246               -1
    x478      c818                -1   c819                 1
    x478      c4240               -1   c4244                1
    x478      c4245                1
    x479      c820                -1   c821                 1
    x479      c4241               -1   c4243                1
    x479      c4245                1
    x480      c822                 1   c856                -1
    x480      c857                 1   c4246               -1
    x481      c823                 1   c824                -1
    x481      c825                 1   c4246               -1
    x482      c824                 1   c825                -1
    x482      c826                 1   c827                -1
    x482      c828                 1   c829                -1
    x483      c826                -1   c827                 1
    x483      c4241               -1   c4242                1
    x483      c4244                1
    x484      c828                 1   c829                -1
    x484      c4247               -1   c4248               -1
    x484      c4249                1   c4250                1
    x484      c4251                1   c4252                1
    x485      c830                 1   c831                -1
    x485      c832                 1   c833                -1
    x485      c834                 1   c835                 1
    x485      c4253               -1
    x486      c830                -1   c831                 1
    x486      c4247               -1   c4251                1
    x486      c4252                1
    x487      c832                -1   c833                 1
    x487      c4248               -1   c4250                1
    x487      c4252                1
    x488      c834                 1   c850                -1
    x488      c851                 1   c4253               -1
    x489      c835                 1   c838                -1
    x489      c839                 1   c4253               -1
    x490      c836                 1   c837                -1
    x490      c838                 1   c839                -1
    x490      c840                 1   c841                -1
    x490      c842                 1   c843                -1
    x490      c844                 1   c845                -1
    x491      c836                -1   c837                 1
    x491      c4248               -1   c4249                1
    x491      c4251                1
    x492      c840                -1   c841                 1
    x492      c4354               -1   c4355                1
    x492      c4357                1
    x493      c842                -1   c843                 1
    x493      c1198                1   c4359               -1
    x494      c844                -1   c845                 1
    x494      c3623                1   c3624               -1
    x495      c846                 1   c847                -1
    x495      c848                 1   c849                -1
    x495      c850                 1   c851                -1
    x495      c852                 1   c853                -1
    x495      c854                 1   c855                -1
    x496      c846                -1   c847                 1
    x496      c1397                1   c1398               -1
    x497      c848                -1   c849                 1
    x497      c4247               -1   c4249                1
    x497      c4250                1
    x498      c852                -1   c853                 1
    x498      c2764                1   c5396               -1
    x498      c5398                1   c5399                1
    x498      c5409               -1   c5413               -1
    x498      c5415                1   c5416                1
    x498      c6563               -1   c6564               -1
    x498      c6565               -1   c6566               -1
    x498      c6567               -1   c6568               -1
    x498      c6571                1
    x499      c854                -1   c855                 1
    x499      c2775                1   c2778                1
    x499      c2779                1   c5424               -1
    x499      c5427               -1
    x500      c856                 1   c857                -1
    x500      c858                 1   c859                -1
    x500      c4254                1   c4255                1
    x500      c4256               -1   c4257               -1
    x500      c4258               -1   c4259               -1
    x501      c858                -1   c859                 1
    x501      c4240               -1   c4242                1
    x501      c4243                1
    x502      c860                 1   c861                -1
    x502      c862                 1   c863                -1
    x502      c864                -1   c865                -1
    x502      c4260                1
    x503      c860                -1   c861                 1
    x503      c4254                1   c4258               -1
    x503      c4259               -1
    x504      c862                -1   c863                 1
    x504      c4255                1   c4257               -1
    x504      c4259               -1
    x505      c864                -1   c880                -1
    x505      c881                 1   c4260                1
    x506      c865                -1   c870                -1
    x506      c871                 1   c4260                1
    x507      c866                 1   c867                -1
    x507      c868                 1   c869                -1
    x507      c870                 1   c871                -1
    x507      c872                 1   c873                -1
    x507      c874                 1   c875                -1
    x507      c876                 1   c877                -1
    x507      c878                 1   c879                -1
    x508      c866                -1   c867                 1
    x508      c1240               -1   c4380                1
    x509      c868                -1   c869                 1
    x509      c4375                1   c4376               -1
    x509      c4378               -1
    x510      c872                -1   c873                 1
    x510      c4255                1   c4256               -1
    x510      c4258               -1
    x511      c874                -1   c875                 1
    x511      c3417               -1   c3420               -1
    x511      c3421               -1   c6040                1
    x511      c6043                1
    x512      c876                -1   c877                 1
    x512      c3406               -1   c6012                1
    x512      c6014               -1   c6015               -1
    x512      c6025               -1   c6029                1
    x512      c6031               -1   c6032               -1
    x512      c6670                1   c6671                1
    x512      c6672                1   c6673                1
    x512      c6674                1   c6675                1
    x512      c6678               -1
    x513      c878                 1   c879                -1
    x514      c880                 1   c881                -1
    x514      c882                 1   c883                -1
    x514      c884                 1   c885                -1
    x514      c886                 1   c887                -1
    x514      c888                 1   c889                -1
    x515      c882                -1   c883                 1
    x515      c4254                1   c4256               -1
    x515      c4257               -1
    x516      c884                -1   c885                 1
    x516      c3143               -1   c3146               -1
    x516      c3147               -1   c5784                1
    x516      c5787                1
    x517      c886                -1   c887                 1
    x517      c3132               -1   c5756                1
    x517      c5758               -1   c5759               -1
    x517      c5769               -1   c5773                1
    x517      c5775               -1   c5776               -1
    x517      c6618                1   c6619                1
    x517      c6620                1   c6621                1
    x517      c6622                1   c6623                1
    x517      c6626               -1
    x518      c888                 1   c889                -1
    x518      c894                -1   c895                 1
    x519      c890                 1   c891                -1
    x519      c892                 1   c893                -1
    x519      c894                 1   c895                -1
    x520      c890                -1   c891                 1
    x520      c1570                1   c4508               -1
    x521      c892                -1   c893                 1
    x521      c4503               -1   c4504                1
    x521      c4506                1
    x522      c896                 1   c897                -1
    x522      c898                 1   c899                -1
    x522      c900                 1   c901                -1
    x522      c902                 1   c903                -1
    x522      c904                 1   c905                -1
    x522      c906                 1   c907                -1
    x522      c908                 1   c909                -1
    x522      c910                 1   c911                -1
    x522      c4261               -1   c4262               -1
    x522      c4263                1   c4264                1
    x522      c4265                1   c4266                1
    x523      c896                -1   c897                 1
    x523      c2353                1   c2354               -1
    x524      c900                -1   c901                 1
    x524      c2118                1   c2121                1
    x524      c2122                1   c4845               -1
    x524      c4848               -1
    x525      c902                -1   c903                 1
    x525      c2887               -1   c2892               -1
    x525      c2894               -1   c2897               -1
    x525      c6752                1   c6753                1
    x526      c904                -1   c905                 1
    x526      c2873                1   c2876                1
    x526      c2877                1   c5508               -1
    x526      c5511               -1
    x527      c906                -1   c907                 1
    x527      c2860                1   c2865                1
    x527      c2867                1   c2870                1
    x527      c6750               -1   c6751               -1
    x528      c908                -1   c909                 1
    x528      c3093               -1   c3096               -1
    x528      c3097               -1   c5741                1
    x528      c5744                1
    x529      c910                -1   c911                 1
    x529      c3708               -1   c3711               -1
    x529      c3712               -1   c6315                1
    x529      c6318                1
    x530      c912                 1   c913                -1
    x530      c914                 1   c915                -1
    x530      c916                 1   c917                 1
    x530      c4267               -1
    x531      c912                -1   c913                 1
    x531      c4261               -1   c4265                1
    x531      c4266                1
    x532      c914                -1   c915                 1
    x532      c4262               -1   c4264                1
    x532      c4266                1
    x533      c916                 1   c1044               -1
    x533      c1045                1   c4267               -1
    x534      c917                 1   c920                -1
    x534      c921                 1   c4267               -1
    x535      c918                 1   c919                -1
    x535      c920                 1   c921                -1
    x535      c4268                1   c4269                1
    x535      c4270               -1   c4271               -1
    x535      c4272               -1   c4273               -1
    x536      c918                -1   c919                 1
    x536      c4262               -1   c4263                1
    x536      c4265                1
    x537      c922                 1   c923                -1
    x537      c924                 1   c925                -1
    x537      c926                -1   c927                -1
    x537      c4274                1
    x538      c922                -1   c923                 1
    x538      c4268                1   c4272               -1
    x538      c4273               -1
    x539      c924                -1   c925                 1
    x539      c4269                1   c4271               -1
    x539      c4273               -1
    x540      c926                -1   c1038               -1
    x540      c1039                1   c4274                1
    x541      c927                -1   c930                -1
    x541      c931                 1   c4274                1
    x542      c928                 1   c929                -1
    x542      c930                 1   c931                -1
    x542      c932                 1   c933                -1
    x543      c928                -1   c929                 1
    x543      c4269                1   c4270               -1
    x543      c4272               -1
    x544      c932                 1   c933                -1
    x544      c4275                1   c4276                1
    x544      c4277               -1   c4278               -1
    x544      c4279               -1   c4280               -1
    x545      c934                 1   c935                -1
    x545      c936                 1   c937                -1
    x545      c938                -1   c939                -1
    x545      c4281                1
    x546      c934                -1   c935                 1
    x546      c4275                1   c4279               -1
    x546      c4280               -1
    x547      c936                -1   c937                 1
    x547      c4276                1   c4278               -1
    x547      c4280               -1
    x548      c938                -1   c948                -1
    x548      c949                 1   c4281                1
    x549      c939                -1   c942                -1
    x549      c943                 1   c4281                1
    x550      c940                 1   c941                -1
    x550      c942                 1   c943                -1
    x550      c944                 1   c945                -1
    x551      c940                -1   c941                 1
    x551      c4276                1   c4277               -1
    x551      c4279               -1
    x552      c946                 1   c947                -1
    x552      c948                 1   c949                -1
    x552      c950                 1   c951                -1
    x552      c952                 1   c953                -1
    x552      c954                 1   c955                -1
    x553      c946                -1   c947                 1
    x553      c4275                1   c4277               -1
    x553      c4278               -1
    x554      c950                -1   c951                 1
    x554      c1818               -1   c4605                1
    x555      c952                -1   c953                 1
    x555      c4599                1   c4601               -1
    x555      c4602               -1
    x556      c954                 1   c955                -1
    x556      c4282                1   c4283                1
    x556      c4284               -1   c4285               -1
    x556      c4286               -1   c4287               -1
    x557      c956                 1   c957                -1
    x557      c958                 1   c959                -1
    x557      c960                -1   c961                -1
    x557      c4288                1
    x558      c956                -1   c957                 1
    x558      c4282                1   c4286               -1
    x558      c4287               -1
    x559      c958                -1   c959                 1
    x559      c4283                1   c4285               -1
    x559      c4287               -1
    x560      c960                -1   c1008               -1
    x560      c1009                1   c4288                1
    x561      c961                -1   c964                -1
    x561      c965                 1   c4288                1
    x562      c962                 1   c963                -1
    x562      c964                 1   c965                -1
    x562      c966                 1   c967                -1
    x563      c962                -1   c963                 1
    x563      c4283                1   c4284               -1
    x563      c4286               -1
    x564      c966                 1   c967                -1
    x564      c4289                1   c4290                1
    x564      c4291               -1   c4292               -1
    x564      c4293               -1   c4294               -1
    x565      c968                 1   c969                -1
    x565      c970                 1   c971                -1
    x565      c972                -1   c973                -1
    x565      c4295                1
    x566      c968                -1   c969                 1
    x566      c4289                1   c4293               -1
    x566      c4294               -1
    x567      c970                -1   c971                 1
    x567      c4290                1   c4292               -1
    x567      c4294               -1
    x568      c972                -1   c996                -1
    x568      c997                 1   c4295                1
    x569      c973                -1   c980                -1
    x569      c981                 1   c4295                1
    x570      c974                 1   c975                -1
    x570      c976                 1   c977                -1
    x570      c978                 1   c979                -1
    x570      c980                 1   c981                -1
    x570      c982                 1   c983                -1
    x571      c974                -1   c975                 1
    x571      c2275               -1   c4984                1
    x571      c4986               -1   c4987               -1
    x571      c4997               -1   c5001                1
    x571      c5003               -1   c5004               -1
    x571      c6481                1   c6482                1
    x571      c6483                1   c6484                1
    x571      c6485                1   c6486                1
    x571      c6489               -1
    x572      c976                -1   c977                 1
    x572      c2286               -1   c2289               -1
    x572      c2290               -1   c5012                1
    x572      c5015                1
    x573      c978                -1   c979                 1
    x573      c4290                1   c4291               -1
    x573      c4293               -1
    x574      c982                 1   c983                -1
    x574      c984                -1   c985                 1
    x575      c984                 1   c985                -1
    x575      c986                 1   c987                -1
    x575      c988                 1   c989                -1
    x576      c986                -1   c987                 1
    x576      c1321                1   c4409               -1
    x577      c988                -1   c989                 1
    x577      c4403               -1   c4405                1
    x577      c4406                1
    x578      c990                 1   c991                -1
    x578      c992                 1   c993                -1
    x578      c994                 1   c995                -1
    x578      c996                 1   c997                -1
    x578      c998                 1   c999                -1
    x579      c990                -1   c991                 1
    x579      c4531                1   c4533               -1
    x579      c4534               -1
    x580      c992                -1   c993                 1
    x580      c1645               -1   c4537                1
    x581      c994                -1   c995                 1
    x581      c4289                1   c4291               -1
    x581      c4292               -1
    x582      c998                 1   c999                -1
    x582      c1000               -1   c1001                1
    x583      c1000                1   c1001               -1
    x583      c1002                1   c1003               -1
    x583      c1004                1   c1005               -1
    x584      c1002               -1   c1003                1
    x584      c2489                1   c5145               -1
    x584      c5147                1   c5148                1
    x584      c5158               -1   c5162               -1
    x584      c5164                1   c5165                1
    x584      c6512               -1   c6513               -1
    x584      c6514               -1   c6515               -1
    x584      c6516               -1   c6517               -1
    x584      c6520                1
    x585      c1004               -1   c1005                1
    x585      c2500                1   c2503                1
    x585      c2504                1   c5173               -1
    x585      c5176               -1
    x586      c1006                1   c1007               -1
    x586      c1008                1   c1009               -1
    x586      c4296               -1   c4297               -1
    x586      c4298                1   c4299                1
    x586      c4300                1   c4301                1
    x587      c1006               -1   c1007                1
    x587      c4282                1   c4284               -1
    x587      c4285               -1
    x588      c1010                1   c1011               -1
    x588      c1012                1   c1013               -1
    x588      c1014                1   c1015                1
    x588      c4302               -1
    x589      c1010               -1   c1011                1
    x589      c4296               -1   c4300                1
    x589      c4301                1
    x590      c1012               -1   c1013                1
    x590      c4297               -1   c4299                1
    x590      c4301                1
    x591      c1014                1   c1030               -1
    x591      c1031                1   c4302               -1
    x592      c1015                1   c1022               -1
    x592      c1023                1   c4302               -1
    x593      c1016                1   c1017               -1
    x593      c1018                1   c1019               -1
    x593      c1020                1   c1021               -1
    x593      c1022                1   c1023               -1
    x593      c1024                1   c1025               -1
    x594      c1016               -1   c1017                1
    x594      c4467               -1   c4469                1
    x594      c4470                1
    x595      c1018               -1   c1019                1
    x595      c1483                1   c4473               -1
    x596      c1020               -1   c1021                1
    x596      c4297               -1   c4298                1
    x596      c4300                1
    x597      c1024               -1   c1025                1
    x597      c2401                1   c2402               -1
    x598      c1026                1   c1027               -1
    x598      c1028                1   c1029               -1
    x598      c1030                1   c1031               -1
    x598      c1032                1   c1033               -1
    x598      c1034                1   c1035               -1
    x599      c1026               -1   c1027                1
    x599      c4296               -1   c4298                1
    x599      c4299                1
    x600      c1028               -1   c1029                1
    x600      c1745                1   c1746               -1
    x601      c1032               -1   c1033                1
    x601      c2417                1   c5092               -1
    x601      c5094                1   c5095                1
    x601      c5105               -1   c5109               -1
    x601      c5111                1   c5112                1
    x601      c6502               -1   c6503               -1
    x601      c6504               -1   c6505               -1
    x601      c6506               -1   c6507               -1
    x601      c6510                1
    x602      c1034               -1   c1035                1
    x602      c2428                1   c2431                1
    x602      c2432                1   c5120               -1
    x602      c5123               -1
    x603      c1036                1   c1037               -1
    x603      c1038                1   c1039               -1
    x603      c1040                1   c1041                1
    x603      c4303               -1
    x604      c1036               -1   c1037                1
    x604      c4268                1   c4270               -1
    x604      c4271               -1
    x605      c1040                1   c4303               -1
    x606      c1042                1   c1043               -1
    x606      c1044                1   c1045               -1
    x606      c1046                1   c1047               -1
    x607      c1042               -1   c1043                1
    x607      c4261               -1   c4263                1
    x607      c4264                1
    x608      c1046                1   c1047               -1
    x608      c4304               -1   c4305               -1
    x608      c4306                1   c4307                1
    x608      c4308                1   c4309                1
    x609      c1048                1   c1049               -1
    x609      c1050                1   c1051               -1
    x609      c1052                1   c1053                1
    x609      c4310               -1
    x610      c1048               -1   c1049                1
    x610      c4304               -1   c4308                1
    x610      c4309                1
    x611      c1050               -1   c1051                1
    x611      c4305               -1   c4307                1
    x611      c4309                1
    x612      c1052                1   c1086               -1
    x612      c1087                1   c4310               -1
    x613      c1053                1   c1056               -1
    x613      c1057                1   c4310               -1
    x614      c1054                1   c1055               -1
    x614      c1056                1   c1057               -1
    x614      c1058                1   c1059               -1
    x615      c1054               -1   c1055                1
    x615      c4305               -1   c4306                1
    x615      c4308                1
    x616      c1058                1   c1059               -1
    x616      c4311               -1   c4312               -1
    x616      c4313                1   c4314                1
    x616      c4315                1   c4316                1
    x617      c1060                1   c1061               -1
    x617      c1062                1   c1063               -1
    x617      c1064                1   c1065                1
    x617      c4317               -1
    x618      c1060               -1   c1061                1
    x618      c4311               -1   c4315                1
    x618      c4316                1
    x619      c1062               -1   c1063                1
    x619      c4312               -1   c4314                1
    x619      c4316                1
    x620      c1064                1   c1082               -1
    x620      c1083                1   c4317               -1
    x621      c1065                1   c1076               -1
    x621      c1077                1   c4317               -1
    x622      c1066                1   c1067               -1
    x622      c1068                1   c1069               -1
    x622      c1070                1   c1071               -1
    x622      c1072                1   c1073               -1
    x622      c1074                1   c1075               -1
    x622      c1076                1   c1077               -1
    x623      c1066               -1   c1067                1
    x623      c4353               -1   c4355                1
    x623      c4356                1
    x624      c1068               -1   c1069                1
    x624      c1197                1   c4359               -1
    x625      c1070               -1   c1071                1
    x625      c3692                1   c3695                1
    x625      c3696                1   c6306               -1
    x625      c6309               -1
    x626      c1072               -1   c1073                1
    x626      c3681                1   c6278               -1
    x626      c6280                1   c6281                1
    x626      c6291               -1   c6295               -1
    x626      c6297                1   c6298                1
    x626      c6721               -1   c6722               -1
    x626      c6723               -1   c6724               -1
    x626      c6725               -1   c6726               -1
    x626      c6729                1
    x627      c1074               -1   c1075                1
    x627      c4312               -1   c4313                1
    x627      c4315                1
    x628      c1078                1   c1079               -1
    x628      c1080                1   c1081               -1
    x628      c1082                1   c1083               -1
    x629      c1078               -1   c1079                1
    x629      c1407                1   c1408               -1
    x630      c1080               -1   c1081                1
    x630      c4311               -1   c4313                1
    x630      c4314                1
    x631      c1084                1   c1085               -1
    x631      c1086                1   c1087               -1
    x631      c1088                1   c1089               -1
    x632      c1084               -1   c1085                1
    x632      c4304               -1   c4306                1
    x632      c4307                1
    x633      c1088                1   c1089               -1
    x633      c4318               -1   c4319               -1
    x633      c4320                1   c4321                1
    x633      c4322                1   c4323                1
    x634      c1090                1   c1091               -1
    x634      c1092                1   c1093               -1
    x634      c1094                1   c1095                1
    x634      c4324               -1
    x635      c1090               -1   c1091                1
    x635      c4318               -1   c4322                1
    x635      c4323                1
    x636      c1092               -1   c1093                1
    x636      c4319               -1   c4321                1
    x636      c4323                1
    x637      c1094                1   c1106               -1
    x637      c1107                1   c4324               -1
    x638      c1095                1   c1098               -1
    x638      c1099                1   c4324               -1
    x639      c1096                1   c1097               -1
    x639      c1098                1   c1099               -1
    x639      c1100                1   c1101               -1
    x640      c1096               -1   c1097                1
    x640      c1249                1   c1250               -1
    x641      c1100               -1   c1101                1
    x641      c4319               -1   c4320                1
    x641      c4322                1
    x642      c1102                1   c1103               -1
    x642      c1104                1   c1105               -1
    x642      c1106                1   c1107               -1
    x642      c1108                1   c1109               -1
    x642      c1110                1   c1111               -1
    x642      c1112                1   c1113               -1
    x643      c1102               -1   c1103                1
    x643      c1569                1   c4508               -1
    x644      c1104               -1   c1105                1
    x644      c4502               -1   c4504                1
    x644      c4505                1
    x645      c1108               -1   c1109                1
    x645      c4318               -1   c4320                1
    x645      c4321                1
    x646      c1110               -1   c1111                1
    x646      c3077                1   c3080                1
    x646      c3081                1   c5732               -1
    x646      c5735               -1
    x647      c1112               -1   c1113                1
    x647      c3066                1   c5704               -1
    x647      c5706                1   c5707                1
    x647      c5717               -1   c5721               -1
    x647      c5723                1   c5724                1
    x647      c6608               -1   c6609               -1
    x647      c6610               -1   c6611               -1
    x647      c6612               -1   c6613               -1
    x647      c6616                1
    x648      c1114                1   c1115               -1
    x648      c1116                1   c1117               -1
    x648      c1118                1   c1119               -1
    x648      c1120                1   c1121               -1
    x648      c1122               -1   c1123               -1
    x648      c1124               -1   c6411                1
    x649      c1114               -1   c1115                1
    x649      c2075               -1   c2080               -1
    x649      c2082               -1   c2085               -1
    x649      c6741                1   c6742                1
    x650      c1118               -1   c1119                1
    x650      c2580               -1   c2582               -1
    x650      c2584               -1   c5236                1
    x650      c5239                1
    x651      c1120               -1   c1121                1
    x651      c2324               -1   c2326               -1
    x651      c2328               -1   c5031                1
    x651      c5034                1
    x652      c1122               -1   c1768               -1
    x652      c1769               -1   c1770               -1
    x652      c1771               -1   c6411                1
    x652      c6739                1
    x653      c1123               -1   c1747                1
    x653      c1748               -1   c6411                1
    x654      c1124               -1   c1125               -1
    x654      c1126               -1   c1127               -1
    x654      c1128               -1   c6411                1
    x654      c6737                1
    x655      c1125               -1   c1667               -1
    x655      c1668                1   c6737                1
    x656      c1126               -1   c1489               -1
    x656      c1490                1   c6737                1
    x657      c1127               -1   c1335               -1
    x657      c1336                1   c6737                1
    x658      c1128               -1   c1147               -1
    x658      c1148                1   c6737                1
    x659      c1129                1   c1130               -1
    x659      c1131                1   c1132               -1
    x659      c1133                1   c1134               -1
    x659      c1135                1   c1136               -1
    x659      c1137                1   c1138               -1
    x659      c1139                1   c1140               -1
    x659      c1141                1   c1142               -1
    x659      c1143                1   c1144               -1
    x659      c1145                1   c1146               -1
    x659      c1147                1   c1148               -1
    x659      c4325                1   c4326                1
    x659      c4327               -1   c4328               -1
    x659      c4329               -1   c4330               -1
    x660      c1129               -1   c1130                1
    x660      c2176                1   c2179                1
    x660      c2180                1   c4889               -1
    x660      c4892               -1
    x661      c1131               -1   c1132                1
    x661      c2558                1   c2561                1
    x661      c2562                1   c5226               -1
    x661      c5229               -1
    x662      c1133               -1   c1134                1
    x662      c2820               -1   c5450                1
    x663      c1135               -1   c1136                1
    x663      c3122               -1   c5752                1
    x664      c1139               -1   c1140                1
    x664      c1767               -1   c4584                1
    x665      c1141               -1   c1142                1
    x665      c1753               -1   c6738                1
    x666      c1143               -1   c1144                1
    x666      c2302                1   c2305                1
    x666      c2306                1   c5021               -1
    x666      c5024               -1
    x667      c1145               -1   c1146                1
    x667      c1778                1   c1779               -1
    x668      c1149                1   c1150               -1
    x668      c1151                1   c1152               -1
    x668      c1153               -1   c1154               -1
    x668      c4331                1
    x669      c1149               -1   c1150                1
    x669      c4325                1   c4329               -1
    x669      c4330               -1
    x670      c1151               -1   c1152                1
    x670      c4326                1   c4328               -1
    x670      c4330               -1
    x671      c1153               -1   c1291               -1
    x671      c1292                1   c4331                1
    x672      c1154               -1   c1155               -1
    x672      c1156                1   c4331                1
    x673      c1155                1   c1156               -1
    x673      c1157                1   c1158               -1
    x673      c1159                1   c1160               -1
    x674      c1157               -1   c1158                1
    x674      c4326                1   c4327               -1
    x674      c4329               -1
    x675      c1159                1   c1160               -1
    x675      c4332                1   c4333                1
    x675      c4334               -1   c4335               -1
    x675      c4336               -1   c4337               -1
    x676      c1161                1   c1162               -1
    x676      c1163                1   c1164               -1
    x676      c1165               -1   c1166               -1
    x676      c4338                1
    x677      c1161               -1   c1162                1
    x677      c4332                1   c4336               -1
    x677      c4337               -1
    x678      c1163               -1   c1164                1
    x678      c4333                1   c4335               -1
    x678      c4337               -1
    x679      c1165               -1   c1285               -1
    x679      c1286                1   c4338                1
    x680      c1166               -1   c1167               -1
    x680      c1168                1   c4338                1
    x681      c1167                1   c1168               -1
    x681      c1169                1   c1170               -1
    x681      c4339               -1   c4340               -1
    x681      c4341                1   c4342                1
    x681      c4343                1   c4344                1
    x682      c1169               -1   c1170                1
    x682      c4333                1   c4334               -1
    x682      c4336               -1
    x683      c1171                1   c1172               -1
    x683      c1173                1   c1174               -1
    x683      c1175                1   c1176                1
    x683      c4345               -1
    x684      c1171               -1   c1172                1
    x684      c4339               -1   c4343                1
    x684      c4344                1
    x685      c1173               -1   c1174                1
    x685      c4340               -1   c4342                1
    x685      c4344                1
    x686      c1175                1   c1217               -1
    x686      c1218                1   c4345               -1
    x687      c1176                1   c1179               -1
    x687      c1180                1   c4345               -1
    x688      c1177                1   c1178               -1
    x688      c1179                1   c1180               -1
    x688      c1181                1   c1182               -1
    x688      c4346                1   c4347                1
    x688      c4348               -1   c4349               -1
    x688      c4350               -1   c4351               -1
    x689      c1177               -1   c1178                1
    x689      c4340               -1   c4341                1
    x689      c4343                1
    x690      c1181               -1   c1182                1
    x690      c1369                1   c1370               -1
    x691      c1183                1   c1184               -1
    x691      c1185                1   c1186               -1
    x691      c1187               -1   c1188               -1
    x691      c4352                1
    x692      c1183               -1   c1184                1
    x692      c4346                1   c4350               -1
    x692      c4351               -1
    x693      c1185               -1   c1186                1
    x693      c4347                1   c4349               -1
    x693      c4351               -1
    x694      c1187               -1   c1201               -1
    x694      c1202                1   c4352                1
    x695      c1188               -1   c1191               -1
    x695      c1192                1   c4352                1
    x696      c1189                1   c1190               -1
    x696      c1191                1   c1192               -1
    x696      c4353               -1   c4354               -1
    x696      c4355                1   c4356                1
    x696      c4357                1   c4358                1
    x697      c1189               -1   c1190                1
    x697      c4347                1   c4348               -1
    x697      c4350               -1
    x698      c1193                1   c1194               -1
    x698      c1195                1   c1196               -1
    x698      c1197                1   c1198                1
    x698      c4359               -1
    x699      c1193               -1   c1194                1
    x699      c4353               -1   c4357                1
    x699      c4358                1
    x700      c1195               -1   c1196                1
    x700      c4354               -1   c4356                1
    x700      c4358                1
    x701      c1199                1   c1200               -1
    x701      c1201                1   c1202               -1
    x701      c4360               -1   c4361               -1
    x701      c4362                1   c4363                1
    x701      c4364                1   c4365                1
    x702      c1199               -1   c1200                1
    x702      c4346                1   c4348               -1
    x702      c4349               -1
    x703      c1203                1   c1204               -1
    x703      c1205                1   c1206               -1
    x703      c1207                1   c1208                1
    x703      c4366               -1
    x704      c1203               -1   c1204                1
    x704      c4360               -1   c4364                1
    x704      c4365                1
    x705      c1205               -1   c1206                1
    x705      c4361               -1   c4363                1
    x705      c4365                1
    x706      c1207                1   c1211               -1
    x706      c1212                1   c4366               -1
    x707      c1209                1   c1210               -1
    x707      c1211                1   c1212               -1
    x707      c1213                1   c1214               -1
    x708      c1209               -1   c1210                1
    x708      c4360               -1   c4362                1
    x708      c4363                1
    x709      c1213               -1   c1214                1
    x709      c1858                1   c1859               -1
    x710      c1215                1   c1216               -1
    x710      c1217                1   c1218               -1
    x710      c1219                1   c1220               -1
    x710      c1221                1   c1222               -1
    x710      c4367                1   c4368                1
    x710      c4369               -1   c4370               -1
    x710      c4371               -1   c4372               -1
    x711      c1215               -1   c1216                1
    x711      c4339               -1   c4341                1
    x711      c4342                1
    x712      c1219               -1   c1220                1
    x712      c1698                1   c4558               -1
    x713      c1221               -1   c1222                1
    x713      c4553               -1   c4554                1
    x713      c4556                1
    x714      c1223                1   c1224               -1
    x714      c1225                1   c1226               -1
    x714      c1227               -1   c1228               -1
    x714      c4373                1
    x715      c1223               -1   c1224                1
    x715      c4367                1   c4371               -1
    x715      c4372               -1
    x716      c1225               -1   c1226                1
    x716      c4368                1   c4370               -1
    x716      c4372               -1
    x717      c1227               -1   c1251               -1
    x717      c1252                1   c4373                1
    x718      c1228               -1   c1229               -1
    x718      c1230                1   c4373                1
    x719      c1229                1   c1230               -1
    x719      c1231                1   c1232               -1
    x719      c1233                1   c1234               -1
    x720      c1231               -1   c1232                1
    x720      c4368                1   c4369               -1
    x720      c4371               -1
    x721      c1233                1   c1234               -1
    x721      c4374                1   c4375                1
    x721      c4376               -1   c4377               -1
    x721      c4378               -1   c4379               -1
    x722      c1235                1   c1236               -1
    x722      c1237                1   c1238               -1
    x722      c1239               -1   c1240               -1
    x722      c4380                1
    x723      c1235               -1   c1236                1
    x723      c4374                1   c4378               -1
    x723      c4379               -1
    x724      c1237               -1   c1238                1
    x724      c4375                1   c4377               -1
    x724      c4379               -1
    x725      c1239               -1   c1241               -1
    x725      c1242                1   c4380                1
    x726      c1241                1   c1242               -1
    x726      c1243                1   c1244               -1
    x726      c1245                1   c1246               -1
    x726      c1247                1   c1248               -1
    x726      c1249                1   c1250               -1
    x727      c1243               -1   c1244                1
    x727      c4374                1   c4376               -1
    x727      c4377               -1
    x728      c1245               -1   c1246                1
    x728      c3278               -1   c5908                1
    x728      c5910               -1   c5911               -1
    x728      c5921               -1   c5925                1
    x728      c5927               -1   c5928               -1
    x728      c6649                1   c6650                1
    x728      c6651                1   c6652                1
    x728      c6653                1   c6654                1
    x728      c6657               -1
    x729      c1247               -1   c1248                1
    x729      c3289               -1   c3292               -1
    x729      c3293               -1   c5936                1
    x729      c5939                1
    x730      c1251                1   c1252               -1
    x730      c1253                1   c1254               -1
    x730      c1255                1   c1256               -1
    x731      c1253               -1   c1254                1
    x731      c4367                1   c4369               -1
    x731      c4370               -1
    x732      c1255                1   c1256               -1
    x732      c4381                1   c4382                1
    x732      c4383               -1   c4384               -1
    x732      c4385               -1   c4386               -1
    x733      c1257                1   c1258               -1
    x733      c1259                1   c1260               -1
    x733      c1261               -1   c1262               -1
    x733      c4387                1
    x734      c1257               -1   c1258                1
    x734      c4381                1   c4385               -1
    x734      c4386               -1
    x735      c1259               -1   c1260                1
    x735      c4382                1   c4384               -1
    x735      c4386               -1
    x736      c1261               -1   c1271               -1
    x736      c1272                1   c4387                1
    x737      c1262               -1   c1265               -1
    x737      c1266                1   c4387                1
    x738      c1263                1   c1264               -1
    x738      c1265                1   c1266               -1
    x738      c1267                1   c1268               -1
    x739      c1263               -1   c1264                1
    x739      c4382                1   c4383               -1
    x739      c4385               -1
    x740      c1269                1   c1270               -1
    x740      c1271                1   c1272               -1
    x740      c1273                1   c1274               -1
    x740      c1275                1   c1276               -1
    x740      c1277                1   c1278               -1
    x741      c1269               -1   c1270                1
    x741      c4381                1   c4383               -1
    x741      c4384               -1
    x742      c1273               -1   c1274                1
    x742      c3375               -1   c3378               -1
    x742      c3379               -1   c5996                1
    x742      c5999                1
    x743      c1275               -1   c1276                1
    x743      c3364               -1   c5968                1
    x743      c5970               -1   c5971               -1
    x743      c5981               -1   c5985                1
    x743      c5987               -1   c5988               -1
    x743      c6660                1   c6661                1
    x743      c6662                1   c6663                1
    x743      c6664                1   c6665                1
    x743      c6668               -1
    x744      c1277                1   c1278               -1
    x744      c1279               -1   c1280                1
    x745      c1279                1   c1280               -1
    x745      c1281                1   c1282               -1
    x745      c1283                1   c1284               -1
    x746      c1281               -1   c1282                1
    x746      c4622               -1   c4623                1
    x746      c4625                1
    x747      c1283               -1   c1284                1
    x747      c1869                1   c4627               -1
    x748      c1285                1   c1286               -1
    x748      c1287                1   c1288               -1
    x748      c1289                1   c1290                1
    x748      c4388               -1
    x749      c1287               -1   c1288                1
    x749      c4332                1   c4334               -1
    x749      c4335               -1
    x750      c1289                1   c4388               -1
    x751      c1291                1   c1292               -1
    x751      c1293                1   c1294               -1
    x751      c4389               -1   c4390               -1
    x751      c4391                1   c4392                1
    x751      c4393                1   c4394                1
    x752      c1293               -1   c1294                1
    x752      c4325                1   c4327               -1
    x752      c4328               -1
    x753      c1295                1   c1296               -1
    x753      c1297                1   c1298               -1
    x753      c1299                1   c1300                1
    x753      c4395               -1
    x754      c1295               -1   c1296                1
    x754      c4389               -1   c4393                1
    x754      c4394                1
    x755      c1297               -1   c1298                1
    x755      c4390               -1   c4392                1
    x755      c4394                1
    x756      c1299                1   c1313               -1
    x756      c1314                1   c4395               -1
    x757      c1300                1   c1303               -1
    x757      c1304                1   c4395               -1
    x758      c1301                1   c1302               -1
    x758      c1303                1   c1304               -1
    x758      c4396                1   c4397                1
    x758      c4398               -1   c4399               -1
    x758      c4400               -1   c4401               -1
    x759      c1301               -1   c1302                1
    x759      c4390               -1   c4391                1
    x759      c4393                1
    x760      c1305                1   c1306               -1
    x760      c1307                1   c1308               -1
    x760      c1309               -1   c1310               -1
    x760      c4402                1
    x761      c1305               -1   c1306                1
    x761      c4396                1   c4400               -1
    x761      c4401               -1
    x762      c1307               -1   c1308                1
    x762      c4397                1   c4399               -1
    x762      c4401               -1
    x763      c1311                1   c1312               -1
    x763      c1313                1   c1314               -1
    x763      c1315                1   c1316               -1
    x764      c1311               -1   c1312                1
    x764      c4389               -1   c4391                1
    x764      c4392                1
    x765      c1315                1   c1316               -1
    x765      c4403               -1   c4404               -1
    x765      c4405                1   c4406                1
    x765      c4407                1   c4408                1
    x766      c1317                1   c1318               -1
    x766      c1319                1   c1320               -1
    x766      c1321                1   c1322                1
    x766      c4409               -1
    x767      c1317               -1   c1318                1
    x767      c4403               -1   c4407                1
    x767      c4408                1
    x768      c1319               -1   c1320                1
    x768      c4404               -1   c4406                1
    x768      c4408                1
    x769      c1323                1   c1324               -1
    x769      c1325                1   c1326               -1
    x769      c1327                1   c1328               -1
    x769      c1329                1   c1330               -1
    x769      c1331                1   c1332               -1
    x769      c1333                1   c1334               -1
    x769      c1335                1   c1336               -1
    x769      c1337                1   c1338               -1
    x769      c4410                1   c4411                1
    x769      c4412               -1   c4413               -1
    x769      c4414               -1   c4415               -1
    x770      c1323               -1   c1324                1
    x770      c2048                1   c2051                1
    x770      c2052                1   c4813               -1
    x770      c4816               -1
    x771      c1325               -1   c1326                1
    x771      c2810                1   c2812                1
    x771      c2818                1   c6747               -1
    x771      c6748               -1
    x772      c1327               -1   c1328                1
    x772      c1764                1   c1765               -1
    x773      c1329               -1   c1330                1
    x773      c3551                1   c3553                1
    x773      c3559                1   c6758               -1
    x773      c6759               -1
    x774      c1331               -1   c1332                1
    x774      c2006                1   c2009                1
    x774      c2010                1   c4760               -1
    x774      c4763               -1
    x775      c1333               -1   c1334                1
    x775      c1770               -1   c6739                1
    x776      c1337               -1   c1338                1
    x776      c2391                1   c2394                1
    x776      c2395                1   c5083               -1
    x776      c5086               -1
    x777      c1339                1   c1340               -1
    x777      c1341                1   c1342               -1
    x777      c1343               -1   c1344               -1
    x777      c4416                1
    x778      c1339               -1   c1340                1
    x778      c4410                1   c4414               -1
    x778      c4415               -1
    x779      c1341               -1   c1342                1
    x779      c4411                1   c4413               -1
    x779      c4415               -1
    x780      c1343               -1   c1451               -1
    x780      c1452                1   c4416                1
    x781      c1344               -1   c1345               -1
    x781      c1346                1   c4416                1
    x782      c1345                1   c1346               -1
    x782      c1347                1   c1348               -1
    x782      c4417               -1   c4418               -1
    x782      c4419                1   c4420                1
    x782      c4421                1   c4422                1
    x783      c1347               -1   c1348                1
    x783      c4411                1   c4412               -1
    x783      c4414               -1
    x784      c1349                1   c1350               -1
    x784      c1351                1   c1352               -1
    x784      c1353                1   c1354                1
    x784      c4423               -1
    x785      c1349               -1   c1350                1
    x785      c4417               -1   c4421                1
    x785      c4422                1
    x786      c1351               -1   c1352                1
    x786      c4418               -1   c4420                1
    x786      c4422                1
    x787      c1353                1   c1443               -1
    x787      c1444                1   c4423               -1
    x788      c1354                1   c1355               -1
    x788      c1356                1   c4423               -1
    x789      c1355                1   c1356               -1
    x789      c1357                1   c1358               -1
    x789      c4424                1   c4425                1
    x789      c4426               -1   c4427               -1
    x789      c4428               -1   c4429               -1
    x790      c1357               -1   c1358                1
    x790      c4418               -1   c4419                1
    x790      c4421                1
    x791      c1359                1   c1360               -1
    x791      c1361                1   c1362               -1
    x791      c1363               -1   c1364               -1
    x791      c4430                1
    x792      c1359               -1   c1360                1
    x792      c4424                1   c4428               -1
    x792      c4429               -1
    x793      c1361               -1   c1362                1
    x793      c4425                1   c4427               -1
    x793      c4429               -1
    x794      c1363               -1   c1371               -1
    x794      c1372                1   c4430                1
    x795      c1364               -1   c1365               -1
    x795      c1366                1   c4430                1
    x796      c1365                1   c1366               -1
    x796      c1367                1   c1368               -1
    x796      c1369                1   c1370               -1
    x797      c1367               -1   c1368                1
    x797      c4425                1   c4426               -1
    x797      c4428               -1
    x798      c1371                1   c1372               -1
    x798      c1373                1   c1374               -1
    x798      c1375                1   c1376               -1
    x798      c4431               -1   c4432               -1
    x798      c4433                1   c4434                1
    x798      c4435                1   c4436                1
    x799      c1373               -1   c1374                1
    x799      c4424                1   c4426               -1
    x799      c4427               -1
    x800      c1375               -1   c1376                1
    x800      c1545                1   c1546               -1
    x801      c1377                1   c1378               -1
    x801      c1379                1   c1380               -1
    x801      c1381                1   c1382                1
    x801      c4437               -1
    x802      c1377               -1   c1378                1
    x802      c4431               -1   c4435                1
    x802      c4436                1
    x803      c1379               -1   c1380                1
    x803      c4432               -1   c4434                1
    x803      c4436                1
    x804      c1381                1   c1409               -1
    x804      c1410                1   c4437               -1
    x805      c1382                1   c1383               -1
    x805      c1384                1   c4437               -1
    x806      c1383                1   c1384               -1
    x806      c1385                1   c1386               -1
    x806      c4438                1   c4439                1
    x806      c4440               -1   c4441               -1
    x806      c4442               -1   c4443               -1
    x807      c1385               -1   c1386                1
    x807      c4432               -1   c4433                1
    x807      c4435                1
    x808      c1387                1   c1388               -1
    x808      c1389                1   c1390               -1
    x808      c1391               -1   c1392               -1
    x808      c4444                1
    x809      c1387               -1   c1388                1
    x809      c4438                1   c4442               -1
    x809      c4443               -1
    x810      c1389               -1   c1390                1
    x810      c4439                1   c4441               -1
    x810      c4443               -1
    x811      c1391               -1   c1399               -1
    x811      c1400                1   c4444                1
    x812      c1392               -1   c1393               -1
    x812      c1394                1   c4444                1
    x813      c1393                1   c1394               -1
    x813      c1395                1   c1396               -1
    x813      c1397                1   c1398               -1
    x814      c1395               -1   c1396                1
    x814      c4439                1   c4440               -1
    x814      c4442               -1
    x815      c1399                1   c1400               -1
    x815      c1401                1   c1402               -1
    x815      c1403                1   c1404               -1
    x815      c1405                1   c1406               -1
    x815      c1407                1   c1408               -1
    x816      c1401               -1   c1402                1
    x816      c4438                1   c4440               -1
    x816      c4441               -1
    x817      c1403               -1   c1404                1
    x817      c2915               -1   c5556                1
    x817      c5558               -1   c5559               -1
    x817      c5569               -1   c5573                1
    x817      c5575               -1   c5576               -1
    x817      c6577                1   c6578                1
    x817      c6579                1   c6580                1
    x817      c6581                1   c6582                1
    x817      c6585               -1
    x818      c1405               -1   c1406                1
    x818      c2926               -1   c2929               -1
    x818      c2930               -1   c5584                1
    x818      c5587                1
    x819      c1409                1   c1410               -1
    x819      c1411                1   c1412               -1
    x819      c4445                1   c4446                1
    x819      c4447               -1   c4448               -1
    x819      c4449               -1   c4450               -1
    x820      c1411               -1   c1412                1
    x820      c4431               -1   c4433                1
    x820      c4434                1
    x821      c1413                1   c1414               -1
    x821      c1415                1   c1416               -1
    x821      c1417               -1   c1418               -1
    x821      c4451                1
    x822      c1413               -1   c1414                1
    x822      c4445                1   c4449               -1
    x822      c4450               -1
    x823      c1415               -1   c1416                1
    x823      c4446                1   c4448               -1
    x823      c4450               -1
    x824      c1417               -1   c1435               -1
    x824      c1436                1   c4451                1
    x825      c1418               -1   c1421               -1
    x825      c1422                1   c4451                1
    x826      c1419                1   c1420               -1
    x826      c1421                1   c1422               -1
    x826      c1423                1   c1424               -1
    x826      c1425                1   c1426               -1
    x826      c1427                1   c1428               -1
    x827      c1419               -1   c1420                1
    x827      c4446                1   c4447               -1
    x827      c4449               -1
    x828      c1423               -1   c1424                1
    x828      c3030               -1   c3033               -1
    x828      c3034               -1   c5680                1
    x828      c5683                1
    x829      c1425               -1   c1426                1
    x829      c3019               -1   c5652                1
    x829      c5654               -1   c5655               -1
    x829      c5665               -1   c5669                1
    x829      c5671               -1   c5672               -1
    x829      c6598                1   c6599                1
    x829      c6600                1   c6601                1
    x829      c6602                1   c6603                1
    x829      c6606               -1
    x830      c1429                1   c1430               -1
    x830      c1431                1   c1432               -1
    x830      c1433                1   c1434               -1
    x830      c1435                1   c1436               -1
    x830      c1437                1   c1438               -1
    x830      c1439                1   c1440               -1
    x830      c1441                1   c1442               -1
    x831      c1429               -1   c1430                1
    x831      c2988               -1   c2991               -1
    x831      c2992               -1   c5636                1
    x831      c5639                1
    x832      c1431               -1   c1432                1
    x832      c2977               -1   c5608                1
    x832      c5610               -1   c5611               -1
    x832      c5621               -1   c5625                1
    x832      c5627               -1   c5628               -1
    x832      c6588                1   c6589                1
    x832      c6590                1   c6591                1
    x832      c6592                1   c6593                1
    x832      c6596               -1
    x833      c1433               -1   c1434                1
    x833      c4445                1   c4447               -1
    x833      c4448               -1
    x834      c1437               -1   c1438                1
    x834      c4614                1   c4616               -1
    x834      c4617               -1
    x835      c1439               -1   c1440                1
    x835      c1848               -1   c4620                1
    x836      c1441                1   c1442               -1
    x837      c1443                1   c1444               -1
    x837      c1445                1   c1446               -1
    x837      c1447                1   c1448               -1
    x838      c1445               -1   c1446                1
    x838      c4417               -1   c4419                1
    x838      c4420                1
    x839      c1447                1   c1448               -1
    x839      c1449                1   c1450                1
    x839      c4452               -1
    x840      c1449                1   c4452               -1
    x841      c1451                1   c1452               -1
    x841      c1453                1   c1454               -1
    x841      c4453               -1   c4454               -1
    x841      c4455                1   c4456                1
    x841      c4457                1   c4458                1
    x842      c1453               -1   c1454                1
    x842      c4410                1   c4412               -1
    x842      c4413               -1
    x843      c1455                1   c1456               -1
    x843      c1457                1   c1458               -1
    x843      c1459                1   c1460                1
    x843      c4459               -1
    x844      c1455               -1   c1456                1
    x844      c4453               -1   c4457                1
    x844      c4458                1
    x845      c1457               -1   c1458                1
    x845      c4454               -1   c4456                1
    x845      c4458                1
    x846      c1459                1   c1475               -1
    x846      c1476                1   c4459               -1
    x847      c1460                1   c1463               -1
    x847      c1464                1   c4459               -1
    x848      c1461                1   c1462               -1
    x848      c1463                1   c1464               -1
    x848      c1465                1   c1466               -1
    x849      c1461               -1   c1462                1
    x849      c4454               -1   c4455                1
    x849      c4457                1
    x850      c1465                1   c1466               -1
    x850      c4460               -1   c4461               -1
    x850      c4462                1   c4463                1
    x850      c4464                1   c4465                1
    x851      c1467                1   c1468               -1
    x851      c1469                1   c1470               -1
    x851      c1471                1   c1472                1
    x851      c4466               -1
    x852      c1467               -1   c1468                1
    x852      c4460               -1   c4464                1
    x852      c4465                1
    x853      c1469               -1   c1470                1
    x853      c4461               -1   c4463                1
    x853      c4465                1
    x854      c1473                1   c1474               -1
    x854      c1475                1   c1476               -1
    x854      c1477                1   c1478               -1
    x855      c1473               -1   c1474                1
    x855      c4453               -1   c4455                1
    x855      c4456                1
    x856      c1477                1   c1478               -1
    x856      c4467               -1   c4468               -1
    x856      c4469                1   c4470                1
    x856      c4471                1   c4472                1
    x857      c1479                1   c1480               -1
    x857      c1481                1   c1482               -1
    x857      c1483                1   c1484                1
    x857      c4473               -1
    x858      c1479               -1   c1480                1
    x858      c4467               -1   c4471                1
    x858      c4472                1
    x859      c1481               -1   c1482                1
    x859      c4468               -1   c4470                1
    x859      c4472                1
    x860      c1485                1   c1486               -1
    x860      c1487                1   c1488               -1
    x860      c1489                1   c1490               -1
    x860      c1491                1   c1492               -1
    x860      c1493                1   c1494               -1
    x861      c1485               -1   c1486                1
    x861      c2819               -1   c5450                1
    x862      c1487               -1   c1488                1
    x862      c3121               -1   c5752                1
    x863      c1491               -1   c1492                1
    x863      c2516               -1   c2519               -1
    x863      c2520               -1   c5182                1
    x863      c5185                1
    x864      c1493                1   c1494               -1
    x864      c1511               -1   c1512                1
    x865      c1495                1   c1496               -1
    x865      c1497                1   c1498               -1
    x865      c1499                1   c1500               -1
    x865      c1501                1   c1502               -1
    x865      c1503                1   c1504               -1
    x865      c1505                1   c1506               -1
    x865      c1507                1   c1508               -1
    x865      c1509                1   c1510               -1
    x865      c1511                1   c1512               -1
    x865      c4474                1   c4475                1
    x865      c4476               -1   c4477               -1
    x865      c4478               -1   c4479               -1
    x866      c1495               -1   c1496                1
    x866      c2218                1   c2221                1
    x866      c2222                1   c4933               -1
    x866      c4936               -1
    x867      c1497               -1   c1498                1
    x867      c2744                1   c2747                1
    x867      c2748                1   c5387               -1
    x867      c5390               -1
    x868      c1499               -1   c1500                1
    x868      c1766               -1   c4584                1
    x869      c1501               -1   c1502                1
    x869      c1751               -1   c6738                1
    x870      c1503               -1   c1504                1
    x870      c1922                1   c1925                1
    x870      c1926                1   c4672               -1
    x870      c4675               -1
    x871      c1505               -1   c1506                1
    x871      c3560               -1   c6171                1
    x872      c1507               -1   c1508                1
    x872      c3353               -1   c5964                1
    x873      c1509               -1   c1510                1
    x873      c1769               -1   c6739                1
    x874      c1513                1   c1514               -1
    x874      c1515                1   c1516               -1
    x874      c1517               -1   c1518               -1
    x874      c4480                1
    x875      c1513               -1   c1514                1
    x875      c4474                1   c4478               -1
    x875      c4479               -1
    x876      c1515               -1   c1516                1
    x876      c4475                1   c4477               -1
    x876      c4479               -1
    x877      c1517               -1   c1615               -1
    x877      c1616                1   c4480                1
    x878      c1518               -1   c1519               -1
    x878      c1520                1   c4480                1
    x879      c1519                1   c1520               -1
    x879      c1521                1   c1522               -1
    x879      c1523                1   c1524               -1
    x880      c1521               -1   c1522                1
    x880      c4475                1   c4476               -1
    x880      c4478               -1
    x881      c1523                1   c1524               -1
    x881      c4481                1   c4482                1
    x881      c4483               -1   c4484               -1
    x881      c4485               -1   c4486               -1
    x882      c1525                1   c1526               -1
    x882      c1527                1   c1528               -1
    x882      c1529               -1   c1530               -1
    x882      c4487                1
    x883      c1525               -1   c1526                1
    x883      c4481                1   c4485               -1
    x883      c4486               -1
    x884      c1527               -1   c1528                1
    x884      c4482                1   c4484               -1
    x884      c4486               -1
    x885      c1529               -1   c1609               -1
    x885      c1610                1   c4487                1
    x886      c1530               -1   c1531               -1
    x886      c1532                1   c4487                1
    x887      c1531                1   c1532               -1
    x887      c1533                1   c1534               -1
    x887      c4488               -1   c4489               -1
    x887      c4490                1   c4491                1
    x887      c4492                1   c4493                1
    x888      c1533               -1   c1534                1
    x888      c4482                1   c4483               -1
    x888      c4485               -1
    x889      c1535                1   c1536               -1
    x889      c1537                1   c1538               -1
    x889      c1539                1   c1540                1
    x889      c4494               -1
    x890      c1535               -1   c1536                1
    x890      c4488               -1   c4492                1
    x890      c4493                1
    x891      c1537               -1   c1538                1
    x891      c4489               -1   c4491                1
    x891      c4493                1
    x892      c1539                1   c1547               -1
    x892      c1548                1   c4494               -1
    x893      c1540                1   c1541               -1
    x893      c1542                1   c4494               -1
    x894      c1541                1   c1542               -1
    x894      c1543                1   c1544               -1
    x894      c1545                1   c1546               -1
    x895      c1543               -1   c1544                1
    x895      c4489               -1   c4490                1
    x895      c4492                1
    x896      c1547                1   c1548               -1
    x896      c1549                1   c1550               -1
    x896      c1551                1   c1552               -1
    x896      c1553                1   c1554               -1
    x896      c4495                1   c4496                1
    x896      c4497               -1   c4498               -1
    x896      c4499               -1   c4500               -1
    x897      c1549               -1   c1550                1
    x897      c4488               -1   c4490                1
    x897      c4491                1
    x898      c1551               -1   c1552                1
    x898      c1697                1   c4558               -1
    x899      c1553               -1   c1554                1
    x899      c4552               -1   c4554                1
    x899      c4555                1
    x900      c1555                1   c1556               -1
    x900      c1557                1   c1558               -1
    x900      c1559               -1   c1560               -1
    x900      c4501                1
    x901      c1555               -1   c1556                1
    x901      c4495                1   c4499               -1
    x901      c4500               -1
    x902      c1557               -1   c1558                1
    x902      c4496                1   c4498               -1
    x902      c4500               -1
    x903      c1559               -1   c1573               -1
    x903      c1574                1   c4501                1
    x904      c1560               -1   c1563               -1
    x904      c1564                1   c4501                1
    x905      c1561                1   c1562               -1
    x905      c1563                1   c1564               -1
    x905      c4502               -1   c4503               -1
    x905      c4504                1   c4505                1
    x905      c4506                1   c4507                1
    x906      c1561               -1   c1562                1
    x906      c4496                1   c4497               -1
    x906      c4499               -1
    x907      c1565                1   c1566               -1
    x907      c1567                1   c1568               -1
    x907      c1569                1   c1570                1
    x907      c4508               -1
    x908      c1565               -1   c1566                1
    x908      c4502               -1   c4506                1
    x908      c4507                1
    x909      c1567               -1   c1568                1
    x909      c4503               -1   c4505                1
    x909      c4507                1
    x910      c1571                1   c1572               -1
    x910      c1573                1   c1574               -1
    x910      c1575                1   c1576               -1
    x911      c1571               -1   c1572                1
    x911      c4495                1   c4497               -1
    x911      c4498               -1
    x912      c1575                1   c1576               -1
    x912      c4509                1   c4510                1
    x912      c4511               -1   c4512               -1
    x912      c4513               -1   c4514               -1
    x913      c1577                1   c1578               -1
    x913      c1579                1   c1580               -1
    x913      c1581               -1   c1582               -1
    x913      c4515                1
    x914      c1577               -1   c1578                1
    x914      c4509                1   c4513               -1
    x914      c4514               -1
    x915      c1579               -1   c1580                1
    x915      c4510                1   c4512               -1
    x915      c4514               -1
    x916      c1581               -1   c1599               -1
    x916      c1600                1   c4515                1
    x917      c1582               -1   c1585               -1
    x917      c1586                1   c4515                1
    x918      c1583                1   c1584               -1
    x918      c1585                1   c1586               -1
    x918      c1587                1   c1588               -1
    x918      c1589                1   c1590               -1
    x918      c1591                1   c1592               -1
    x919      c1583               -1   c1584                1
    x919      c4510                1   c4511               -1
    x919      c4513               -1
    x920      c1587               -1   c1588                1
    x920      c3247               -1   c3250               -1
    x920      c3251               -1   c5886                1
    x920      c5889                1
    x921      c1589               -1   c1590                1
    x921      c3236               -1   c5858                1
    x921      c5860               -1   c5861               -1
    x921      c5871               -1   c5875                1
    x921      c5877               -1   c5878               -1
    x921      c6639                1   c6640                1
    x921      c6641                1   c6642                1
    x921      c6643                1   c6644                1
    x921      c6647               -1
    x922      c1593                1   c1594               -1
    x922      c1595                1   c1596               -1
    x922      c1597                1   c1598               -1
    x922      c1599                1   c1600               -1
    x922      c1601                1   c1602               -1
    x923      c1593               -1   c1594                1
    x923      c3205               -1   c3208               -1
    x923      c3209               -1   c5842                1
    x923      c5845                1
    x924      c1595               -1   c1596                1
    x924      c3194               -1   c5814                1
    x924      c5816               -1   c5817               -1
    x924      c5827               -1   c5831                1
    x924      c5833               -1   c5834               -1
    x924      c6629                1   c6630                1
    x924      c6631                1   c6632                1
    x924      c6633                1   c6634                1
    x924      c6637               -1
    x925      c1597               -1   c1598                1
    x925      c4509                1   c4511               -1
    x925      c4512               -1
    x926      c1601                1   c1602               -1
    x926      c1607               -1   c1608                1
    x927      c1603                1   c1604               -1
    x927      c1605                1   c1606               -1
    x927      c1607                1   c1608               -1
    x928      c1603               -1   c1604                1
    x928      c4621               -1   c4623                1
    x928      c4624                1
    x929      c1605               -1   c1606                1
    x929      c1868                1   c4627               -1
    x930      c1609                1   c1610               -1
    x930      c1611                1   c1612               -1
    x930      c1613                1   c1614                1
    x930      c4516               -1
    x931      c1611               -1   c1612                1
    x931      c4481                1   c4483               -1
    x931      c4484               -1
    x932      c1613                1   c4516               -1
    x933      c1615                1   c1616               -1
    x933      c1617                1   c1618               -1
    x933      c4517               -1   c4518               -1
    x933      c4519                1   c4520                1
    x933      c4521                1   c4522                1
    x934      c1617               -1   c1618                1
    x934      c4474                1   c4476               -1
    x934      c4477               -1
    x935      c1619                1   c1620               -1
    x935      c1621                1   c1622               -1
    x935      c1623                1   c1624                1
    x935      c4523               -1
    x936      c1619               -1   c1620                1
    x936      c4517               -1   c4521                1
    x936      c4522                1
    x937      c1621               -1   c1622                1
    x937      c4518               -1   c4520                1
    x937      c4522                1
    x938      c1623                1   c1637               -1
    x938      c1638                1   c4523               -1
    x939      c1624                1   c1625               -1
    x939      c1626                1   c4523               -1
    x940      c1625                1   c1626               -1
    x940      c1627                1   c1628               -1
    x940      c1629                1   c1630               -1
    x941      c1627               -1   c1628                1
    x941      c4518               -1   c4519                1
    x941      c4521                1
    x942      c1629                1   c1630               -1
    x942      c4524               -1   c4525               -1
    x942      c4526                1   c4527                1
    x942      c4528                1   c4529                1
    x943      c1631                1   c1632               -1
    x943      c1633                1   c1634               -1
    x943      c1635                1   c1636                1
    x943      c4530               -1
    x944      c1631               -1   c1632                1
    x944      c4524               -1   c4528                1
    x944      c4529                1
    x945      c1633               -1   c1634                1
    x945      c4525               -1   c4527                1
    x945      c4529                1
    x946      c1637                1   c1638               -1
    x946      c1639                1   c1640               -1
    x946      c4531                1   c4532                1
    x946      c4533               -1   c4534               -1
    x946      c4535               -1   c4536               -1
    x947      c1639               -1   c1640                1
    x947      c4517               -1   c4519                1
    x947      c4520                1
    x948      c1641                1   c1642               -1
    x948      c1643                1   c1644               -1
    x948      c1645               -1   c1646               -1
    x948      c4537                1
    x949      c1641               -1   c1642                1
    x949      c4531                1   c4535               -1
    x949      c4536               -1
    x950      c1643               -1   c1644                1
    x950      c4532                1   c4534               -1
    x950      c4536               -1
    x951      c1646               -1   c1649               -1
    x951      c1650                1   c4537                1
    x952      c1647                1   c1648               -1
    x952      c1649                1   c1650               -1
    x952      c1651                1   c1652               -1
    x953      c1647               -1   c1648                1
    x953      c4532                1   c4533               -1
    x953      c4535               -1
    x954      c1653                1   c1654               -1
    x954      c1655                1   c1656               -1
    x954      c1657                1   c1658               -1
    x954      c1659                1   c1660               -1
    x954      c1661                1   c1662               -1
    x954      c1663                1   c1664               -1
    x954      c1665                1   c1666               -1
    x954      c1667                1   c1668               -1
    x954      c1669                1   c1670               -1
    x954      c4538                1   c4539                1
    x954      c4540               -1   c4541               -1
    x954      c4542               -1   c4543               -1
    x955      c1653               -1   c1654                1
    x955      c2260                1   c2263                1
    x955      c2264                1   c4977               -1
    x955      c4980               -1
    x956      c1655               -1   c1656                1
    x956      c3109                1   c3116                1
    x956      c3117                1   c6754               -1
    x956      c6755               -1
    x957      c1657               -1   c1658                1
    x957      c3341                1   c3348                1
    x957      c3349                1   c6756               -1
    x957      c6757               -1
    x958      c1659               -1   c1660                1
    x958      c4581                1   c6412               -1
    x959      c1661               -1   c1662                1
    x959      c1750               -1   c6738                1
    x960      c1663               -1   c1664                1
    x960      c1964                1   c1967                1
    x960      c1968                1   c4716               -1
    x960      c4719               -1
    x961      c1665               -1   c1666                1
    x961      c1768               -1   c6739                1
    x962      c1669               -1   c1670                1
    x962      c2473                1   c2474               -1
    x963      c1671                1   c1672               -1
    x963      c1673                1   c1674               -1
    x963      c1675               -1   c1676               -1
    x963      c4544                1
    x964      c1671               -1   c1672                1
    x964      c4538                1   c4542               -1
    x964      c4543               -1
    x965      c1673               -1   c1674                1
    x965      c4539                1   c4541               -1
    x965      c4543               -1
    x966      c1675               -1   c1709               -1
    x966      c1710                1   c4544                1
    x967      c1676               -1   c1677               -1
    x967      c1678                1   c4544                1
    x968      c1677                1   c1678               -1
    x968      c1679                1   c1680               -1
    x968      c1681                1   c1682               -1
    x969      c1679               -1   c1680                1
    x969      c4539                1   c4540               -1
    x969      c4542               -1
    x970      c1681                1   c1682               -1
    x970      c4545                1   c4546                1
    x970      c4547               -1   c4548               -1
    x970      c4549               -1   c4550               -1
    x971      c1683                1   c1684               -1
    x971      c1685                1   c1686               -1
    x971      c1687               -1   c1688               -1
    x971      c4551                1
    x972      c1683               -1   c1684                1
    x972      c4545                1   c4549               -1
    x972      c4550               -1
    x973      c1685               -1   c1686                1
    x973      c4546                1   c4548               -1
    x973      c4550               -1
    x974      c1687               -1   c1699                1
    x974      c1700               -1   c4551                1
    x975      c1688               -1   c1691               -1
    x975      c1692                1   c4551                1
    x976      c1689                1   c1690               -1
    x976      c1691                1   c1692               -1
    x976      c4552               -1   c4553               -1
    x976      c4554                1   c4555                1
    x976      c4556                1   c4557                1
    x977      c1689               -1   c1690                1
    x977      c4546                1   c4547               -1
    x977      c4549               -1
    x978      c1693                1   c1694               -1
    x978      c1695                1   c1696               -1
    x978      c1697                1   c1698                1
    x978      c4558               -1
    x979      c1693               -1   c1694                1
    x979      c4552               -1   c4556                1
    x979      c4557                1
    x980      c1695               -1   c1696                1
    x980      c4553               -1   c4555                1
    x980      c4557                1
    x981      c1699                1   c1700               -1
    x981      c1701                1   c1702               -1
    x982      c1701                1   c1702               -1
    x982      c1705               -1   c1706                1
    x983      c1703                1   c1704               -1
    x983      c1705                1   c1706               -1
    x983      c1707                1   c1708                1
    x983      c4559               -1
    x984      c1703               -1   c1704                1
    x984      c4545                1   c4547               -1
    x984      c4548               -1
    x985      c1707                1   c4559               -1
    x986      c1709                1   c1710               -1
    x986      c1711                1   c1712               -1
    x986      c4560               -1   c4561               -1
    x986      c4562                1   c4563                1
    x986      c4564                1   c4565                1
    x987      c1711               -1   c1712                1
    x987      c4538                1   c4540               -1
    x987      c4541               -1
    x988      c1713                1   c1714               -1
    x988      c1715                1   c1716               -1
    x988      c1717                1   c1718                1
    x988      c4566               -1
    x989      c1713               -1   c1714                1
    x989      c4560               -1   c4564                1
    x989      c4565                1
    x990      c1715               -1   c1716                1
    x990      c4561               -1   c4563                1
    x990      c4565                1
    x991      c1717                1   c1733               -1
    x991      c1734                1   c4566               -1
    x992      c1718                1   c1721               -1
    x992      c1722                1   c4566               -1
    x993      c1719                1   c1720               -1
    x993      c1721                1   c1722               -1
    x993      c1723                1   c1724               -1
    x994      c1719               -1   c1720                1
    x994      c4561               -1   c4562                1
    x994      c4564                1
    x995      c1723                1   c1724               -1
    x995      c4567               -1   c4568               -1
    x995      c4569                1   c4570                1
    x995      c4571                1   c4572                1
    x996      c1725                1   c1726               -1
    x996      c1727                1   c1728               -1
    x996      c1729                1   c1730                1
    x996      c4573               -1
    x997      c1725               -1   c1726                1
    x997      c4567               -1   c4571                1
    x997      c4572                1
    x998      c1727               -1   c1728                1
    x998      c4568               -1   c4570                1
    x998      c4572                1
    x999      c1731                1   c1732               -1
    x999      c1733                1   c1734               -1
    x999      c4574                1   c4575                1
    x999      c4576               -1   c4577               -1
    x999      c4578               -1   c4579               -1
    x1000     c1731               -1   c1732                1
    x1000     c4560               -1   c4562                1
    x1000     c4563                1
    x1001     c1735                1   c1736               -1
    x1001     c1737                1   c1738               -1
    x1001     c1739               -1   c1740               -1
    x1001     c4580                1
    x1002     c1735               -1   c1736                1
    x1002     c4574                1   c4578               -1
    x1002     c4579               -1
    x1003     c1737               -1   c1738                1
    x1003     c4575                1   c4577               -1
    x1003     c4579               -1
    x1004     c1739               -1   c1743               -1
    x1004     c1744                1   c4580                1
    x1005     c1741                1   c1742               -1
    x1005     c1743                1   c1744               -1
    x1005     c1745                1   c1746               -1
    x1006     c1741               -1   c1742                1
    x1006     c4574                1   c4576               -1
    x1006     c4577               -1
    x1007     c1747                1   c1748               -1
    x1007     c1749               -1   c4581                1
    x1007     c4582                1   c4583                1
    x1007     c6412               -1
    x1008     c1749               -1   c1750               -1
    x1008     c1751               -1   c1752               -1
    x1008     c1753               -1   c4581                1
    x1008     c4582                1   c4583                1
    x1008     c6738                1
    x1009     c1752               -1   c1762               -1
    x1009     c1763                1   c6738                1
    x1010     c1754                1   c1755               -1
    x1010     c1756                1   c1757               -1
    x1010     c1758                1   c1759               -1
    x1010     c1760                1   c1761               -1
    x1010     c1762                1   c1763               -1
    x1010     c1764                1   c1765               -1
    x1011     c1754               -1   c1755                1
    x1011     c2640               -1   c2643               -1
    x1011     c2644               -1   c5290                1
    x1011     c5293                1
    x1012     c1756               -1   c1757                1
    x1012     c3112                1   c3114                1
    x1012     c3120                1   c6754               -1
    x1012     c6755               -1
    x1013     c1758               -1   c1759                1
    x1013     c3344                1   c3346                1
    x1013     c3352                1   c6756               -1
    x1013     c6757               -1
    x1014     c1760               -1   c1761                1
    x1014     c4583                1   c6412               -1
    x1015     c1766               -1   c1767               -1
    x1015     c4582                1   c4584                1
    x1015     c6412               -1
    x1016     c1771               -1   c1776               -1
    x1016     c1777                1   c6739                1
    x1017     c1772                1   c1773               -1
    x1017     c1774                1   c1775               -1
    x1017     c1776                1   c1777               -1
    x1017     c1778                1   c1779               -1
    x1018     c1772               -1   c1773                1
    x1018     c3561               -1   c6171                1
    x1019     c1774               -1   c1775                1
    x1019     c3354               -1   c5964                1
    x1020     c1780                1   c1781               -1
    x1020     c1782                1   c1783               -1
    x1020     c1784                1   c1785               -1
    x1020     c1786                1   c1787               -1
    x1020     c1788                1   c1789               -1
    x1020     c1790                1   c1791               -1
    x1020     c4585               -1   c4586               -1
    x1020     c4587                1   c4588                1
    x1020     c4589                1   c4590                1
    x1021     c1780               -1   c1781                1
    x1021     c2883                1   c2884                1
    x1021     c5512                1   c5522               -1
    x1021     c5525               -1   c5534               -1
    x1021     c5538                1   c6575               -1
    x1021     c6576               -1
    x1022     c1782               -1   c1783                1
    x1022     c2585                1   c2592                1
    x1022     c2594                1   c2595                1
    x1022     c6745               -1   c6746               -1
    x1023     c1784               -1   c1785                1
    x1023     c2859                1   c2866                1
    x1023     c2868                1   c2869                1
    x1023     c6750               -1   c6751               -1
    x1024     c1786               -1   c1787                1
    x1024     c2856               -1   c2857               -1
    x1024     c5471               -1   c5481               -1
    x1024     c5484               -1   c5493               -1
    x1024     c5497               -1   c6573                1
    x1024     c6574                1
    x1025     c1790               -1   c1791                1
    x1025     c2138                1   c2139               -1
    x1026     c1792                1   c1793               -1
    x1026     c1794                1   c1795               -1
    x1026     c1796                1   c1797                1
    x1026     c4591               -1
    x1027     c1792               -1   c1793                1
    x1027     c4585               -1   c4589                1
    x1027     c4590                1
    x1028     c1794               -1   c1795                1
    x1028     c4586               -1   c4588                1
    x1028     c4590                1
    x1029     c1796                1   c1828               -1
    x1029     c1829                1   c4591               -1
    x1030     c1797                1   c1798               -1
    x1030     c1799                1   c4591               -1
    x1031     c1798                1   c1799               -1
    x1031     c1800                1   c1801               -1
    x1031     c1802                1   c1803               -1
    x1032     c1800               -1   c1801                1
    x1032     c4586               -1   c4587                1
    x1032     c4589                1
    x1033     c1802                1   c1803               -1
    x1033     c4592               -1   c4593               -1
    x1033     c4594                1   c4595                1
    x1033     c4596                1   c4597                1
    x1034     c1804                1   c1805               -1
    x1034     c1806                1   c1807               -1
    x1034     c1808                1   c1809                1
    x1034     c4598               -1
    x1035     c1804               -1   c1805                1
    x1035     c4592               -1   c4596                1
    x1035     c4597                1
    x1036     c1806               -1   c1807                1
    x1036     c4593               -1   c4595                1
    x1036     c4597                1
    x1037     c1808                1   c1822               -1
    x1037     c1823                1   c4598               -1
    x1038     c1809                1   c1812               -1
    x1038     c1813                1   c4598               -1
    x1039     c1810                1   c1811               -1
    x1039     c1812                1   c1813               -1
    x1039     c4599                1   c4600                1
    x1039     c4601               -1   c4602               -1
    x1039     c4603               -1   c4604               -1
    x1040     c1810               -1   c1811                1
    x1040     c4593               -1   c4594                1
    x1040     c4596                1
    x1041     c1814                1   c1815               -1
    x1041     c1816                1   c1817               -1
    x1041     c1818               -1   c1819               -1
    x1041     c4605                1
    x1042     c1814               -1   c1815                1
    x1042     c4599                1   c4603               -1
    x1042     c4604               -1
    x1043     c1816               -1   c1817                1
    x1043     c4600                1   c4602               -1
    x1043     c4604               -1
    x1044     c1820                1   c1821               -1
    x1044     c1822                1   c1823               -1
    x1044     c1824                1   c1825               -1
    x1045     c1820               -1   c1821                1
    x1045     c4592               -1   c4594                1
    x1045     c4595                1
    x1046     c1824                1   c1825               -1
    x1046     c1826                1   c1827                1
    x1046     c4606               -1
    x1047     c1826                1   c4606               -1
    x1048     c1828                1   c1829               -1
    x1048     c1830                1   c1831               -1
    x1048     c4607                1   c4608                1
    x1048     c4609               -1   c4610               -1
    x1048     c4611               -1   c4612               -1
    x1049     c1830               -1   c1831                1
    x1049     c4585               -1   c4587                1
    x1049     c4588                1
    x1050     c1832                1   c1833               -1
    x1050     c1834                1   c1835               -1
    x1050     c1836               -1   c1837               -1
    x1050     c4613                1
    x1051     c1832               -1   c1833                1
    x1051     c4607                1   c4611               -1
    x1051     c4612               -1
    x1052     c1834               -1   c1835                1
    x1052     c4608                1   c4610               -1
    x1052     c4612               -1
    x1053     c1836               -1   c1862               -1
    x1053     c1863                1   c4613                1
    x1054     c1837               -1   c1840               -1
    x1054     c1841                1   c4613                1
    x1055     c1838                1   c1839               -1
    x1055     c1840                1   c1841               -1
    x1055     c1842                1   c1843               -1
    x1056     c1838               -1   c1839                1
    x1056     c4608                1   c4609               -1
    x1056     c4611               -1
    x1057     c1842                1   c1843               -1
    x1057     c4614                1   c4615                1
    x1057     c4616               -1   c4617               -1
    x1057     c4618               -1   c4619               -1
    x1058     c1844                1   c1845               -1
    x1058     c1846                1   c1847               -1
    x1058     c1848               -1   c1849               -1
    x1058     c4620                1
    x1059     c1844               -1   c1845                1
    x1059     c4614                1   c4618               -1
    x1059     c4619               -1
    x1060     c1846               -1   c1847                1
    x1060     c4615                1   c4617               -1
    x1060     c4619               -1
    x1061     c1849               -1   c1856               -1
    x1061     c1857                1   c4620                1
    x1062     c1850                1   c1851               -1
    x1062     c1852                1   c1853               -1
    x1062     c1854                1   c1855               -1
    x1062     c1856                1   c1857               -1
    x1062     c1858                1   c1859               -1
    x1063     c1850               -1   c1851                1
    x1063     c3634               -1   c6232                1
    x1063     c6234               -1   c6235               -1
    x1063     c6245               -1   c6249                1
    x1063     c6251               -1   c6252               -1
    x1063     c6711                1   c6712                1
    x1063     c6713                1   c6714                1
    x1063     c6715                1   c6716                1
    x1063     c6719               -1
    x1064     c1852               -1   c1853                1
    x1064     c3645               -1   c3648               -1
    x1064     c3649               -1   c6260                1
    x1064     c6263                1
    x1065     c1854               -1   c1855                1
    x1065     c4615                1   c4616               -1
    x1065     c4618               -1
    x1066     c1860                1   c1861               -1
    x1066     c1862                1   c1863               -1
    x1066     c4621               -1   c4622               -1
    x1066     c4623                1   c4624                1
    x1066     c4625                1   c4626                1
    x1067     c1860               -1   c1861                1
    x1067     c4607                1   c4609               -1
    x1067     c4610               -1
    x1068     c1864                1   c1865               -1
    x1068     c1866                1   c1867               -1
    x1068     c1868                1   c1869                1
    x1068     c4627               -1
    x1069     c1864               -1   c1865                1
    x1069     c4621               -1   c4625                1
    x1069     c4626                1
    x1070     c1866               -1   c1867                1
    x1070     c4622               -1   c4624                1
    x1070     c4626                1
    x1071     c1870                1   c1871               -1
    x1071     c1872                1   c1873               -1
    x1071     c1874                1   c1875               -1
    x1072     c1876               -1   c1878                1
    x1072     c1885                1   c1886               -1
    x1072     c4628                1   c4629               -1
    x1072     c4631                1   c4632               -1
    x1073     c1876               -1   c1877               -1
    x1073     c1881               -1   c4628                1
    x1073     c4630                1
    x1074     c1877                1   c1879               -1
    x1074     c1882                1   c1883               -1
    x1074     c4628               -1   c4629                1
    x1074     c4631                1   c4632               -1
    x1075     c1878               -1   c1879               -1
    x1075     c1880               -1   c4629                1
    x1075     c4630                1
    x1076     c1880                1   c1881                1
    x1076     c3744               -1   c4630               -1
    x1076     c6760                1
    x1077     c1882                1   c1883               -1
    x1077     c4633               -1   c4634               -1
    x1077     c4635                1   c4636                1
    x1077     c4637                1   c4638                1
    x1077     c4648                1   c4649               -1
    x1078     c1884               -1   c1887                1
    x1078     c1888                1   c1889                1
    x1078     c4648               -1   c4649               -1
    x1079     c1884                1   c4631               -1
    x1079     c4632               -1   c6319                1
    x1080     c1885                1   c1886               -1
    x1080     c4648                1   c4649               -1
    x1080     c4650               -1   c4651               -1
    x1080     c4652                1   c4653                1
    x1080     c4654                1   c4655                1
    x1081     c1887               -1   c1890               -1
    x1081     c1895               -1   c4656                1
    x1081     c4659               -1   c4660               -1
    x1081     c6419               -1   c6420               -1
    x1082     c1888               -1   c1912               -1
    x1082     c4642               -1   c4643               -1
    x1082     c4644               -1   c4665                1
    x1082     c4666               -1   c4667               -1
    x1082     c6416               -1   c6417               -1
    x1082     c6418               -1
    x1083     c1889               -1   c1896               -1
    x1083     c4639               -1   c4640               -1
    x1083     c4641               -1   c4656                1
    x1083     c4657               -1   c4658               -1
    x1083     c6413               -1   c6414               -1
    x1083     c6415               -1
    x1084     c1891                1   c1892               -1
    x1084     c1893                1   c1894               -1
    x1084     c1901                1   c1902                1
    x1084     c4661               -1   c4662                1
    x1084     c4663               -1
    x1085     c1891               -1   c1892                1
    x1085     c4633               -1   c4637                1
    x1085     c4638                1   c4646                1
    x1085     c4647                1   c4659                1
    x1085     c4660               -1   c6413               -1
    x1085     c6415               -1   c6416               -1
    x1085     c6418               -1   c6419                1
    x1086     c1893               -1   c1894                1
    x1086     c4634               -1   c4636                1
    x1086     c4638                1   c4640               -1
    x1086     c4643                1   c4644                1
    x1086     c4657                1   c4658               -1
    x1086     c6414               -1   c6419               -1
    x1086     c6421               -1
    x1087     c1895                1   c1896                1
    x1087     c1903                1   c4656               -1
    x1087     c4662               -1   c4663               -1
    x1088     c1897                1   c1898               -1
    x1088     c1899                1   c1900               -1
    x1088     c1905                1   c1906                1
    x1088     c4662                1   c4663               -1
    x1088     c4664               -1
    x1089     c1897               -1   c1898                1
    x1089     c4645                1   c4647                1
    x1089     c4650               -1   c4654                1
    x1089     c4655                1   c4659                1
    x1089     c4660               -1   c6414               -1
    x1089     c6415               -1   c6417               -1
    x1089     c6418               -1   c6420                1
    x1090     c1899               -1   c1900                1
    x1090     c4639               -1   c4642                1
    x1090     c4644                1   c4651               -1
    x1090     c4653                1   c4655                1
    x1090     c4657                1   c4658               -1
    x1090     c6413               -1   c6420               -1
    x1090     c6422               -1
    x1091     c1902                1   c1907               -1
    x1091     c1908                1   c4661               -1
    x1091     c4668                1   c4669               -1
    x1092     c1903               -1   c1904               -1
    x1092     c1911               -1   c4665                1
    x1092     c4668               -1   c4669               -1
    x1093     c1906                1   c1913               -1
    x1093     c1914                1   c4664               -1
    x1093     c4668                1   c4669               -1
    x1094     c1907                1   c1908               -1
    x1094     c1909                1   c1910               -1
    x1094     c1917                1   c1918               -1
    x1094     c4670                1   c4671               -1
    x1095     c1909               -1   c1910                1
    x1095     c4634               -1   c4635                1
    x1095     c4637                1   c4640                1
    x1095     c4641                1   c4643               -1
    x1095     c4666                1   c4667               -1
    x1095     c6417               -1   c6419               -1
    x1095     c6421               -1
    x1096     c1911                1   c1912                1
    x1096     c1919                1   c4665               -1
    x1096     c4670               -1   c4671               -1
    x1097     c1913                1   c1914               -1
    x1097     c1915                1   c1916               -1
    x1097     c1920                1   c1921               -1
    x1097     c4670                1   c4671               -1
    x1098     c1915               -1   c1916                1
    x1098     c4639                1   c4641                1
    x1098     c4642               -1   c4651               -1
    x1098     c4652                1   c4654                1
    x1098     c4666                1   c4667               -1
    x1098     c6416               -1   c6420               -1
    x1098     c6422               -1
    x1099     c1917                1   c1918               -1
    x1099     c1922                1   c1923                1
    x1099     c4672               -1   c4673                1
    x1099     c4674               -1
    x1100     c1919               -1   c1924                1
    x1100     c4673               -1   c4674               -1
    x1101     c1920                1   c1921               -1
    x1101     c1926                1   c1927                1
    x1101     c4673                1   c4674               -1
    x1101     c4675               -1
    x1102     c1928               -1   c1930                1
    x1102     c4676                1   c4677               -1
    x1102     c4694                1   c4695               -1
    x1102     c4696                1   c4697                1
    x1102     c4698               -1   c4699               -1
    x1102     c4700               -1   c4701               -1
    x1103     c1928               -1   c1929               -1
    x1103     c1933               -1   c4676                1
    x1103     c4678                1
    x1104     c1929                1   c1931               -1
    x1104     c4676               -1   c4677                1
    x1104     c4679                1   c4680                1
    x1104     c4681               -1   c4682               -1
    x1104     c4683               -1   c4684               -1
    x1104     c4694                1   c4695               -1
    x1105     c1930               -1   c1931               -1
    x1105     c1932               -1   c4677                1
    x1105     c4678                1
    x1106     c1932                1   c1933                1
    x1106     c3743               -1   c4678               -1
    x1106     c6760                1
    x1107     c1934               -1   c1937               -1
    x1107     c1942               -1   c4702                1
    x1107     c4705               -1   c4706               -1
    x1107     c6429               -1   c6430               -1
    x1108     c1934                1   c1935                1
    x1108     c1936                1   c4694               -1
    x1108     c4695               -1   c6319                1
    x1109     c1935               -1   c1959               -1
    x1109     c4688               -1   c4689               -1
    x1109     c4690               -1   c4711                1
    x1109     c4712               -1   c4713               -1
    x1109     c6426               -1   c6427               -1
    x1109     c6428               -1
    x1110     c1936               -1   c1943               -1
    x1110     c4685               -1   c4686               -1
    x1110     c4687               -1   c4702                1
    x1110     c4703               -1   c4704               -1
    x1110     c6423               -1   c6424               -1
    x1110     c6425               -1
    x1111     c1938                1   c1939               -1
    x1111     c1940                1   c1941               -1
    x1111     c1948               -1   c1949               -1
    x1111     c4707                1   c4708                1
    x1111     c4709               -1
    x1112     c1938               -1   c1939                1
    x1112     c4679                1   c4683               -1
    x1112     c4684               -1   c4691               -1
    x1112     c4693               -1   c4705                1
    x1112     c4706               -1   c6424                1
    x1112     c6425                1   c6427                1
    x1112     c6428                1   c6429               -1
    x1113     c1940               -1   c1941                1
    x1113     c4680                1   c4682               -1
    x1113     c4684               -1   c4686               -1
    x1113     c4688               -1   c4690               -1
    x1113     c4703                1   c4704               -1
    x1113     c6424               -1   c6429                1
    x1113     c6431                1
    x1114     c1942                1   c1943                1
    x1114     c1950                1   c4702               -1
    x1114     c4708               -1   c4709               -1
    x1115     c1944                1   c1945               -1
    x1115     c1946                1   c1947               -1
    x1115     c1952               -1   c1953               -1
    x1115     c4708                1   c4709               -1
    x1115     c4710                1
    x1116     c1944               -1   c1945                1
    x1116     c4692               -1   c4693               -1
    x1116     c4696                1   c4700               -1
    x1116     c4701               -1   c4705                1
    x1116     c4706               -1   c6423                1
    x1116     c6425                1   c6426                1
    x1116     c6428                1   c6430               -1
    x1117     c1946               -1   c1947                1
    x1117     c4685               -1   c4689               -1
    x1117     c4690               -1   c4697                1
    x1117     c4699               -1   c4701               -1
    x1117     c4703                1   c4704               -1
    x1117     c6423               -1   c6430                1
    x1117     c6432                1
    x1118     c1949               -1   c1954               -1
    x1118     c1955                1   c4707                1
    x1118     c4714                1   c4715               -1
    x1119     c1950               -1   c1951               -1
    x1119     c1958               -1   c4711                1
    x1119     c4714               -1   c4715               -1
    x1120     c1953               -1   c1960               -1
    x1120     c1961                1   c4710                1
    x1120     c4714                1   c4715               -1
    x1121     c1954                1   c1955               -1
    x1121     c1956                1   c1957               -1
    x1121     c1964                1   c1965                1
    x1121     c4716               -1   c4717                1
    x1121     c4718               -1
    x1122     c1956               -1   c1957                1
    x1122     c4680                1   c4681               -1
    x1122     c4683               -1   c4685               -1
    x1122     c4687               -1   c4689               -1
    x1122     c4712                1   c4713               -1
    x1122     c6427               -1   c6429                1
    x1122     c6431                1
    x1123     c1958                1   c1959                1
    x1123     c1966                1   c4711               -1
    x1123     c4717               -1   c4718               -1
    x1124     c1960                1   c1961               -1
    x1124     c1962                1   c1963               -1
    x1124     c1968                1   c1969                1
    x1124     c4717                1   c4718               -1
    x1124     c4719               -1
    x1125     c1962               -1   c1963                1
    x1125     c4686               -1   c4687               -1
    x1125     c4688               -1   c4697                1
    x1125     c4698               -1   c4700               -1
    x1125     c4712                1   c4713               -1
    x1125     c6426               -1   c6430                1
    x1125     c6432                1
    x1126     c1970               -1   c1972                1
    x1126     c4720                1   c4721               -1
    x1126     c4738                1   c4739               -1
    x1126     c4740                1   c4741                1
    x1126     c4742               -1   c4743               -1
    x1126     c4744               -1   c4745               -1
    x1127     c1970               -1   c1971               -1
    x1127     c1975               -1   c4720                1
    x1127     c4722                1
    x1128     c1971                1   c1973               -1
    x1128     c4720               -1   c4721                1
    x1128     c4723                1   c4724                1
    x1128     c4725               -1   c4726               -1
    x1128     c4727               -1   c4728               -1
    x1128     c4738                1   c4739               -1
    x1129     c1972               -1   c1973               -1
    x1129     c1974               -1   c4721                1
    x1129     c4722                1
    x1130     c1974                1   c1975                1
    x1130     c3742               -1   c4722               -1
    x1130     c6760                1
    x1131     c1976               -1   c1979               -1
    x1131     c1984               -1   c4746                1
    x1131     c4749               -1   c4750               -1
    x1131     c6439               -1   c6440               -1
    x1132     c1976                1   c1977                1
    x1132     c1978                1   c4738               -1
    x1132     c4739               -1   c6767                1
    x1133     c1977               -1   c2000               -1
    x1133     c4732               -1   c4733               -1
    x1133     c4734               -1   c4755                1
    x1133     c4758               -1   c4759               -1
    x1133     c6436               -1   c6437               -1
    x1133     c6438               -1
    x1134     c1978               -1   c1985               -1
    x1134     c4729               -1   c4730               -1
    x1134     c4731               -1   c4746                1
    x1134     c4747               -1   c4748               -1
    x1134     c6433               -1   c6434               -1
    x1134     c6435               -1
    x1135     c1980                1   c1981               -1
    x1135     c1982                1   c1983               -1
    x1135     c1990               -1   c1991               -1
    x1135     c4751                1   c4752                1
    x1135     c4753               -1
    x1136     c1980               -1   c1981                1
    x1136     c4723                1   c4727               -1
    x1136     c4728               -1   c4735               -1
    x1136     c4737               -1   c4749                1
    x1136     c4750               -1   c6434                1
    x1136     c6435                1   c6437                1
    x1136     c6438                1   c6439               -1
    x1137     c1982               -1   c1983                1
    x1137     c4724                1   c4726               -1
    x1137     c4728               -1   c4730               -1
    x1137     c4732               -1   c4734               -1
    x1137     c4747                1   c4748               -1
    x1137     c6434               -1   c6439                1
    x1137     c6441                1
    x1138     c1984                1   c1985                1
    x1138     c1992                1   c4746               -1
    x1138     c4752               -1   c4753               -1
    x1139     c1986                1   c1987               -1
    x1139     c1988                1   c1989               -1
    x1139     c1994               -1   c1995               -1
    x1139     c4752                1   c4753               -1
    x1139     c4754                1
    x1140     c1986               -1   c1987                1
    x1140     c4736               -1   c4737               -1
    x1140     c4740                1   c4744               -1
    x1140     c4745               -1   c4749                1
    x1140     c4750               -1   c6433                1
    x1140     c6435                1   c6436                1
    x1140     c6438                1   c6440               -1
    x1141     c1988               -1   c1989                1
    x1141     c4729               -1   c4733               -1
    x1141     c4734               -1   c4741                1
    x1141     c4743               -1   c4745               -1
    x1141     c4747                1   c4748               -1
    x1141     c6433               -1   c6440                1
    x1141     c6442                1
    x1142     c1991               -1   c1998               -1
    x1142     c1999                1   c4751                1
    x1142     c4756                1   c4757               -1
    x1143     c1992               -1   c1993               -1
    x1143     c2001               -1   c4755                1
    x1143     c4756               -1   c4757               -1
    x1144     c1995               -1   c2004               -1
    x1144     c2005                1   c4754                1
    x1144     c4756                1   c4757               -1
    x1145     c1996                1   c1997               -1
    x1145     c1998                1   c1999               -1
    x1145     c2006                1   c2007                1
    x1145     c4760               -1   c4761                1
    x1145     c4762               -1
    x1146     c1996               -1   c1997                1
    x1146     c4724                1   c4725               -1
    x1146     c4727               -1   c4729               -1
    x1146     c4731               -1   c4733               -1
    x1146     c4758                1   c4759               -1
    x1146     c6437               -1   c6439                1
    x1146     c6441                1
    x1147     c2000                1   c2001                1
    x1147     c2008                1   c4755               -1
    x1147     c4761               -1   c4762               -1
    x1148     c2002                1   c2003               -1
    x1148     c2004                1   c2005               -1
    x1148     c2010                1   c2011                1
    x1148     c4761                1   c4762               -1
    x1148     c4763               -1
    x1149     c2002               -1   c2003                1
    x1149     c4730               -1   c4731               -1
    x1149     c4732               -1   c4741                1
    x1149     c4742               -1   c4744               -1
    x1149     c4758                1   c4759               -1
    x1149     c6436               -1   c6440                1
    x1149     c6442                1
    x1150     c2012               -1   c2014                1
    x1150     c4764                1   c4765               -1
    x1150     c4785                1   c4786               -1
    x1150     c4787                1   c4788                1
    x1150     c4789               -1   c4790               -1
    x1150     c4791               -1   c4792               -1
    x1151     c2012               -1   c2013               -1
    x1151     c2017               -1   c4764                1
    x1151     c4766                1
    x1152     c2013                1   c2015               -1
    x1152     c4764               -1   c4765                1
    x1152     c4767                1   c4768                1
    x1152     c4769               -1   c4770               -1
    x1152     c4771               -1   c4772               -1
    x1152     c4785                1   c4786               -1
    x1153     c2014               -1   c2015               -1
    x1153     c2016               -1   c4765                1
    x1153     c4766                1
    x1154     c2016                1   c2017                1
    x1154     c3741               -1   c4766               -1
    x1154     c6778                1
    x1155     c2018                1   c2019                1
    x1155     c2020                1   c2021                1
    x1155     c4785               -1   c4786               -1
    x1155     c6767                1
    x1156     c2019               -1   c2026               -1
    x1156     c4779               -1   c4780               -1
    x1156     c4781               -1   c4793                1
    x1156     c4796               -1   c4797               -1
    x1156     c6447               -1   c6448               -1
    x1157     c2020               -1   c2043               -1
    x1157     c4776               -1   c4777               -1
    x1157     c4778               -1   c4808                1
    x1157     c4809               -1   c4810               -1
    x1157     c6445               -1   c6446               -1
    x1158     c2021               -1   c2027               -1
    x1158     c4773               -1   c4774               -1
    x1158     c4775               -1   c4793                1
    x1158     c4794               -1   c4795               -1
    x1158     c6443               -1   c6444               -1
    x1159     c2022                1   c2023               -1
    x1159     c2024                1   c2025               -1
    x1159     c2032               -1   c2033               -1
    x1159     c4798                1   c4805                1
    x1159     c4806               -1
    x1160     c2022               -1   c2023                1
    x1160     c4767                1   c4771               -1
    x1160     c4772               -1   c4780               -1
    x1160     c4782               -1   c4784               -1
    x1160     c4796                1   c4797               -1
    x1160     c6443                1   c6445                1
    x1160     c6447               -1
    x1161     c2024               -1   c2025                1
    x1161     c4768                1   c4770               -1
    x1161     c4772               -1   c4774               -1
    x1161     c4776               -1   c4778               -1
    x1161     c4794                1   c4795               -1
    x1161     c6443               -1   c6447                1
    x1161     c6449                1
    x1162     c2026                1   c2027                1
    x1162     c2034                1   c2035                1
    x1162     c4793               -1   c4805               -1
    x1162     c4806               -1
    x1163     c2028                1   c2029               -1
    x1163     c2030                1   c2031               -1
    x1163     c2036               -1   c2037               -1
    x1163     c4805                1   c4806               -1
    x1163     c4807                1
    x1164     c2028               -1   c2029                1
    x1164     c4779               -1   c4783               -1
    x1164     c4784               -1   c4787                1
    x1164     c4791               -1   c4792               -1
    x1164     c4796                1   c4797               -1
    x1164     c6444                1   c6446                1
    x1164     c6448               -1
    x1165     c2030               -1   c2031                1
    x1165     c4773               -1   c4777               -1
    x1165     c4778               -1   c4788                1
    x1165     c4790               -1   c4792               -1
    x1165     c4794                1   c4795               -1
    x1165     c6444               -1   c6448                1
    x1165     c6450                1
    x1166     c2033               -1   c2038               -1
    x1166     c2039                1   c4798                1
    x1166     c4800               -1   c4802               -1
    x1166     c4804               -1   c4811                1
    x1166     c4812               -1
    x1167     c2035               -1   c2042               -1
    x1167     c4799               -1   c4800               -1
    x1167     c4801               -1   c4808                1
    x1167     c4811               -1   c4812               -1
    x1168     c2037               -1   c2044               -1
    x1168     c2045                1   c4799               -1
    x1168     c4803               -1   c4804               -1
    x1168     c4807                1   c4811                1
    x1168     c4812               -1
    x1169     c2038                1   c2039               -1
    x1169     c2040                1   c2041               -1
    x1169     c2048                1   c2049                1
    x1169     c4813               -1   c4814                1
    x1169     c4815               -1
    x1170     c2040               -1   c2041                1
    x1170     c4768                1   c4769               -1
    x1170     c4771               -1   c4773               -1
    x1170     c4775               -1   c4777               -1
    x1170     c4809                1   c4810               -1
    x1170     c6445               -1   c6447                1
    x1170     c6449                1
    x1171     c2042                1   c2043                1
    x1171     c2050                1   c4808               -1
    x1171     c4814               -1   c4815               -1
    x1172     c2044                1   c2045               -1
    x1172     c2046                1   c2047               -1
    x1172     c2052                1   c2053                1
    x1172     c4814                1   c4815               -1
    x1172     c4816               -1
    x1173     c2046               -1   c2047                1
    x1173     c4774               -1   c4775               -1
    x1173     c4776               -1   c4788                1
    x1173     c4789               -1   c4791               -1
    x1173     c4809                1   c4810               -1
    x1173     c6446               -1   c6448                1
    x1173     c6450                1
    x1174     c2049                1   c2054               -1
    x1174     c2055                1   c4813               -1
    x1174     c4823                1   c4824               -1
    x1175     c2050               -1   c2051               -1
    x1175     c2062               -1   c4823               -1
    x1175     c4824               -1   c6740                1
    x1176     c2053                1   c2066               -1
    x1176     c2067                1   c4816               -1
    x1176     c4823                1   c4824               -1
    x1177     c2054                1   c2055               -1
    x1177     c2056                1   c2057               -1
    x1177     c2058                1   c2059               -1
    x1177     c2060                1   c2061               -1
    x1177     c2074               -1   c2075               -1
    x1177     c2076               -1   c2077               -1
    x1177     c4831                1   c4832               -1
    x1177     c6741                1
    x1178     c2056               -1   c2057                1
    x1178     c2177                1   c4821                1
    x1178     c4822               -1   c4889               -1
    x1179     c2058               -1   c2059                1
    x1179     c2219                1   c4819                1
    x1179     c4820               -1   c4933               -1
    x1180     c2060               -1   c2061                1
    x1180     c2261                1   c4817                1
    x1180     c4818               -1   c4977               -1
    x1181     c2062                1   c2063                1
    x1181     c2064                1   c2065                1
    x1181     c2078                1   c2079                1
    x1181     c4831               -1   c4832               -1
    x1181     c6740               -1
    x1182     c2063               -1   c2178               -1
    x1182     c2179               -1   c4821               -1
    x1182     c4822               -1   c6740                1
    x1183     c2064               -1   c2220               -1
    x1183     c2221               -1   c4819               -1
    x1183     c4820               -1   c6740                1
    x1184     c2065               -1   c2262               -1
    x1184     c2263               -1   c4817               -1
    x1184     c4818               -1   c6740                1
    x1185     c2066                1   c2067               -1
    x1185     c2068                1   c2069               -1
    x1185     c2070                1   c2071               -1
    x1185     c2072                1   c2073               -1
    x1185     c2084               -1   c2085               -1
    x1185     c2086               -1   c2087               -1
    x1185     c4831                1   c4832               -1
    x1185     c6742                1
    x1186     c2068               -1   c2069                1
    x1186     c2181                1   c4821                1
    x1186     c4822               -1   c4892               -1
    x1187     c2070               -1   c2071                1
    x1187     c2223                1   c4819                1
    x1187     c4820               -1   c4936               -1
    x1188     c2072               -1   c2073                1
    x1188     c2265                1   c4817                1
    x1188     c4818               -1   c4980               -1
    x1189     c2074               -1   c2081               -1
    x1189     c2083               -1   c2084               -1
    x1189     c2134               -1   c2135                1
    x1189     c6741                1   c6742                1
    x1190     c2076               -1   c2118                1
    x1190     c2119                1   c4825               -1
    x1190     c4827               -1   c4829               -1
    x1190     c4845               -1   c4846                1
    x1190     c4847               -1   c6741                1
    x1191     c2077               -1   c2094               -1
    x1191     c2095                1   c4826               -1
    x1191     c4828               -1   c4830               -1
    x1191     c4835                1   c4836               -1
    x1191     c6741                1
    x1192     c2078               -1   c2082               -1
    x1192     c2083               -1   c2120                1
    x1192     c4828               -1   c4829               -1
    x1192     c4830               -1   c4846               -1
    x1192     c4847               -1
    x1193     c2079               -1   c2080               -1
    x1193     c2081               -1   c2101               -1
    x1193     c4825               -1   c4826               -1
    x1193     c4827               -1   c4835               -1
    x1193     c4836               -1   c6771                1
    x1194     c2086               -1   c2122                1
    x1194     c2123                1   c4826               -1
    x1194     c4827               -1   c4828               -1
    x1194     c4846                1   c4847               -1
    x1194     c4848               -1   c6742                1
    x1195     c2087               -1   c2109               -1
    x1195     c2110                1   c4825               -1
    x1195     c4829               -1   c4830               -1
    x1195     c4835                1   c4836               -1
    x1195     c6742                1
    x1196     c2088                1   c2089               -1
    x1196     c2090                1   c2091               -1
    x1196     c2092                1   c2093               -1
    x1196     c2094                1   c2095               -1
    x1196     c2096                1   c2097               -1
    x1196     c2113                1   c2114               -1
    x1196     c4843                1   c4844               -1
    x1197     c2088               -1   c2089                1
    x1197     c2331                1   c4841                1
    x1197     c4842               -1   c5036                1
    x1197     c5037                1   c5039               -1
    x1197     c6743               -1
    x1198     c2090               -1   c2091                1
    x1198     c4839                1   c4840               -1
    x1198     c5514                1   c5516               -1
    x1198     c5519                1   c5520                1
    x1198     c5522                1   c5523                1
    x1198     c5528               -1   c6575               -1
    x1199     c2092               -1   c2093                1
    x1199     c3480               -1   c4837                1
    x1199     c4838               -1   c6101                1
    x1199     c6102               -1   c6104               -1
    x1199     c6106               -1
    x1200     c2096               -1   c2097                1
    x1200     c3527               -1   c4833                1
    x1200     c4834               -1   c6153                1
    x1200     c6154               -1   c6156               -1
    x1200     c6158               -1
    x1201     c2098                1   c2099                1
    x1201     c2100                1   c2101                1
    x1201     c2102                1   c2115                1
    x1201     c4843               -1   c4844               -1
    x1201     c6771               -1
    x1202     c2098               -1   c2333               -1
    x1202     c2337               -1   c2338               -1
    x1202     c4841               -1   c4842               -1
    x1202     c5038               -1   c5039               -1
    x1202     c5040               -1   c6771                1
    x1203     c2099               -1   c2881               -1
    x1203     c2883               -1   c4839               -1
    x1203     c4840               -1   c5515               -1
    x1203     c5516               -1   c5517               -1
    x1203     c5527               -1   c5528               -1
    x1203     c5529               -1   c6771                1
    x1204     c2100               -1   c3482               -1
    x1204     c4837               -1   c4838               -1
    x1204     c6105               -1   c6106               -1
    x1204     c6107               -1   c6771                1
    x1205     c2102               -1   c3529               -1
    x1205     c4833               -1   c4834               -1
    x1205     c6157               -1   c6158               -1
    x1205     c6159               -1   c6771                1
    x1206     c2103                1   c2104               -1
    x1206     c2105                1   c2106               -1
    x1206     c2107                1   c2108               -1
    x1206     c2109                1   c2110               -1
    x1206     c2111                1   c2112               -1
    x1206     c2116                1   c2117               -1
    x1206     c4843                1   c4844               -1
    x1207     c2103               -1   c2104                1
    x1207     c2341                1   c4841                1
    x1207     c4842               -1   c5035                1
    x1207     c5037                1   c5038               -1
    x1207     c6744               -1
    x1208     c2105               -1   c2106                1
    x1208     c4839                1   c4840               -1
    x1208     c5515               -1   c5518                1
    x1208     c5520                1   c5521                1
    x1208     c5523                1   c5527               -1
    x1208     c5540                1   c6576               -1
    x1209     c2107               -1   c2108                1
    x1209     c3484               -1   c4837                1
    x1209     c4838               -1   c6103               -1
    x1209     c6104               -1   c6105               -1
    x1209     c6110                1
    x1210     c2111               -1   c2112                1
    x1210     c3531               -1   c4833                1
    x1210     c4834               -1   c6155               -1
    x1210     c6156               -1   c6157               -1
    x1210     c6162                1
    x1211     c2124                1   c2125               -1
    x1211     c2126                1   c2127               -1
    x1211     c2128                1   c2129               -1
    x1211     c2130                1   c2131               -1
    x1211     c2132                1   c2133               -1
    x1211     c2134                1   c2135               -1
    x1211     c2136                1   c2137               -1
    x1211     c2138                1   c2139               -1
    x1212     c2124               -1   c2125                1
    x1212     c3391                1   c3394                1
    x1212     c3395                1   c6005               -1
    x1212     c6008               -1
    x1213     c2126               -1   c2127                1
    x1213     c3221                1   c3224                1
    x1213     c3225                1   c5851               -1
    x1213     c5854               -1
    x1214     c2128               -1   c2129                1
    x1214     c2886               -1   c2893               -1
    x1214     c2895               -1   c2896               -1
    x1214     c6752                1   c6753                1
    x1215     c2130               -1   c2131                1
    x1215     c2329                1   c2336                1
    x1215     c2338                1   c2339                1
    x1215     c6743               -1   c6744               -1
    x1216     c2132               -1   c2133                1
    x1216     c3004                1   c3007                1
    x1216     c3008                1   c5645               -1
    x1216     c5648               -1
    x1217     c2136               -1   c2137                1
    x1217     c3661                1   c3664                1
    x1217     c3665                1   c6269               -1
    x1217     c6272               -1
    x1218     c2140               -1   c2142                1
    x1218     c4849                1   c4850               -1
    x1218     c4867                1   c4868               -1
    x1218     c4869                1   c4870                1
    x1218     c4871               -1   c4872               -1
    x1218     c4873               -1   c4874               -1
    x1219     c2140               -1   c2141               -1
    x1219     c2145               -1   c4849                1
    x1219     c4851                1
    x1220     c2141                1   c2143               -1
    x1220     c4849               -1   c4850                1
    x1220     c4852                1   c4853                1
    x1220     c4854               -1   c4855               -1
    x1220     c4856               -1   c4857               -1
    x1220     c4867                1   c4868               -1
    x1221     c2142               -1   c2143               -1
    x1221     c2144               -1   c4850                1
    x1221     c4851                1
    x1222     c2144                1   c2145                1
    x1222     c3740               -1   c4851               -1
    x1222     c6778                1
    x1223     c2146               -1   c2149               -1
    x1223     c2154               -1   c4875                1
    x1223     c4878               -1   c4879               -1
    x1223     c6457               -1   c6458               -1
    x1224     c2146                1   c2147                1
    x1224     c2148                1   c4867               -1
    x1224     c4868               -1   c6767                1
    x1225     c2147               -1   c2171               -1
    x1225     c4861               -1   c4862               -1
    x1225     c4863               -1   c4884                1
    x1225     c4885               -1   c4886               -1
    x1225     c6454               -1   c6455               -1
    x1225     c6456               -1
    x1226     c2148               -1   c2155               -1
    x1226     c4858               -1   c4859               -1
    x1226     c4860               -1   c4875                1
    x1226     c4876               -1   c4877               -1
    x1226     c6451               -1   c6452               -1
    x1226     c6453               -1
    x1227     c2150                1   c2151               -1
    x1227     c2152                1   c2153               -1
    x1227     c2160               -1   c2161               -1
    x1227     c4880                1   c4881                1
    x1227     c4882               -1
    x1228     c2150               -1   c2151                1
    x1228     c4852                1   c4856               -1
    x1228     c4857               -1   c4864               -1
    x1228     c4866               -1   c4878                1
    x1228     c4879               -1   c6452                1
    x1228     c6453                1   c6455                1
    x1228     c6456                1   c6457               -1
    x1229     c2152               -1   c2153                1
    x1229     c4853                1   c4855               -1
    x1229     c4857               -1   c4859               -1
    x1229     c4861               -1   c4863               -1
    x1229     c4876                1   c4877               -1
    x1229     c6452               -1   c6457                1
    x1229     c6459                1
    x1230     c2154                1   c2155                1
    x1230     c2162                1   c4875               -1
    x1230     c4881               -1   c4882               -1
    x1231     c2156                1   c2157               -1
    x1231     c2158                1   c2159               -1
    x1231     c2164               -1   c2165               -1
    x1231     c4881                1   c4882               -1
    x1231     c4883                1
    x1232     c2156               -1   c2157                1
    x1232     c4865               -1   c4866               -1
    x1232     c4869                1   c4873               -1
    x1232     c4874               -1   c4878                1
    x1232     c4879               -1   c6451                1
    x1232     c6453                1   c6454                1
    x1232     c6456                1   c6458               -1
    x1233     c2158               -1   c2159                1
    x1233     c4858               -1   c4862               -1
    x1233     c4863               -1   c4870                1
    x1233     c4872               -1   c4874               -1
    x1233     c4876                1   c4877               -1
    x1233     c6451               -1   c6458                1
    x1233     c6460                1
    x1234     c2161               -1   c2166               -1
    x1234     c2167                1   c4880                1
    x1234     c4887                1   c4888               -1
    x1235     c2162               -1   c2163               -1
    x1235     c2170               -1   c4884                1
    x1235     c4887               -1   c4888               -1
    x1236     c2165               -1   c2172               -1
    x1236     c2173                1   c4883                1
    x1236     c4887                1   c4888               -1
    x1237     c2166                1   c2167               -1
    x1237     c2168                1   c2169               -1
    x1237     c2176                1   c2177                1
    x1237     c4889               -1   c4890                1
    x1237     c4891               -1
    x1238     c2168               -1   c2169                1
    x1238     c4853                1   c4854               -1
    x1238     c4856               -1   c4858               -1
    x1238     c4860               -1   c4862               -1
    x1238     c4885                1   c4886               -1
    x1238     c6455               -1   c6457                1
    x1238     c6459                1
    x1239     c2170                1   c2171                1
    x1239     c2178                1   c4884               -1
    x1239     c4890               -1   c4891               -1
    x1240     c2172                1   c2173               -1
    x1240     c2174                1   c2175               -1
    x1240     c2180                1   c2181                1
    x1240     c4890                1   c4891               -1
    x1240     c4892               -1
    x1241     c2174               -1   c2175                1
    x1241     c4859               -1   c4860               -1
    x1241     c4861               -1   c4870                1
    x1241     c4871               -1   c4873               -1
    x1241     c4885                1   c4886               -1
    x1241     c6454               -1   c6458                1
    x1241     c6460                1
    x1242     c2182               -1   c2184                1
    x1242     c4893                1   c4894               -1
    x1242     c4911                1   c4912               -1
    x1242     c4913                1   c4914                1
    x1242     c4915               -1   c4916               -1
    x1242     c4917               -1   c4918               -1
    x1243     c2182               -1   c2183               -1
    x1243     c2187               -1   c4893                1
    x1243     c4895                1
    x1244     c2183                1   c2185               -1
    x1244     c4893               -1   c4894                1
    x1244     c4896                1   c4897                1
    x1244     c4898               -1   c4899               -1
    x1244     c4900               -1   c4901               -1
    x1244     c4911                1   c4912               -1
    x1245     c2184               -1   c2185               -1
    x1245     c2186               -1   c4894                1
    x1245     c4895                1
    x1246     c2186                1   c2187                1
    x1246     c3739               -1   c4895               -1
    x1246     c6778                1
    x1247     c2188               -1   c2191               -1
    x1247     c2196               -1   c4919                1
    x1247     c4922               -1   c4923               -1
    x1247     c6467               -1   c6468               -1
    x1248     c2188                1   c2189                1
    x1248     c2190                1   c4911               -1
    x1248     c4912               -1   c6767                1
    x1249     c2189               -1   c2212               -1
    x1249     c4905               -1   c4906               -1
    x1249     c4907               -1   c4928                1
    x1249     c4931               -1   c4932               -1
    x1249     c6464               -1   c6465               -1
    x1249     c6466               -1
    x1250     c2190               -1   c2197               -1
    x1250     c4902               -1   c4903               -1
    x1250     c4904               -1   c4919                1
    x1250     c4920               -1   c4921               -1
    x1250     c6461               -1   c6462               -1
    x1250     c6463               -1
    x1251     c2192                1   c2193               -1
    x1251     c2194                1   c2195               -1
    x1251     c2202               -1   c2203               -1
    x1251     c4924                1   c4925                1
    x1251     c4926               -1
    x1252     c2192               -1   c2193                1
    x1252     c4896                1   c4900               -1
    x1252     c4901               -1   c4908               -1
    x1252     c4910               -1   c4922                1
    x1252     c4923               -1   c6462                1
    x1252     c6463                1   c6465                1
    x1252     c6466                1   c6467               -1
    x1253     c2194               -1   c2195                1
    x1253     c4897                1   c4899               -1
    x1253     c4901               -1   c4903               -1
    x1253     c4905               -1   c4907               -1
    x1253     c4920                1   c4921               -1
    x1253     c6462               -1   c6467                1
    x1253     c6469                1
    x1254     c2196                1   c2197                1
    x1254     c2204                1   c4919               -1
    x1254     c4925               -1   c4926               -1
    x1255     c2198                1   c2199               -1
    x1255     c2200                1   c2201               -1
    x1255     c2206               -1   c2207               -1
    x1255     c4925                1   c4926               -1
    x1255     c4927                1
    x1256     c2198               -1   c2199                1
    x1256     c4909               -1   c4910               -1
    x1256     c4913                1   c4917               -1
    x1256     c4918               -1   c4922                1
    x1256     c4923               -1   c6461                1
    x1256     c6463                1   c6464                1
    x1256     c6466                1   c6468               -1
    x1257     c2200               -1   c2201                1
    x1257     c4902               -1   c4906               -1
    x1257     c4907               -1   c4914                1
    x1257     c4916               -1   c4918               -1
    x1257     c4920                1   c4921               -1
    x1257     c6461               -1   c6468                1
    x1257     c6470                1
    x1258     c2203               -1   c2210               -1
    x1258     c2211                1   c4924                1
    x1258     c4929                1   c4930               -1
    x1259     c2204               -1   c2205               -1
    x1259     c2213               -1   c4928                1
    x1259     c4929               -1   c4930               -1
    x1260     c2207               -1   c2216               -1
    x1260     c2217                1   c4927                1
    x1260     c4929                1   c4930               -1
    x1261     c2208                1   c2209               -1
    x1261     c2210                1   c2211               -1
    x1261     c2218                1   c2219                1
    x1261     c4933               -1   c4934                1
    x1261     c4935               -1
    x1262     c2208               -1   c2209                1
    x1262     c4897                1   c4898               -1
    x1262     c4900               -1   c4902               -1
    x1262     c4904               -1   c4906               -1
    x1262     c4931                1   c4932               -1
    x1262     c6465               -1   c6467                1
    x1262     c6469                1
    x1263     c2212                1   c2213                1
    x1263     c2220                1   c4928               -1
    x1263     c4934               -1   c4935               -1
    x1264     c2214                1   c2215               -1
    x1264     c2216                1   c2217               -1
    x1264     c2222                1   c2223                1
    x1264     c4934                1   c4935               -1
    x1264     c4936               -1
    x1265     c2214               -1   c2215                1
    x1265     c4903               -1   c4904               -1
    x1265     c4905               -1   c4914                1
    x1265     c4915               -1   c4917               -1
    x1265     c4931                1   c4932               -1
    x1265     c6464               -1   c6468                1
    x1265     c6470                1
    x1266     c2224               -1   c2226                1
    x1266     c4937                1   c4938               -1
    x1266     c4955                1   c4956               -1
    x1266     c4957                1   c4958                1
    x1266     c4959               -1   c4960               -1
    x1266     c4961               -1   c4962               -1
    x1267     c2224               -1   c2225               -1
    x1267     c2229               -1   c4937                1
    x1267     c4939                1
    x1268     c2225                1   c2227               -1
    x1268     c4937               -1   c4938                1
    x1268     c4940                1   c4941                1
    x1268     c4942               -1   c4943               -1
    x1268     c4944               -1   c4945               -1
    x1268     c4955                1   c4956               -1
    x1269     c2226               -1   c2227               -1
    x1269     c2228               -1   c4938                1
    x1269     c4939                1
    x1270     c2228                1   c2229                1
    x1270     c3738               -1   c4939               -1
    x1270     c6778                1
    x1271     c2230               -1   c2233               -1
    x1271     c2238               -1   c4963                1
    x1271     c4966               -1   c4967               -1
    x1271     c6477               -1   c6478               -1
    x1272     c2230                1   c2231                1
    x1272     c2232                1   c4955               -1
    x1272     c4956               -1   c6766                1
    x1273     c2231               -1   c2254               -1
    x1273     c4949               -1   c4950               -1
    x1273     c4951               -1   c4972                1
    x1273     c4975               -1   c4976               -1
    x1273     c6474               -1   c6475               -1
    x1273     c6476               -1
    x1274     c2232               -1   c2239               -1
    x1274     c4946               -1   c4947               -1
    x1274     c4948               -1   c4963                1
    x1274     c4964               -1   c4965               -1
    x1274     c6471               -1   c6472               -1
    x1274     c6473               -1
    x1275     c2234                1   c2235               -1
    x1275     c2236                1   c2237               -1
    x1275     c2244               -1   c2245               -1
    x1275     c4968                1   c4969                1
    x1275     c4970               -1
    x1276     c2234               -1   c2235                1
    x1276     c4940                1   c4944               -1
    x1276     c4945               -1   c4952               -1
    x1276     c4954               -1   c4966                1
    x1276     c4967               -1   c6472                1
    x1276     c6473                1   c6475                1
    x1276     c6476                1   c6477               -1
    x1277     c2236               -1   c2237                1
    x1277     c4941                1   c4943               -1
    x1277     c4945               -1   c4947               -1
    x1277     c4949               -1   c4951               -1
    x1277     c4964                1   c4965               -1
    x1277     c6472               -1   c6477                1
    x1277     c6479                1
    x1278     c2238                1   c2239                1
    x1278     c2246                1   c4963               -1
    x1278     c4969               -1   c4970               -1
    x1279     c2240                1   c2241               -1
    x1279     c2242                1   c2243               -1
    x1279     c2248               -1   c2249               -1
    x1279     c4969                1   c4970               -1
    x1279     c4971                1
    x1280     c2240               -1   c2241                1
    x1280     c4953               -1   c4954               -1
    x1280     c4957                1   c4961               -1
    x1280     c4962               -1   c4966                1
    x1280     c4967               -1   c6471                1
    x1280     c6473                1   c6474                1
    x1280     c6476                1   c6478               -1
    x1281     c2242               -1   c2243                1
    x1281     c4946               -1   c4950               -1
    x1281     c4951               -1   c4958                1
    x1281     c4960               -1   c4962               -1
    x1281     c4964                1   c4965               -1
    x1281     c6471               -1   c6478                1
    x1281     c6480                1
    x1282     c2245               -1   c2252               -1
    x1282     c2253                1   c4968                1
    x1282     c4973                1   c4974               -1
    x1283     c2246               -1   c2247               -1
    x1283     c2255               -1   c4972                1
    x1283     c4973               -1   c4974               -1
    x1284     c2249               -1   c2258               -1
    x1284     c2259                1   c4971                1
    x1284     c4973                1   c4974               -1
    x1285     c2250                1   c2251               -1
    x1285     c2252                1   c2253               -1
    x1285     c2260                1   c2261                1
    x1285     c4977               -1   c4978                1
    x1285     c4979               -1
    x1286     c2250               -1   c2251                1
    x1286     c4941                1   c4942               -1
    x1286     c4944               -1   c4946               -1
    x1286     c4948               -1   c4950               -1
    x1286     c4975                1   c4976               -1
    x1286     c6475               -1   c6477                1
    x1286     c6479                1
    x1287     c2254                1   c2255                1
    x1287     c2262                1   c4972               -1
    x1287     c4978               -1   c4979               -1
    x1288     c2256                1   c2257               -1
    x1288     c2258                1   c2259               -1
    x1288     c2264                1   c2265                1
    x1288     c4978                1   c4979               -1
    x1288     c4980               -1
    x1289     c2256               -1   c2257                1
    x1289     c4947               -1   c4948               -1
    x1289     c4949               -1   c4958                1
    x1289     c4959               -1   c4961               -1
    x1289     c4975                1   c4976               -1
    x1289     c6474               -1   c6478                1
    x1289     c6480                1
    x1290     c2266               -1   c2268                1
    x1290     c4981                1   c4982               -1
    x1290     c4999                1   c5000               -1
    x1290     c5001                1   c5002                1
    x1290     c5003               -1   c5004               -1
    x1290     c5005               -1   c5006               -1
    x1291     c2266               -1   c2267               -1
    x1291     c2271               -1   c4981                1
    x1291     c4983                1
    x1292     c2267                1   c2269               -1
    x1292     c4981               -1   c4982                1
    x1292     c4984                1   c4985                1
    x1292     c4986               -1   c4987               -1
    x1292     c4988               -1   c4989               -1
    x1292     c4999                1   c5000               -1
    x1293     c2268               -1   c2269               -1
    x1293     c2270               -1   c4982                1
    x1293     c4983                1
    x1294     c2270                1   c2271                1
    x1294     c3737               -1   c4983               -1
    x1294     c6777                1
    x1295     c2272               -1   c2275               -1
    x1295     c2280               -1   c5007                1
    x1295     c5010               -1   c5011               -1
    x1295     c6487               -1   c6488               -1
    x1296     c2272                1   c2273                1
    x1296     c2274                1   c4999               -1
    x1296     c5000               -1   c6766                1
    x1297     c2273               -1   c2296               -1
    x1297     c4993               -1   c4994               -1
    x1297     c4995               -1   c5016                1
    x1297     c5019               -1   c5020               -1
    x1297     c6484               -1   c6485               -1
    x1297     c6486               -1
    x1298     c2274               -1   c2281               -1
    x1298     c4990               -1   c4991               -1
    x1298     c4992               -1   c5007                1
    x1298     c5008               -1   c5009               -1
    x1298     c6481               -1   c6482               -1
    x1298     c6483               -1
    x1299     c2276                1   c2277               -1
    x1299     c2278                1   c2279               -1
    x1299     c2286               -1   c2287               -1
    x1299     c5012                1   c5013                1
    x1299     c5014               -1
    x1300     c2276               -1   c2277                1
    x1300     c4984                1   c4988               -1
    x1300     c4989               -1   c4996               -1
    x1300     c4998               -1   c5010                1
    x1300     c5011               -1   c6482                1
    x1300     c6483                1   c6485                1
    x1300     c6486                1   c6487               -1
    x1301     c2278               -1   c2279                1
    x1301     c4985                1   c4987               -1
    x1301     c4989               -1   c4991               -1
    x1301     c4993               -1   c4995               -1
    x1301     c5008                1   c5009               -1
    x1301     c6482               -1   c6487                1
    x1301     c6489                1
    x1302     c2280                1   c2281                1
    x1302     c2288                1   c5007               -1
    x1302     c5013               -1   c5014               -1
    x1303     c2282                1   c2283               -1
    x1303     c2284                1   c2285               -1
    x1303     c2290               -1   c2291               -1
    x1303     c5013                1   c5014               -1
    x1303     c5015                1
    x1304     c2282               -1   c2283                1
    x1304     c4997               -1   c4998               -1
    x1304     c5001                1   c5005               -1
    x1304     c5006               -1   c5010                1
    x1304     c5011               -1   c6481                1
    x1304     c6483                1   c6484                1
    x1304     c6486                1   c6488               -1
    x1305     c2284               -1   c2285                1
    x1305     c4990               -1   c4994               -1
    x1305     c4995               -1   c5002                1
    x1305     c5004               -1   c5006               -1
    x1305     c5008                1   c5009               -1
    x1305     c6481               -1   c6488                1
    x1305     c6490                1
    x1306     c2287               -1   c2294               -1
    x1306     c2295                1   c5012                1
    x1306     c5017                1   c5018               -1
    x1307     c2288               -1   c2289               -1
    x1307     c2297               -1   c5016                1
    x1307     c5017               -1   c5018               -1
    x1308     c2291               -1   c2300               -1
    x1308     c2301                1   c5015                1
    x1308     c5017                1   c5018               -1
    x1309     c2292                1   c2293               -1
    x1309     c2294                1   c2295               -1
    x1309     c2302                1   c2303                1
    x1309     c5021               -1   c5022                1
    x1309     c5023               -1
    x1310     c2292               -1   c2293                1
    x1310     c4985                1   c4986               -1
    x1310     c4988               -1   c4990               -1
    x1310     c4992               -1   c4994               -1
    x1310     c5019                1   c5020               -1
    x1310     c6485               -1   c6487                1
    x1310     c6489                1
    x1311     c2296                1   c2297                1
    x1311     c2304                1   c5016               -1
    x1311     c5022               -1   c5023               -1
    x1312     c2298                1   c2299               -1
    x1312     c2300                1   c2301               -1
    x1312     c2306                1   c2307                1
    x1312     c5022                1   c5023               -1
    x1312     c5024               -1
    x1313     c2298               -1   c2299                1
    x1313     c4991               -1   c4992               -1
    x1313     c4993               -1   c5002                1
    x1313     c5003               -1   c5005               -1
    x1313     c5019                1   c5020               -1
    x1313     c6484               -1   c6488                1
    x1313     c6490                1
    x1314     c2303                1   c2308               -1
    x1314     c2309                1   c5021               -1
    x1314     c5029                1   c5030               -1
    x1315     c2304               -1   c2305               -1
    x1315     c2314               -1   c5029               -1
    x1315     c5030               -1   c6491                1
    x1316     c2307                1   c2317               -1
    x1316     c2318                1   c5024               -1
    x1316     c5029                1   c5030               -1
    x1317     c2308                1   c2309               -1
    x1317     c2310                1   c2311               -1
    x1317     c2312                1   c2313               -1
    x1317     c2323               -1   c2324               -1
    x1317     c5031                1   c5032                1
    x1317     c5033               -1
    x1318     c2310               -1   c2311                1
    x1318     c2392                1   c5027                1
    x1318     c5028               -1   c5083               -1
    x1319     c2312               -1   c2313                1
    x1319     c2460                1   c2461               -1
    x1319     c5025                1   c5026               -1
    x1320     c2314                1   c2315                1
    x1320     c2316                1   c2325                1
    x1320     c5032               -1   c5033               -1
    x1320     c6491               -1
    x1321     c2315               -1   c2393               -1
    x1321     c2394               -1   c5027               -1
    x1321     c5028               -1   c6491                1
    x1322     c2316               -1   c2462               -1
    x1322     c5025               -1   c5026               -1
    x1322     c6491                1
    x1323     c2317                1   c2318               -1
    x1323     c2319                1   c2320               -1
    x1323     c2321                1   c2322               -1
    x1323     c2327               -1   c2328               -1
    x1323     c5032                1   c5033               -1
    x1323     c5034                1
    x1324     c2319               -1   c2320                1
    x1324     c2396                1   c5027                1
    x1324     c5028               -1   c5086               -1
    x1325     c2321               -1   c2322                1
    x1325     c2463                1   c2464               -1
    x1325     c5025                1   c5026               -1
    x1326     c2323               -1   c2329                1
    x1326     c2330                1   c2331                1
    x1326     c2332                1   c5031                1
    x1326     c5041                1   c5042               -1
    x1326     c6743               -1
    x1327     c2325               -1   c2326               -1
    x1327     c2333                1   c2334                1
    x1327     c5041               -1   c5042               -1
    x1328     c2327               -1   c2339                1
    x1328     c2340                1   c2341                1
    x1328     c2342                1   c5034                1
    x1328     c5041                1   c5042               -1
    x1328     c6744               -1
    x1329     c2330                1   c2335                1
    x1329     c2337                1   c2340                1
    x1329     c2345               -1   c2346                1
    x1329     c6743               -1   c6744               -1
    x1330     c2343                1   c2344               -1
    x1330     c2345                1   c2346               -1
    x1330     c2347                1   c2348               -1
    x1330     c2349                1   c2350               -1
    x1330     c2351                1   c2352               -1
    x1330     c2353                1   c2354               -1
    x1331     c2343               -1   c2344                1
    x1331     c3305                1   c3308                1
    x1331     c3309                1   c5945               -1
    x1331     c5948               -1
    x1332     c2347               -1   c2348                1
    x1332     c2900               -1   c2903               -1
    x1332     c2904               -1   c5549                1
    x1332     c5552                1
    x1333     c2349               -1   c2350                1
    x1333     c2586                1   c2591                1
    x1333     c2593                1   c2596                1
    x1333     c6745               -1   c6746               -1
    x1334     c2351               -1   c2352                1
    x1334     c2942                1   c2945                1
    x1334     c2946                1   c5593               -1
    x1334     c5596               -1
    x1335     c2355               -1   c2357                1
    x1335     c5043                1   c5044               -1
    x1335     c5061                1   c5062               -1
    x1335     c5063                1   c5064                1
    x1335     c5065               -1   c5066               -1
    x1335     c5067               -1   c5068               -1
    x1336     c2355               -1   c2356               -1
    x1336     c2360               -1   c5043                1
    x1336     c5045                1
    x1337     c2356                1   c2358               -1
    x1337     c5043               -1   c5044                1
    x1337     c5046                1   c5047                1
    x1337     c5048               -1   c5049               -1
    x1337     c5050               -1   c5051               -1
    x1337     c5061                1   c5062               -1
    x1338     c2357               -1   c2358               -1
    x1338     c2359               -1   c5044                1
    x1338     c5045                1
    x1339     c2359                1   c2360                1
    x1339     c3736               -1   c5045               -1
    x1339     c6777                1
    x1340     c2361               -1   c2364               -1
    x1340     c2369               -1   c5069                1
    x1340     c5072               -1   c5073               -1
    x1340     c6498               -1   c6499               -1
    x1341     c2361                1   c2362                1
    x1341     c2363                1   c5061               -1
    x1341     c5062               -1   c6766                1
    x1342     c2362               -1   c2385               -1
    x1342     c5055               -1   c5056               -1
    x1342     c5057               -1   c5078                1
    x1342     c5081               -1   c5082               -1
    x1342     c6495               -1   c6496               -1
    x1342     c6497               -1
    x1343     c2363               -1   c2370               -1
    x1343     c5052               -1   c5053               -1
    x1343     c5054               -1   c5069                1
    x1343     c5070               -1   c5071               -1
    x1343     c6492               -1   c6493               -1
    x1343     c6494               -1
    x1344     c2364               -1   c2397               -1
    x1344     c2398                1   c5046                1
    x1344     c5048               -1   c5049               -1
    x1344     c5059               -1   c5063                1
    x1344     c5065               -1   c5066               -1
    x1344     c6492                1   c6493                1
    x1344     c6494                1   c6495                1
    x1344     c6496                1   c6497                1
    x1344     c6500               -1
    x1345     c2365                1   c2366               -1
    x1345     c2367                1   c2368               -1
    x1345     c2375               -1   c2376               -1
    x1345     c5074                1   c5075                1
    x1345     c5076               -1
    x1346     c2365               -1   c2366                1
    x1346     c5046                1   c5050               -1
    x1346     c5051               -1   c5058               -1
    x1346     c5060               -1   c5072                1
    x1346     c5073               -1   c6493                1
    x1346     c6494                1   c6496                1
    x1346     c6497                1   c6498               -1
    x1347     c2367               -1   c2368                1
    x1347     c5047                1   c5049               -1
    x1347     c5051               -1   c5053               -1
    x1347     c5055               -1   c5057               -1
    x1347     c5070                1   c5071               -1
    x1347     c6493               -1   c6498                1
    x1347     c6500                1
    x1348     c2369                1   c2370                1
    x1348     c2377                1   c5069               -1
    x1348     c5075               -1   c5076               -1
    x1349     c2371                1   c2372               -1
    x1349     c2373                1   c2374               -1
    x1349     c2379               -1   c2380               -1
    x1349     c5075                1   c5076               -1
    x1349     c5077                1
    x1350     c2371               -1   c2372                1
    x1350     c5059               -1   c5060               -1
    x1350     c5063                1   c5067               -1
    x1350     c5068               -1   c5072                1
    x1350     c5073               -1   c6492                1
    x1350     c6494                1   c6495                1
    x1350     c6497                1   c6499               -1
    x1351     c2373               -1   c2374                1
    x1351     c5052               -1   c5056               -1
    x1351     c5057               -1   c5064                1
    x1351     c5066               -1   c5068               -1
    x1351     c5070                1   c5071               -1
    x1351     c6492               -1   c6499                1
    x1351     c6501                1
    x1352     c2375               -1   c2378               -1
    x1352     c2379               -1   c2399               -1
    x1352     c2400                1   c5074                1
    x1352     c5077                1
    x1353     c2376               -1   c2383               -1
    x1353     c2384                1   c5074                1
    x1353     c5079                1   c5080               -1
    x1354     c2377               -1   c2378               -1
    x1354     c2386               -1   c5078                1
    x1354     c5079               -1   c5080               -1
    x1355     c2380               -1   c2389               -1
    x1355     c2390                1   c5077                1
    x1355     c5079                1   c5080               -1
    x1356     c2381                1   c2382               -1
    x1356     c2383                1   c2384               -1
    x1356     c2391                1   c2392                1
    x1356     c5083               -1   c5084                1
    x1356     c5085               -1
    x1357     c2381               -1   c2382                1
    x1357     c5047                1   c5048               -1
    x1357     c5050               -1   c5052               -1
    x1357     c5054               -1   c5056               -1
    x1357     c5081                1   c5082               -1
    x1357     c6496               -1   c6498                1
    x1357     c6500                1
    x1358     c2385                1   c2386                1
    x1358     c2393                1   c5078               -1
    x1358     c5084               -1   c5085               -1
    x1359     c2387                1   c2388               -1
    x1359     c2389                1   c2390               -1
    x1359     c2395                1   c2396                1
    x1359     c5084                1   c5085               -1
    x1359     c5086               -1
    x1360     c2387               -1   c2388                1
    x1360     c5053               -1   c5054               -1
    x1360     c5055               -1   c5064                1
    x1360     c5065               -1   c5067               -1
    x1360     c5081                1   c5082               -1
    x1360     c6495               -1   c6499                1
    x1360     c6501                1
    x1361     c2397                1   c2398               -1
    x1361     c2399                1   c2400               -1
    x1361     c2401                1   c2402               -1
    x1362     c2403               -1   c2405                1
    x1362     c2412                1   c2413               -1
    x1362     c5087                1   c5088               -1
    x1362     c5090                1   c5091               -1
    x1363     c2403               -1   c2404               -1
    x1363     c2408               -1   c5087                1
    x1363     c5089                1
    x1364     c2404                1   c2406               -1
    x1364     c2409                1   c2410               -1
    x1364     c5087               -1   c5088                1
    x1364     c5090                1   c5091               -1
    x1365     c2405               -1   c2406               -1
    x1365     c2407               -1   c5088                1
    x1365     c5089                1
    x1366     c2407                1   c2408                1
    x1366     c3735               -1   c5089               -1
    x1366     c6777                1
    x1367     c2409                1   c2410               -1
    x1367     c5092               -1   c5093               -1
    x1367     c5094                1   c5095                1
    x1367     c5096                1   c5097                1
    x1367     c5107                1   c5108               -1
    x1368     c2411               -1   c2414                1
    x1368     c2415                1   c2416                1
    x1368     c5107               -1   c5108               -1
    x1369     c2411                1   c5090               -1
    x1369     c5091               -1   c6766                1
    x1370     c2412                1   c2413               -1
    x1370     c5107                1   c5108               -1
    x1370     c5109               -1   c5110               -1
    x1370     c5111                1   c5112                1
    x1370     c5113                1   c5114                1
    x1371     c2414               -1   c2417               -1
    x1371     c2422               -1   c5115                1
    x1371     c5118               -1   c5119               -1
    x1371     c6508               -1   c6509               -1
    x1372     c2415               -1   c2438               -1
    x1372     c5101               -1   c5102               -1
    x1372     c5103               -1   c5124                1
    x1372     c5127               -1   c5128               -1
    x1372     c6505               -1   c6506               -1
    x1372     c6507               -1
    x1373     c2416               -1   c2423               -1
    x1373     c5098               -1   c5099               -1
    x1373     c5100               -1   c5115                1
    x1373     c5116               -1   c5117               -1
    x1373     c6502               -1   c6503               -1
    x1373     c6504               -1
    x1374     c2418                1   c2419               -1
    x1374     c2420                1   c2421               -1
    x1374     c2428                1   c2429                1
    x1374     c5120               -1   c5121                1
    x1374     c5122               -1
    x1375     c2418               -1   c2419                1
    x1375     c5092               -1   c5096                1
    x1375     c5097                1   c5105                1
    x1375     c5106                1   c5118                1
    x1375     c5119               -1   c6502               -1
    x1375     c6504               -1   c6505               -1
    x1375     c6507               -1   c6508                1
    x1376     c2420               -1   c2421                1
    x1376     c5093               -1   c5095                1
    x1376     c5097                1   c5099               -1
    x1376     c5102                1   c5103                1
    x1376     c5116                1   c5117               -1
    x1376     c6503               -1   c6508               -1
    x1376     c6510               -1
    x1377     c2422                1   c2423                1
    x1377     c2430                1   c5115               -1
    x1377     c5121               -1   c5122               -1
    x1378     c2424                1   c2425               -1
    x1378     c2426                1   c2427               -1
    x1378     c2432                1   c2433                1
    x1378     c5121                1   c5122               -1
    x1378     c5123               -1
    x1379     c2424               -1   c2425                1
    x1379     c5104                1   c5106                1
    x1379     c5109               -1   c5113                1
    x1379     c5114                1   c5118                1
    x1379     c5119               -1   c6503               -1
    x1379     c6504               -1   c6506               -1
    x1379     c6507               -1   c6509                1
    x1380     c2426               -1   c2427                1
    x1380     c5098               -1   c5101                1
    x1380     c5103                1   c5110               -1
    x1380     c5112                1   c5114                1
    x1380     c5116                1   c5117               -1
    x1380     c6502               -1   c6509               -1
    x1380     c6511               -1
    x1381     c2429                1   c2436               -1
    x1381     c2437                1   c5120               -1
    x1381     c5125                1   c5126               -1
    x1382     c2430               -1   c2431               -1
    x1382     c2439               -1   c5124                1
    x1382     c5125               -1   c5126               -1
    x1383     c2433                1   c2442               -1
    x1383     c2443                1   c5123               -1
    x1383     c5125                1   c5126               -1
    x1384     c2434                1   c2435               -1
    x1384     c2436                1   c2437               -1
    x1384     c2444               -1   c2445               -1
    x1384     c5129                1   c5130                1
    x1384     c5131               -1
    x1385     c2434               -1   c2435                1
    x1385     c5093               -1   c5094                1
    x1385     c5096                1   c5099                1
    x1385     c5100                1   c5102               -1
    x1385     c5127                1   c5128               -1
    x1385     c6506               -1   c6508               -1
    x1385     c6510               -1
    x1386     c2438                1   c2439                1
    x1386     c2446                1   c5124               -1
    x1386     c5130               -1   c5131               -1
    x1387     c2440                1   c2441               -1
    x1387     c2442                1   c2443               -1
    x1387     c2448               -1   c2449               -1
    x1387     c5130                1   c5131               -1
    x1387     c5132                1
    x1388     c2440               -1   c2441                1
    x1388     c5098                1   c5100                1
    x1388     c5101               -1   c5110               -1
    x1388     c5111                1   c5113                1
    x1388     c5127                1   c5128               -1
    x1388     c6505               -1   c6509               -1
    x1388     c6511               -1
    x1389     c2444               -1   c2447               -1
    x1389     c2448               -1   c2471               -1
    x1389     c2472                1   c5129                1
    x1389     c5132                1
    x1390     c2445               -1   c2450               -1
    x1390     c2451                1   c5129                1
    x1390     c5136                1   c5137               -1
    x1391     c2446               -1   c2447               -1
    x1391     c2454               -1   c5133                1
    x1391     c5136               -1   c5137               -1
    x1392     c2449               -1   c2456               -1
    x1392     c2457                1   c5132                1
    x1392     c5136                1   c5137               -1
    x1393     c2450                1   c2451               -1
    x1393     c2452                1   c2453               -1
    x1393     c2460                1   c2461               -1
    x1393     c5138                1   c5139               -1
    x1394     c2452               -1   c2453                1
    x1394     c2517               -1   c5134                1
    x1394     c5135               -1   c5182                1
    x1395     c2454                1   c2455                1
    x1395     c2462                1   c5133               -1
    x1395     c5138               -1   c5139               -1
    x1396     c2455               -1   c2518               -1
    x1396     c2519               -1   c5133                1
    x1396     c5134               -1   c5135               -1
    x1397     c2456                1   c2457               -1
    x1397     c2458                1   c2459               -1
    x1397     c2463                1   c2464               -1
    x1397     c5138                1   c5139               -1
    x1398     c2458               -1   c2459                1
    x1398     c2521               -1   c5134                1
    x1398     c5135               -1   c5185                1
    x1399     c2465                1   c2466               -1
    x1399     c2467                1   c2468               -1
    x1399     c2469                1   c2470               -1
    x1399     c2471                1   c2472               -1
    x1399     c2473                1   c2474               -1
    x1400     c2465               -1   c2466                1
    x1400     c2807                1   c2814                1
    x1400     c2815                1   c6747               -1
    x1400     c6748               -1
    x1401     c2467               -1   c2468                1
    x1401     c2702               -1   c2705               -1
    x1401     c2706               -1   c5343                1
    x1401     c5346                1
    x1402     c2469               -1   c2470                1
    x1402     c3548                1   c3555                1
    x1402     c3556                1   c6758               -1
    x1402     c6759               -1
    x1403     c2475               -1   c2477                1
    x1403     c2484                1   c2485               -1
    x1403     c5140                1   c5141               -1
    x1403     c5143                1   c5144               -1
    x1404     c2475               -1   c2476               -1
    x1404     c2480               -1   c5140                1
    x1404     c5142                1
    x1405     c2476                1   c2478               -1
    x1405     c2481                1   c2482               -1
    x1405     c5140               -1   c5141                1
    x1405     c5143                1   c5144               -1
    x1406     c2477               -1   c2478               -1
    x1406     c2479               -1   c5141                1
    x1406     c5142                1
    x1407     c2479                1   c2480                1
    x1407     c3734               -1   c5142               -1
    x1407     c6777                1
    x1408     c2481                1   c2482               -1
    x1408     c5145               -1   c5146               -1
    x1408     c5147                1   c5148                1
    x1408     c5149                1   c5150                1
    x1408     c5160                1   c5161               -1
    x1409     c2483               -1   c2486                1
    x1409     c2487                1   c2488                1
    x1409     c5160               -1   c5161               -1
    x1410     c2483                1   c5143               -1
    x1410     c5144               -1   c6765                1
    x1411     c2484                1   c2485               -1
    x1411     c5160                1   c5161               -1
    x1411     c5162               -1   c5163               -1
    x1411     c5164                1   c5165                1
    x1411     c5166                1   c5167                1
    x1412     c2486               -1   c2489               -1
    x1412     c2494               -1   c5168                1
    x1412     c5171               -1   c5172               -1
    x1412     c6518               -1   c6519               -1
    x1413     c2487               -1   c2510               -1
    x1413     c5154               -1   c5155               -1
    x1413     c5156               -1   c5177                1
    x1413     c5180               -1   c5181               -1
    x1413     c6515               -1   c6516               -1
    x1413     c6517               -1
    x1414     c2488               -1   c2495               -1
    x1414     c5151               -1   c5152               -1
    x1414     c5153               -1   c5168                1
    x1414     c5169               -1   c5170               -1
    x1414     c6512               -1   c6513               -1
    x1414     c6514               -1
    x1415     c2490                1   c2491               -1
    x1415     c2492                1   c2493               -1
    x1415     c2500                1   c2501                1
    x1415     c5173               -1   c5174                1
    x1415     c5175               -1
    x1416     c2490               -1   c2491                1
    x1416     c5145               -1   c5149                1
    x1416     c5150                1   c5158                1
    x1416     c5159                1   c5171                1
    x1416     c5172               -1   c6512               -1
    x1416     c6514               -1   c6515               -1
    x1416     c6517               -1   c6518                1
    x1417     c2492               -1   c2493                1
    x1417     c5146               -1   c5148                1
    x1417     c5150                1   c5152               -1
    x1417     c5155                1   c5156                1
    x1417     c5169                1   c5170               -1
    x1417     c6513               -1   c6518               -1
    x1417     c6520               -1
    x1418     c2494                1   c2495                1
    x1418     c2502                1   c5168               -1
    x1418     c5174               -1   c5175               -1
    x1419     c2496                1   c2497               -1
    x1419     c2498                1   c2499               -1
    x1419     c2504                1   c2505                1
    x1419     c5174                1   c5175               -1
    x1419     c5176               -1
    x1420     c2496               -1   c2497                1
    x1420     c5157                1   c5159                1
    x1420     c5162               -1   c5166                1
    x1420     c5167                1   c5171                1
    x1420     c5172               -1   c6513               -1
    x1420     c6514               -1   c6516               -1
    x1420     c6517               -1   c6519                1
    x1421     c2498               -1   c2499                1
    x1421     c5151               -1   c5154                1
    x1421     c5156                1   c5163               -1
    x1421     c5165                1   c5167                1
    x1421     c5169                1   c5170               -1
    x1421     c6512               -1   c6519               -1
    x1421     c6521               -1
    x1422     c2501                1   c2508               -1
    x1422     c2509                1   c5173               -1
    x1422     c5178                1   c5179               -1
    x1423     c2502               -1   c2503               -1
    x1423     c2511               -1   c5177                1
    x1423     c5178               -1   c5179               -1
    x1424     c2505                1   c2514               -1
    x1424     c2515                1   c5176               -1
    x1424     c5178                1   c5179               -1
    x1425     c2506                1   c2507               -1
    x1425     c2508                1   c2509               -1
    x1425     c2516               -1   c2517               -1
    x1425     c5182                1   c5183                1
    x1425     c5184               -1
    x1426     c2506               -1   c2507                1
    x1426     c5146               -1   c5147                1
    x1426     c5149                1   c5152                1
    x1426     c5153                1   c5155               -1
    x1426     c5180                1   c5181               -1
    x1426     c6516               -1   c6518               -1
    x1426     c6520               -1
    x1427     c2510                1   c2511                1
    x1427     c2518                1   c5177               -1
    x1427     c5183               -1   c5184               -1
    x1428     c2512                1   c2513               -1
    x1428     c2514                1   c2515               -1
    x1428     c2520               -1   c2521               -1
    x1428     c5183                1   c5184               -1
    x1428     c5185                1
    x1429     c2512               -1   c2513                1
    x1429     c5151                1   c5153                1
    x1429     c5154               -1   c5163               -1
    x1429     c5164                1   c5166                1
    x1429     c5180                1   c5181               -1
    x1429     c6515               -1   c6519               -1
    x1429     c6521               -1
    x1430     c2522               -1   c2524                1
    x1430     c5186                1   c5187               -1
    x1430     c5204                1   c5205               -1
    x1430     c5206                1   c5207                1
    x1430     c5208               -1   c5209               -1
    x1430     c5210               -1   c5211               -1
    x1431     c2522               -1   c2523               -1
    x1431     c2527               -1   c5186                1
    x1431     c5188                1
    x1432     c2523                1   c2525               -1
    x1432     c5186               -1   c5187                1
    x1432     c5189                1   c5190                1
    x1432     c5191               -1   c5192               -1
    x1432     c5193               -1   c5194               -1
    x1432     c5204                1   c5205               -1
    x1433     c2524               -1   c2525               -1
    x1433     c2526               -1   c5187                1
    x1433     c5188                1
    x1434     c2526                1   c2527                1
    x1434     c3733               -1   c5188               -1
    x1434     c6776                1
    x1435     c2528               -1   c2531               -1
    x1435     c2536               -1   c5212                1
    x1435     c5215               -1   c5216               -1
    x1435     c6528               -1   c6529               -1
    x1436     c2528                1   c2529                1
    x1436     c2530                1   c5204               -1
    x1436     c5205               -1   c6765                1
    x1437     c2529               -1   c2553               -1
    x1437     c5198               -1   c5199               -1
    x1437     c5200               -1   c5221                1
    x1437     c5222               -1   c5223               -1
    x1437     c6525               -1   c6526               -1
    x1437     c6527               -1
    x1438     c2530               -1   c2537               -1
    x1438     c5195               -1   c5196               -1
    x1438     c5197               -1   c5212                1
    x1438     c5213               -1   c5214               -1
    x1438     c6522               -1   c6523               -1
    x1438     c6524               -1
    x1439     c2532                1   c2533               -1
    x1439     c2534                1   c2535               -1
    x1439     c2542               -1   c2543               -1
    x1439     c5217                1   c5218                1
    x1439     c5219               -1
    x1440     c2532               -1   c2533                1
    x1440     c5189                1   c5193               -1
    x1440     c5194               -1   c5201               -1
    x1440     c5203               -1   c5215                1
    x1440     c5216               -1   c6523                1
    x1440     c6524                1   c6526                1
    x1440     c6527                1   c6528               -1
    x1441     c2534               -1   c2535                1
    x1441     c5190                1   c5192               -1
    x1441     c5194               -1   c5196               -1
    x1441     c5198               -1   c5200               -1
    x1441     c5213                1   c5214               -1
    x1441     c6523               -1   c6528                1
    x1441     c6530                1
    x1442     c2536                1   c2537                1
    x1442     c2544                1   c5212               -1
    x1442     c5218               -1   c5219               -1
    x1443     c2538                1   c2539               -1
    x1443     c2540                1   c2541               -1
    x1443     c2546               -1   c2547               -1
    x1443     c5218                1   c5219               -1
    x1443     c5220                1
    x1444     c2538               -1   c2539                1
    x1444     c5202               -1   c5203               -1
    x1444     c5206                1   c5210               -1
    x1444     c5211               -1   c5215                1
    x1444     c5216               -1   c6522                1
    x1444     c6524                1   c6525                1
    x1444     c6527                1   c6529               -1
    x1445     c2540               -1   c2541                1
    x1445     c5195               -1   c5199               -1
    x1445     c5200               -1   c5207                1
    x1445     c5209               -1   c5211               -1
    x1445     c5213                1   c5214               -1
    x1445     c6522               -1   c6529                1
    x1445     c6531                1
    x1446     c2543               -1   c2548               -1
    x1446     c2549                1   c5217                1
    x1446     c5224                1   c5225               -1
    x1447     c2544               -1   c2545               -1
    x1447     c2552               -1   c5221                1
    x1447     c5224               -1   c5225               -1
    x1448     c2547               -1   c2554               -1
    x1448     c2555                1   c5220                1
    x1448     c5224                1   c5225               -1
    x1449     c2548                1   c2549               -1
    x1449     c2550                1   c2551               -1
    x1449     c2558                1   c2559                1
    x1449     c5226               -1   c5227                1
    x1449     c5228               -1
    x1450     c2550               -1   c2551                1
    x1450     c5190                1   c5191               -1
    x1450     c5193               -1   c5195               -1
    x1450     c5197               -1   c5199               -1
    x1450     c5222                1   c5223               -1
    x1450     c6526               -1   c6528                1
    x1450     c6530                1
    x1451     c2552                1   c2553                1
    x1451     c2560                1   c5221               -1
    x1451     c5227               -1   c5228               -1
    x1452     c2554                1   c2555               -1
    x1452     c2556                1   c2557               -1
    x1452     c2562                1   c2563                1
    x1452     c5227                1   c5228               -1
    x1452     c5229               -1
    x1453     c2556               -1   c2557                1
    x1453     c5196               -1   c5197               -1
    x1453     c5198               -1   c5207                1
    x1453     c5208               -1   c5210               -1
    x1453     c5222                1   c5223               -1
    x1453     c6525               -1   c6529                1
    x1453     c6531                1
    x1454     c2559                1   c2564               -1
    x1454     c2565                1   c5226               -1
    x1454     c5234                1   c5235               -1
    x1455     c2560               -1   c2561               -1
    x1455     c2570               -1   c5234               -1
    x1455     c5235               -1   c6532                1
    x1456     c2563                1   c2573               -1
    x1456     c2574                1   c5229               -1
    x1456     c5234                1   c5235               -1
    x1457     c2564                1   c2565               -1
    x1457     c2566                1   c2567               -1
    x1457     c2568                1   c2569               -1
    x1457     c2579               -1   c2580               -1
    x1457     c5236                1   c5237                1
    x1457     c5238               -1
    x1458     c2566               -1   c2567                1
    x1458     c2656                1   c2657               -1
    x1458     c5232                1   c5233               -1
    x1459     c2568               -1   c2569                1
    x1459     c2745                1   c5230                1
    x1459     c5231               -1   c5387               -1
    x1460     c2570                1   c2571                1
    x1460     c2572                1   c2581                1
    x1460     c5237               -1   c5238               -1
    x1460     c6532               -1
    x1461     c2571               -1   c2658               -1
    x1461     c5232               -1   c5233               -1
    x1461     c6532                1
    x1462     c2572               -1   c2746               -1
    x1462     c2747               -1   c5230               -1
    x1462     c5231               -1   c6532                1
    x1463     c2573                1   c2574               -1
    x1463     c2575                1   c2576               -1
    x1463     c2577                1   c2578               -1
    x1463     c2583               -1   c2584               -1
    x1463     c5237                1   c5238               -1
    x1463     c5239                1
    x1464     c2575               -1   c2576                1
    x1464     c2659                1   c2660               -1
    x1464     c5232                1   c5233               -1
    x1465     c2577               -1   c2578                1
    x1465     c2749                1   c5230                1
    x1465     c5231               -1   c5390               -1
    x1466     c2579               -1   c2585                1
    x1466     c2586                1   c2587                1
    x1466     c2588                1   c5236                1
    x1466     c5246                1   c5247               -1
    x1466     c6745               -1
    x1467     c2581               -1   c2582               -1
    x1467     c2589                1   c2590                1
    x1467     c5246               -1   c5247               -1
    x1468     c2583               -1   c2595                1
    x1468     c2596                1   c2597                1
    x1468     c2598                1   c5239                1
    x1468     c5246                1   c5247               -1
    x1468     c6746               -1
    x1469     c2599               -1   c2601                1
    x1469     c2608                1   c2609               -1
    x1469     c5248                1   c5249               -1
    x1469     c5251                1   c5252               -1
    x1470     c2599               -1   c2600               -1
    x1470     c2604               -1   c5248                1
    x1470     c5250                1
    x1471     c2600                1   c2602               -1
    x1471     c2605                1   c2606               -1
    x1471     c5248               -1   c5249                1
    x1471     c5251                1   c5252               -1
    x1472     c2601               -1   c2602               -1
    x1472     c2603               -1   c5249                1
    x1472     c5250                1
    x1473     c2603                1   c2604                1
    x1473     c3732               -1   c5250               -1
    x1473     c6776                1
    x1474     c2605                1   c2606               -1
    x1474     c5253               -1   c5254               -1
    x1474     c5255                1   c5256                1
    x1474     c5257                1   c5258                1
    x1474     c5268                1   c5269               -1
    x1475     c2607               -1   c2610                1
    x1475     c2611                1   c2612                1
    x1475     c5268               -1   c5269               -1
    x1476     c2607                1   c5251               -1
    x1476     c5252               -1   c6765                1
    x1477     c2608                1   c2609               -1
    x1477     c5268                1   c5269               -1
    x1477     c5270               -1   c5271               -1
    x1477     c5272                1   c5273                1
    x1477     c5274                1   c5275                1
    x1478     c2610               -1   c2613               -1
    x1478     c2618               -1   c5276                1
    x1478     c5279               -1   c5280               -1
    x1478     c6539               -1   c6540               -1
    x1479     c2611               -1   c2634               -1
    x1479     c5262               -1   c5263               -1
    x1479     c5264               -1   c5285                1
    x1479     c5288               -1   c5289               -1
    x1479     c6536               -1   c6537               -1
    x1479     c6538               -1
    x1480     c2612               -1   c2619               -1
    x1480     c5259               -1   c5260               -1
    x1480     c5261               -1   c5276                1
    x1480     c5277               -1   c5278               -1
    x1480     c6533               -1   c6534               -1
    x1480     c6535               -1
    x1481     c2614                1   c2615               -1
    x1481     c2616                1   c2617               -1
    x1481     c2624                1   c2625                1
    x1481     c5281               -1   c5282                1
    x1481     c5283               -1
    x1482     c2614               -1   c2615                1
    x1482     c5253               -1   c5257                1
    x1482     c5258                1   c5266                1
    x1482     c5267                1   c5279                1
    x1482     c5280               -1   c6533               -1
    x1482     c6535               -1   c6536               -1
    x1482     c6538               -1   c6539                1
    x1483     c2616               -1   c2617                1
    x1483     c5254               -1   c5256                1
    x1483     c5258                1   c5260               -1
    x1483     c5263                1   c5264                1
    x1483     c5277                1   c5278               -1
    x1483     c6534               -1   c6539               -1
    x1483     c6541               -1
    x1484     c2618                1   c2619                1
    x1484     c2626                1   c5276               -1
    x1484     c5282               -1   c5283               -1
    x1485     c2620                1   c2621               -1
    x1485     c2622                1   c2623               -1
    x1485     c2628                1   c2629                1
    x1485     c5282                1   c5283               -1
    x1485     c5284               -1
    x1486     c2620               -1   c2621                1
    x1486     c5265                1   c5267                1
    x1486     c5270               -1   c5274                1
    x1486     c5275                1   c5279                1
    x1486     c5280               -1   c6534               -1
    x1486     c6535               -1   c6537               -1
    x1486     c6538               -1   c6540                1
    x1487     c2622               -1   c2623                1
    x1487     c5259               -1   c5262                1
    x1487     c5264                1   c5271               -1
    x1487     c5273                1   c5275                1
    x1487     c5277                1   c5278               -1
    x1487     c6533               -1   c6540               -1
    x1487     c6542               -1
    x1488     c2625                1   c2632               -1
    x1488     c2633                1   c5281               -1
    x1488     c5286                1   c5287               -1
    x1489     c2626               -1   c2627               -1
    x1489     c2635               -1   c5285                1
    x1489     c5286               -1   c5287               -1
    x1490     c2629                1   c2638               -1
    x1490     c2639                1   c5284               -1
    x1490     c5286                1   c5287               -1
    x1491     c2630                1   c2631               -1
    x1491     c2632                1   c2633               -1
    x1491     c2640               -1   c2641               -1
    x1491     c5290                1   c5291                1
    x1491     c5292               -1
    x1492     c2630               -1   c2631                1
    x1492     c5254               -1   c5255                1
    x1492     c5257                1   c5260                1
    x1492     c5261                1   c5263               -1
    x1492     c5288                1   c5289               -1
    x1492     c6537               -1   c6539               -1
    x1492     c6541               -1
    x1493     c2634                1   c2635                1
    x1493     c2642                1   c5285               -1
    x1493     c5291               -1   c5292               -1
    x1494     c2636                1   c2637               -1
    x1494     c2638                1   c2639               -1
    x1494     c2644               -1   c2645               -1
    x1494     c5291                1   c5292               -1
    x1494     c5293                1
    x1495     c2636               -1   c2637                1
    x1495     c5259                1   c5261                1
    x1495     c5262               -1   c5271               -1
    x1495     c5272                1   c5274                1
    x1495     c5288                1   c5289               -1
    x1495     c6536               -1   c6540               -1
    x1495     c6542               -1
    x1496     c2641               -1   c2646               -1
    x1496     c2647                1   c5290                1
    x1496     c5297                1   c5298               -1
    x1497     c2642               -1   c2643               -1
    x1497     c2650               -1   c5294                1
    x1497     c5297               -1   c5298               -1
    x1498     c2645               -1   c2652               -1
    x1498     c2653                1   c5293                1
    x1498     c5297                1   c5298               -1
    x1499     c2646                1   c2647               -1
    x1499     c2648                1   c2649               -1
    x1499     c2656                1   c2657               -1
    x1499     c5299                1   c5300               -1
    x1500     c2648               -1   c2649                1
    x1500     c2703               -1   c5295                1
    x1500     c5296               -1   c5343                1
    x1501     c2650                1   c2651                1
    x1501     c2658                1   c5294               -1
    x1501     c5299               -1   c5300               -1
    x1502     c2651               -1   c2704               -1
    x1502     c2705               -1   c5294                1
    x1502     c5295               -1   c5296               -1
    x1503     c2652                1   c2653               -1
    x1503     c2654                1   c2655               -1
    x1503     c2659                1   c2660               -1
    x1503     c5299                1   c5300               -1
    x1504     c2654               -1   c2655                1
    x1504     c2707               -1   c5295                1
    x1504     c5296               -1   c5346                1
    x1505     c2661               -1   c2663                1
    x1505     c2670                1   c2671               -1
    x1505     c5301                1   c5302               -1
    x1505     c5304                1   c5305               -1
    x1506     c2661               -1   c2662               -1
    x1506     c2666               -1   c5301                1
    x1506     c5303                1
    x1507     c2662                1   c2664               -1
    x1507     c2667                1   c2668               -1
    x1507     c5301               -1   c5302                1
    x1507     c5304                1   c5305               -1
    x1508     c2663               -1   c2664               -1
    x1508     c2665               -1   c5302                1
    x1508     c5303                1
    x1509     c2665                1   c2666                1
    x1509     c3731               -1   c5303               -1
    x1509     c6776                1
    x1510     c2667                1   c2668               -1
    x1510     c5306               -1   c5307               -1
    x1510     c5308                1   c5309                1
    x1510     c5310                1   c5311                1
    x1510     c5321                1   c5322               -1
    x1511     c2669               -1   c2672                1
    x1511     c2673                1   c2674                1
    x1511     c5321               -1   c5322               -1
    x1512     c2669                1   c5304               -1
    x1512     c5305               -1   c6765                1
    x1513     c2670                1   c2671               -1
    x1513     c5321                1   c5322               -1
    x1513     c5323               -1   c5324               -1
    x1513     c5325                1   c5326                1
    x1513     c5327                1   c5328                1
    x1514     c2672               -1   c2675               -1
    x1514     c2680               -1   c5329                1
    x1514     c5332               -1   c5333               -1
    x1514     c6549               -1   c6550               -1
    x1515     c2673               -1   c2697               -1
    x1515     c5315               -1   c5316               -1
    x1515     c5317               -1   c5338                1
    x1515     c5339               -1   c5340               -1
    x1515     c6546               -1   c6547               -1
    x1515     c6548               -1
    x1516     c2674               -1   c2681               -1
    x1516     c5312               -1   c5313               -1
    x1516     c5314               -1   c5329                1
    x1516     c5330               -1   c5331               -1
    x1516     c6543               -1   c6544               -1
    x1516     c6545               -1
    x1517     c2676                1   c2677               -1
    x1517     c2678                1   c2679               -1
    x1517     c2686                1   c2687                1
    x1517     c5334               -1   c5335                1
    x1517     c5336               -1
    x1518     c2676               -1   c2677                1
    x1518     c5306               -1   c5310                1
    x1518     c5311                1   c5319                1
    x1518     c5320                1   c5332                1
    x1518     c5333               -1   c6543               -1
    x1518     c6545               -1   c6546               -1
    x1518     c6548               -1   c6549                1
    x1519     c2678               -1   c2679                1
    x1519     c5307               -1   c5309                1
    x1519     c5311                1   c5313               -1
    x1519     c5316                1   c5317                1
    x1519     c5330                1   c5331               -1
    x1519     c6544               -1   c6549               -1
    x1519     c6551               -1
    x1520     c2680                1   c2681                1
    x1520     c2688                1   c5329               -1
    x1520     c5335               -1   c5336               -1
    x1521     c2682                1   c2683               -1
    x1521     c2684                1   c2685               -1
    x1521     c2690                1   c2691                1
    x1521     c5335                1   c5336               -1
    x1521     c5337               -1
    x1522     c2682               -1   c2683                1
    x1522     c5318                1   c5320                1
    x1522     c5323               -1   c5327                1
    x1522     c5328                1   c5332                1
    x1522     c5333               -1   c6544               -1
    x1522     c6545               -1   c6547               -1
    x1522     c6548               -1   c6550                1
    x1523     c2684               -1   c2685                1
    x1523     c5312               -1   c5315                1
    x1523     c5317                1   c5324               -1
    x1523     c5326                1   c5328                1
    x1523     c5330                1   c5331               -1
    x1523     c6543               -1   c6550               -1
    x1523     c6552               -1
    x1524     c2687                1   c2692               -1
    x1524     c2693                1   c5334               -1
    x1524     c5341                1   c5342               -1
    x1525     c2688               -1   c2689               -1
    x1525     c2696               -1   c5338                1
    x1525     c5341               -1   c5342               -1
    x1526     c2691                1   c2698               -1
    x1526     c2699                1   c5337               -1
    x1526     c5341                1   c5342               -1
    x1527     c2692                1   c2693               -1
    x1527     c2694                1   c2695               -1
    x1527     c2702               -1   c2703               -1
    x1527     c5343                1   c5344                1
    x1527     c5345               -1
    x1528     c2694               -1   c2695                1
    x1528     c5307               -1   c5308                1
    x1528     c5310                1   c5313                1
    x1528     c5314                1   c5316               -1
    x1528     c5339                1   c5340               -1
    x1528     c6547               -1   c6549               -1
    x1528     c6551               -1
    x1529     c2696                1   c2697                1
    x1529     c2704                1   c5338               -1
    x1529     c5344               -1   c5345               -1
    x1530     c2698                1   c2699               -1
    x1530     c2700                1   c2701               -1
    x1530     c2706               -1   c2707               -1
    x1530     c5344                1   c5345               -1
    x1530     c5346                1
    x1531     c2700               -1   c2701                1
    x1531     c5312                1   c5314                1
    x1531     c5315               -1   c5324               -1
    x1531     c5325                1   c5327                1
    x1531     c5339                1   c5340               -1
    x1531     c6546               -1   c6550               -1
    x1531     c6552               -1
    x1532     c2708               -1   c2710                1
    x1532     c5347                1   c5348               -1
    x1532     c5365                1   c5366               -1
    x1532     c5367                1   c5368                1
    x1532     c5369               -1   c5370               -1
    x1532     c5371               -1   c5372               -1
    x1533     c2708               -1   c2709               -1
    x1533     c2713               -1   c5347                1
    x1533     c5349                1
    x1534     c2709                1   c2711               -1
    x1534     c5347               -1   c5348                1
    x1534     c5350                1   c5351                1
    x1534     c5352               -1   c5353               -1
    x1534     c5354               -1   c5355               -1
    x1534     c5365                1   c5366               -1
    x1535     c2710               -1   c2711               -1
    x1535     c2712               -1   c5348                1
    x1535     c5349                1
    x1536     c2712                1   c2713                1
    x1536     c3730               -1   c5349               -1
    x1536     c6776                1
    x1537     c2714               -1   c2717               -1
    x1537     c2722               -1   c5373                1
    x1537     c5376               -1   c5377               -1
    x1537     c6559               -1   c6560               -1
    x1538     c2714                1   c2715                1
    x1538     c2716                1   c5365               -1
    x1538     c5366               -1   c6764                1
    x1539     c2715               -1   c2739               -1
    x1539     c5359               -1   c5360               -1
    x1539     c5361               -1   c5382                1
    x1539     c5383               -1   c5384               -1
    x1539     c6556               -1   c6557               -1
    x1539     c6558               -1
    x1540     c2716               -1   c2723               -1
    x1540     c5356               -1   c5357               -1
    x1540     c5358               -1   c5373                1
    x1540     c5374               -1   c5375               -1
    x1540     c6553               -1   c6554               -1
    x1540     c6555               -1
    x1541     c2718                1   c2719               -1
    x1541     c2720                1   c2721               -1
    x1541     c2728               -1   c2729               -1
    x1541     c5378                1   c5379                1
    x1541     c5380               -1
    x1542     c2718               -1   c2719                1
    x1542     c5350                1   c5354               -1
    x1542     c5355               -1   c5362               -1
    x1542     c5364               -1   c5376                1
    x1542     c5377               -1   c6554                1
    x1542     c6555                1   c6557                1
    x1542     c6558                1   c6559               -1
    x1543     c2720               -1   c2721                1
    x1543     c5351                1   c5353               -1
    x1543     c5355               -1   c5357               -1
    x1543     c5359               -1   c5361               -1
    x1543     c5374                1   c5375               -1
    x1543     c6554               -1   c6559                1
    x1543     c6561                1
    x1544     c2722                1   c2723                1
    x1544     c2730                1   c5373               -1
    x1544     c5379               -1   c5380               -1
    x1545     c2724                1   c2725               -1
    x1545     c2726                1   c2727               -1
    x1545     c2732               -1   c2733               -1
    x1545     c5379                1   c5380               -1
    x1545     c5381                1
    x1546     c2724               -1   c2725                1
    x1546     c5363               -1   c5364               -1
    x1546     c5367                1   c5371               -1
    x1546     c5372               -1   c5376                1
    x1546     c5377               -1   c6553                1
    x1546     c6555                1   c6556                1
    x1546     c6558                1   c6560               -1
    x1547     c2726               -1   c2727                1
    x1547     c5356               -1   c5360               -1
    x1547     c5361               -1   c5368                1
    x1547     c5370               -1   c5372               -1
    x1547     c5374                1   c5375               -1
    x1547     c6553               -1   c6560                1
    x1547     c6562                1
    x1548     c2729               -1   c2734               -1
    x1548     c2735                1   c5378                1
    x1548     c5385                1   c5386               -1
    x1549     c2730               -1   c2731               -1
    x1549     c2738               -1   c5382                1
    x1549     c5385               -1   c5386               -1
    x1550     c2733               -1   c2740               -1
    x1550     c2741                1   c5381                1
    x1550     c5385                1   c5386               -1
    x1551     c2734                1   c2735               -1
    x1551     c2736                1   c2737               -1
    x1551     c2744                1   c2745                1
    x1551     c5387               -1   c5388                1
    x1551     c5389               -1
    x1552     c2736               -1   c2737                1
    x1552     c5351                1   c5352               -1
    x1552     c5354               -1   c5356               -1
    x1552     c5358               -1   c5360               -1
    x1552     c5383                1   c5384               -1
    x1552     c6557               -1   c6559                1
    x1552     c6561                1
    x1553     c2738                1   c2739                1
    x1553     c2746                1   c5382               -1
    x1553     c5388               -1   c5389               -1
    x1554     c2740                1   c2741               -1
    x1554     c2742                1   c2743               -1
    x1554     c2748                1   c2749                1
    x1554     c5388                1   c5389               -1
    x1554     c5390               -1
    x1555     c2742               -1   c2743                1
    x1555     c5357               -1   c5358               -1
    x1555     c5359               -1   c5368                1
    x1555     c5369               -1   c5371               -1
    x1555     c5383                1   c5384               -1
    x1555     c6556               -1   c6560                1
    x1555     c6562                1
    x1556     c2750               -1   c2752                1
    x1556     c2759                1   c2760               -1
    x1556     c5391                1   c5392               -1
    x1556     c5394                1   c5395               -1
    x1557     c2750               -1   c2751               -1
    x1557     c2755               -1   c5391                1
    x1557     c5393                1
    x1558     c2751                1   c2753               -1
    x1558     c2756                1   c2757               -1
    x1558     c5391               -1   c5392                1
    x1558     c5394                1   c5395               -1
    x1559     c2752               -1   c2753               -1
    x1559     c2754               -1   c5392                1
    x1559     c5393                1
    x1560     c2754                1   c2755                1
    x1560     c3729               -1   c5393               -1
    x1560     c6775                1
    x1561     c2756                1   c2757               -1
    x1561     c5396               -1   c5397               -1
    x1561     c5398                1   c5399                1
    x1561     c5400                1   c5401                1
    x1561     c5411                1   c5412               -1
    x1562     c2758               -1   c2761                1
    x1562     c2762                1   c2763                1
    x1562     c5411               -1   c5412               -1
    x1563     c2758                1   c5394               -1
    x1563     c5395               -1   c6764                1
    x1564     c2759                1   c2760               -1
    x1564     c5411                1   c5412               -1
    x1564     c5413               -1   c5414               -1
    x1564     c5415                1   c5416                1
    x1564     c5417                1   c5418                1
    x1565     c2761               -1   c2764               -1
    x1565     c2769               -1   c5419                1
    x1565     c5422               -1   c5423               -1
    x1565     c6569               -1   c6570               -1
    x1566     c2762               -1   c2785               -1
    x1566     c5405               -1   c5406               -1
    x1566     c5407               -1   c5428                1
    x1566     c5431               -1   c5432               -1
    x1566     c6566               -1   c6567               -1
    x1566     c6568               -1
    x1567     c2763               -1   c2770               -1
    x1567     c5402               -1   c5403               -1
    x1567     c5404               -1   c5419                1
    x1567     c5420               -1   c5421               -1
    x1567     c6563               -1   c6564               -1
    x1567     c6565               -1
    x1568     c2765                1   c2766               -1
    x1568     c2767                1   c2768               -1
    x1568     c2775                1   c2776                1
    x1568     c5424               -1   c5425                1
    x1568     c5426               -1
    x1569     c2765               -1   c2766                1
    x1569     c5396               -1   c5400                1
    x1569     c5401                1   c5409                1
    x1569     c5410                1   c5422                1
    x1569     c5423               -1   c6563               -1
    x1569     c6565               -1   c6566               -1
    x1569     c6568               -1   c6569                1
    x1570     c2767               -1   c2768                1
    x1570     c5397               -1   c5399                1
    x1570     c5401                1   c5403               -1
    x1570     c5406                1   c5407                1
    x1570     c5420                1   c5421               -1
    x1570     c6564               -1   c6569               -1
    x1570     c6571               -1
    x1571     c2769                1   c2770                1
    x1571     c2777                1   c5419               -1
    x1571     c5425               -1   c5426               -1
    x1572     c2771                1   c2772               -1
    x1572     c2773                1   c2774               -1
    x1572     c2779                1   c2780                1
    x1572     c5425                1   c5426               -1
    x1572     c5427               -1
    x1573     c2771               -1   c2772                1
    x1573     c5408                1   c5410                1
    x1573     c5413               -1   c5417                1
    x1573     c5418                1   c5422                1
    x1573     c5423               -1   c6564               -1
    x1573     c6565               -1   c6567               -1
    x1573     c6568               -1   c6570                1
    x1574     c2773               -1   c2774                1
    x1574     c5402               -1   c5405                1
    x1574     c5407                1   c5414               -1
    x1574     c5416                1   c5418                1
    x1574     c5420                1   c5421               -1
    x1574     c6563               -1   c6570               -1
    x1574     c6572               -1
    x1575     c2776                1   c2783               -1
    x1575     c2784                1   c5424               -1
    x1575     c5429                1   c5430               -1
    x1576     c2777               -1   c2778               -1
    x1576     c2786               -1   c5428                1
    x1576     c5429               -1   c5430               -1
    x1577     c2780                1   c2789               -1
    x1577     c2790                1   c5427               -1
    x1577     c5429                1   c5430               -1
    x1578     c2781                1   c2782               -1
    x1578     c2783                1   c2784               -1
    x1578     c2791               -1   c2792               -1
    x1578     c5433                1   c5440                1
    x1578     c5441               -1
    x1579     c2781               -1   c2782                1
    x1579     c5397               -1   c5398                1
    x1579     c5400                1   c5403                1
    x1579     c5404                1   c5406               -1
    x1579     c5431                1   c5432               -1
    x1579     c6567               -1   c6569               -1
    x1579     c6571               -1
    x1580     c2785                1   c2786                1
    x1580     c2793                1   c2794                1
    x1580     c5428               -1   c5440               -1
    x1580     c5441               -1
    x1581     c2787                1   c2788               -1
    x1581     c2789                1   c2790               -1
    x1581     c2795               -1   c2796               -1
    x1581     c5440                1   c5441               -1
    x1581     c5442                1
    x1582     c2787               -1   c2788                1
    x1582     c5402                1   c5404                1
    x1582     c5405               -1   c5414               -1
    x1582     c5415                1   c5417                1
    x1582     c5431                1   c5432               -1
    x1582     c6566               -1   c6570               -1
    x1582     c6572               -1
    x1583     c2792               -1   c2797               -1
    x1583     c2798                1   c5433                1
    x1583     c5435               -1   c5437               -1
    x1583     c5439               -1   c5446                1
    x1583     c5447               -1
    x1584     c2794               -1   c2801               -1
    x1584     c5434               -1   c5435               -1
    x1584     c5436               -1   c5443                1
    x1584     c5446               -1   c5447               -1
    x1585     c2796               -1   c2803               -1
    x1585     c2804                1   c5434               -1
    x1585     c5438               -1   c5439               -1
    x1585     c5442                1   c5446                1
    x1585     c5447               -1
    x1586     c2797                1   c2798               -1
    x1586     c2799                1   c2800               -1
    x1586     c2807                1   c2808                1
    x1586     c2809                1   c2810                1
    x1586     c5448                1   c5449               -1
    x1586     c6747               -1
    x1587     c2799               -1   c2800                1
    x1587     c2963                1   c2964               -1
    x1587     c5444                1   c5445               -1
    x1588     c2801                1   c2802                1
    x1588     c2811                1   c5443               -1
    x1588     c5448               -1   c5449               -1
    x1589     c2802               -1   c2965               -1
    x1589     c5443                1   c5444               -1
    x1589     c5445               -1
    x1590     c2803                1   c2804               -1
    x1590     c2805                1   c2806               -1
    x1590     c2815                1   c2816                1
    x1590     c2817                1   c2818                1
    x1590     c5448                1   c5449               -1
    x1590     c6748               -1
    x1591     c2805               -1   c2806                1
    x1591     c2966                1   c2967               -1
    x1591     c5444                1   c5445               -1
    x1592     c2808                1   c2821               -1
    x1592     c2822                1   c5457                1
    x1592     c5458               -1   c6747               -1
    x1593     c2809                1   c2813                1
    x1593     c2817                1   c2819               -1
    x1593     c2820               -1   c5450                1
    x1593     c6747               -1   c6748               -1
    x1594     c2811               -1   c2812               -1
    x1594     c2813               -1   c2814               -1
    x1594     c2829               -1   c5457               -1
    x1594     c5458               -1   c6749                1
    x1595     c2816                1   c2833               -1
    x1595     c2834                1   c5457                1
    x1595     c5458               -1   c6748               -1
    x1596     c2821                1   c2822               -1
    x1596     c2823                1   c2824               -1
    x1596     c2825                1   c2826               -1
    x1596     c2827                1   c2828               -1
    x1596     c2841                1   c2842                1
    x1596     c5459               -1   c5466                1
    x1596     c5467               -1
    x1597     c2823               -1   c2824                1
    x1597     c3110                1   c5455                1
    x1597     c5456               -1   c6754               -1
    x1598     c2825               -1   c2826                1
    x1598     c3342                1   c5453                1
    x1598     c5454               -1   c6756               -1
    x1599     c2827               -1   c2828                1
    x1599     c3549                1   c5451                1
    x1599     c5452               -1   c6758               -1
    x1600     c2829                1   c2830                1
    x1600     c2831                1   c2832                1
    x1600     c2843                1   c2844                1
    x1600     c5466               -1   c5467               -1
    x1600     c6749               -1
    x1601     c2830               -1   c3113               -1
    x1601     c3114               -1   c3115               -1
    x1601     c3116               -1   c5455               -1
    x1601     c5456               -1   c6749                1
    x1602     c2831               -1   c3345               -1
    x1602     c3346               -1   c3347               -1
    x1602     c3348               -1   c5453               -1
    x1602     c5454               -1   c6749                1
    x1603     c2832               -1   c3552               -1
    x1603     c3553               -1   c3554               -1
    x1603     c3555               -1   c5451               -1
    x1603     c5452               -1   c6749                1
    x1604     c2833                1   c2834               -1
    x1604     c2835                1   c2836               -1
    x1604     c2837                1   c2838               -1
    x1604     c2839                1   c2840               -1
    x1604     c2845                1   c2846                1
    x1604     c5466                1   c5467               -1
    x1604     c5468               -1
    x1605     c2835               -1   c2836                1
    x1605     c3118                1   c5455                1
    x1605     c5456               -1   c6755               -1
    x1606     c2837               -1   c2838                1
    x1606     c3350                1   c5453                1
    x1606     c5454               -1   c6757               -1
    x1607     c2839               -1   c2840                1
    x1607     c3557                1   c5451                1
    x1607     c5452               -1   c6759               -1
    x1608     c2841                1   c2879               -1
    x1608     c5459               -1   c5461                1
    x1608     c5462                1   c5464               -1
    x1608     c5512                1   c5513                1
    x1608     c5514                1   c5536                1
    x1608     c5537               -1   c6575               -1
    x1609     c2842                1   c2847                1
    x1609     c2848               -1   c5459               -1
    x1609     c5461               -1   c5464                1
    x1609     c5465                1   c5469                1
    x1609     c5470               -1
    x1610     c2843               -1   c2880                1
    x1610     c2881                1   c2882                1
    x1610     c5463               -1   c5464               -1
    x1610     c5465               -1   c5536               -1
    x1610     c5537               -1
    x1611     c2844               -1   c2849                1
    x1611     c5460               -1   c5461               -1
    x1611     c5462               -1   c5469               -1
    x1611     c5470               -1
    x1612     c2845                1   c2885               -1
    x1612     c5460                1   c5462                1
    x1612     c5463               -1   c5468               -1
    x1612     c5536                1   c5537               -1
    x1612     c5538                1   c5539                1
    x1612     c5540                1   c6576               -1
    x1613     c2846                1   c2850                1
    x1613     c2851               -1   c5460               -1
    x1613     c5463                1   c5465                1
    x1613     c5468               -1   c5469                1
    x1613     c5470               -1
    x1614     c2847                1   c2848               -1
    x1614     c2852                1   c5471               -1
    x1614     c5472               -1   c5473               -1
    x1614     c5495                1   c5496               -1
    x1614     c6573                1
    x1615     c2849               -1   c2853                1
    x1615     c2854                1   c2855                1
    x1615     c5495               -1   c5496               -1
    x1616     c2850                1   c2851               -1
    x1616     c2858                1   c5495                1
    x1616     c5496               -1   c5497               -1
    x1616     c5498               -1   c5499               -1
    x1616     c6574                1
    x1617     c2852                1   c2859                1
    x1617     c2860                1   c2861                1
    x1617     c2862                1   c5471               -1
    x1617     c5472               -1   c5473               -1
    x1617     c5487                1   c5488                1
    x1617     c5490                1   c5491                1
    x1617     c5493                1   c5494                1
    x1617     c5506                1   c5507               -1
    x1617     c6750               -1
    x1618     c2853               -1   c2857               -1
    x1618     c2875                1   c5477               -1
    x1618     c5478               -1   c5479               -1
    x1618     c5489               -1   c5490               -1
    x1618     c5491               -1   c5509               -1
    x1618     c5510               -1
    x1619     c2855               -1   c2863                1
    x1619     c2864                1   c5506               -1
    x1619     c5507               -1
    x1620     c2858                1   c2869                1
    x1620     c2870                1   c2871                1
    x1620     c2872                1   c5486                1
    x1620     c5488                1   c5489                1
    x1620     c5491                1   c5492                1
    x1620     c5494                1   c5497               -1
    x1620     c5498               -1   c5499               -1
    x1620     c5506                1   c5507               -1
    x1620     c6751               -1
    x1621     c2873                1   c2874                1
    x1621     c5472               -1   c5474               -1
    x1621     c5476               -1   c5478               -1
    x1621     c5483               -1   c5485               -1
    x1621     c5490               -1   c5508               -1
    x1621     c5509                1   c5510               -1
    x1621     c6573                1
    x1622     c2877                1   c2878                1
    x1622     c5475               -1   c5476               -1
    x1622     c5477               -1   c5484               -1
    x1622     c5485               -1   c5489               -1
    x1622     c5498               -1   c5509                1
    x1622     c5510               -1   c5511               -1
    x1622     c6574                1
    x1623     c2879               -1   c2886               -1
    x1623     c2887               -1   c2888               -1
    x1623     c2889               -1   c5512                1
    x1623     c5513                1   c5514                1
    x1623     c5527               -1   c5529               -1
    x1623     c5530               -1   c5532               -1
    x1623     c5533               -1   c5535               -1
    x1623     c5547                1   c5548               -1
    x1623     c6752                1
    x1624     c2880               -1   c2884               -1
    x1624     c2902                1   c5518               -1
    x1624     c5519               -1   c5520               -1
    x1624     c5530               -1   c5531               -1
    x1624     c5532               -1   c5550               -1
    x1624     c5551               -1
    x1625     c2882               -1   c2890                1
    x1625     c2891                1   c5547               -1
    x1625     c5548               -1
    x1626     c2885               -1   c2896               -1
    x1626     c2897               -1   c2898               -1
    x1626     c2899               -1   c5528               -1
    x1626     c5529               -1   c5531               -1
    x1626     c5532               -1   c5534               -1
    x1626     c5535               -1   c5538                1
    x1626     c5539                1   c5540                1
    x1626     c5547                1   c5548               -1
    x1626     c6753                1
    x1627     c2900               -1   c2901               -1
    x1627     c5513                1   c5516                1
    x1627     c5517                1   c5519               -1
    x1627     c5525                1   c5526                1
    x1627     c5531               -1   c5549                1
    x1627     c5550                1   c5551               -1
    x1627     c6575               -1
    x1628     c2904               -1   c2905               -1
    x1628     c5515                1   c5517                1
    x1628     c5518               -1   c5524                1
    x1628     c5526                1   c5530               -1
    x1628     c5539                1   c5550                1
    x1628     c5551               -1   c5552                1
    x1628     c6576               -1
    x1629     c2906               -1   c2908                1
    x1629     c5553                1   c5554               -1
    x1629     c5571                1   c5572               -1
    x1629     c5573                1   c5574                1
    x1629     c5575               -1   c5576               -1
    x1629     c5577               -1   c5578               -1
    x1630     c2906               -1   c2907               -1
    x1630     c2911               -1   c5553                1
    x1630     c5555                1
    x1631     c2907                1   c2909               -1
    x1631     c5553               -1   c5554                1
    x1631     c5556                1   c5557                1
    x1631     c5558               -1   c5559               -1
    x1631     c5560               -1   c5561               -1
    x1631     c5571                1   c5572               -1
    x1632     c2908               -1   c2909               -1
    x1632     c2910               -1   c5554                1
    x1632     c5555                1
    x1633     c2910                1   c2911                1
    x1633     c3728               -1   c5555               -1
    x1633     c6775                1
    x1634     c2912               -1   c2915               -1
    x1634     c2920               -1   c5579                1
    x1634     c5582               -1   c5583               -1
    x1634     c6583               -1   c6584               -1
    x1635     c2912                1   c2913                1
    x1635     c2914                1   c5571               -1
    x1635     c5572               -1   c6764                1
    x1636     c2913               -1   c2936               -1
    x1636     c5565               -1   c5566               -1
    x1636     c5567               -1   c5588                1
    x1636     c5591               -1   c5592               -1
    x1636     c6580               -1   c6581               -1
    x1636     c6582               -1
    x1637     c2914               -1   c2921               -1
    x1637     c5562               -1   c5563               -1
    x1637     c5564               -1   c5579                1
    x1637     c5580               -1   c5581               -1
    x1637     c6577               -1   c6578               -1
    x1637     c6579               -1
    x1638     c2916                1   c2917               -1
    x1638     c2918                1   c2919               -1
    x1638     c2926               -1   c2927               -1
    x1638     c5584                1   c5585                1
    x1638     c5586               -1
    x1639     c2916               -1   c2917                1
    x1639     c5556                1   c5560               -1
    x1639     c5561               -1   c5568               -1
    x1639     c5570               -1   c5582                1
    x1639     c5583               -1   c6578                1
    x1639     c6579                1   c6581                1
    x1639     c6582                1   c6583               -1
    x1640     c2918               -1   c2919                1
    x1640     c5557                1   c5559               -1
    x1640     c5561               -1   c5563               -1
    x1640     c5565               -1   c5567               -1
    x1640     c5580                1   c5581               -1
    x1640     c6578               -1   c6583                1
    x1640     c6585                1
    x1641     c2920                1   c2921                1
    x1641     c2928                1   c5579               -1
    x1641     c5585               -1   c5586               -1
    x1642     c2922                1   c2923               -1
    x1642     c2924                1   c2925               -1
    x1642     c2930               -1   c2931               -1
    x1642     c5585                1   c5586               -1
    x1642     c5587                1
    x1643     c2922               -1   c2923                1
    x1643     c5569               -1   c5570               -1
    x1643     c5573                1   c5577               -1
    x1643     c5578               -1   c5582                1
    x1643     c5583               -1   c6577                1
    x1643     c6579                1   c6580                1
    x1643     c6582                1   c6584               -1
    x1644     c2924               -1   c2925                1
    x1644     c5562               -1   c5566               -1
    x1644     c5567               -1   c5574                1
    x1644     c5576               -1   c5578               -1
    x1644     c5580                1   c5581               -1
    x1644     c6577               -1   c6584                1
    x1644     c6586                1
    x1645     c2927               -1   c2934               -1
    x1645     c2935                1   c5584                1
    x1645     c5589                1   c5590               -1
    x1646     c2928               -1   c2929               -1
    x1646     c2937               -1   c5588                1
    x1646     c5589               -1   c5590               -1
    x1647     c2931               -1   c2940               -1
    x1647     c2941                1   c5587                1
    x1647     c5589                1   c5590               -1
    x1648     c2932                1   c2933               -1
    x1648     c2934                1   c2935               -1
    x1648     c2942                1   c2943                1
    x1648     c5593               -1   c5594                1
    x1648     c5595               -1
    x1649     c2932               -1   c2933                1
    x1649     c5557                1   c5558               -1
    x1649     c5560               -1   c5562               -1
    x1649     c5564               -1   c5566               -1
    x1649     c5591                1   c5592               -1
    x1649     c6581               -1   c6583                1
    x1649     c6585                1
    x1650     c2936                1   c2937                1
    x1650     c2944                1   c5588               -1
    x1650     c5594               -1   c5595               -1
    x1651     c2938                1   c2939               -1
    x1651     c2940                1   c2941               -1
    x1651     c2946                1   c2947                1
    x1651     c5594                1   c5595               -1
    x1651     c5596               -1
    x1652     c2938               -1   c2939                1
    x1652     c5563               -1   c5564               -1
    x1652     c5565               -1   c5574                1
    x1652     c5575               -1   c5577               -1
    x1652     c5591                1   c5592               -1
    x1652     c6580               -1   c6584                1
    x1652     c6586                1
    x1653     c2943                1   c2948               -1
    x1653     c2949                1   c5593               -1
    x1653     c5601                1   c5602               -1
    x1654     c2944               -1   c2945               -1
    x1654     c2954               -1   c5601               -1
    x1654     c5602               -1   c6587                1
    x1655     c2947                1   c2957               -1
    x1655     c2958                1   c5596               -1
    x1655     c5601                1   c5602               -1
    x1656     c2948                1   c2949               -1
    x1656     c2950                1   c2951               -1
    x1656     c2952                1   c2953               -1
    x1656     c2963                1   c2964               -1
    x1656     c5603                1   c5604               -1
    x1657     c2950               -1   c2951                1
    x1657     c3005                1   c5599                1
    x1657     c5600               -1   c5645               -1
    x1658     c2952               -1   c2953                1
    x1658     c3047                1   c5597                1
    x1658     c5598               -1   c5689               -1
    x1658     c5691               -1   c5694                1
    x1658     c5695                1
    x1659     c2954                1   c2955                1
    x1659     c2956                1   c2965                1
    x1659     c5603               -1   c5604               -1
    x1659     c6587               -1
    x1660     c2955               -1   c3006               -1
    x1660     c3007               -1   c5599               -1
    x1660     c5600               -1   c6587                1
    x1661     c2956               -1   c3049               -1
    x1661     c5597               -1   c5598               -1
    x1661     c5690               -1   c5691               -1
    x1661     c5692               -1   c6587                1
    x1662     c2957                1   c2958               -1
    x1662     c2959                1   c2960               -1
    x1662     c2961                1   c2962               -1
    x1662     c2966                1   c2967               -1
    x1662     c5603                1   c5604               -1
    x1663     c2959               -1   c2960                1
    x1663     c3009                1   c5599                1
    x1663     c5600               -1   c5648               -1
    x1664     c2961               -1   c2962                1
    x1664     c3051                1   c5597                1
    x1664     c5598               -1   c5690               -1
    x1664     c5693                1   c5695                1
    x1664     c5698               -1
    x1665     c2968               -1   c2970                1
    x1665     c5605                1   c5606               -1
    x1665     c5623                1   c5624               -1
    x1665     c5625                1   c5626                1
    x1665     c5627               -1   c5628               -1
    x1665     c5629               -1   c5630               -1
    x1666     c2968               -1   c2969               -1
    x1666     c2973               -1   c5605                1
    x1666     c5607                1
    x1667     c2969                1   c2971               -1
    x1667     c5605               -1   c5606                1
    x1667     c5608                1   c5609                1
    x1667     c5610               -1   c5611               -1
    x1667     c5612               -1   c5613               -1
    x1667     c5623                1   c5624               -1
    x1668     c2970               -1   c2971               -1
    x1668     c2972               -1   c5606                1
    x1668     c5607                1
    x1669     c2972                1   c2973                1
    x1669     c3727               -1   c5607               -1
    x1669     c6775                1
    x1670     c2974               -1   c2977               -1
    x1670     c2982               -1   c5631                1
    x1670     c5634               -1   c5635               -1
    x1670     c6594               -1   c6595               -1
    x1671     c2974                1   c2975                1
    x1671     c2976                1   c5623               -1
    x1671     c5624               -1   c6764                1
    x1672     c2975               -1   c2999               -1
    x1672     c5617               -1   c5618               -1
    x1672     c5619               -1   c5640                1
    x1672     c5641               -1   c5642               -1
    x1672     c6591               -1   c6592               -1
    x1672     c6593               -1
    x1673     c2976               -1   c2983               -1
    x1673     c5614               -1   c5615               -1
    x1673     c5616               -1   c5631                1
    x1673     c5632               -1   c5633               -1
    x1673     c6588               -1   c6589               -1
    x1673     c6590               -1
    x1674     c2978                1   c2979               -1
    x1674     c2980                1   c2981               -1
    x1674     c2988               -1   c2989               -1
    x1674     c5636                1   c5637                1
    x1674     c5638               -1
    x1675     c2978               -1   c2979                1
    x1675     c5608                1   c5612               -1
    x1675     c5613               -1   c5620               -1
    x1675     c5622               -1   c5634                1
    x1675     c5635               -1   c6589                1
    x1675     c6590                1   c6592                1
    x1675     c6593                1   c6594               -1
    x1676     c2980               -1   c2981                1
    x1676     c5609                1   c5611               -1
    x1676     c5613               -1   c5615               -1
    x1676     c5617               -1   c5619               -1
    x1676     c5632                1   c5633               -1
    x1676     c6589               -1   c6594                1
    x1676     c6596                1
    x1677     c2982                1   c2983                1
    x1677     c2990                1   c5631               -1
    x1677     c5637               -1   c5638               -1
    x1678     c2984                1   c2985               -1
    x1678     c2986                1   c2987               -1
    x1678     c2992               -1   c2993               -1
    x1678     c5637                1   c5638               -1
    x1678     c5639                1
    x1679     c2984               -1   c2985                1
    x1679     c5621               -1   c5622               -1
    x1679     c5625                1   c5629               -1
    x1679     c5630               -1   c5634                1
    x1679     c5635               -1   c6588                1
    x1679     c6590                1   c6591                1
    x1679     c6593                1   c6595               -1
    x1680     c2986               -1   c2987                1
    x1680     c5614               -1   c5618               -1
    x1680     c5619               -1   c5626                1
    x1680     c5628               -1   c5630               -1
    x1680     c5632                1   c5633               -1
    x1680     c6588               -1   c6595                1
    x1680     c6597                1
    x1681     c2989               -1   c2994               -1
    x1681     c2995                1   c5636                1
    x1681     c5643                1   c5644               -1
    x1682     c2990               -1   c2991               -1
    x1682     c2998               -1   c5640                1
    x1682     c5643               -1   c5644               -1
    x1683     c2993               -1   c3000               -1
    x1683     c3001                1   c5639                1
    x1683     c5643                1   c5644               -1
    x1684     c2994                1   c2995               -1
    x1684     c2996                1   c2997               -1
    x1684     c3004                1   c3005                1
    x1684     c5645               -1   c5646                1
    x1684     c5647               -1
    x1685     c2996               -1   c2997                1
    x1685     c5609                1   c5610               -1
    x1685     c5612               -1   c5614               -1
    x1685     c5616               -1   c5618               -1
    x1685     c5641                1   c5642               -1
    x1685     c6592               -1   c6594                1
    x1685     c6596                1
    x1686     c2998                1   c2999                1
    x1686     c3006                1   c5640               -1
    x1686     c5646               -1   c5647               -1
    x1687     c3000                1   c3001               -1
    x1687     c3002                1   c3003               -1
    x1687     c3008                1   c3009                1
    x1687     c5646                1   c5647               -1
    x1687     c5648               -1
    x1688     c3002               -1   c3003                1
    x1688     c5615               -1   c5616               -1
    x1688     c5617               -1   c5626                1
    x1688     c5627               -1   c5629               -1
    x1688     c5641                1   c5642               -1
    x1688     c6591               -1   c6595                1
    x1688     c6597                1
    x1689     c3010               -1   c3012                1
    x1689     c5649                1   c5650               -1
    x1689     c5667                1   c5668               -1
    x1689     c5669                1   c5670                1
    x1689     c5671               -1   c5672               -1
    x1689     c5673               -1   c5674               -1
    x1690     c3010               -1   c3011               -1
    x1690     c3015               -1   c5649                1
    x1690     c5651                1
    x1691     c3011                1   c3013               -1
    x1691     c5649               -1   c5650                1
    x1691     c5652                1   c5653                1
    x1691     c5654               -1   c5655               -1
    x1691     c5656               -1   c5657               -1
    x1691     c5667                1   c5668               -1
    x1692     c3012               -1   c3013               -1
    x1692     c3014               -1   c5650                1
    x1692     c5651                1
    x1693     c3014                1   c3015                1
    x1693     c3726               -1   c5651               -1
    x1693     c6775                1
    x1694     c3016               -1   c3019               -1
    x1694     c3024               -1   c5675                1
    x1694     c5678               -1   c5679               -1
    x1694     c6604               -1   c6605               -1
    x1695     c3016                1   c3017                1
    x1695     c3018                1   c5667               -1
    x1695     c5668               -1   c6763                1
    x1696     c3017               -1   c3041               -1
    x1696     c5661               -1   c5662               -1
    x1696     c5663               -1   c5684                1
    x1696     c5685               -1   c5686               -1
    x1696     c6601               -1   c6602               -1
    x1696     c6603               -1
    x1697     c3018               -1   c3025               -1
    x1697     c5658               -1   c5659               -1
    x1697     c5660               -1   c5675                1
    x1697     c5676               -1   c5677               -1
    x1697     c6598               -1   c6599               -1
    x1697     c6600               -1
    x1698     c3020                1   c3021               -1
    x1698     c3022                1   c3023               -1
    x1698     c3030               -1   c3031               -1
    x1698     c5680                1   c5681                1
    x1698     c5682               -1
    x1699     c3020               -1   c3021                1
    x1699     c5652                1   c5656               -1
    x1699     c5657               -1   c5664               -1
    x1699     c5666               -1   c5678                1
    x1699     c5679               -1   c6599                1
    x1699     c6600                1   c6602                1
    x1699     c6603                1   c6604               -1
    x1700     c3022               -1   c3023                1
    x1700     c5653                1   c5655               -1
    x1700     c5657               -1   c5659               -1
    x1700     c5661               -1   c5663               -1
    x1700     c5676                1   c5677               -1
    x1700     c6599               -1   c6604                1
    x1700     c6606                1
    x1701     c3024                1   c3025                1
    x1701     c3032                1   c5675               -1
    x1701     c5681               -1   c5682               -1
    x1702     c3026                1   c3027               -1
    x1702     c3028                1   c3029               -1
    x1702     c3034               -1   c3035               -1
    x1702     c5681                1   c5682               -1
    x1702     c5683                1
    x1703     c3026               -1   c3027                1
    x1703     c5665               -1   c5666               -1
    x1703     c5669                1   c5673               -1
    x1703     c5674               -1   c5678                1
    x1703     c5679               -1   c6598                1
    x1703     c6600                1   c6601                1
    x1703     c6603                1   c6605               -1
    x1704     c3028               -1   c3029                1
    x1704     c5658               -1   c5662               -1
    x1704     c5663               -1   c5670                1
    x1704     c5672               -1   c5674               -1
    x1704     c5676                1   c5677               -1
    x1704     c6598               -1   c6605                1
    x1704     c6607                1
    x1705     c3031               -1   c3036               -1
    x1705     c3037                1   c5680                1
    x1705     c5687                1   c5688               -1
    x1706     c3032               -1   c3033               -1
    x1706     c3040               -1   c5684                1
    x1706     c5687               -1   c5688               -1
    x1707     c3035               -1   c3042               -1
    x1707     c3043                1   c5683                1
    x1707     c5687                1   c5688               -1
    x1708     c3036                1   c3037               -1
    x1708     c3038                1   c3039               -1
    x1708     c3046                1   c3047                1
    x1708     c5689               -1   c5696                1
    x1708     c5697               -1
    x1709     c3038               -1   c3039                1
    x1709     c5653                1   c5654               -1
    x1709     c5656               -1   c5658               -1
    x1709     c5660               -1   c5662               -1
    x1709     c5685                1   c5686               -1
    x1709     c6602               -1   c6604                1
    x1709     c6606                1
    x1710     c3040                1   c3041                1
    x1710     c3048                1   c3049                1
    x1710     c5684               -1   c5696               -1
    x1710     c5697               -1
    x1711     c3042                1   c3043               -1
    x1711     c3044                1   c3045               -1
    x1711     c3050                1   c3051                1
    x1711     c5696                1   c5697               -1
    x1711     c5698               -1
    x1712     c3044               -1   c3045                1
    x1712     c5659               -1   c5660               -1
    x1712     c5661               -1   c5670                1
    x1712     c5671               -1   c5673               -1
    x1712     c5685                1   c5686               -1
    x1712     c6601               -1   c6605                1
    x1712     c6607                1
    x1713     c3052               -1   c3054                1
    x1713     c3061                1   c3062               -1
    x1713     c5699                1   c5700               -1
    x1713     c5702                1   c5703               -1
    x1714     c3052               -1   c3053               -1
    x1714     c3057               -1   c5699                1
    x1714     c5701                1
    x1715     c3053                1   c3055               -1
    x1715     c3058                1   c3059               -1
    x1715     c5699               -1   c5700                1
    x1715     c5702                1   c5703               -1
    x1716     c3054               -1   c3055               -1
    x1716     c3056               -1   c5700                1
    x1716     c5701                1
    x1717     c3056                1   c3057                1
    x1717     c3725               -1   c5701               -1
    x1717     c6774                1
    x1718     c3058                1   c3059               -1
    x1718     c5704               -1   c5705               -1
    x1718     c5706                1   c5707                1
    x1718     c5708                1   c5709                1
    x1718     c5719                1   c5720               -1
    x1719     c3060               -1   c3063                1
    x1719     c3064                1   c3065                1
    x1719     c5719               -1   c5720               -1
    x1720     c3060                1   c5702               -1
    x1720     c5703               -1   c6763                1
    x1721     c3061                1   c3062               -1
    x1721     c5719                1   c5720               -1
    x1721     c5721               -1   c5722               -1
    x1721     c5723                1   c5724                1
    x1721     c5725                1   c5726                1
    x1722     c3063               -1   c3066               -1
    x1722     c3071               -1   c5727                1
    x1722     c5730               -1   c5731               -1
    x1722     c6614               -1   c6615               -1
    x1723     c3064               -1   c3088               -1
    x1723     c5713               -1   c5714               -1
    x1723     c5715               -1   c5736                1
    x1723     c5737               -1   c5738               -1
    x1723     c6611               -1   c6612               -1
    x1723     c6613               -1
    x1724     c3065               -1   c3072               -1
    x1724     c5710               -1   c5711               -1
    x1724     c5712               -1   c5727                1
    x1724     c5728               -1   c5729               -1
    x1724     c6608               -1   c6609               -1
    x1724     c6610               -1
    x1725     c3067                1   c3068               -1
    x1725     c3069                1   c3070               -1
    x1725     c3077                1   c3078                1
    x1725     c5732               -1   c5733                1
    x1725     c5734               -1
    x1726     c3067               -1   c3068                1
    x1726     c5704               -1   c5708                1
    x1726     c5709                1   c5717                1
    x1726     c5718                1   c5730                1
    x1726     c5731               -1   c6608               -1
    x1726     c6610               -1   c6611               -1
    x1726     c6613               -1   c6614                1
    x1727     c3069               -1   c3070                1
    x1727     c5705               -1   c5707                1
    x1727     c5709                1   c5711               -1
    x1727     c5714                1   c5715                1
    x1727     c5728                1   c5729               -1
    x1727     c6609               -1   c6614               -1
    x1727     c6616               -1
    x1728     c3071                1   c3072                1
    x1728     c3079                1   c5727               -1
    x1728     c5733               -1   c5734               -1
    x1729     c3073                1   c3074               -1
    x1729     c3075                1   c3076               -1
    x1729     c3081                1   c3082                1
    x1729     c5733                1   c5734               -1
    x1729     c5735               -1
    x1730     c3073               -1   c3074                1
    x1730     c5716                1   c5718                1
    x1730     c5721               -1   c5725                1
    x1730     c5726                1   c5730                1
    x1730     c5731               -1   c6609               -1
    x1730     c6610               -1   c6612               -1
    x1730     c6613               -1   c6615                1
    x1731     c3075               -1   c3076                1
    x1731     c5710               -1   c5713                1
    x1731     c5715                1   c5722               -1
    x1731     c5724                1   c5726                1
    x1731     c5728                1   c5729               -1
    x1731     c6608               -1   c6615               -1
    x1731     c6617               -1
    x1732     c3078                1   c3083               -1
    x1732     c3084                1   c5732               -1
    x1732     c5739                1   c5740               -1
    x1733     c3079               -1   c3080               -1
    x1733     c3087               -1   c5736                1
    x1733     c5739               -1   c5740               -1
    x1734     c3082                1   c3089               -1
    x1734     c3090                1   c5735               -1
    x1734     c5739                1   c5740               -1
    x1735     c3083                1   c3084               -1
    x1735     c3085                1   c3086               -1
    x1735     c3093               -1   c3094               -1
    x1735     c5741                1   c5742                1
    x1735     c5743               -1
    x1736     c3085               -1   c3086                1
    x1736     c5705               -1   c5706                1
    x1736     c5708                1   c5711                1
    x1736     c5712                1   c5714               -1
    x1736     c5737                1   c5738               -1
    x1736     c6612               -1   c6614               -1
    x1736     c6616               -1
    x1737     c3087                1   c3088                1
    x1737     c3095                1   c5736               -1
    x1737     c5742               -1   c5743               -1
    x1738     c3089                1   c3090               -1
    x1738     c3091                1   c3092               -1
    x1738     c3097               -1   c3098               -1
    x1738     c5742                1   c5743               -1
    x1738     c5744                1
    x1739     c3091               -1   c3092                1
    x1739     c5710                1   c5712                1
    x1739     c5713               -1   c5722               -1
    x1739     c5723                1   c5725                1
    x1739     c5737                1   c5738               -1
    x1739     c6611               -1   c6615               -1
    x1739     c6617               -1
    x1740     c3094               -1   c3099               -1
    x1740     c3100                1   c5741                1
    x1740     c5748                1   c5749               -1
    x1741     c3095               -1   c3096               -1
    x1741     c3103               -1   c5745                1
    x1741     c5748               -1   c5749               -1
    x1742     c3098               -1   c3105               -1
    x1742     c3106                1   c5744                1
    x1742     c5748                1   c5749               -1
    x1743     c3099                1   c3100               -1
    x1743     c3101                1   c3102               -1
    x1743     c3109                1   c3110                1
    x1743     c3111                1   c3112                1
    x1743     c5750                1   c5751               -1
    x1743     c6754               -1
    x1744     c3101               -1   c3102                1
    x1744     c3180                1   c3181               -1
    x1744     c5746                1   c5747               -1
    x1745     c3103                1   c3104                1
    x1745     c3113                1   c5745               -1
    x1745     c5750               -1   c5751               -1
    x1746     c3104               -1   c3182               -1
    x1746     c5745                1   c5746               -1
    x1746     c5747               -1
    x1747     c3105                1   c3106               -1
    x1747     c3107                1   c3108               -1
    x1747     c3117                1   c3118                1
    x1747     c3119                1   c3120                1
    x1747     c5750                1   c5751               -1
    x1747     c6755               -1
    x1748     c3107               -1   c3108                1
    x1748     c3183                1   c3184               -1
    x1748     c5746                1   c5747               -1
    x1749     c3111                1   c3115                1
    x1749     c3119                1   c3121               -1
    x1749     c3122               -1   c5752                1
    x1749     c6754               -1   c6755               -1
    x1750     c3123               -1   c3125                1
    x1750     c5753                1   c5754               -1
    x1750     c5771                1   c5772               -1
    x1750     c5773                1   c5774                1
    x1750     c5775               -1   c5776               -1
    x1750     c5777               -1   c5778               -1
    x1751     c3123               -1   c3124               -1
    x1751     c3128               -1   c5753                1
    x1751     c5755                1
    x1752     c3124                1   c3126               -1
    x1752     c5753               -1   c5754                1
    x1752     c5756                1   c5757                1
    x1752     c5758               -1   c5759               -1
    x1752     c5760               -1   c5761               -1
    x1752     c5771                1   c5772               -1
    x1753     c3125               -1   c3126               -1
    x1753     c3127               -1   c5754                1
    x1753     c5755                1
    x1754     c3127                1   c3128                1
    x1754     c3724               -1   c5755               -1
    x1754     c6774                1
    x1755     c3129               -1   c3132               -1
    x1755     c3137               -1   c5779                1
    x1755     c5782               -1   c5783               -1
    x1755     c6624               -1   c6625               -1
    x1756     c3129                1   c3130                1
    x1756     c3131                1   c5771               -1
    x1756     c5772               -1   c6763                1
    x1757     c3130               -1   c3154               -1
    x1757     c5765               -1   c5766               -1
    x1757     c5767               -1   c5788                1
    x1757     c5789               -1   c5790               -1
    x1757     c6621               -1   c6622               -1
    x1757     c6623               -1
    x1758     c3131               -1   c3138               -1
    x1758     c5762               -1   c5763               -1
    x1758     c5764               -1   c5779                1
    x1758     c5780               -1   c5781               -1
    x1758     c6618               -1   c6619               -1
    x1758     c6620               -1
    x1759     c3133                1   c3134               -1
    x1759     c3135                1   c3136               -1
    x1759     c3143               -1   c3144               -1
    x1759     c5784                1   c5785                1
    x1759     c5786               -1
    x1760     c3133               -1   c3134                1
    x1760     c5756                1   c5760               -1
    x1760     c5761               -1   c5768               -1
    x1760     c5770               -1   c5782                1
    x1760     c5783               -1   c6619                1
    x1760     c6620                1   c6622                1
    x1760     c6623                1   c6624               -1
    x1761     c3135               -1   c3136                1
    x1761     c5757                1   c5759               -1
    x1761     c5761               -1   c5763               -1
    x1761     c5765               -1   c5767               -1
    x1761     c5780                1   c5781               -1
    x1761     c6619               -1   c6624                1
    x1761     c6626                1
    x1762     c3137                1   c3138                1
    x1762     c3145                1   c5779               -1
    x1762     c5785               -1   c5786               -1
    x1763     c3139                1   c3140               -1
    x1763     c3141                1   c3142               -1
    x1763     c3147               -1   c3148               -1
    x1763     c5785                1   c5786               -1
    x1763     c5787                1
    x1764     c3139               -1   c3140                1
    x1764     c5769               -1   c5770               -1
    x1764     c5773                1   c5777               -1
    x1764     c5778               -1   c5782                1
    x1764     c5783               -1   c6618                1
    x1764     c6620                1   c6621                1
    x1764     c6623                1   c6625               -1
    x1765     c3141               -1   c3142                1
    x1765     c5762               -1   c5766               -1
    x1765     c5767               -1   c5774                1
    x1765     c5776               -1   c5778               -1
    x1765     c5780                1   c5781               -1
    x1765     c6618               -1   c6625                1
    x1765     c6627                1
    x1766     c3144               -1   c3149               -1
    x1766     c3150                1   c5784                1
    x1766     c5791                1   c5792               -1
    x1767     c3145               -1   c3146               -1
    x1767     c3153               -1   c5788                1
    x1767     c5791               -1   c5792               -1
    x1768     c3148               -1   c3155               -1
    x1768     c3156                1   c5787                1
    x1768     c5791                1   c5792               -1
    x1769     c3149                1   c3150               -1
    x1769     c3151                1   c3152               -1
    x1769     c3159                1   c3160                1
    x1769     c5793               -1   c5800                1
    x1769     c5801               -1
    x1770     c3151               -1   c3152                1
    x1770     c5757                1   c5758               -1
    x1770     c5760               -1   c5762               -1
    x1770     c5764               -1   c5766               -1
    x1770     c5789                1   c5790               -1
    x1770     c6622               -1   c6624                1
    x1770     c6626                1
    x1771     c3153                1   c3154                1
    x1771     c3161                1   c3162                1
    x1771     c5788               -1   c5800               -1
    x1771     c5801               -1
    x1772     c3155                1   c3156               -1
    x1772     c3157                1   c3158               -1
    x1772     c3163                1   c3164                1
    x1772     c5800                1   c5801               -1
    x1772     c5802               -1
    x1773     c3157               -1   c3158                1
    x1773     c5763               -1   c5764               -1
    x1773     c5765               -1   c5774                1
    x1773     c5775               -1   c5777               -1
    x1773     c5789                1   c5790               -1
    x1773     c6621               -1   c6625                1
    x1773     c6627                1
    x1774     c3160                1   c3165               -1
    x1774     c3166                1   c5793               -1
    x1774     c5795               -1   c5798                1
    x1774     c5799                1   c5807                1
    x1774     c5808               -1
    x1775     c3162               -1   c3171               -1
    x1775     c5794               -1   c5795               -1
    x1775     c5796               -1   c5807               -1
    x1775     c5808               -1   c6628                1
    x1776     c3164                1   c3174               -1
    x1776     c3175                1   c5794               -1
    x1776     c5797                1   c5799                1
    x1776     c5802               -1   c5807                1
    x1776     c5808               -1
    x1777     c3165                1   c3166               -1
    x1777     c3167                1   c3168               -1
    x1777     c3169                1   c3170               -1
    x1777     c3180                1   c3181               -1
    x1777     c5809                1   c5810               -1
    x1778     c3167               -1   c3168                1
    x1778     c3222                1   c5805                1
    x1778     c5806               -1   c5851               -1
    x1779     c3169               -1   c3170                1
    x1779     c3264                1   c5803                1
    x1779     c5804               -1   c5895               -1
    x1779     c5897               -1   c5900                1
    x1779     c5901                1
    x1780     c3171                1   c3172                1
    x1780     c3173                1   c3182                1
    x1780     c5809               -1   c5810               -1
    x1780     c6628               -1
    x1781     c3172               -1   c3223               -1
    x1781     c3224               -1   c5805               -1
    x1781     c5806               -1   c6628                1
    x1782     c3173               -1   c3266               -1
    x1782     c5803               -1   c5804               -1
    x1782     c5896               -1   c5897               -1
    x1782     c5898               -1   c6628                1
    x1783     c3174                1   c3175               -1
    x1783     c3176                1   c3177               -1
    x1783     c3178                1   c3179               -1
    x1783     c3183                1   c3184               -1
    x1783     c5809                1   c5810               -1
    x1784     c3176               -1   c3177                1
    x1784     c3226                1   c5805                1
    x1784     c5806               -1   c5854               -1
    x1785     c3178               -1   c3179                1
    x1785     c3268                1   c5803                1
    x1785     c5804               -1   c5896               -1
    x1785     c5899                1   c5901                1
    x1785     c5904               -1
    x1786     c3185               -1   c3187                1
    x1786     c5811                1   c5812               -1
    x1786     c5829                1   c5830               -1
    x1786     c5831                1   c5832                1
    x1786     c5833               -1   c5834               -1
    x1786     c5835               -1   c5836               -1
    x1787     c3185               -1   c3186               -1
    x1787     c3190               -1   c5811                1
    x1787     c5813                1
    x1788     c3186                1   c3188               -1
    x1788     c5811               -1   c5812                1
    x1788     c5814                1   c5815                1
    x1788     c5816               -1   c5817               -1
    x1788     c5818               -1   c5819               -1
    x1788     c5829                1   c5830               -1
    x1789     c3187               -1   c3188               -1
    x1789     c3189               -1   c5812                1
    x1789     c5813                1
    x1790     c3189                1   c3190                1
    x1790     c3723               -1   c5813               -1
    x1790     c6774                1
    x1791     c3191               -1   c3194               -1
    x1791     c3199               -1   c5837                1
    x1791     c5840               -1   c5841               -1
    x1791     c6635               -1   c6636               -1
    x1792     c3191                1   c3192                1
    x1792     c3193                1   c5829               -1
    x1792     c5830               -1   c6763                1
    x1793     c3192               -1   c3216               -1
    x1793     c5823               -1   c5824               -1
    x1793     c5825               -1   c5846                1
    x1793     c5847               -1   c5848               -1
    x1793     c6632               -1   c6633               -1
    x1793     c6634               -1
    x1794     c3193               -1   c3200               -1
    x1794     c5820               -1   c5821               -1
    x1794     c5822               -1   c5837                1
    x1794     c5838               -1   c5839               -1
    x1794     c6629               -1   c6630               -1
    x1794     c6631               -1
    x1795     c3195                1   c3196               -1
    x1795     c3197                1   c3198               -1
    x1795     c3205               -1   c3206               -1
    x1795     c5842                1   c5843                1
    x1795     c5844               -1
    x1796     c3195               -1   c3196                1
    x1796     c5814                1   c5818               -1
    x1796     c5819               -1   c5826               -1
    x1796     c5828               -1   c5840                1
    x1796     c5841               -1   c6630                1
    x1796     c6631                1   c6633                1
    x1796     c6634                1   c6635               -1
    x1797     c3197               -1   c3198                1
    x1797     c5815                1   c5817               -1
    x1797     c5819               -1   c5821               -1
    x1797     c5823               -1   c5825               -1
    x1797     c5838                1   c5839               -1
    x1797     c6630               -1   c6635                1
    x1797     c6637                1
    x1798     c3199                1   c3200                1
    x1798     c3207                1   c5837               -1
    x1798     c5843               -1   c5844               -1
    x1799     c3201                1   c3202               -1
    x1799     c3203                1   c3204               -1
    x1799     c3209               -1   c3210               -1
    x1799     c5843                1   c5844               -1
    x1799     c5845                1
    x1800     c3201               -1   c3202                1
    x1800     c5827               -1   c5828               -1
    x1800     c5831                1   c5835               -1
    x1800     c5836               -1   c5840                1
    x1800     c5841               -1   c6629                1
    x1800     c6631                1   c6632                1
    x1800     c6634                1   c6636               -1
    x1801     c3203               -1   c3204                1
    x1801     c5820               -1   c5824               -1
    x1801     c5825               -1   c5832                1
    x1801     c5834               -1   c5836               -1
    x1801     c5838                1   c5839               -1
    x1801     c6629               -1   c6636                1
    x1801     c6638                1
    x1802     c3206               -1   c3211               -1
    x1802     c3212                1   c5842                1
    x1802     c5849                1   c5850               -1
    x1803     c3207               -1   c3208               -1
    x1803     c3215               -1   c5846                1
    x1803     c5849               -1   c5850               -1
    x1804     c3210               -1   c3217               -1
    x1804     c3218                1   c5845                1
    x1804     c5849                1   c5850               -1
    x1805     c3211                1   c3212               -1
    x1805     c3213                1   c3214               -1
    x1805     c3221                1   c3222                1
    x1805     c5851               -1   c5852                1
    x1805     c5853               -1
    x1806     c3213               -1   c3214                1
    x1806     c5815                1   c5816               -1
    x1806     c5818               -1   c5820               -1
    x1806     c5822               -1   c5824               -1
    x1806     c5847                1   c5848               -1
    x1806     c6633               -1   c6635                1
    x1806     c6637                1
    x1807     c3215                1   c3216                1
    x1807     c3223                1   c5846               -1
    x1807     c5852               -1   c5853               -1
    x1808     c3217                1   c3218               -1
    x1808     c3219                1   c3220               -1
    x1808     c3225                1   c3226                1
    x1808     c5852                1   c5853               -1
    x1808     c5854               -1
    x1809     c3219               -1   c3220                1
    x1809     c5821               -1   c5822               -1
    x1809     c5823               -1   c5832                1
    x1809     c5833               -1   c5835               -1
    x1809     c5847                1   c5848               -1
    x1809     c6632               -1   c6636                1
    x1809     c6638                1
    x1810     c3227               -1   c3229                1
    x1810     c5855                1   c5856               -1
    x1810     c5873                1   c5874               -1
    x1810     c5875                1   c5876                1
    x1810     c5877               -1   c5878               -1
    x1810     c5879               -1   c5880               -1
    x1811     c3227               -1   c3228               -1
    x1811     c3232               -1   c5855                1
    x1811     c5857                1
    x1812     c3228                1   c3230               -1
    x1812     c5855               -1   c5856                1
    x1812     c5858                1   c5859                1
    x1812     c5860               -1   c5861               -1
    x1812     c5862               -1   c5863               -1
    x1812     c5873                1   c5874               -1
    x1813     c3229               -1   c3230               -1
    x1813     c3231               -1   c5856                1
    x1813     c5857                1
    x1814     c3231                1   c3232                1
    x1814     c3722               -1   c5857               -1
    x1814     c6774                1
    x1815     c3233               -1   c3236               -1
    x1815     c3241               -1   c5881                1
    x1815     c5884               -1   c5885               -1
    x1815     c6645               -1   c6646               -1
    x1816     c3233                1   c3234                1
    x1816     c3235                1   c5873               -1
    x1816     c5874               -1   c6762                1
    x1817     c3234               -1   c3258               -1
    x1817     c5867               -1   c5868               -1
    x1817     c5869               -1   c5890                1
    x1817     c5891               -1   c5892               -1
    x1817     c6642               -1   c6643               -1
    x1817     c6644               -1
    x1818     c3235               -1   c3242               -1
    x1818     c5864               -1   c5865               -1
    x1818     c5866               -1   c5881                1
    x1818     c5882               -1   c5883               -1
    x1818     c6639               -1   c6640               -1
    x1818     c6641               -1
    x1819     c3237                1   c3238               -1
    x1819     c3239                1   c3240               -1
    x1819     c3247               -1   c3248               -1
    x1819     c5886                1   c5887                1
    x1819     c5888               -1
    x1820     c3237               -1   c3238                1
    x1820     c5858                1   c5862               -1
    x1820     c5863               -1   c5870               -1
    x1820     c5872               -1   c5884                1
    x1820     c5885               -1   c6640                1
    x1820     c6641                1   c6643                1
    x1820     c6644                1   c6645               -1
    x1821     c3239               -1   c3240                1
    x1821     c5859                1   c5861               -1
    x1821     c5863               -1   c5865               -1
    x1821     c5867               -1   c5869               -1
    x1821     c5882                1   c5883               -1
    x1821     c6640               -1   c6645                1
    x1821     c6647                1
    x1822     c3241                1   c3242                1
    x1822     c3249                1   c5881               -1
    x1822     c5887               -1   c5888               -1
    x1823     c3243                1   c3244               -1
    x1823     c3245                1   c3246               -1
    x1823     c3251               -1   c3252               -1
    x1823     c5887                1   c5888               -1
    x1823     c5889                1
    x1824     c3243               -1   c3244                1
    x1824     c5871               -1   c5872               -1
    x1824     c5875                1   c5879               -1
    x1824     c5880               -1   c5884                1
    x1824     c5885               -1   c6639                1
    x1824     c6641                1   c6642                1
    x1824     c6644                1   c6646               -1
    x1825     c3245               -1   c3246                1
    x1825     c5864               -1   c5868               -1
    x1825     c5869               -1   c5876                1
    x1825     c5878               -1   c5880               -1
    x1825     c5882                1   c5883               -1
    x1825     c6639               -1   c6646                1
    x1825     c6648                1
    x1826     c3248               -1   c3253               -1
    x1826     c3254                1   c5886                1
    x1826     c5893                1   c5894               -1
    x1827     c3249               -1   c3250               -1
    x1827     c3257               -1   c5890                1
    x1827     c5893               -1   c5894               -1
    x1828     c3252               -1   c3259               -1
    x1828     c3260                1   c5889                1
    x1828     c5893                1   c5894               -1
    x1829     c3253                1   c3254               -1
    x1829     c3255                1   c3256               -1
    x1829     c3263                1   c3264                1
    x1829     c5895               -1   c5902                1
    x1829     c5903               -1
    x1830     c3255               -1   c3256                1
    x1830     c5859                1   c5860               -1
    x1830     c5862               -1   c5864               -1
    x1830     c5866               -1   c5868               -1
    x1830     c5891                1   c5892               -1
    x1830     c6643               -1   c6645                1
    x1830     c6647                1
    x1831     c3257                1   c3258                1
    x1831     c3265                1   c3266                1
    x1831     c5890               -1   c5902               -1
    x1831     c5903               -1
    x1832     c3259                1   c3260               -1
    x1832     c3261                1   c3262               -1
    x1832     c3267                1   c3268                1
    x1832     c5902                1   c5903               -1
    x1832     c5904               -1
    x1833     c3261               -1   c3262                1
    x1833     c5865               -1   c5866               -1
    x1833     c5867               -1   c5876                1
    x1833     c5877               -1   c5879               -1
    x1833     c5891                1   c5892               -1
    x1833     c6642               -1   c6646                1
    x1833     c6648                1
    x1834     c3269               -1   c3271                1
    x1834     c5905                1   c5906               -1
    x1834     c5923                1   c5924               -1
    x1834     c5925                1   c5926                1
    x1834     c5927               -1   c5928               -1
    x1834     c5929               -1   c5930               -1
    x1835     c3269               -1   c3270               -1
    x1835     c3274               -1   c5905                1
    x1835     c5907                1
    x1836     c3270                1   c3272               -1
    x1836     c5905               -1   c5906                1
    x1836     c5908                1   c5909                1
    x1836     c5910               -1   c5911               -1
    x1836     c5912               -1   c5913               -1
    x1836     c5923                1   c5924               -1
    x1837     c3271               -1   c3272               -1
    x1837     c3273               -1   c5906                1
    x1837     c5907                1
    x1838     c3273                1   c3274                1
    x1838     c3721               -1   c5907               -1
    x1838     c6773                1
    x1839     c3275               -1   c3278               -1
    x1839     c3283               -1   c5931                1
    x1839     c5934               -1   c5935               -1
    x1839     c6655               -1   c6656               -1
    x1840     c3275                1   c3276                1
    x1840     c3277                1   c5923               -1
    x1840     c5924               -1   c6762                1
    x1841     c3276               -1   c3299               -1
    x1841     c5917               -1   c5918               -1
    x1841     c5919               -1   c5940                1
    x1841     c5943               -1   c5944               -1
    x1841     c6652               -1   c6653               -1
    x1841     c6654               -1
    x1842     c3277               -1   c3284               -1
    x1842     c5914               -1   c5915               -1
    x1842     c5916               -1   c5931                1
    x1842     c5932               -1   c5933               -1
    x1842     c6649               -1   c6650               -1
    x1842     c6651               -1
    x1843     c3279                1   c3280               -1
    x1843     c3281                1   c3282               -1
    x1843     c3289               -1   c3290               -1
    x1843     c5936                1   c5937                1
    x1843     c5938               -1
    x1844     c3279               -1   c3280                1
    x1844     c5908                1   c5912               -1
    x1844     c5913               -1   c5920               -1
    x1844     c5922               -1   c5934                1
    x1844     c5935               -1   c6650                1
    x1844     c6651                1   c6653                1
    x1844     c6654                1   c6655               -1
    x1845     c3281               -1   c3282                1
    x1845     c5909                1   c5911               -1
    x1845     c5913               -1   c5915               -1
    x1845     c5917               -1   c5919               -1
    x1845     c5932                1   c5933               -1
    x1845     c6650               -1   c6655                1
    x1845     c6657                1
    x1846     c3283                1   c3284                1
    x1846     c3291                1   c5931               -1
    x1846     c5937               -1   c5938               -1
    x1847     c3285                1   c3286               -1
    x1847     c3287                1   c3288               -1
    x1847     c3293               -1   c3294               -1
    x1847     c5937                1   c5938               -1
    x1847     c5939                1
    x1848     c3285               -1   c3286                1
    x1848     c5921               -1   c5922               -1
    x1848     c5925                1   c5929               -1
    x1848     c5930               -1   c5934                1
    x1848     c5935               -1   c6649                1
    x1848     c6651                1   c6652                1
    x1848     c6654                1   c6656               -1
    x1849     c3287               -1   c3288                1
    x1849     c5914               -1   c5918               -1
    x1849     c5919               -1   c5926                1
    x1849     c5928               -1   c5930               -1
    x1849     c5932                1   c5933               -1
    x1849     c6649               -1   c6656                1
    x1849     c6658                1
    x1850     c3290               -1   c3297               -1
    x1850     c3298                1   c5936                1
    x1850     c5941                1   c5942               -1
    x1851     c3291               -1   c3292               -1
    x1851     c3300               -1   c5940                1
    x1851     c5941               -1   c5942               -1
    x1852     c3294               -1   c3303               -1
    x1852     c3304                1   c5939                1
    x1852     c5941                1   c5942               -1
    x1853     c3295                1   c3296               -1
    x1853     c3297                1   c3298               -1
    x1853     c3305                1   c3306                1
    x1853     c5945               -1   c5946                1
    x1853     c5947               -1
    x1854     c3295               -1   c3296                1
    x1854     c5909                1   c5910               -1
    x1854     c5912               -1   c5914               -1
    x1854     c5916               -1   c5918               -1
    x1854     c5943                1   c5944               -1
    x1854     c6653               -1   c6655                1
    x1854     c6657                1
    x1855     c3299                1   c3300                1
    x1855     c3307                1   c5940               -1
    x1855     c5946               -1   c5947               -1
    x1856     c3301                1   c3302               -1
    x1856     c3303                1   c3304               -1
    x1856     c3309                1   c3310                1
    x1856     c5946                1   c5947               -1
    x1856     c5948               -1
    x1857     c3301               -1   c3302                1
    x1857     c5915               -1   c5916               -1
    x1857     c5917               -1   c5926                1
    x1857     c5927               -1   c5929               -1
    x1857     c5943                1   c5944               -1
    x1857     c6652               -1   c6656                1
    x1857     c6658                1
    x1858     c3306                1   c3311               -1
    x1858     c3312                1   c5945               -1
    x1858     c5953                1   c5954               -1
    x1859     c3307               -1   c3308               -1
    x1859     c3317               -1   c5953               -1
    x1859     c5954               -1   c6659                1
    x1860     c3310                1   c3320               -1
    x1860     c3321                1   c5948               -1
    x1860     c5953                1   c5954               -1
    x1861     c3311                1   c3312               -1
    x1861     c3313                1   c3314               -1
    x1861     c3315                1   c3316               -1
    x1861     c3326                1   c3327               -1
    x1861     c5955                1   c5956               -1
    x1862     c3313               -1   c3314                1
    x1862     c3392                1   c5951                1
    x1862     c5952               -1   c6005               -1
    x1863     c3315               -1   c3316                1
    x1863     c3434                1   c5949                1
    x1863     c5950               -1   c6049               -1
    x1863     c6051               -1   c6054                1
    x1863     c6055                1
    x1864     c3317                1   c3318                1
    x1864     c3319                1   c3328                1
    x1864     c5955               -1   c5956               -1
    x1864     c6659               -1
    x1865     c3318               -1   c3393               -1
    x1865     c3394               -1   c5951               -1
    x1865     c5952               -1   c6659                1
    x1866     c3319               -1   c3436               -1
    x1866     c5949               -1   c5950               -1
    x1866     c6050               -1   c6051               -1
    x1866     c6052               -1   c6659                1
    x1867     c3320                1   c3321               -1
    x1867     c3322                1   c3323               -1
    x1867     c3324                1   c3325               -1
    x1867     c3329                1   c3330               -1
    x1867     c5955                1   c5956               -1
    x1868     c3322               -1   c3323                1
    x1868     c3396                1   c5951                1
    x1868     c5952               -1   c6008               -1
    x1869     c3324               -1   c3325                1
    x1869     c3438                1   c5949                1
    x1869     c5950               -1   c6050               -1
    x1869     c6053                1   c6055                1
    x1869     c6058               -1
    x1870     c3326                1   c3327               -1
    x1870     c3331               -1   c3332                1
    x1870     c5960                1   c5961               -1
    x1871     c3328               -1   c3335               -1
    x1871     c5957                1   c5960               -1
    x1871     c5961               -1
    x1872     c3329                1   c3330               -1
    x1872     c3337               -1   c3338                1
    x1872     c5960                1   c5961               -1
    x1873     c3331                1   c3332               -1
    x1873     c3333                1   c3334               -1
    x1873     c3341                1   c3342                1
    x1873     c3343                1   c3344                1
    x1873     c5962                1   c5963               -1
    x1873     c6756               -1
    x1874     c3333               -1   c3334                1
    x1874     c3481               -1   c5958                1
    x1874     c5959               -1   c6101                1
    x1874     c6103               -1   c6105               -1
    x1874     c6107               -1
    x1875     c3335                1   c3336                1
    x1875     c3345                1   c5957               -1
    x1875     c5962               -1   c5963               -1
    x1876     c3336               -1   c3483               -1
    x1876     c5957                1   c5958               -1
    x1876     c5959               -1   c6102               -1
    x1876     c6103               -1   c6104               -1
    x1877     c3337                1   c3338               -1
    x1877     c3339                1   c3340               -1
    x1877     c3349                1   c3350                1
    x1877     c3351                1   c3352                1
    x1877     c5962                1   c5963               -1
    x1877     c6757               -1
    x1878     c3339               -1   c3340                1
    x1878     c3485               -1   c5958                1
    x1878     c5959               -1   c6102               -1
    x1878     c6106               -1   c6107               -1
    x1878     c6110                1
    x1879     c3343                1   c3347                1
    x1879     c3351                1   c3353               -1
    x1879     c3354               -1   c5964                1
    x1879     c6756               -1   c6757               -1
    x1880     c3355               -1   c3357                1
    x1880     c5965                1   c5966               -1
    x1880     c5983                1   c5984               -1
    x1880     c5985                1   c5986                1
    x1880     c5987               -1   c5988               -1
    x1880     c5989               -1   c5990               -1
    x1881     c3355               -1   c3356               -1
    x1881     c3360               -1   c5965                1
    x1881     c5967                1
    x1882     c3356                1   c3358               -1
    x1882     c5965               -1   c5966                1
    x1882     c5968                1   c5969                1
    x1882     c5970               -1   c5971               -1
    x1882     c5972               -1   c5973               -1
    x1882     c5983                1   c5984               -1
    x1883     c3357               -1   c3358               -1
    x1883     c3359               -1   c5966                1
    x1883     c5967                1
    x1884     c3359                1   c3360                1
    x1884     c3720               -1   c5967               -1
    x1884     c6773                1
    x1885     c3361               -1   c3364               -1
    x1885     c3369               -1   c5991                1
    x1885     c5994               -1   c5995               -1
    x1885     c6666               -1   c6667               -1
    x1886     c3361                1   c3362                1
    x1886     c3363                1   c5983               -1
    x1886     c5984               -1   c6762                1
    x1887     c3362               -1   c3386               -1
    x1887     c5977               -1   c5978               -1
    x1887     c5979               -1   c6000                1
    x1887     c6001               -1   c6002               -1
    x1887     c6663               -1   c6664               -1
    x1887     c6665               -1
    x1888     c3363               -1   c3370               -1
    x1888     c5974               -1   c5975               -1
    x1888     c5976               -1   c5991                1
    x1888     c5992               -1   c5993               -1
    x1888     c6660               -1   c6661               -1
    x1888     c6662               -1
    x1889     c3365                1   c3366               -1
    x1889     c3367                1   c3368               -1
    x1889     c3375               -1   c3376               -1
    x1889     c5996                1   c5997                1
    x1889     c5998               -1
    x1890     c3365               -1   c3366                1
    x1890     c5968                1   c5972               -1
    x1890     c5973               -1   c5980               -1
    x1890     c5982               -1   c5994                1
    x1890     c5995               -1   c6661                1
    x1890     c6662                1   c6664                1
    x1890     c6665                1   c6666               -1
    x1891     c3367               -1   c3368                1
    x1891     c5969                1   c5971               -1
    x1891     c5973               -1   c5975               -1
    x1891     c5977               -1   c5979               -1
    x1891     c5992                1   c5993               -1
    x1891     c6661               -1   c6666                1
    x1891     c6668                1
    x1892     c3369                1   c3370                1
    x1892     c3377                1   c5991               -1
    x1892     c5997               -1   c5998               -1
    x1893     c3371                1   c3372               -1
    x1893     c3373                1   c3374               -1
    x1893     c3379               -1   c3380               -1
    x1893     c5997                1   c5998               -1
    x1893     c5999                1
    x1894     c3371               -1   c3372                1
    x1894     c5981               -1   c5982               -1
    x1894     c5985                1   c5989               -1
    x1894     c5990               -1   c5994                1
    x1894     c5995               -1   c6660                1
    x1894     c6662                1   c6663                1
    x1894     c6665                1   c6667               -1
    x1895     c3373               -1   c3374                1
    x1895     c5974               -1   c5978               -1
    x1895     c5979               -1   c5986                1
    x1895     c5988               -1   c5990               -1
    x1895     c5992                1   c5993               -1
    x1895     c6660               -1   c6667                1
    x1895     c6669                1
    x1896     c3376               -1   c3381               -1
    x1896     c3382                1   c5996                1
    x1896     c6003                1   c6004               -1
    x1897     c3377               -1   c3378               -1
    x1897     c3385               -1   c6000                1
    x1897     c6003               -1   c6004               -1
    x1898     c3380               -1   c3387               -1
    x1898     c3388                1   c5999                1
    x1898     c6003                1   c6004               -1
    x1899     c3381                1   c3382               -1
    x1899     c3383                1   c3384               -1
    x1899     c3391                1   c3392                1
    x1899     c6005               -1   c6006                1
    x1899     c6007               -1
    x1900     c3383               -1   c3384                1
    x1900     c5969                1   c5970               -1
    x1900     c5972               -1   c5974               -1
    x1900     c5976               -1   c5978               -1
    x1900     c6001                1   c6002               -1
    x1900     c6664               -1   c6666                1
    x1900     c6668                1
    x1901     c3385                1   c3386                1
    x1901     c3393                1   c6000               -1
    x1901     c6006               -1   c6007               -1
    x1902     c3387                1   c3388               -1
    x1902     c3389                1   c3390               -1
    x1902     c3395                1   c3396                1
    x1902     c6006                1   c6007               -1
    x1902     c6008               -1
    x1903     c3389               -1   c3390                1
    x1903     c5975               -1   c5976               -1
    x1903     c5977               -1   c5986                1
    x1903     c5987               -1   c5989               -1
    x1903     c6001                1   c6002               -1
    x1903     c6663               -1   c6667                1
    x1903     c6669                1
    x1904     c3397               -1   c3399                1
    x1904     c6009                1   c6010               -1
    x1904     c6027                1   c6028               -1
    x1904     c6029                1   c6030                1
    x1904     c6031               -1   c6032               -1
    x1904     c6033               -1   c6034               -1
    x1905     c3397               -1   c3398               -1
    x1905     c3402               -1   c6009                1
    x1905     c6011                1
    x1906     c3398                1   c3400               -1
    x1906     c6009               -1   c6010                1
    x1906     c6012                1   c6013                1
    x1906     c6014               -1   c6015               -1
    x1906     c6016               -1   c6017               -1
    x1906     c6027                1   c6028               -1
    x1907     c3399               -1   c3400               -1
    x1907     c3401               -1   c6010                1
    x1907     c6011                1
    x1908     c3401                1   c3402                1
    x1908     c3719               -1   c6011               -1
    x1908     c6773                1
    x1909     c3403               -1   c3406               -1
    x1909     c3411               -1   c6035                1
    x1909     c6038               -1   c6039               -1
    x1909     c6676               -1   c6677               -1
    x1910     c3403                1   c3404                1
    x1910     c3405                1   c6027               -1
    x1910     c6028               -1   c6762                1
    x1911     c3404               -1   c3428               -1
    x1911     c6021               -1   c6022               -1
    x1911     c6023               -1   c6044                1
    x1911     c6045               -1   c6046               -1
    x1911     c6673               -1   c6674               -1
    x1911     c6675               -1
    x1912     c3405               -1   c3412               -1
    x1912     c6018               -1   c6019               -1
    x1912     c6020               -1   c6035                1
    x1912     c6036               -1   c6037               -1
    x1912     c6670               -1   c6671               -1
    x1912     c6672               -1
    x1913     c3407                1   c3408               -1
    x1913     c3409                1   c3410               -1
    x1913     c3417               -1   c3418               -1
    x1913     c6040                1   c6041                1
    x1913     c6042               -1
    x1914     c3407               -1   c3408                1
    x1914     c6012                1   c6016               -1
    x1914     c6017               -1   c6024               -1
    x1914     c6026               -1   c6038                1
    x1914     c6039               -1   c6671                1
    x1914     c6672                1   c6674                1
    x1914     c6675                1   c6676               -1
    x1915     c3409               -1   c3410                1
    x1915     c6013                1   c6015               -1
    x1915     c6017               -1   c6019               -1
    x1915     c6021               -1   c6023               -1
    x1915     c6036                1   c6037               -1
    x1915     c6671               -1   c6676                1
    x1915     c6678                1
    x1916     c3411                1   c3412                1
    x1916     c3419                1   c6035               -1
    x1916     c6041               -1   c6042               -1
    x1917     c3413                1   c3414               -1
    x1917     c3415                1   c3416               -1
    x1917     c3421               -1   c3422               -1
    x1917     c6041                1   c6042               -1
    x1917     c6043                1
    x1918     c3413               -1   c3414                1
    x1918     c6025               -1   c6026               -1
    x1918     c6029                1   c6033               -1
    x1918     c6034               -1   c6038                1
    x1918     c6039               -1   c6670                1
    x1918     c6672                1   c6673                1
    x1918     c6675                1   c6677               -1
    x1919     c3415               -1   c3416                1
    x1919     c6018               -1   c6022               -1
    x1919     c6023               -1   c6030                1
    x1919     c6032               -1   c6034               -1
    x1919     c6036                1   c6037               -1
    x1919     c6670               -1   c6677                1
    x1919     c6679                1
    x1920     c3418               -1   c3423               -1
    x1920     c3424                1   c6040                1
    x1920     c6047                1   c6048               -1
    x1921     c3419               -1   c3420               -1
    x1921     c3427               -1   c6044                1
    x1921     c6047               -1   c6048               -1
    x1922     c3422               -1   c3429               -1
    x1922     c3430                1   c6043                1
    x1922     c6047                1   c6048               -1
    x1923     c3423                1   c3424               -1
    x1923     c3425                1   c3426               -1
    x1923     c3433                1   c3434                1
    x1923     c6049               -1   c6056                1
    x1923     c6057               -1
    x1924     c3425               -1   c3426                1
    x1924     c6013                1   c6014               -1
    x1924     c6016               -1   c6018               -1
    x1924     c6020               -1   c6022               -1
    x1924     c6045                1   c6046               -1
    x1924     c6674               -1   c6676                1
    x1924     c6678                1
    x1925     c3427                1   c3428                1
    x1925     c3435                1   c3436                1
    x1925     c6044               -1   c6056               -1
    x1925     c6057               -1
    x1926     c3429                1   c3430               -1
    x1926     c3431                1   c3432               -1
    x1926     c3437                1   c3438                1
    x1926     c6056                1   c6057               -1
    x1926     c6058               -1
    x1927     c3431               -1   c3432                1
    x1927     c6019               -1   c6020               -1
    x1927     c6021               -1   c6030                1
    x1927     c6031               -1   c6033               -1
    x1927     c6045                1   c6046               -1
    x1927     c6673               -1   c6677                1
    x1927     c6679                1
    x1928     c3439               -1   c3441                1
    x1928     c3448                1   c3449               -1
    x1928     c6059                1   c6060               -1
    x1928     c6062                1   c6063               -1
    x1929     c3439               -1   c3440               -1
    x1929     c3444               -1   c6059                1
    x1929     c6061                1
    x1930     c3440                1   c3442               -1
    x1930     c3445                1   c3446               -1
    x1930     c6059               -1   c6060                1
    x1930     c6062                1   c6063               -1
    x1931     c3441               -1   c3442               -1
    x1931     c3443               -1   c6060                1
    x1931     c6061                1
    x1932     c3443                1   c3444                1
    x1932     c3718               -1   c6061               -1
    x1932     c6773                1
    x1933     c3445                1   c3446               -1
    x1933     c6064               -1   c6065               -1
    x1933     c6066                1   c6067                1
    x1933     c6068                1   c6069                1
    x1933     c6079                1   c6080               -1
    x1934     c3447               -1   c3450                1
    x1934     c3451                1   c3452                1
    x1934     c6079               -1   c6080               -1
    x1935     c3447                1   c6062               -1
    x1935     c6063               -1   c6761                1
    x1936     c3448                1   c3449               -1
    x1936     c6079                1   c6080               -1
    x1936     c6081               -1   c6082               -1
    x1936     c6083                1   c6084                1
    x1936     c6085                1   c6086                1
    x1937     c3450               -1   c3453               -1
    x1937     c3458               -1   c6087                1
    x1937     c6090               -1   c6091               -1
    x1937     c6686               -1   c6687               -1
    x1938     c3451               -1   c3474               -1
    x1938     c6073               -1   c6074               -1
    x1938     c6075               -1   c6096                1
    x1938     c6099               -1   c6100               -1
    x1938     c6683               -1   c6684               -1
    x1938     c6685               -1
    x1939     c3452               -1   c3459               -1
    x1939     c6070               -1   c6071               -1
    x1939     c6072               -1   c6087                1
    x1939     c6088               -1   c6089               -1
    x1939     c6680               -1   c6681               -1
    x1939     c6682               -1
    x1940     c3454                1   c3455               -1
    x1940     c3456                1   c3457               -1
    x1940     c3464                1   c3465                1
    x1940     c6092               -1   c6093                1
    x1940     c6094               -1
    x1941     c3454               -1   c3455                1
    x1941     c6064               -1   c6068                1
    x1941     c6069                1   c6077                1
    x1941     c6078                1   c6090                1
    x1941     c6091               -1   c6680               -1
    x1941     c6682               -1   c6683               -1
    x1941     c6685               -1   c6686                1
    x1942     c3456               -1   c3457                1
    x1942     c6065               -1   c6067                1
    x1942     c6069                1   c6071               -1
    x1942     c6074                1   c6075                1
    x1942     c6088                1   c6089               -1
    x1942     c6681               -1   c6686               -1
    x1942     c6688               -1
    x1943     c3458                1   c3459                1
    x1943     c3466                1   c6087               -1
    x1943     c6093               -1   c6094               -1
    x1944     c3460                1   c3461               -1
    x1944     c3462                1   c3463               -1
    x1944     c3468                1   c3469                1
    x1944     c6093                1   c6094               -1
    x1944     c6095               -1
    x1945     c3460               -1   c3461                1
    x1945     c6076                1   c6078                1
    x1945     c6081               -1   c6085                1
    x1945     c6086                1   c6090                1
    x1945     c6091               -1   c6681               -1
    x1945     c6682               -1   c6684               -1
    x1945     c6685               -1   c6687                1
    x1946     c3462               -1   c3463                1
    x1946     c6070               -1   c6073                1
    x1946     c6075                1   c6082               -1
    x1946     c6084                1   c6086                1
    x1946     c6088                1   c6089               -1
    x1946     c6680               -1   c6687               -1
    x1946     c6689               -1
    x1947     c3465                1   c3472               -1
    x1947     c3473                1   c6092               -1
    x1947     c6097                1   c6098               -1
    x1948     c3466               -1   c3467               -1
    x1948     c3475               -1   c6096                1
    x1948     c6097               -1   c6098               -1
    x1949     c3469                1   c3478               -1
    x1949     c3479                1   c6095               -1
    x1949     c6097                1   c6098               -1
    x1950     c3470                1   c3471               -1
    x1950     c3472                1   c3473               -1
    x1950     c3480               -1   c3481               -1
    x1950     c6101                1   c6108                1
    x1950     c6109               -1
    x1951     c3470               -1   c3471                1
    x1951     c6065               -1   c6066                1
    x1951     c6068                1   c6071                1
    x1951     c6072                1   c6074               -1
    x1951     c6099                1   c6100               -1
    x1951     c6684               -1   c6686               -1
    x1951     c6688               -1
    x1952     c3474                1   c3475                1
    x1952     c3482                1   c3483                1
    x1952     c6096               -1   c6108               -1
    x1952     c6109               -1
    x1953     c3476                1   c3477               -1
    x1953     c3478                1   c3479               -1
    x1953     c3484               -1   c3485               -1
    x1953     c6108                1   c6109               -1
    x1953     c6110                1
    x1954     c3476               -1   c3477                1
    x1954     c6070                1   c6072                1
    x1954     c6073               -1   c6082               -1
    x1954     c6083                1   c6085                1
    x1954     c6099                1   c6100               -1
    x1954     c6683               -1   c6687               -1
    x1954     c6689               -1
    x1955     c3486               -1   c3488                1
    x1955     c3495                1   c3496               -1
    x1955     c6111                1   c6112               -1
    x1955     c6114                1   c6115               -1
    x1956     c3486               -1   c3487               -1
    x1956     c3491               -1   c6111                1
    x1956     c6113                1
    x1957     c3487                1   c3489               -1
    x1957     c3492                1   c3493               -1
    x1957     c6111               -1   c6112                1
    x1957     c6114                1   c6115               -1
    x1958     c3488               -1   c3489               -1
    x1958     c3490               -1   c6112                1
    x1958     c6113                1
    x1959     c3490                1   c3491                1
    x1959     c3717               -1   c6113               -1
    x1959     c6772                1
    x1960     c3492                1   c3493               -1
    x1960     c6116               -1   c6117               -1
    x1960     c6118                1   c6119                1
    x1960     c6120                1   c6121                1
    x1960     c6131                1   c6132               -1
    x1961     c3494               -1   c3497                1
    x1961     c3498                1   c3499                1
    x1961     c6131               -1   c6132               -1
    x1962     c3494                1   c6114               -1
    x1962     c6115               -1   c6761                1
    x1963     c3495                1   c3496               -1
    x1963     c6131                1   c6132               -1
    x1963     c6133               -1   c6134               -1
    x1963     c6135                1   c6136                1
    x1963     c6137                1   c6138                1
    x1964     c3497               -1   c3500               -1
    x1964     c3505               -1   c6139                1
    x1964     c6142               -1   c6143               -1
    x1964     c6696               -1   c6697               -1
    x1965     c3498               -1   c3522               -1
    x1965     c6125               -1   c6126               -1
    x1965     c6127               -1   c6148                1
    x1965     c6149               -1   c6150               -1
    x1965     c6693               -1   c6694               -1
    x1965     c6695               -1
    x1966     c3499               -1   c3506               -1
    x1966     c6122               -1   c6123               -1
    x1966     c6124               -1   c6139                1
    x1966     c6140               -1   c6141               -1
    x1966     c6690               -1   c6691               -1
    x1966     c6692               -1
    x1967     c3501                1   c3502               -1
    x1967     c3503                1   c3504               -1
    x1967     c3511                1   c3512                1
    x1967     c6144               -1   c6145                1
    x1967     c6146               -1
    x1968     c3501               -1   c3502                1
    x1968     c6116               -1   c6120                1
    x1968     c6121                1   c6129                1
    x1968     c6130                1   c6142                1
    x1968     c6143               -1   c6690               -1
    x1968     c6692               -1   c6693               -1
    x1968     c6695               -1   c6696                1
    x1969     c3503               -1   c3504                1
    x1969     c6117               -1   c6119                1
    x1969     c6121                1   c6123               -1
    x1969     c6126                1   c6127                1
    x1969     c6140                1   c6141               -1
    x1969     c6691               -1   c6696               -1
    x1969     c6698               -1
    x1970     c3505                1   c3506                1
    x1970     c3513                1   c6139               -1
    x1970     c6145               -1   c6146               -1
    x1971     c3507                1   c3508               -1
    x1971     c3509                1   c3510               -1
    x1971     c3515                1   c3516                1
    x1971     c6145                1   c6146               -1
    x1971     c6147               -1
    x1972     c3507               -1   c3508                1
    x1972     c6128                1   c6130                1
    x1972     c6133               -1   c6137                1
    x1972     c6138                1   c6142                1
    x1972     c6143               -1   c6691               -1
    x1972     c6692               -1   c6694               -1
    x1972     c6695               -1   c6697                1
    x1973     c3509               -1   c3510                1
    x1973     c6122               -1   c6125                1
    x1973     c6127                1   c6134               -1
    x1973     c6136                1   c6138                1
    x1973     c6140                1   c6141               -1
    x1973     c6690               -1   c6697               -1
    x1973     c6699               -1
    x1974     c3512                1   c3517               -1
    x1974     c3518                1   c6144               -1
    x1974     c6151                1   c6152               -1
    x1975     c3513               -1   c3514               -1
    x1975     c3521               -1   c6148                1
    x1975     c6151               -1   c6152               -1
    x1976     c3516                1   c3523               -1
    x1976     c3524                1   c6147               -1
    x1976     c6151                1   c6152               -1
    x1977     c3517                1   c3518               -1
    x1977     c3519                1   c3520               -1
    x1977     c3527               -1   c3528               -1
    x1977     c6153                1   c6160                1
    x1977     c6161               -1
    x1978     c3519               -1   c3520                1
    x1978     c6117               -1   c6118                1
    x1978     c6120                1   c6123                1
    x1978     c6124                1   c6126               -1
    x1978     c6149                1   c6150               -1
    x1978     c6694               -1   c6696               -1
    x1978     c6698               -1
    x1979     c3521                1   c3522                1
    x1979     c3529                1   c3530                1
    x1979     c6148               -1   c6160               -1
    x1979     c6161               -1
    x1980     c3523                1   c3524               -1
    x1980     c3525                1   c3526               -1
    x1980     c3531               -1   c3532               -1
    x1980     c6160                1   c6161               -1
    x1980     c6162                1
    x1981     c3525               -1   c3526                1
    x1981     c6122                1   c6124                1
    x1981     c6125               -1   c6134               -1
    x1981     c6135                1   c6137                1
    x1981     c6149                1   c6150               -1
    x1981     c6693               -1   c6697               -1
    x1981     c6699               -1
    x1982     c3528               -1   c3533               -1
    x1982     c3534                1   c6153                1
    x1982     c6155               -1   c6157               -1
    x1982     c6159               -1   c6167                1
    x1982     c6168               -1
    x1983     c3530               -1   c3539               -1
    x1983     c6154               -1   c6155               -1
    x1983     c6156               -1   c6167               -1
    x1983     c6168               -1   c6700                1
    x1984     c3532               -1   c3542               -1
    x1984     c3543                1   c6154               -1
    x1984     c6158               -1   c6159               -1
    x1984     c6162                1   c6167                1
    x1984     c6168               -1
    x1985     c3533                1   c3534               -1
    x1985     c3535                1   c3536               -1
    x1985     c3537                1   c3538               -1
    x1985     c3548                1   c3549                1
    x1985     c3550                1   c3551                1
    x1985     c6169                1   c6170               -1
    x1985     c6758               -1
    x1986     c3535               -1   c3536                1
    x1986     c3614                1   c3615               -1
    x1986     c6165                1   c6166               -1
    x1987     c3537               -1   c3538                1
    x1987     c3709               -1   c6163                1
    x1987     c6164               -1   c6315                1
    x1988     c3539                1   c3540                1
    x1988     c3541                1   c3552                1
    x1988     c6169               -1   c6170               -1
    x1988     c6700               -1
    x1989     c3540               -1   c3616               -1
    x1989     c6165               -1   c6166               -1
    x1989     c6700                1
    x1990     c3541               -1   c3710               -1
    x1990     c3711               -1   c6163               -1
    x1990     c6164               -1   c6700                1
    x1991     c3542                1   c3543               -1
    x1991     c3544                1   c3545               -1
    x1991     c3546                1   c3547               -1
    x1991     c3556                1   c3557                1
    x1991     c3558                1   c3559                1
    x1991     c6169                1   c6170               -1
    x1991     c6759               -1
    x1992     c3544               -1   c3545                1
    x1992     c3617                1   c3618               -1
    x1992     c6165                1   c6166               -1
    x1993     c3546               -1   c3547                1
    x1993     c3713               -1   c6163                1
    x1993     c6164               -1   c6318                1
    x1994     c3550                1   c3554                1
    x1994     c3558                1   c3560               -1
    x1994     c3561               -1   c6171                1
    x1994     c6758               -1   c6759               -1
    x1995     c3562               -1   c3564                1
    x1995     c6172                1   c6173               -1
    x1995     c6190                1   c6191               -1
    x1995     c6192                1   c6193                1
    x1995     c6194               -1   c6195               -1
    x1995     c6196               -1   c6197               -1
    x1996     c3562               -1   c3563               -1
    x1996     c3567               -1   c6172                1
    x1996     c6174                1
    x1997     c3563                1   c3565               -1
    x1997     c6172               -1   c6173                1
    x1997     c6175                1   c6176                1
    x1997     c6177               -1   c6178               -1
    x1997     c6179               -1   c6180               -1
    x1997     c6190                1   c6191               -1
    x1998     c3564               -1   c3565               -1
    x1998     c3566               -1   c6173                1
    x1998     c6174                1
    x1999     c3566                1   c3567                1
    x1999     c3716               -1   c6174               -1
    x1999     c6772                1
    x2000     c3568               -1   c3571               -1
    x2000     c3576               -1   c6198                1
    x2000     c6201               -1   c6202               -1
    x2000     c6707               -1   c6708               -1
    x2001     c3568                1   c3569                1
    x2001     c3570                1   c6190               -1
    x2001     c6191               -1   c6761                1
    x2002     c3569               -1   c3592               -1
    x2002     c6184               -1   c6185               -1
    x2002     c6186               -1   c6207                1
    x2002     c6210               -1   c6211               -1
    x2002     c6704               -1   c6705               -1
    x2002     c6706               -1
    x2003     c3570               -1   c3577               -1
    x2003     c6181               -1   c6182               -1
    x2003     c6183               -1   c6198                1
    x2003     c6199               -1   c6200               -1
    x2003     c6701               -1   c6702               -1
    x2003     c6703               -1
    x2004     c3571               -1   c3619               -1
    x2004     c3620                1   c6175                1
    x2004     c6177               -1   c6178               -1
    x2004     c6188               -1   c6192                1
    x2004     c6194               -1   c6195               -1
    x2004     c6701                1   c6702                1
    x2004     c6703                1   c6704                1
    x2004     c6705                1   c6706                1
    x2004     c6709               -1
    x2005     c3572                1   c3573               -1
    x2005     c3574                1   c3575               -1
    x2005     c3582               -1   c3583               -1
    x2005     c6203                1   c6204                1
    x2005     c6205               -1
    x2006     c3572               -1   c3573                1
    x2006     c6175                1   c6179               -1
    x2006     c6180               -1   c6187               -1
    x2006     c6189               -1   c6201                1
    x2006     c6202               -1   c6702                1
    x2006     c6703                1   c6705                1
    x2006     c6706                1   c6707               -1
    x2007     c3574               -1   c3575                1
    x2007     c6176                1   c6178               -1
    x2007     c6180               -1   c6182               -1
    x2007     c6184               -1   c6186               -1
    x2007     c6199                1   c6200               -1
    x2007     c6702               -1   c6707                1
    x2007     c6709                1
    x2008     c3576                1   c3577                1
    x2008     c3584                1   c6198               -1
    x2008     c6204               -1   c6205               -1
    x2009     c3578                1   c3579               -1
    x2009     c3580                1   c3581               -1
    x2009     c3586               -1   c3587               -1
    x2009     c6204                1   c6205               -1
    x2009     c6206                1
    x2010     c3578               -1   c3579                1
    x2010     c6188               -1   c6189               -1
    x2010     c6192                1   c6196               -1
    x2010     c6197               -1   c6201                1
    x2010     c6202               -1   c6701                1
    x2010     c6703                1   c6704                1
    x2010     c6706                1   c6708               -1
    x2011     c3580               -1   c3581                1
    x2011     c6181               -1   c6185               -1
    x2011     c6186               -1   c6193                1
    x2011     c6195               -1   c6197               -1
    x2011     c6199                1   c6200               -1
    x2011     c6701               -1   c6708                1
    x2011     c6710                1
    x2012     c3582               -1   c3585               -1
    x2012     c3586               -1   c3621               -1
    x2012     c3622                1   c6203                1
    x2012     c6206                1
    x2013     c3583               -1   c3590               -1
    x2013     c3591                1   c6203                1
    x2013     c6208                1   c6209               -1
    x2014     c3584               -1   c3585               -1
    x2014     c3593               -1   c6207                1
    x2014     c6208               -1   c6209               -1
    x2015     c3587               -1   c3596               -1
    x2015     c3597                1   c6206                1
    x2015     c6208                1   c6209               -1
    x2016     c3588                1   c3589               -1
    x2016     c3590                1   c3591               -1
    x2016     c3598                1   c3599                1
    x2016     c6212               -1   c6219                1
    x2016     c6220               -1
    x2017     c3588               -1   c3589                1
    x2017     c6176                1   c6177               -1
    x2017     c6179               -1   c6181               -1
    x2017     c6183               -1   c6185               -1
    x2017     c6210                1   c6211               -1
    x2017     c6705               -1   c6707                1
    x2017     c6709                1
    x2018     c3592                1   c3593                1
    x2018     c3600                1   c3601                1
    x2018     c6207               -1   c6219               -1
    x2018     c6220               -1
    x2019     c3594                1   c3595               -1
    x2019     c3596                1   c3597               -1
    x2019     c3602                1   c3603                1
    x2019     c6219                1   c6220               -1
    x2019     c6221               -1
    x2020     c3594               -1   c3595                1
    x2020     c6182               -1   c6183               -1
    x2020     c6184               -1   c6193                1
    x2020     c6194               -1   c6196               -1
    x2020     c6210                1   c6211               -1
    x2020     c6704               -1   c6708                1
    x2020     c6710                1
    x2021     c3599                1   c3604               -1
    x2021     c3605                1   c6212               -1
    x2021     c6214               -1   c6217                1
    x2021     c6218                1   c6225                1
    x2021     c6226               -1
    x2022     c3601               -1   c3608               -1
    x2022     c6213               -1   c6214               -1
    x2022     c6215               -1   c6222                1
    x2022     c6225               -1   c6226               -1
    x2023     c3603                1   c3610               -1
    x2023     c3611                1   c6213               -1
    x2023     c6216                1   c6218                1
    x2023     c6221               -1   c6225                1
    x2023     c6226               -1
    x2024     c3604                1   c3605               -1
    x2024     c3606                1   c3607               -1
    x2024     c3614                1   c3615               -1
    x2024     c6227                1   c6228               -1
    x2025     c3606               -1   c3607                1
    x2025     c3662                1   c6223                1
    x2025     c6224               -1   c6269               -1
    x2026     c3608                1   c3609                1
    x2026     c3616                1   c6222               -1
    x2026     c6227               -1   c6228               -1
    x2027     c3609               -1   c3663               -1
    x2027     c3664               -1   c6222                1
    x2027     c6223               -1   c6224               -1
    x2028     c3610                1   c3611               -1
    x2028     c3612                1   c3613               -1
    x2028     c3617                1   c3618               -1
    x2028     c6227                1   c6228               -1
    x2029     c3612               -1   c3613                1
    x2029     c3666                1   c6223                1
    x2029     c6224               -1   c6272               -1
    x2030     c3619                1   c3620               -1
    x2030     c3621                1   c3622               -1
    x2030     c3623                1   c3624               -1
    x2031     c3625               -1   c3627                1
    x2031     c6229                1   c6230               -1
    x2031     c6247                1   c6248               -1
    x2031     c6249                1   c6250                1
    x2031     c6251               -1   c6252               -1
    x2031     c6253               -1   c6254               -1
    x2032     c3625               -1   c3626               -1
    x2032     c3630               -1   c6229                1
    x2032     c6231                1
    x2033     c3626                1   c3628               -1
    x2033     c6229               -1   c6230                1
    x2033     c6232                1   c6233                1
    x2033     c6234               -1   c6235               -1
    x2033     c6236               -1   c6237               -1
    x2033     c6247                1   c6248               -1
    x2034     c3627               -1   c3628               -1
    x2034     c3629               -1   c6230                1
    x2034     c6231                1
    x2035     c3629                1   c3630                1
    x2035     c3715               -1   c6231               -1
    x2035     c6772                1
    x2036     c3631               -1   c3634               -1
    x2036     c3639               -1   c6255                1
    x2036     c6258               -1   c6259               -1
    x2036     c6717               -1   c6718               -1
    x2037     c3631                1   c3632                1
    x2037     c3633                1   c6247               -1
    x2037     c6248               -1   c6761                1
    x2038     c3632               -1   c3655               -1
    x2038     c6241               -1   c6242               -1
    x2038     c6243               -1   c6264                1
    x2038     c6267               -1   c6268               -1
    x2038     c6714               -1   c6715               -1
    x2038     c6716               -1
    x2039     c3633               -1   c3640               -1
    x2039     c6238               -1   c6239               -1
    x2039     c6240               -1   c6255                1
    x2039     c6256               -1   c6257               -1
    x2039     c6711               -1   c6712               -1
    x2039     c6713               -1
    x2040     c3635                1   c3636               -1
    x2040     c3637                1   c3638               -1
    x2040     c3645               -1   c3646               -1
    x2040     c6260                1   c6261                1
    x2040     c6262               -1
    x2041     c3635               -1   c3636                1
    x2041     c6232                1   c6236               -1
    x2041     c6237               -1   c6244               -1
    x2041     c6246               -1   c6258                1
    x2041     c6259               -1   c6712                1
    x2041     c6713                1   c6715                1
    x2041     c6716                1   c6717               -1
    x2042     c3637               -1   c3638                1
    x2042     c6233                1   c6235               -1
    x2042     c6237               -1   c6239               -1
    x2042     c6241               -1   c6243               -1
    x2042     c6256                1   c6257               -1
    x2042     c6712               -1   c6717                1
    x2042     c6719                1
    x2043     c3639                1   c3640                1
    x2043     c3647                1   c6255               -1
    x2043     c6261               -1   c6262               -1
    x2044     c3641                1   c3642               -1
    x2044     c3643                1   c3644               -1
    x2044     c3649               -1   c3650               -1
    x2044     c6261                1   c6262               -1
    x2044     c6263                1
    x2045     c3641               -1   c3642                1
    x2045     c6245               -1   c6246               -1
    x2045     c6249                1   c6253               -1
    x2045     c6254               -1   c6258                1
    x2045     c6259               -1   c6711                1
    x2045     c6713                1   c6714                1
    x2045     c6716                1   c6718               -1
    x2046     c3643               -1   c3644                1
    x2046     c6238               -1   c6242               -1
    x2046     c6243               -1   c6250                1
    x2046     c6252               -1   c6254               -1
    x2046     c6256                1   c6257               -1
    x2046     c6711               -1   c6718                1
    x2046     c6720                1
    x2047     c3646               -1   c3653               -1
    x2047     c3654                1   c6260                1
    x2047     c6265                1   c6266               -1
    x2048     c3647               -1   c3648               -1
    x2048     c3656               -1   c6264                1
    x2048     c6265               -1   c6266               -1
    x2049     c3650               -1   c3659               -1
    x2049     c3660                1   c6263                1
    x2049     c6265                1   c6266               -1
    x2050     c3651                1   c3652               -1
    x2050     c3653                1   c3654               -1
    x2050     c3661                1   c3662                1
    x2050     c6269               -1   c6270                1
    x2050     c6271               -1
    x2051     c3651               -1   c3652                1
    x2051     c6233                1   c6234               -1
    x2051     c6236               -1   c6238               -1
    x2051     c6240               -1   c6242               -1
    x2051     c6267                1   c6268               -1
    x2051     c6715               -1   c6717                1
    x2051     c6719                1
    x2052     c3655                1   c3656                1
    x2052     c3663                1   c6264               -1
    x2052     c6270               -1   c6271               -1
    x2053     c3657                1   c3658               -1
    x2053     c3659                1   c3660               -1
    x2053     c3665                1   c3666                1
    x2053     c6270                1   c6271               -1
    x2053     c6272               -1
    x2054     c3657               -1   c3658                1
    x2054     c6239               -1   c6240               -1
    x2054     c6241               -1   c6250                1
    x2054     c6251               -1   c6253               -1
    x2054     c6267                1   c6268               -1
    x2054     c6714               -1   c6718                1
    x2054     c6720                1
    x2055     c3667               -1   c3669                1
    x2055     c3676                1   c3677               -1
    x2055     c6273                1   c6274               -1
    x2055     c6276                1   c6277               -1
    x2056     c3667               -1   c3668               -1
    x2056     c3672               -1   c6273                1
    x2056     c6275                1
    x2057     c3668                1   c3670               -1
    x2057     c3673                1   c3674               -1
    x2057     c6273               -1   c6274                1
    x2057     c6276                1   c6277               -1
    x2058     c3669               -1   c3670               -1
    x2058     c3671               -1   c6274                1
    x2058     c6275                1
    x2059     c3671                1   c3672                1
    x2059     c3714               -1   c6275               -1
    x2059     c6772                1
    x2060     c3673                1   c3674               -1
    x2060     c6278               -1   c6279               -1
    x2060     c6280                1   c6281                1
    x2060     c6282                1   c6283                1
    x2060     c6293                1   c6294               -1
    x2061     c3675               -1   c3678                1
    x2061     c3679                1   c3680                1
    x2061     c6293               -1   c6294               -1
    x2062     c3675                1   c6276               -1
    x2062     c6277               -1   c6761                1
    x2063     c3676                1   c3677               -1
    x2063     c6293                1   c6294               -1
    x2063     c6295               -1   c6296               -1
    x2063     c6297                1   c6298                1
    x2063     c6299                1   c6300                1
    x2064     c3678               -1   c3681               -1
    x2064     c3686               -1   c6301                1
    x2064     c6304               -1   c6305               -1
    x2064     c6727               -1   c6728               -1
    x2065     c3679               -1   c3703               -1
    x2065     c6287               -1   c6288               -1
    x2065     c6289               -1   c6310                1
    x2065     c6311               -1   c6312               -1
    x2065     c6724               -1   c6725               -1
    x2065     c6726               -1
    x2066     c3680               -1   c3687               -1
    x2066     c6284               -1   c6285               -1
    x2066     c6286               -1   c6301                1
    x2066     c6302               -1   c6303               -1
    x2066     c6721               -1   c6722               -1
    x2066     c6723               -1
    x2067     c3682                1   c3683               -1
    x2067     c3684                1   c3685               -1
    x2067     c3692                1   c3693                1
    x2067     c6306               -1   c6307                1
    x2067     c6308               -1
    x2068     c3682               -1   c3683                1
    x2068     c6278               -1   c6282                1
    x2068     c6283                1   c6291                1
    x2068     c6292                1   c6304                1
    x2068     c6305               -1   c6721               -1
    x2068     c6723               -1   c6724               -1
    x2068     c6726               -1   c6727                1
    x2069     c3684               -1   c3685                1
    x2069     c6279               -1   c6281                1
    x2069     c6283                1   c6285               -1
    x2069     c6288                1   c6289                1
    x2069     c6302                1   c6303               -1
    x2069     c6722               -1   c6727               -1
    x2069     c6729               -1
    x2070     c3686                1   c3687                1
    x2070     c3694                1   c6301               -1
    x2070     c6307               -1   c6308               -1
    x2071     c3688                1   c3689               -1
    x2071     c3690                1   c3691               -1
    x2071     c3696                1   c3697                1
    x2071     c6307                1   c6308               -1
    x2071     c6309               -1
    x2072     c3688               -1   c3689                1
    x2072     c6290                1   c6292                1
    x2072     c6295               -1   c6299                1
    x2072     c6300                1   c6304                1
    x2072     c6305               -1   c6722               -1
    x2072     c6723               -1   c6725               -1
    x2072     c6726               -1   c6728                1
    x2073     c3690               -1   c3691                1
    x2073     c6284               -1   c6287                1
    x2073     c6289                1   c6296               -1
    x2073     c6298                1   c6300                1
    x2073     c6302                1   c6303               -1
    x2073     c6721               -1   c6728               -1
    x2073     c6730               -1
    x2074     c3693                1   c3698               -1
    x2074     c3699                1   c6306               -1
    x2074     c6313                1   c6314               -1
    x2075     c3694               -1   c3695               -1
    x2075     c3702               -1   c6310                1
    x2075     c6313               -1   c6314               -1
    x2076     c3697                1   c3704               -1
    x2076     c3705                1   c6309               -1
    x2076     c6313                1   c6314               -1
    x2077     c3698                1   c3699               -1
    x2077     c3700                1   c3701               -1
    x2077     c3708               -1   c3709               -1
    x2077     c6315                1   c6316                1
    x2077     c6317               -1
    x2078     c3700               -1   c3701                1
    x2078     c6279               -1   c6280                1
    x2078     c6282                1   c6285                1
    x2078     c6286                1   c6288               -1
    x2078     c6311                1   c6312               -1
    x2078     c6725               -1   c6727               -1
    x2078     c6729               -1
    x2079     c3702                1   c3703                1
    x2079     c3710                1   c6310               -1
    x2079     c6316               -1   c6317               -1
    x2080     c3704                1   c3705               -1
    x2080     c3706                1   c3707               -1
    x2080     c3712               -1   c3713               -1
    x2080     c6316                1   c6317               -1
    x2080     c6318                1
    x2081     c3706               -1   c3707                1
    x2081     c6284                1   c6286                1
    x2081     c6287               -1   c6296               -1
    x2081     c6297                1   c6299                1
    x2081     c6311                1   c6312               -1
    x2081     c6724               -1   c6728               -1
    x2081     c6730               -1
    x2082     c3773               -1   c3774               -1
    x2082     c3775               -1   c6328               -1
    x2082     c6329               -1
    x2083     c3773               -1   c6329               -1
    x2084     c3846               -1   c3847               -1
    x2084     c3848               -1   c6338               -1
    x2084     c6339               -1
    x2085     c3846               -1   c6339               -1
    x2086     c3885               -1   c3886               -1
    x2086     c3887               -1   c6348               -1
    x2086     c6349               -1
    x2087     c3885               -1   c6349               -1
    x2088     c3922               -1   c3923               -1
    x2088     c3924               -1   c6358               -1
    x2088     c6359               -1
    x2089     c3922               -1   c6359                1
    x2090     c3958               -1   c3959               -1
    x2090     c3960               -1   c6362               -1
    x2090     c6363               -1
    x2091     c3958               -1   c6363                1
    x2092     c4008               -1   c4009               -1
    x2092     c4010               -1   c6378               -1
    x2092     c6379               -1
    x2093     c4008               -1   c6379               -1
    x2094     c4083               -1   c6769                1
    x2095     c4124               -1   c4125               -1
    x2095     c4126               -1   c6389               -1
    x2095     c6390               -1
    x2096     c4124               -1   c6390                1
    x2097     c4161               -1   c4162               -1
    x2097     c4163               -1   c6399               -1
    x2097     c6400               -1
    x2098     c4161               -1   c6400               -1
    x2099     c4198               -1   c4199               -1
    x2099     c4200               -1   c6409               -1
    x2099     c6410               -1
    x2100     c4198               -1   c6410                1
    x2101     c4645               -1   c4646               -1
    x2101     c4647               -1   c6421               -1
    x2101     c6422               -1
    x2102     c4645               -1   c6422                1
    x2103     c4691               -1   c4692               -1
    x2103     c4693               -1   c6431               -1
    x2103     c6432               -1
    x2104     c4691               -1   c6432               -1
    x2105     c4735               -1   c4736               -1
    x2105     c4737               -1   c6441               -1
    x2105     c6442               -1
    x2106     c4735               -1   c6442               -1
    x2107     c4864               -1   c4865               -1
    x2107     c4866               -1   c6459               -1
    x2107     c6460               -1
    x2108     c4864               -1   c6460               -1
    x2109     c4908               -1   c4909               -1
    x2109     c4910               -1   c6469               -1
    x2109     c6470               -1
    x2110     c4908               -1   c6470               -1
    x2111     c4952               -1   c4953               -1
    x2111     c4954               -1   c6479               -1
    x2111     c6480               -1
    x2112     c4952               -1   c6480               -1
    x2113     c4996               -1   c4997               -1
    x2113     c4998               -1   c6489               -1
    x2113     c6490               -1
    x2114     c4996               -1   c6490               -1
    x2115     c5058               -1   c5059               -1
    x2115     c5060               -1   c6500               -1
    x2115     c6501               -1
    x2116     c5058               -1   c6501               -1
    x2117     c5104               -1   c5105               -1
    x2117     c5106               -1   c6510               -1
    x2117     c6511               -1
    x2118     c5104               -1   c6511                1
    x2119     c5157               -1   c5158               -1
    x2119     c5159               -1   c6520               -1
    x2119     c6521               -1
    x2120     c5157               -1   c6521                1
    x2121     c5201               -1   c5202               -1
    x2121     c5203               -1   c6530               -1
    x2121     c6531               -1
    x2122     c5201               -1   c6531               -1
    x2123     c5265               -1   c5266               -1
    x2123     c5267               -1   c6541               -1
    x2123     c6542               -1
    x2124     c5265               -1   c6542                1
    x2125     c5318               -1   c5319               -1
    x2125     c5320               -1   c6551               -1
    x2125     c6552               -1
    x2126     c5318               -1   c6552                1
    x2127     c5362               -1   c5363               -1
    x2127     c5364               -1   c6561               -1
    x2127     c6562               -1
    x2128     c5362               -1   c6562               -1
    x2129     c5408               -1   c5409               -1
    x2129     c5410               -1   c6571               -1
    x2129     c6572               -1
    x2130     c5408               -1   c6572                1
    x2131     c5480               -1   c5481               -1
    x2131     c5482               -1   c5483               -1
    x2131     c5484               -1   c5485               -1
    x2131     c5492               -1   c5493               -1
    x2131     c5494               -1
    x2132     c5480               -1   c5483               -1
    x2132     c5492               -1
    x2133     c5521               -1   c5522               -1
    x2133     c5523               -1   c5524               -1
    x2133     c5525               -1   c5526               -1
    x2133     c5533               -1   c5534               -1
    x2133     c5535               -1
    x2134     c5521               -1   c5524               -1
    x2134     c5533               -1
    x2135     c5568               -1   c5569               -1
    x2135     c5570               -1   c6585               -1
    x2135     c6586               -1
    x2136     c5568               -1   c6586               -1
    x2137     c5620               -1   c5621               -1
    x2137     c5622               -1   c6596               -1
    x2137     c6597               -1
    x2138     c5620               -1   c6597               -1
    x2139     c5664               -1   c5665               -1
    x2139     c5666               -1   c6606               -1
    x2139     c6607               -1
    x2140     c5664               -1   c6607               -1
    x2141     c5716               -1   c5717               -1
    x2141     c5718               -1   c6616               -1
    x2141     c6617               -1
    x2142     c5716               -1   c6617                1
    x2143     c5768               -1   c5769               -1
    x2143     c5770               -1   c6626               -1
    x2143     c6627               -1
    x2144     c5768               -1   c6627               -1
    x2145     c5826               -1   c5827               -1
    x2145     c5828               -1   c6637               -1
    x2145     c6638               -1
    x2146     c5826               -1   c6638               -1
    x2147     c5870               -1   c5871               -1
    x2147     c5872               -1   c6647               -1
    x2147     c6648               -1
    x2148     c5870               -1   c6648               -1
    x2149     c5920               -1   c5921               -1
    x2149     c5922               -1   c6657               -1
    x2149     c6658               -1
    x2150     c5920               -1   c6658               -1
    x2151     c5980               -1   c5981               -1
    x2151     c5982               -1   c6668               -1
    x2151     c6669               -1
    x2152     c5980               -1   c6669               -1
    x2153     c6024               -1   c6025               -1
    x2153     c6026               -1   c6678               -1
    x2153     c6679               -1
    x2154     c6024               -1   c6679               -1
    x2155     c6076               -1   c6077               -1
    x2155     c6078               -1   c6688               -1
    x2155     c6689               -1
    x2156     c6076               -1   c6689                1
    x2157     c6128               -1   c6129               -1
    x2157     c6130               -1   c6698               -1
    x2157     c6699               -1
    x2158     c6128               -1   c6699                1
    x2159     c6187               -1   c6188               -1
    x2159     c6189               -1   c6709               -1
    x2159     c6710               -1
    x2160     c6187               -1   c6710               -1
    x2161     c6244               -1   c6245               -1
    x2161     c6246               -1   c6719               -1
    x2161     c6720               -1
    x2162     c6244               -1   c6720               -1
    x2163     c6290               -1   c6291               -1
    x2163     c6292               -1   c6729               -1
    x2163     c6730               -1
    x2164     c6290               -1   c6730                1
    x2165     c6319               -1   c6767                1
    x2166     c6380               -1   c6770                1
    x2167     c6734               -1   c6768                1
    x2168     c6760               -1   c6778                1
    x2169     c6761                1   c6762               -1
    x2170     c6762                1   c6763               -1
    x2171     c6763                1   c6764               -1
    x2172     c6764                1   c6765               -1
    x2173     c6765                1   c6766               -1
    x2174     c6766                1   c6767               -1
    x2175     c6772                1   c6773               -1
    x2176     c6773                1   c6774               -1
    x2177     c6774                1   c6775               -1
    x2178     c6775                1   c6776               -1
    x2179     c6776                1   c6777               -1
    x2180     c6777                1   c6778               -1
    MARK0001  'MARKER'                 'INTEND'
RHS
    rhs       c1                   1   c2                   1
    rhs       c3                   1   c5                   1
    rhs       c8                   1   c9                  -1
    rhs       c14                  1   c15                 -1
    rhs       c22                 -1   c25                 -1
    rhs       c31                 -1   c42                 -1
    rhs       c43                 -1   c45                 -1
    rhs       c46                 -1   c47                 -1
    rhs       c58                  1   c59                  1
    rhs       c62                  1   c63                  1
    rhs       c84                 -1   c85                 -1
    rhs       c86                 -1   c87                 -1
    rhs       c90                 -1   c91                 -1
    rhs       c92                 -1   c93                 -1
    rhs       c94                 -1   c95                 -1
    rhs       c96                 -1   c97                 -1
    rhs       c141                -1   c152                -1
    rhs       c153                -1   c155                -1
    rhs       c156                -1   c157                -1
    rhs       c168                 1   c169                -1
    rhs       c171                 1   c172                -1
    rhs       c176                -1   c187                -1
    rhs       c188                -1   c190                -1
    rhs       c191                -1   c192                -1
    rhs       c217                 1   c218                 1
    rhs       c221                 1   c222                 1
    rhs       c243                 1   c244                -1
    rhs       c246                 1   c247                -1
    rhs       c262                 1   c263                 1
    rhs       c266                 1   c267                 1
    rhs       c276                -1   c277                -1
    rhs       c290                 1   c291                -1
    rhs       c300                 1   c301                -1
    rhs       c321                -1   c332                -1
    rhs       c333                -1   c335                -1
    rhs       c336                -1   c337                -1
    rhs       c358                 1   c359                -1
    rhs       c374                 1   c375                -1
    rhs       c392                -1   c393                -1
    rhs       c398                 1   c399                -1
    rhs       c404                -1   c405                -1
    rhs       c418                 1   c419                -1
    rhs       c428                 1   c429                -1
    rhs       c444                 1   c445                 1
    rhs       c474                 1   c475                 1
    rhs       c500                 1   c501                 1
    rhs       c506                 1   c507                -1
    rhs       c512                 1   c513                 1
    rhs       c536                 1   c537                -1
    rhs       c542                 1   c543                 1
    rhs       c560                 1   c561                 1
    rhs       c564                 1   c565                 1
    rhs       c596                 1   c597                -1
    rhs       c599                 1   c600                -1
    rhs       c650                 1   c651                 1
    rhs       c654                 1   c655                 1
    rhs       c669                -1   c680                -1
    rhs       c681                -1   c683                -1
    rhs       c684                -1   c685                -1
    rhs       c710                 1   c711                 1
    rhs       c714                 1   c715                 1
    rhs       c720                 1   c721                -1
    rhs       c732                 1   c733                 1
    rhs       c738                 1   c739                -1
    rhs       c744                 1   c745                 1
    rhs       c774                -1   c775                -1
    rhs       c784                 1   c785                -1
    rhs       c804                 1   c805                -1
    rhs       c810                 1   c811                 1
    rhs       c816                 1   c817                -1
    rhs       c822                 1   c823                 1
    rhs       c828                 1   c829                -1
    rhs       c834                 1   c835                 1
    rhs       c864                -1   c865                -1
    rhs       c878                 1   c879                -1
    rhs       c888                 1   c889                -1
    rhs       c916                 1   c917                 1
    rhs       c926                -1   c927                -1
    rhs       c932                 1   c933                -1
    rhs       c938                -1   c939                -1
    rhs       c944                 1   c945                -1
    rhs       c954                 1   c955                -1
    rhs       c960                -1   c961                -1
    rhs       c966                 1   c967                -1
    rhs       c972                -1   c973                -1
    rhs       c982                 1   c983                -1
    rhs       c998                 1   c999                -1
    rhs       c1014                1   c1015                1
    rhs       c1040                1   c1041                1
    rhs       c1046                1   c1047               -1
    rhs       c1052                1   c1053                1
    rhs       c1058                1   c1059               -1
    rhs       c1064                1   c1065                1
    rhs       c1088                1   c1089               -1
    rhs       c1094                1   c1095                1
    rhs       c1122               -1   c1123               -1
    rhs       c1124               -1   c1125               -1
    rhs       c1126               -1   c1127               -1
    rhs       c1128               -1   c1153               -1
    rhs       c1154               -1   c1159                1
    rhs       c1160               -1   c1165               -1
    rhs       c1166               -1   c1175                1
    rhs       c1176                1   c1187               -1
    rhs       c1188               -1   c1197                1
    rhs       c1198                1   c1207                1
    rhs       c1208                1   c1227               -1
    rhs       c1228               -1   c1233                1
    rhs       c1234               -1   c1239               -1
    rhs       c1240               -1   c1249                1
    rhs       c1250               -1   c1255                1
    rhs       c1256               -1   c1261               -1
    rhs       c1262               -1   c1267                1
    rhs       c1268               -1   c1277                1
    rhs       c1278               -1   c1289                1
    rhs       c1290                1   c1299                1
    rhs       c1300                1   c1309               -1
    rhs       c1310               -1   c1315                1
    rhs       c1316               -1   c1321                1
    rhs       c1322                1   c1343               -1
    rhs       c1344               -1   c1353                1
    rhs       c1354                1   c1363               -1
    rhs       c1364               -1   c1369                1
    rhs       c1370               -1   c1381                1
    rhs       c1382                1   c1391               -1
    rhs       c1392               -1   c1397                1
    rhs       c1398               -1   c1407                1
    rhs       c1408               -1   c1417               -1
    rhs       c1418               -1   c1427                1
    rhs       c1428               -1   c1441                1
    rhs       c1442               -1   c1447                1
    rhs       c1448               -1   c1449                1
    rhs       c1450                1   c1459                1
    rhs       c1460                1   c1465                1
    rhs       c1466               -1   c1471                1
    rhs       c1472                1   c1477                1
    rhs       c1478               -1   c1483                1
    rhs       c1484                1   c1493                1
    rhs       c1494               -1   c1517               -1
    rhs       c1518               -1   c1523                1
    rhs       c1524               -1   c1529               -1
    rhs       c1530               -1   c1539                1
    rhs       c1540                1   c1545                1
    rhs       c1546               -1   c1559               -1
    rhs       c1560               -1   c1569                1
    rhs       c1570                1   c1575                1
    rhs       c1576               -1   c1581               -1
    rhs       c1582               -1   c1591                1
    rhs       c1592               -1   c1601                1
    rhs       c1602               -1   c1613                1
    rhs       c1614                1   c1623                1
    rhs       c1624                1   c1629                1
    rhs       c1630               -1   c1635                1
    rhs       c1636                1   c1645               -1
    rhs       c1646               -1   c1651                1
    rhs       c1652               -1   c1675               -1
    rhs       c1676               -1   c1681                1
    rhs       c1682               -1   c1687               -1
    rhs       c1688               -1   c1697                1
    rhs       c1698                1   c1699                1
    rhs       c1700               -1   c1701                1
    rhs       c1702               -1   c1707                1
    rhs       c1708                1   c1717                1
    rhs       c1718                1   c1723                1
    rhs       c1724               -1   c1729                1
    rhs       c1730                1   c1739               -1
    rhs       c1740               -1   c1745                1
    rhs       c1746               -1   c1747                1
    rhs       c1748               -1   c1749               -1
    rhs       c1750               -1   c1751               -1
    rhs       c1752               -1   c1753               -1
    rhs       c1764                1   c1765               -1
    rhs       c1766               -1   c1767               -1
    rhs       c1768               -1   c1769               -1
    rhs       c1770               -1   c1771               -1
    rhs       c1778                1   c1779               -1
    rhs       c1796                1   c1797                1
    rhs       c1802                1   c1803               -1
    rhs       c1808                1   c1809                1
    rhs       c1818               -1   c1819               -1
    rhs       c1824                1   c1825               -1
    rhs       c1826                1   c1827                1
    rhs       c1836               -1   c1837               -1
    rhs       c1842                1   c1843               -1
    rhs       c1848               -1   c1849               -1
    rhs       c1858                1   c1859               -1
    rhs       c1868                1   c1869                1
    rhs       c1874                1   c1875               -1
    rhs       c1876               -1   c1879               -1
    rhs       c1882                1   c1883               -1
    rhs       c1885                1   c1886               -1
    rhs       c1901                1   c1902                1
    rhs       c1905                1   c1906                1
    rhs       c1917                1   c1918               -1
    rhs       c1920                1   c1921               -1
    rhs       c1922                1   c1923                1
    rhs       c1926                1   c1927                1
    rhs       c1928               -1   c1931               -1
    rhs       c1937               -1   c1948               -1
    rhs       c1949               -1   c1951               -1
    rhs       c1952               -1   c1953               -1
    rhs       c1964                1   c1965                1
    rhs       c1968                1   c1969                1
    rhs       c1970               -1   c1973               -1
    rhs       c1979               -1   c1990               -1
    rhs       c1991               -1   c1993               -1
    rhs       c1994               -1   c1995               -1
    rhs       c2006                1   c2007                1
    rhs       c2010                1   c2011                1
    rhs       c2012               -1   c2015               -1
    rhs       c2032               -1   c2033               -1
    rhs       c2036               -1   c2037               -1
    rhs       c2048                1   c2049                1
    rhs       c2052                1   c2053                1
    rhs       c2074               -1   c2075               -1
    rhs       c2076               -1   c2077               -1
    rhs       c2080               -1   c2081               -1
    rhs       c2082               -1   c2083               -1
    rhs       c2084               -1   c2085               -1
    rhs       c2086               -1   c2087               -1
    rhs       c2113                1   c2114               -1
    rhs       c2116                1   c2117               -1
    rhs       c2118                1   c2119                1
    rhs       c2122                1   c2123                1
    rhs       c2138                1   c2139               -1
    rhs       c2140               -1   c2143               -1
    rhs       c2149               -1   c2160               -1
    rhs       c2161               -1   c2163               -1
    rhs       c2164               -1   c2165               -1
    rhs       c2176                1   c2177                1
    rhs       c2180                1   c2181                1
    rhs       c2182               -1   c2185               -1
    rhs       c2191               -1   c2202               -1
    rhs       c2203               -1   c2205               -1
    rhs       c2206               -1   c2207               -1
    rhs       c2218                1   c2219                1
    rhs       c2222                1   c2223                1
    rhs       c2224               -1   c2227               -1
    rhs       c2233               -1   c2244               -1
    rhs       c2245               -1   c2247               -1
    rhs       c2248               -1   c2249               -1
    rhs       c2260                1   c2261                1
    rhs       c2264                1   c2265                1
    rhs       c2266               -1   c2269               -1
    rhs       c2275               -1   c2286               -1
    rhs       c2287               -1   c2289               -1
    rhs       c2290               -1   c2291               -1
    rhs       c2302                1   c2303                1
    rhs       c2306                1   c2307                1
    rhs       c2323               -1   c2324               -1
    rhs       c2326               -1   c2327               -1
    rhs       c2328               -1   c2329                1
    rhs       c2330                1   c2331                1
    rhs       c2332                1   c2339                1
    rhs       c2340                1   c2341                1
    rhs       c2342                1   c2353                1
    rhs       c2354               -1   c2355               -1
    rhs       c2358               -1   c2364               -1
    rhs       c2375               -1   c2376               -1
    rhs       c2378               -1   c2379               -1
    rhs       c2380               -1   c2391                1
    rhs       c2392                1   c2395                1
    rhs       c2396                1   c2401                1
    rhs       c2402               -1   c2403               -1
    rhs       c2406               -1   c2409                1
    rhs       c2410               -1   c2412                1
    rhs       c2413               -1   c2428                1
    rhs       c2429                1   c2432                1
    rhs       c2433                1   c2444               -1
    rhs       c2445               -1   c2447               -1
    rhs       c2448               -1   c2449               -1
    rhs       c2460                1   c2461               -1
    rhs       c2463                1   c2464               -1
    rhs       c2473                1   c2474               -1
    rhs       c2475               -1   c2478               -1
    rhs       c2481                1   c2482               -1
    rhs       c2484                1   c2485               -1
    rhs       c2500                1   c2501                1
    rhs       c2504                1   c2505                1
    rhs       c2516               -1   c2517               -1
    rhs       c2519               -1   c2520               -1
    rhs       c2521               -1   c2522               -1
    rhs       c2525               -1   c2531               -1
    rhs       c2542               -1   c2543               -1
    rhs       c2545               -1   c2546               -1
    rhs       c2547               -1   c2558                1
    rhs       c2559                1   c2562                1
    rhs       c2563                1   c2579               -1
    rhs       c2580               -1   c2582               -1
    rhs       c2583               -1   c2584               -1
    rhs       c2585                1   c2586                1
    rhs       c2587                1   c2588                1
    rhs       c2595                1   c2596                1
    rhs       c2597                1   c2598                1
    rhs       c2599               -1   c2602               -1
    rhs       c2605                1   c2606               -1
    rhs       c2608                1   c2609               -1
    rhs       c2624                1   c2625                1
    rhs       c2628                1   c2629                1
    rhs       c2640               -1   c2641               -1
    rhs       c2643               -1   c2644               -1
    rhs       c2645               -1   c2656                1
    rhs       c2657               -1   c2659                1
    rhs       c2660               -1   c2661               -1
    rhs       c2664               -1   c2667                1
    rhs       c2668               -1   c2670                1
    rhs       c2671               -1   c2686                1
    rhs       c2687                1   c2690                1
    rhs       c2691                1   c2702               -1
    rhs       c2703               -1   c2705               -1
    rhs       c2706               -1   c2707               -1
    rhs       c2708               -1   c2711               -1
    rhs       c2717               -1   c2728               -1
    rhs       c2729               -1   c2731               -1
    rhs       c2732               -1   c2733               -1
    rhs       c2744                1   c2745                1
    rhs       c2748                1   c2749                1
    rhs       c2750               -1   c2753               -1
    rhs       c2756                1   c2757               -1
    rhs       c2759                1   c2760               -1
    rhs       c2775                1   c2776                1
    rhs       c2779                1   c2780                1
    rhs       c2791               -1   c2792               -1
    rhs       c2795               -1   c2796               -1
    rhs       c2807                1   c2808                1
    rhs       c2809                1   c2810                1
    rhs       c2815                1   c2816                1
    rhs       c2817                1   c2818                1
    rhs       c2819               -1   c2820               -1
    rhs       c2841                1   c2842                1
    rhs       c2845                1   c2846                1
    rhs       c2847                1   c2848               -1
    rhs       c2850                1   c2851               -1
    rhs       c2852                1   c2856               -1
    rhs       c2857               -1   c2858                1
    rhs       c2859                1   c2860                1
    rhs       c2861                1   c2862                1
    rhs       c2869                1   c2870                1
    rhs       c2871                1   c2872                1
    rhs       c2873                1   c2874                1
    rhs       c2877                1   c2878                1
    rhs       c2879               -1   c2885               -1
    rhs       c2886               -1   c2887               -1
    rhs       c2888               -1   c2889               -1
    rhs       c2892               -1   c2893               -1
    rhs       c2894               -1   c2895               -1
    rhs       c2896               -1   c2897               -1
    rhs       c2898               -1   c2899               -1
    rhs       c2900               -1   c2901               -1
    rhs       c2903               -1   c2904               -1
    rhs       c2905               -1   c2906               -1
    rhs       c2909               -1   c2915               -1
    rhs       c2926               -1   c2927               -1
    rhs       c2929               -1   c2930               -1
    rhs       c2931               -1   c2942                1
    rhs       c2943                1   c2946                1
    rhs       c2947                1   c2963                1
    rhs       c2964               -1   c2966                1
    rhs       c2967               -1   c2968               -1
    rhs       c2971               -1   c2977               -1
    rhs       c2988               -1   c2989               -1
    rhs       c2991               -1   c2992               -1
    rhs       c2993               -1   c3004                1
    rhs       c3005                1   c3008                1
    rhs       c3009                1   c3010               -1
    rhs       c3013               -1   c3019               -1
    rhs       c3030               -1   c3031               -1
    rhs       c3033               -1   c3034               -1
    rhs       c3035               -1   c3046                1
    rhs       c3047                1   c3050                1
    rhs       c3051                1   c3052               -1
    rhs       c3055               -1   c3058                1
    rhs       c3059               -1   c3061                1
    rhs       c3062               -1   c3077                1
    rhs       c3078                1   c3081                1
    rhs       c3082                1   c3093               -1
    rhs       c3094               -1   c3096               -1
    rhs       c3097               -1   c3098               -1
    rhs       c3109                1   c3110                1
    rhs       c3111                1   c3112                1
    rhs       c3117                1   c3118                1
    rhs       c3119                1   c3120                1
    rhs       c3121               -1   c3122               -1
    rhs       c3123               -1   c3126               -1
    rhs       c3132               -1   c3143               -1
    rhs       c3144               -1   c3146               -1
    rhs       c3147               -1   c3148               -1
    rhs       c3159                1   c3160                1
    rhs       c3163                1   c3164                1
    rhs       c3180                1   c3181               -1
    rhs       c3183                1   c3184               -1
    rhs       c3185               -1   c3188               -1
    rhs       c3194               -1   c3205               -1
    rhs       c3206               -1   c3208               -1
    rhs       c3209               -1   c3210               -1
    rhs       c3221                1   c3222                1
    rhs       c3225                1   c3226                1
    rhs       c3227               -1   c3230               -1
    rhs       c3236               -1   c3247               -1
    rhs       c3248               -1   c3250               -1
    rhs       c3251               -1   c3252               -1
    rhs       c3263                1   c3264                1
    rhs       c3267                1   c3268                1
    rhs       c3269               -1   c3272               -1
    rhs       c3278               -1   c3289               -1
    rhs       c3290               -1   c3292               -1
    rhs       c3293               -1   c3294               -1
    rhs       c3305                1   c3306                1
    rhs       c3309                1   c3310                1
    rhs       c3326                1   c3327               -1
    rhs       c3329                1   c3330               -1
    rhs       c3341                1   c3342                1
    rhs       c3343                1   c3344                1
    rhs       c3349                1   c3350                1
    rhs       c3351                1   c3352                1
    rhs       c3353               -1   c3354               -1
    rhs       c3355               -1   c3358               -1
    rhs       c3364               -1   c3375               -1
    rhs       c3376               -1   c3378               -1
    rhs       c3379               -1   c3380               -1
    rhs       c3391                1   c3392                1
    rhs       c3395                1   c3396                1
    rhs       c3397               -1   c3400               -1
    rhs       c3406               -1   c3417               -1
    rhs       c3418               -1   c3420               -1
    rhs       c3421               -1   c3422               -1
    rhs       c3433                1   c3434                1
    rhs       c3437                1   c3438                1
    rhs       c3439               -1   c3442               -1
    rhs       c3445                1   c3446               -1
    rhs       c3448                1   c3449               -1
    rhs       c3464                1   c3465                1
    rhs       c3468                1   c3469                1
    rhs       c3480               -1   c3481               -1
    rhs       c3484               -1   c3485               -1
    rhs       c3486               -1   c3489               -1
    rhs       c3492                1   c3493               -1
    rhs       c3495                1   c3496               -1
    rhs       c3511                1   c3512                1
    rhs       c3515                1   c3516                1
    rhs       c3527               -1   c3528               -1
    rhs       c3531               -1   c3532               -1
    rhs       c3548                1   c3549                1
    rhs       c3550                1   c3551                1
    rhs       c3556                1   c3557                1
    rhs       c3558                1   c3559                1
    rhs       c3560               -1   c3561               -1
    rhs       c3562               -1   c3565               -1
    rhs       c3571               -1   c3582               -1
    rhs       c3583               -1   c3585               -1
    rhs       c3586               -1   c3587               -1
    rhs       c3598                1   c3599                1
    rhs       c3602                1   c3603                1
    rhs       c3614                1   c3615               -1
    rhs       c3617                1   c3618               -1
    rhs       c3623                1   c3624               -1
    rhs       c3625               -1   c3628               -1
    rhs       c3634               -1   c3645               -1
    rhs       c3646               -1   c3648               -1
    rhs       c3649               -1   c3650               -1
    rhs       c3661                1   c3662                1
    rhs       c3665                1   c3666                1
    rhs       c3667               -1   c3670               -1
    rhs       c3673                1   c3674               -1
    rhs       c3676                1   c3677               -1
    rhs       c3692                1   c3693                1
    rhs       c3696                1   c3697                1
    rhs       c3708               -1   c3709               -1
    rhs       c3711               -1   c3712               -1
    rhs       c3713               -1   c3746               -2
    rhs       c3747               -2   c3748                1
    rhs       c3749               -2   c3750               -2
    rhs       c3751                1   c3752               -2
    rhs       c3753               -2   c3754                1
    rhs       c3755               -2   c3756               -2
    rhs       c3757                1   c3761                1
    rhs       c3762                1   c3763               -2
    rhs       c3764               -2   c3765               -2
    rhs       c3766               -2   c3767               -2
    rhs       c3768               -2   c3769               -2
    rhs       c3770               -2   c3771               -2
    rhs       c3772               -2   c3773               -2
    rhs       c3774               -2   c3775               -2
    rhs       c3777               -2   c3778                1
    rhs       c3779                1   c3780               -2
    rhs       c3781               -2   c3782               -2
    rhs       c3783               -2   c3786               -2
    rhs       c3788               -2   c3789                1
    rhs       c3791               -2   c3792                1
    rhs       c3795               -2   c3797               -2
    rhs       c3798               -2   c3800               -2
    rhs       c3801               -2   c3803               -2
    rhs       c3805               -2   c3807               -2
    rhs       c3809               -2   c3810               -2
    rhs       c3811               -2   c3812               -2
    rhs       c3813               -2   c3814               -2
    rhs       c3815               -2   c3817               -2
    rhs       c3819               -2   c3821               -2
    rhs       c3823               -2   c3825               -2
    rhs       c3827               -2   c3829               -2
    rhs       c3831               -2   c3833               -2
    rhs       c3834                1   c3835                1
    rhs       c3836               -2   c3837               -2
    rhs       c3838               -2   c3839               -2
    rhs       c3840               -2   c3841               -2
    rhs       c3842               -2   c3843               -2
    rhs       c3844               -2   c3845               -2
    rhs       c3846               -2   c3847               -2
    rhs       c3848               -2   c3850               -2
    rhs       c3851                1   c3852                1
    rhs       c3853               -2   c3854               -2
    rhs       c3855               -2   c3856               -2
    rhs       c3859               -2   c3861               -2
    rhs       c3862                1   c3864               -2
    rhs       c3865                1   c3868               -2
    rhs       c3870               -2   c3872               -2
    rhs       c3873                1   c3874                1
    rhs       c3875               -2   c3876               -2
    rhs       c3877               -2   c3878               -2
    rhs       c3879               -2   c3880               -2
    rhs       c3881               -2   c3882               -2
    rhs       c3883               -2   c3884               -2
    rhs       c3885               -2   c3886               -2
    rhs       c3887               -2   c3889               -2
    rhs       c3890                1   c3891                1
    rhs       c3892               -2   c3893               -2
    rhs       c3894               -2   c3895               -2
    rhs       c3898               -2   c3900               -2
    rhs       c3901                1   c3903               -2
    rhs       c3904                1   c3907               -2
    rhs       c3909               -2   c3910               -2
    rhs       c3911               -2   c3912                1
    rhs       c3913                1   c3914                1
    rhs       c3915                1   c3916               -1
    rhs       c3917               -1   c3919               -1
    rhs       c3920               -1   c3922               -1
    rhs       c3923               -1   c3926               -2
    rhs       c3927               -2   c3928               -2
    rhs       c3929                1   c3930                1
    rhs       c3931                1   c3932                1
    rhs       c3935               -2   c3937               -2
    rhs       c3938               -2   c3940               -2
    rhs       c3941               -2   c3943               -2
    rhs       c3945               -2   c3947               -2
    rhs       c3949               -2   c3951               -2
    rhs       c3952               -2   c3953               -2
    rhs       c3954                1   c3955                1
    rhs       c3956                1   c3957                1
    rhs       c3958               -1   c3959               -1
    rhs       c3961               -1   c3962               -1
    rhs       c3964               -1   c3965               -1
    rhs       c3968               -2   c3969               -2
    rhs       c3970               -2   c3971                1
    rhs       c3972                1   c3973                1
    rhs       c3974                1   c3977               -2
    rhs       c3979               -2   c3980               -2
    rhs       c3982               -2   c3983               -2
    rhs       c3984                1   c3985                1
    rhs       c3986               -2   c3987               -2
    rhs       c3988               -2   c3989               -2
    rhs       c3990                1   c3993               -2
    rhs       c3995               -2   c3996                1
    rhs       c3997                1   c3998               -2
    rhs       c3999               -2   c4000               -2
    rhs       c4001               -2   c4002               -2
    rhs       c4003               -2   c4004               -2
    rhs       c4005               -2   c4006               -2
    rhs       c4007               -2   c4008               -2
    rhs       c4009               -2   c4010               -2
    rhs       c4012               -2   c4013                1
    rhs       c4014                1   c4015               -2
    rhs       c4016               -2   c4017               -2
    rhs       c4018               -2   c4021               -2
    rhs       c4023               -2   c4024                1
    rhs       c4026               -2   c4027                1
    rhs       c4029               -2   c4031               -2
    rhs       c4033               -2   c4035               -2
    rhs       c4036                1   c4037                1
    rhs       c4038               -2   c4039               -2
    rhs       c4040               -2   c4041               -2
    rhs       c4042                1   c4043                1
    rhs       c4044                1   c4045               -2
    rhs       c4046               -2   c4047               -2
    rhs       c4048               -2   c4049                1
    rhs       c4050               -2   c4051               -2
    rhs       c4052                1   c4053                1
    rhs       c4054                1   c4055                1
    rhs       c4056               -2   c4057               -2
    rhs       c4058               -2   c4059               -2
    rhs       c4060                1   c4061                1
    rhs       c4062                1   c4063                1
    rhs       c4064               -2   c4065               -2
    rhs       c4066               -2   c4067                1
    rhs       c4068                1   c4069                1
    rhs       c4070                1   c4071               -2
    rhs       c4072               -2   c4073               -2
    rhs       c4074                1   c4075                1
    rhs       c4076                1   c4077                1
    rhs       c4078               -2   c4079               -2
    rhs       c4081               -2   c4082               -2
    rhs       c4085               -2   c4087               -2
    rhs       c4089               -2   c4091               -2
    rhs       c4093               -2   c4095               -2
    rhs       c4097               -2   c4099               -2
    rhs       c4101               -2   c4103               -2
    rhs       c4105               -2   c4107               -2
    rhs       c4109               -2   c4111               -2
    rhs       c4112               -2   c4113               -2
    rhs       c4114                1   c4115                1
    rhs       c4116                1   c4117                1
    rhs       c4118               -1   c4119               -1
    rhs       c4121               -1   c4122               -1
    rhs       c4124               -1   c4125               -1
    rhs       c4128               -2   c4129               -2
    rhs       c4130               -2   c4131                1
    rhs       c4132                1   c4133                1
    rhs       c4134                1   c4137               -2
    rhs       c4139               -2   c4140               -2
    rhs       c4142               -2   c4143               -2
    rhs       c4146               -2   c4148               -2
    rhs       c4149                1   c4150                1
    rhs       c4151               -2   c4152               -2
    rhs       c4153               -2   c4154               -2
    rhs       c4155               -2   c4156               -2
    rhs       c4157               -2   c4158               -2
    rhs       c4159               -2   c4160               -2
    rhs       c4161               -2   c4162               -2
    rhs       c4163               -2   c4165               -2
    rhs       c4166                1   c4167                1
    rhs       c4168               -2   c4169               -2
    rhs       c4170               -2   c4171               -2
    rhs       c4174               -2   c4176               -2
    rhs       c4177                1   c4179               -2
    rhs       c4180                1   c4183               -2
    rhs       c4185               -2   c4186               -2
    rhs       c4187               -2   c4188                1
    rhs       c4189                1   c4190                1
    rhs       c4191                1   c4192               -1
    rhs       c4193               -1   c4195               -1
    rhs       c4196               -1   c4198               -1
    rhs       c4199               -1   c4202               -2
    rhs       c4203               -2   c4204               -2
    rhs       c4205                1   c4206                1
    rhs       c4207                1   c4208                1
    rhs       c4211               -2   c4213               -2
    rhs       c4214               -2   c4216               -2
    rhs       c4217               -2   c4218               -2
    rhs       c4219               -2   c4220                1
    rhs       c4221                1   c4222                1
    rhs       c4223                1   c4224               -2
    rhs       c4225               -2   c4226               -2
    rhs       c4227                1   c4228                1
    rhs       c4229                1   c4230                1
    rhs       c4231               -2   c4232                1
    rhs       c4233                1   c4234               -2
    rhs       c4235               -2   c4236               -2
    rhs       c4237               -2   c4238                1
    rhs       c4239               -2   c4240               -2
    rhs       c4241               -2   c4242                1
    rhs       c4243                1   c4244                1
    rhs       c4245                1   c4246               -2
    rhs       c4247               -2   c4248               -2
    rhs       c4249                1   c4250                1
    rhs       c4251                1   c4252                1
    rhs       c4253               -2   c4254                1
    rhs       c4255                1   c4256               -2
    rhs       c4257               -2   c4258               -2
    rhs       c4259               -2   c4260                1
    rhs       c4261               -2   c4262               -2
    rhs       c4263                1   c4264                1
    rhs       c4265                1   c4266                1
    rhs       c4267               -2   c4268                1
    rhs       c4269                1   c4270               -2
    rhs       c4271               -2   c4272               -2
    rhs       c4273               -2   c4274                1
    rhs       c4275                1   c4276                1
    rhs       c4277               -2   c4278               -2
    rhs       c4279               -2   c4280               -2
    rhs       c4281                1   c4282                1
    rhs       c4283                1   c4284               -2
    rhs       c4285               -2   c4286               -2
    rhs       c4287               -2   c4288                1
    rhs       c4289                1   c4290                1
    rhs       c4291               -2   c4292               -2
    rhs       c4293               -2   c4294               -2
    rhs       c4295                1   c4296               -2
    rhs       c4297               -2   c4298                1
    rhs       c4299                1   c4300                1
    rhs       c4301                1   c4302               -2
    rhs       c4303               -2   c4304               -2
    rhs       c4305               -2   c4306                1
    rhs       c4307                1   c4308                1
    rhs       c4309                1   c4310               -2
    rhs       c4311               -2   c4312               -2
    rhs       c4313                1   c4314                1
    rhs       c4315                1   c4316                1
    rhs       c4317               -2   c4318               -2
    rhs       c4319               -2   c4320                1
    rhs       c4321                1   c4322                1
    rhs       c4323                1   c4324               -2
    rhs       c4325                1   c4326                1
    rhs       c4327               -2   c4328               -2
    rhs       c4329               -2   c4330               -2
    rhs       c4331                1   c4332                1
    rhs       c4333                1   c4334               -2
    rhs       c4335               -2   c4336               -2
    rhs       c4337               -2   c4338                1
    rhs       c4339               -2   c4340               -2
    rhs       c4341                1   c4342                1
    rhs       c4343                1   c4344                1
    rhs       c4345               -2   c4346                1
    rhs       c4347                1   c4348               -2
    rhs       c4349               -2   c4350               -2
    rhs       c4351               -2   c4352                1
    rhs       c4353               -2   c4354               -2
    rhs       c4355                1   c4356                1
    rhs       c4357                1   c4358                1
    rhs       c4359               -2   c4360               -2
    rhs       c4361               -2   c4362                1
    rhs       c4363                1   c4364                1
    rhs       c4365                1   c4366               -2
    rhs       c4367                1   c4368                1
    rhs       c4369               -2   c4370               -2
    rhs       c4371               -2   c4372               -2
    rhs       c4373                1   c4374                1
    rhs       c4375                1   c4376               -2
    rhs       c4377               -2   c4378               -2
    rhs       c4379               -2   c4380                1
    rhs       c4381                1   c4382                1
    rhs       c4383               -2   c4384               -2
    rhs       c4385               -2   c4386               -2
    rhs       c4387                1   c4388               -2
    rhs       c4389               -2   c4390               -2
    rhs       c4391                1   c4392                1
    rhs       c4393                1   c4394                1
    rhs       c4395               -2   c4396                1
    rhs       c4397                1   c4398               -2
    rhs       c4399               -2   c4400               -2
    rhs       c4401               -2   c4402                1
    rhs       c4403               -2   c4404               -2
    rhs       c4405                1   c4406                1
    rhs       c4407                1   c4408                1
    rhs       c4409               -2   c4410                1
    rhs       c4411                1   c4412               -2
    rhs       c4413               -2   c4414               -2
    rhs       c4415               -2   c4416                1
    rhs       c4417               -2   c4418               -2
    rhs       c4419                1   c4420                1
    rhs       c4421                1   c4422                1
    rhs       c4423               -2   c4424                1
    rhs       c4425                1   c4426               -2
    rhs       c4427               -2   c4428               -2
    rhs       c4429               -2   c4430                1
    rhs       c4431               -2   c4432               -2
    rhs       c4433                1   c4434                1
    rhs       c4435                1   c4436                1
    rhs       c4437               -2   c4438                1
    rhs       c4439                1   c4440               -2
    rhs       c4441               -2   c4442               -2
    rhs       c4443               -2   c4444                1
    rhs       c4445                1   c4446                1
    rhs       c4447               -2   c4448               -2
    rhs       c4449               -2   c4450               -2
    rhs       c4451                1   c4452               -2
    rhs       c4453               -2   c4454               -2
    rhs       c4455                1   c4456                1
    rhs       c4457                1   c4458                1
    rhs       c4459               -2   c4460               -2
    rhs       c4461               -2   c4462                1
    rhs       c4463                1   c4464                1
    rhs       c4465                1   c4466               -2
    rhs       c4467               -2   c4468               -2
    rhs       c4469                1   c4470                1
    rhs       c4471                1   c4472                1
    rhs       c4473               -2   c4474                1
    rhs       c4475                1   c4476               -2
    rhs       c4477               -2   c4478               -2
    rhs       c4479               -2   c4480                1
    rhs       c4481                1   c4482                1
    rhs       c4483               -2   c4484               -2
    rhs       c4485               -2   c4486               -2
    rhs       c4487                1   c4488               -2
    rhs       c4489               -2   c4490                1
    rhs       c4491                1   c4492                1
    rhs       c4493                1   c4494               -2
    rhs       c4495                1   c4496                1
    rhs       c4497               -2   c4498               -2
    rhs       c4499               -2   c4500               -2
    rhs       c4501                1   c4502               -2
    rhs       c4503               -2   c4504                1
    rhs       c4505                1   c4506                1
    rhs       c4507                1   c4508               -2
    rhs       c4509                1   c4510                1
    rhs       c4511               -2   c4512               -2
    rhs       c4513               -2   c4514               -2
    rhs       c4515                1   c4516               -2
    rhs       c4517               -2   c4518               -2
    rhs       c4519                1   c4520                1
    rhs       c4521                1   c4522                1
    rhs       c4523               -2   c4524               -2
    rhs       c4525               -2   c4526                1
    rhs       c4527                1   c4528                1
    rhs       c4529                1   c4530               -2
    rhs       c4531                1   c4532                1
    rhs       c4533               -2   c4534               -2
    rhs       c4535               -2   c4536               -2
    rhs       c4537                1   c4538                1
    rhs       c4539                1   c4540               -2
    rhs       c4541               -2   c4542               -2
    rhs       c4543               -2   c4544                1
    rhs       c4545                1   c4546                1
    rhs       c4547               -2   c4548               -2
    rhs       c4549               -2   c4550               -2
    rhs       c4551                1   c4552               -2
    rhs       c4553               -2   c4554                1
    rhs       c4555                1   c4556                1
    rhs       c4557                1   c4558               -2
    rhs       c4559               -2   c4560               -2
    rhs       c4561               -2   c4562                1
    rhs       c4563                1   c4564                1
    rhs       c4565                1   c4566               -2
    rhs       c4567               -2   c4568               -2
    rhs       c4569                1   c4570                1
    rhs       c4571                1   c4572                1
    rhs       c4573               -2   c4574                1
    rhs       c4575                1   c4576               -2
    rhs       c4577               -2   c4578               -2
    rhs       c4579               -2   c4580                1
    rhs       c4581                1   c4582                1
    rhs       c4583                1   c4584                1
    rhs       c4585               -2   c4586               -2
    rhs       c4587                1   c4588                1
    rhs       c4589                1   c4590                1
    rhs       c4591               -2   c4592               -2
    rhs       c4593               -2   c4594                1
    rhs       c4595                1   c4596                1
    rhs       c4597                1   c4598               -2
    rhs       c4599                1   c4600                1
    rhs       c4601               -2   c4602               -2
    rhs       c4603               -2   c4604               -2
    rhs       c4605                1   c4606               -2
    rhs       c4607                1   c4608                1
    rhs       c4609               -2   c4610               -2
    rhs       c4611               -2   c4612               -2
    rhs       c4613                1   c4614                1
    rhs       c4615                1   c4616               -2
    rhs       c4617               -2   c4618               -2
    rhs       c4619               -2   c4620                1
    rhs       c4621               -2   c4622               -2
    rhs       c4623                1   c4624                1
    rhs       c4625                1   c4626                1
    rhs       c4627               -2   c4632               -2
    rhs       c4633               -2   c4634               -2
    rhs       c4635                1   c4636                1
    rhs       c4637                1   c4638                1
    rhs       c4639               -1   c4640               -1
    rhs       c4642               -1   c4643               -1
    rhs       c4645               -1   c4646               -1
    rhs       c4649               -2   c4650               -2
    rhs       c4651               -2   c4652                1
    rhs       c4653                1   c4654                1
    rhs       c4655                1   c4658               -2
    rhs       c4660               -2   c4661               -2
    rhs       c4663               -2   c4664               -2
    rhs       c4667               -2   c4669               -2
    rhs       c4671               -2   c4672               -2
    rhs       c4674               -2   c4675               -2
    rhs       c4679                1   c4680                1
    rhs       c4681               -2   c4682               -2
    rhs       c4683               -2   c4684               -2
    rhs       c4685               -2   c4686               -2
    rhs       c4687               -2   c4688               -2
    rhs       c4689               -2   c4690               -2
    rhs       c4691               -2   c4692               -2
    rhs       c4693               -2   c4695               -2
    rhs       c4696                1   c4697                1
    rhs       c4698               -2   c4699               -2
    rhs       c4700               -2   c4701               -2
    rhs       c4704               -2   c4706               -2
    rhs       c4707                1   c4709               -2
    rhs       c4710                1   c4713               -2
    rhs       c4715               -2   c4716               -2
    rhs       c4718               -2   c4719               -2
    rhs       c4723                1   c4724                1
    rhs       c4725               -2   c4726               -2
    rhs       c4727               -2   c4728               -2
    rhs       c4729               -2   c4730               -2
    rhs       c4731               -2   c4732               -2
    rhs       c4733               -2   c4734               -2
    rhs       c4735               -2   c4736               -2
    rhs       c4737               -2   c4739               -2
    rhs       c4740                1   c4741                1
    rhs       c4742               -2   c4743               -2
    rhs       c4744               -2   c4745               -2
    rhs       c4748               -2   c4750               -2
    rhs       c4751                1   c4753               -2
    rhs       c4754                1   c4757               -2
    rhs       c4759               -2   c4760               -2
    rhs       c4762               -2   c4763               -2
    rhs       c4767                1   c4768                1
    rhs       c4769               -2   c4770               -2
    rhs       c4771               -2   c4772               -2
    rhs       c4773               -2   c4774               -2
    rhs       c4775               -2   c4776               -2
    rhs       c4777               -2   c4778               -2
    rhs       c4779               -2   c4780               -2
    rhs       c4781               -2   c4782               -2
    rhs       c4783               -2   c4784               -2
    rhs       c4786               -2   c4787                1
    rhs       c4788                1   c4789               -2
    rhs       c4790               -2   c4791               -2
    rhs       c4792               -2   c4795               -2
    rhs       c4797               -2   c4798                1
    rhs       c4799               -2   c4800               -2
    rhs       c4801               -2   c4802               -2
    rhs       c4803               -2   c4804               -2
    rhs       c4806               -2   c4807                1
    rhs       c4810               -2   c4812               -2
    rhs       c4813               -2   c4815               -2
    rhs       c4816               -2   c4818               -2
    rhs       c4820               -2   c4822               -2
    rhs       c4824               -2   c4825               -2
    rhs       c4826               -2   c4827               -2
    rhs       c4828               -2   c4829               -2
    rhs       c4830               -2   c4832               -2
    rhs       c4834               -2   c4836               -2
    rhs       c4838               -2   c4840               -2
    rhs       c4842               -2   c4844               -2
    rhs       c4845               -2   c4847               -2
    rhs       c4848               -2   c4852                1
    rhs       c4853                1   c4854               -2
    rhs       c4855               -2   c4856               -2
    rhs       c4857               -2   c4858               -2
    rhs       c4859               -2   c4860               -2
    rhs       c4861               -2   c4862               -2
    rhs       c4863               -2   c4864               -2
    rhs       c4865               -2   c4866               -2
    rhs       c4868               -2   c4869                1
    rhs       c4870                1   c4871               -2
    rhs       c4872               -2   c4873               -2
    rhs       c4874               -2   c4877               -2
    rhs       c4879               -2   c4880                1
    rhs       c4882               -2   c4883                1
    rhs       c4886               -2   c4888               -2
    rhs       c4889               -2   c4891               -2
    rhs       c4892               -2   c4896                1
    rhs       c4897                1   c4898               -2
    rhs       c4899               -2   c4900               -2
    rhs       c4901               -2   c4902               -2
    rhs       c4903               -2   c4904               -2
    rhs       c4905               -2   c4906               -2
    rhs       c4907               -2   c4908               -2
    rhs       c4909               -2   c4910               -2
    rhs       c4912               -2   c4913                1
    rhs       c4914                1   c4915               -2
    rhs       c4916               -2   c4917               -2
    rhs       c4918               -2   c4921               -2
    rhs       c4923               -2   c4924                1
    rhs       c4926               -2   c4927                1
    rhs       c4930               -2   c4932               -2
    rhs       c4933               -2   c4935               -2
    rhs       c4936               -2   c4940                1
    rhs       c4941                1   c4942               -2
    rhs       c4943               -2   c4944               -2
    rhs       c4945               -2   c4946               -2
    rhs       c4947               -2   c4948               -2
    rhs       c4949               -2   c4950               -2
    rhs       c4951               -2   c4952               -2
    rhs       c4953               -2   c4954               -2
    rhs       c4956               -2   c4957                1
    rhs       c4958                1   c4959               -2
    rhs       c4960               -2   c4961               -2
    rhs       c4962               -2   c4965               -2
    rhs       c4967               -2   c4968                1
    rhs       c4970               -2   c4971                1
    rhs       c4974               -2   c4976               -2
    rhs       c4977               -2   c4979               -2
    rhs       c4980               -2   c4984                1
    rhs       c4985                1   c4986               -2
    rhs       c4987               -2   c4988               -2
    rhs       c4989               -2   c4990               -2
    rhs       c4991               -2   c4992               -2
    rhs       c4993               -2   c4994               -2
    rhs       c4995               -2   c4996               -2
    rhs       c4997               -2   c4998               -2
    rhs       c5000               -2   c5001                1
    rhs       c5002                1   c5003               -2
    rhs       c5004               -2   c5005               -2
    rhs       c5006               -2   c5009               -2
    rhs       c5011               -2   c5012                1
    rhs       c5014               -2   c5015                1
    rhs       c5018               -2   c5020               -2
    rhs       c5021               -2   c5023               -2
    rhs       c5024               -2   c5026               -2
    rhs       c5028               -2   c5030               -2
    rhs       c5031                1   c5033               -2
    rhs       c5034                1   c5035               -1
    rhs       c5036               -1   c5038               -1
    rhs       c5039               -1   c5042               -2
    rhs       c5046                1   c5047                1
    rhs       c5048               -2   c5049               -2
    rhs       c5050               -2   c5051               -2
    rhs       c5052               -2   c5053               -2
    rhs       c5054               -2   c5055               -2
    rhs       c5056               -2   c5057               -2
    rhs       c5058               -2   c5059               -2
    rhs       c5060               -2   c5062               -2
    rhs       c5063                1   c5064                1
    rhs       c5065               -2   c5066               -2
    rhs       c5067               -2   c5068               -2
    rhs       c5071               -2   c5073               -2
    rhs       c5074                1   c5076               -2
    rhs       c5077                1   c5080               -2
    rhs       c5082               -2   c5083               -2
    rhs       c5085               -2   c5086               -2
    rhs       c5091               -2   c5092               -2
    rhs       c5093               -2   c5094                1
    rhs       c5095                1   c5096                1
    rhs       c5097                1   c5098               -1
    rhs       c5099               -1   c5101               -1
    rhs       c5102               -1   c5104               -1
    rhs       c5105               -1   c5108               -2
    rhs       c5109               -2   c5110               -2
    rhs       c5111                1   c5112                1
    rhs       c5113                1   c5114                1
    rhs       c5117               -2   c5119               -2
    rhs       c5120               -2   c5122               -2
    rhs       c5123               -2   c5126               -2
    rhs       c5128               -2   c5129                1
    rhs       c5131               -2   c5132                1
    rhs       c5135               -2   c5137               -2
    rhs       c5139               -2   c5144               -2
    rhs       c5145               -2   c5146               -2
    rhs       c5147                1   c5148                1
    rhs       c5149                1   c5150                1
    rhs       c5151               -1   c5152               -1
    rhs       c5154               -1   c5155               -1
    rhs       c5157               -1   c5158               -1
    rhs       c5161               -2   c5162               -2
    rhs       c5163               -2   c5164                1
    rhs       c5165                1   c5166                1
    rhs       c5167                1   c5170               -2
    rhs       c5172               -2   c5173               -2
    rhs       c5175               -2   c5176               -2
    rhs       c5179               -2   c5181               -2
    rhs       c5182                1   c5184               -2
    rhs       c5185                1   c5189                1
    rhs       c5190                1   c5191               -2
    rhs       c5192               -2   c5193               -2
    rhs       c5194               -2   c5195               -2
    rhs       c5196               -2   c5197               -2
    rhs       c5198               -2   c5199               -2
    rhs       c5200               -2   c5201               -2
    rhs       c5202               -2   c5203               -2
    rhs       c5205               -2   c5206                1
    rhs       c5207                1   c5208               -2
    rhs       c5209               -2   c5210               -2
    rhs       c5211               -2   c5214               -2
    rhs       c5216               -2   c5217                1
    rhs       c5219               -2   c5220                1
    rhs       c5223               -2   c5225               -2
    rhs       c5226               -2   c5228               -2
    rhs       c5229               -2   c5231               -2
    rhs       c5233               -2   c5235               -2
    rhs       c5236                1   c5238               -2
    rhs       c5239                1   c5240               -1
    rhs       c5241               -1   c5243               -1
    rhs       c5244               -1   c5247               -2
    rhs       c5252               -2   c5253               -2
    rhs       c5254               -2   c5255                1
    rhs       c5256                1   c5257                1
    rhs       c5258                1   c5259               -1
    rhs       c5260               -1   c5262               -1
    rhs       c5263               -1   c5265               -1
    rhs       c5266               -1   c5269               -2
    rhs       c5270               -2   c5271               -2
    rhs       c5272                1   c5273                1
    rhs       c5274                1   c5275                1
    rhs       c5278               -2   c5280               -2
    rhs       c5281               -2   c5283               -2
    rhs       c5284               -2   c5287               -2
    rhs       c5289               -2   c5290                1
    rhs       c5292               -2   c5293                1
    rhs       c5296               -2   c5298               -2
    rhs       c5300               -2   c5305               -2
    rhs       c5306               -2   c5307               -2
    rhs       c5308                1   c5309                1
    rhs       c5310                1   c5311                1
    rhs       c5312               -1   c5313               -1
    rhs       c5315               -1   c5316               -1
    rhs       c5318               -1   c5319               -1
    rhs       c5322               -2   c5323               -2
    rhs       c5324               -2   c5325                1
    rhs       c5326                1   c5327                1
    rhs       c5328                1   c5331               -2
    rhs       c5333               -2   c5334               -2
    rhs       c5336               -2   c5337               -2
    rhs       c5340               -2   c5342               -2
    rhs       c5343                1   c5345               -2
    rhs       c5346                1   c5350                1
    rhs       c5351                1   c5352               -2
    rhs       c5353               -2   c5354               -2
    rhs       c5355               -2   c5356               -2
    rhs       c5357               -2   c5358               -2
    rhs       c5359               -2   c5360               -2
    rhs       c5361               -2   c5362               -2
    rhs       c5363               -2   c5364               -2
    rhs       c5366               -2   c5367                1
    rhs       c5368                1   c5369               -2
    rhs       c5370               -2   c5371               -2
    rhs       c5372               -2   c5375               -2
    rhs       c5377               -2   c5378                1
    rhs       c5380               -2   c5381                1
    rhs       c5384               -2   c5386               -2
    rhs       c5387               -2   c5389               -2
    rhs       c5390               -2   c5395               -2
    rhs       c5396               -2   c5397               -2
    rhs       c5398                1   c5399                1
    rhs       c5400                1   c5401                1
    rhs       c5402               -1   c5403               -1
    rhs       c5405               -1   c5406               -1
    rhs       c5408               -1   c5409               -1
    rhs       c5412               -2   c5413               -2
    rhs       c5414               -2   c5415                1
    rhs       c5416                1   c5417                1
    rhs       c5418                1   c5421               -2
    rhs       c5423               -2   c5424               -2
    rhs       c5426               -2   c5427               -2
    rhs       c5430               -2   c5432               -2
    rhs       c5433                1   c5434               -2
    rhs       c5435               -2   c5436               -2
    rhs       c5437               -2   c5438               -2
    rhs       c5439               -2   c5441               -2
    rhs       c5442                1   c5445               -2
    rhs       c5447               -2   c5449               -2
    rhs       c5450                1   c5452               -2
    rhs       c5454               -2   c5456               -2
    rhs       c5458               -2   c5459               -2
    rhs       c5460               -1   c5461               -1
    rhs       c5463               -1   c5464               -1
    rhs       c5467               -2   c5468               -2
    rhs       c5470               -2   c5471               -2
    rhs       c5472               -2   c5473               -2
    rhs       c5474               -2   c5475               -2
    rhs       c5476               -2   c5477               -2
    rhs       c5478               -2   c5479               -2
    rhs       c5480               -2   c5481               -2
    rhs       c5482               -2   c5483               -2
    rhs       c5484               -2   c5485               -2
    rhs       c5486               -1   c5487               -1
    rhs       c5489               -1   c5490               -1
    rhs       c5492               -1   c5493               -1
    rhs       c5496               -2   c5497               -2
    rhs       c5498               -2   c5499               -2
    rhs       c5500               -1   c5501               -1
    rhs       c5503               -1   c5504               -1
    rhs       c5507               -2   c5508               -2
    rhs       c5510               -2   c5511               -2
    rhs       c5512                1   c5513                1
    rhs       c5514                1   c5515               -1
    rhs       c5516               -1   c5518               -1
    rhs       c5519               -1   c5521               -1
    rhs       c5522               -1   c5524               -1
    rhs       c5525               -1   c5527               -2
    rhs       c5528               -2   c5529               -2
    rhs       c5530               -2   c5531               -2
    rhs       c5532               -2   c5533               -2
    rhs       c5534               -2   c5535               -2
    rhs       c5537               -2   c5538                1
    rhs       c5539                1   c5540                1
    rhs       c5541               -2   c5542               -2
    rhs       c5543               -2   c5544               -2
    rhs       c5545               -2   c5546               -2
    rhs       c5548               -2   c5549                1
    rhs       c5551               -2   c5552                1
    rhs       c5556                1   c5557                1
    rhs       c5558               -2   c5559               -2
    rhs       c5560               -2   c5561               -2
    rhs       c5562               -2   c5563               -2
    rhs       c5564               -2   c5565               -2
    rhs       c5566               -2   c5567               -2
    rhs       c5568               -2   c5569               -2
    rhs       c5570               -2   c5572               -2
    rhs       c5573                1   c5574                1
    rhs       c5575               -2   c5576               -2
    rhs       c5577               -2   c5578               -2
    rhs       c5581               -2   c5583               -2
    rhs       c5584                1   c5586               -2
    rhs       c5587                1   c5590               -2
    rhs       c5592               -2   c5593               -2
    rhs       c5595               -2   c5596               -2
    rhs       c5598               -2   c5600               -2
    rhs       c5602               -2   c5604               -2
    rhs       c5608                1   c5609                1
    rhs       c5610               -2   c5611               -2
    rhs       c5612               -2   c5613               -2
    rhs       c5614               -2   c5615               -2
    rhs       c5616               -2   c5617               -2
    rhs       c5618               -2   c5619               -2
    rhs       c5620               -2   c5621               -2
    rhs       c5622               -2   c5624               -2
    rhs       c5625                1   c5626                1
    rhs       c5627               -2   c5628               -2
    rhs       c5629               -2   c5630               -2
    rhs       c5633               -2   c5635               -2
    rhs       c5636                1   c5638               -2
    rhs       c5639                1   c5642               -2
    rhs       c5644               -2   c5645               -2
    rhs       c5647               -2   c5648               -2
    rhs       c5652                1   c5653                1
    rhs       c5654               -2   c5655               -2
    rhs       c5656               -2   c5657               -2
    rhs       c5658               -2   c5659               -2
    rhs       c5660               -2   c5661               -2
    rhs       c5662               -2   c5663               -2
    rhs       c5664               -2   c5665               -2
    rhs       c5666               -2   c5668               -2
    rhs       c5669                1   c5670                1
    rhs       c5671               -2   c5672               -2
    rhs       c5673               -2   c5674               -2
    rhs       c5677               -2   c5679               -2
    rhs       c5680                1   c5682               -2
    rhs       c5683                1   c5686               -2
    rhs       c5688               -2   c5689               -2
    rhs       c5690               -1   c5691               -1
    rhs       c5693               -1   c5694               -1
    rhs       c5697               -2   c5698               -2
    rhs       c5703               -2   c5704               -2
    rhs       c5705               -2   c5706                1
    rhs       c5707                1   c5708                1
    rhs       c5709                1   c5710               -1
    rhs       c5711               -1   c5713               -1
    rhs       c5714               -1   c5716               -1
    rhs       c5717               -1   c5720               -2
    rhs       c5721               -2   c5722               -2
    rhs       c5723                1   c5724                1
    rhs       c5725                1   c5726                1
    rhs       c5729               -2   c5731               -2
    rhs       c5732               -2   c5734               -2
    rhs       c5735               -2   c5738               -2
    rhs       c5740               -2   c5741                1
    rhs       c5743               -2   c5744                1
    rhs       c5747               -2   c5749               -2
    rhs       c5751               -2   c5752                1
    rhs       c5756                1   c5757                1
    rhs       c5758               -2   c5759               -2
    rhs       c5760               -2   c5761               -2
    rhs       c5762               -2   c5763               -2
    rhs       c5764               -2   c5765               -2
    rhs       c5766               -2   c5767               -2
    rhs       c5768               -2   c5769               -2
    rhs       c5770               -2   c5772               -2
    rhs       c5773                1   c5774                1
    rhs       c5775               -2   c5776               -2
    rhs       c5777               -2   c5778               -2
    rhs       c5781               -2   c5783               -2
    rhs       c5784                1   c5786               -2
    rhs       c5787                1   c5790               -2
    rhs       c5792               -2   c5793               -2
    rhs       c5794               -1   c5795               -1
    rhs       c5797               -1   c5798               -1
    rhs       c5801               -2   c5802               -2
    rhs       c5804               -2   c5806               -2
    rhs       c5808               -2   c5810               -2
    rhs       c5814                1   c5815                1
    rhs       c5816               -2   c5817               -2
    rhs       c5818               -2   c5819               -2
    rhs       c5820               -2   c5821               -2
    rhs       c5822               -2   c5823               -2
    rhs       c5824               -2   c5825               -2
    rhs       c5826               -2   c5827               -2
    rhs       c5828               -2   c5830               -2
    rhs       c5831                1   c5832                1
    rhs       c5833               -2   c5834               -2
    rhs       c5835               -2   c5836               -2
    rhs       c5839               -2   c5841               -2
    rhs       c5842                1   c5844               -2
    rhs       c5845                1   c5848               -2
    rhs       c5850               -2   c5851               -2
    rhs       c5853               -2   c5854               -2
    rhs       c5858                1   c5859                1
    rhs       c5860               -2   c5861               -2
    rhs       c5862               -2   c5863               -2
    rhs       c5864               -2   c5865               -2
    rhs       c5866               -2   c5867               -2
    rhs       c5868               -2   c5869               -2
    rhs       c5870               -2   c5871               -2
    rhs       c5872               -2   c5874               -2
    rhs       c5875                1   c5876                1
    rhs       c5877               -2   c5878               -2
    rhs       c5879               -2   c5880               -2
    rhs       c5883               -2   c5885               -2
    rhs       c5886                1   c5888               -2
    rhs       c5889                1   c5892               -2
    rhs       c5894               -2   c5895               -2
    rhs       c5896               -1   c5897               -1
    rhs       c5899               -1   c5900               -1
    rhs       c5903               -2   c5904               -2
    rhs       c5908                1   c5909                1
    rhs       c5910               -2   c5911               -2
    rhs       c5912               -2   c5913               -2
    rhs       c5914               -2   c5915               -2
    rhs       c5916               -2   c5917               -2
    rhs       c5918               -2   c5919               -2
    rhs       c5920               -2   c5921               -2
    rhs       c5922               -2   c5924               -2
    rhs       c5925                1   c5926                1
    rhs       c5927               -2   c5928               -2
    rhs       c5929               -2   c5930               -2
    rhs       c5933               -2   c5935               -2
    rhs       c5936                1   c5938               -2
    rhs       c5939                1   c5942               -2
    rhs       c5944               -2   c5945               -2
    rhs       c5947               -2   c5948               -2
    rhs       c5950               -2   c5952               -2
    rhs       c5954               -2   c5956               -2
    rhs       c5959               -2   c5961               -2
    rhs       c5963               -2   c5964                1
    rhs       c5968                1   c5969                1
    rhs       c5970               -2   c5971               -2
    rhs       c5972               -2   c5973               -2
    rhs       c5974               -2   c5975               -2
    rhs       c5976               -2   c5977               -2
    rhs       c5978               -2   c5979               -2
    rhs       c5980               -2   c5981               -2
    rhs       c5982               -2   c5984               -2
    rhs       c5985                1   c5986                1
    rhs       c5987               -2   c5988               -2
    rhs       c5989               -2   c5990               -2
    rhs       c5993               -2   c5995               -2
    rhs       c5996                1   c5998               -2
    rhs       c5999                1   c6002               -2
    rhs       c6004               -2   c6005               -2
    rhs       c6007               -2   c6008               -2
    rhs       c6012                1   c6013                1
    rhs       c6014               -2   c6015               -2
    rhs       c6016               -2   c6017               -2
    rhs       c6018               -2   c6019               -2
    rhs       c6020               -2   c6021               -2
    rhs       c6022               -2   c6023               -2
    rhs       c6024               -2   c6025               -2
    rhs       c6026               -2   c6028               -2
    rhs       c6029                1   c6030                1
    rhs       c6031               -2   c6032               -2
    rhs       c6033               -2   c6034               -2
    rhs       c6037               -2   c6039               -2
    rhs       c6040                1   c6042               -2
    rhs       c6043                1   c6046               -2
    rhs       c6048               -2   c6049               -2
    rhs       c6050               -1   c6051               -1
    rhs       c6053               -1   c6054               -1
    rhs       c6057               -2   c6058               -2
    rhs       c6063               -2   c6064               -2
    rhs       c6065               -2   c6066                1
    rhs       c6067                1   c6068                1
    rhs       c6069                1   c6070               -1
    rhs       c6071               -1   c6073               -1
    rhs       c6074               -1   c6076               -1
    rhs       c6077               -1   c6080               -2
    rhs       c6081               -2   c6082               -2
    rhs       c6083                1   c6084                1
    rhs       c6085                1   c6086                1
    rhs       c6089               -2   c6091               -2
    rhs       c6092               -2   c6094               -2
    rhs       c6095               -2   c6098               -2
    rhs       c6100               -2   c6101                1
    rhs       c6102               -2   c6103               -2
    rhs       c6104               -2   c6105               -2
    rhs       c6106               -2   c6107               -2
    rhs       c6109               -2   c6110                1
    rhs       c6115               -2   c6116               -2
    rhs       c6117               -2   c6118                1
    rhs       c6119                1   c6120                1
    rhs       c6121                1   c6122               -1
    rhs       c6123               -1   c6125               -1
    rhs       c6126               -1   c6128               -1
    rhs       c6129               -1   c6132               -2
    rhs       c6133               -2   c6134               -2
    rhs       c6135                1   c6136                1
    rhs       c6137                1   c6138                1
    rhs       c6141               -2   c6143               -2
    rhs       c6144               -2   c6146               -2
    rhs       c6147               -2   c6150               -2
    rhs       c6152               -2   c6153                1
    rhs       c6154               -2   c6155               -2
    rhs       c6156               -2   c6157               -2
    rhs       c6158               -2   c6159               -2
    rhs       c6161               -2   c6162                1
    rhs       c6164               -2   c6166               -2
    rhs       c6168               -2   c6170               -2
    rhs       c6171                1   c6175                1
    rhs       c6176                1   c6177               -2
    rhs       c6178               -2   c6179               -2
    rhs       c6180               -2   c6181               -2
    rhs       c6182               -2   c6183               -2
    rhs       c6184               -2   c6185               -2
    rhs       c6186               -2   c6187               -2
    rhs       c6188               -2   c6189               -2
    rhs       c6191               -2   c6192                1
    rhs       c6193                1   c6194               -2
    rhs       c6195               -2   c6196               -2
    rhs       c6197               -2   c6200               -2
    rhs       c6202               -2   c6203                1
    rhs       c6205               -2   c6206                1
    rhs       c6209               -2   c6211               -2
    rhs       c6212               -2   c6213               -1
    rhs       c6214               -1   c6216               -1
    rhs       c6217               -1   c6220               -2
    rhs       c6221               -2   c6224               -2
    rhs       c6226               -2   c6228               -2
    rhs       c6232                1   c6233                1
    rhs       c6234               -2   c6235               -2
    rhs       c6236               -2   c6237               -2
    rhs       c6238               -2   c6239               -2
    rhs       c6240               -2   c6241               -2
    rhs       c6242               -2   c6243               -2
    rhs       c6244               -2   c6245               -2
    rhs       c6246               -2   c6248               -2
    rhs       c6249                1   c6250                1
    rhs       c6251               -2   c6252               -2
    rhs       c6253               -2   c6254               -2
    rhs       c6257               -2   c6259               -2
    rhs       c6260                1   c6262               -2
    rhs       c6263                1   c6266               -2
    rhs       c6268               -2   c6269               -2
    rhs       c6271               -2   c6272               -2
    rhs       c6277               -2   c6278               -2
    rhs       c6279               -2   c6280                1
    rhs       c6281                1   c6282                1
    rhs       c6283                1   c6284               -1
    rhs       c6285               -1   c6287               -1
    rhs       c6288               -1   c6290               -1
    rhs       c6291               -1   c6294               -2
    rhs       c6295               -2   c6296               -2
    rhs       c6297                1   c6298                1
    rhs       c6299                1   c6300                1
    rhs       c6303               -2   c6305               -2
    rhs       c6306               -2   c6308               -2
    rhs       c6309               -2   c6312               -2
    rhs       c6314               -2   c6315                1
    rhs       c6317               -2   c6318                1
    rhs       c6320               -1   c6321               -1
    rhs       c6323               -1   c6324               -1
    rhs       c6326               -1   c6327               -1
    rhs       c6328               -1   c6329               -1
    rhs       c6330               -1   c6331               -1
    rhs       c6333               -1   c6334               -1
    rhs       c6336               -1   c6337               -1
    rhs       c6338               -1   c6339               -1
    rhs       c6340               -1   c6341               -1
    rhs       c6343               -1   c6344               -1
    rhs       c6346               -1   c6347               -1
    rhs       c6348               -1   c6349               -1
    rhs       c6350               -3   c6351               -3
    rhs       c6352               -3   c6353               -3
    rhs       c6354               -3   c6355               -3
    rhs       c6356               -2   c6357               -2
    rhs       c6358               -2   c6359               -2
    rhs       c6360               -2   c6361               -2
    rhs       c6362               -2   c6363               -2
    rhs       c6364               -3   c6365               -3
    rhs       c6366               -3   c6367               -3
    rhs       c6368               -3   c6369               -3
    rhs       c6370               -1   c6371               -1
    rhs       c6373               -1   c6374               -1
    rhs       c6376               -1   c6377               -1
    rhs       c6378               -1   c6379               -1
    rhs       c6381               -3   c6382               -3
    rhs       c6383               -3   c6384               -3
    rhs       c6385               -3   c6386               -3
    rhs       c6387               -2   c6388               -2
    rhs       c6389               -2   c6390               -2
    rhs       c6391               -1   c6392               -1
    rhs       c6394               -1   c6395               -1
    rhs       c6397               -1   c6398               -1
    rhs       c6399               -1   c6400               -1
    rhs       c6401               -3   c6402               -3
    rhs       c6403               -3   c6404               -3
    rhs       c6405               -3   c6406               -3
    rhs       c6407               -2   c6408               -2
    rhs       c6409               -2   c6410               -2
    rhs       c6411                1   c6412               -3
    rhs       c6413               -3   c6414               -3
    rhs       c6415               -3   c6416               -3
    rhs       c6417               -3   c6418               -3
    rhs       c6419               -2   c6420               -2
    rhs       c6421               -2   c6422               -2
    rhs       c6423               -1   c6424               -1
    rhs       c6426               -1   c6427               -1
    rhs       c6429               -1   c6430               -1
    rhs       c6431               -1   c6432               -1
    rhs       c6433               -1   c6434               -1
    rhs       c6436               -1   c6437               -1
    rhs       c6439               -1   c6440               -1
    rhs       c6441               -1   c6442               -1
    rhs       c6443               -1   c6444               -1
    rhs       c6445               -1   c6446               -1
    rhs       c6447               -1   c6448               -1
    rhs       c6449               -1   c6450               -1
    rhs       c6451               -1   c6452               -1
    rhs       c6454               -1   c6455               -1
    rhs       c6457               -1   c6458               -1
    rhs       c6459               -1   c6460               -1
    rhs       c6461               -1   c6462               -1
    rhs       c6464               -1   c6465               -1
    rhs       c6467               -1   c6468               -1
    rhs       c6469               -1   c6470               -1
    rhs       c6471               -1   c6472               -1
    rhs       c6474               -1   c6475               -1
    rhs       c6477               -1   c6478               -1
    rhs       c6479               -1   c6480               -1
    rhs       c6481               -1   c6482               -1
    rhs       c6484               -1   c6485               -1
    rhs       c6487               -1   c6488               -1
    rhs       c6489               -1   c6490               -1
    rhs       c6492               -1   c6493               -1
    rhs       c6495               -1   c6496               -1
    rhs       c6498               -1   c6499               -1
    rhs       c6500               -1   c6501               -1
    rhs       c6502               -3   c6503               -3
    rhs       c6504               -3   c6505               -3
    rhs       c6506               -3   c6507               -3
    rhs       c6508               -2   c6509               -2
    rhs       c6510               -2   c6511               -2
    rhs       c6512               -3   c6513               -3
    rhs       c6514               -3   c6515               -3
    rhs       c6516               -3   c6517               -3
    rhs       c6518               -2   c6519               -2
    rhs       c6520               -2   c6521               -2
    rhs       c6522               -1   c6523               -1
    rhs       c6525               -1   c6526               -1
    rhs       c6528               -1   c6529               -1
    rhs       c6530               -1   c6531               -1
    rhs       c6533               -3   c6534               -3
    rhs       c6535               -3   c6536               -3
    rhs       c6537               -3   c6538               -3
    rhs       c6539               -2   c6540               -2
    rhs       c6541               -2   c6542               -2
    rhs       c6543               -3   c6544               -3
    rhs       c6545               -3   c6546               -3
    rhs       c6547               -3   c6548               -3
    rhs       c6549               -2   c6550               -2
    rhs       c6551               -2   c6552               -2
    rhs       c6553               -1   c6554               -1
    rhs       c6556               -1   c6557               -1
    rhs       c6559               -1   c6560               -1
    rhs       c6561               -1   c6562               -1
    rhs       c6563               -3   c6564               -3
    rhs       c6565               -3   c6566               -3
    rhs       c6567               -3   c6568               -3
    rhs       c6569               -2   c6570               -2
    rhs       c6571               -2   c6572               -2
    rhs       c6573                1   c6574                1
    rhs       c6575               -3   c6576               -3
    rhs       c6577               -1   c6578               -1
    rhs       c6580               -1   c6581               -1
    rhs       c6583               -1   c6584               -1
    rhs       c6585               -1   c6586               -1
    rhs       c6588               -1   c6589               -1
    rhs       c6591               -1   c6592               -1
    rhs       c6594               -1   c6595               -1
    rhs       c6596               -1   c6597               -1
    rhs       c6598               -1   c6599               -1
    rhs       c6601               -1   c6602               -1
    rhs       c6604               -1   c6605               -1
    rhs       c6606               -1   c6607               -1
    rhs       c6608               -3   c6609               -3
    rhs       c6610               -3   c6611               -3
    rhs       c6612               -3   c6613               -3
    rhs       c6614               -2   c6615               -2
    rhs       c6616               -2   c6617               -2
    rhs       c6618               -1   c6619               -1
    rhs       c6621               -1   c6622               -1
    rhs       c6624               -1   c6625               -1
    rhs       c6626               -1   c6627               -1
    rhs       c6629               -1   c6630               -1
    rhs       c6632               -1   c6633               -1
    rhs       c6635               -1   c6636               -1
    rhs       c6637               -1   c6638               -1
    rhs       c6639               -1   c6640               -1
    rhs       c6642               -1   c6643               -1
    rhs       c6645               -1   c6646               -1
    rhs       c6647               -1   c6648               -1
    rhs       c6649               -1   c6650               -1
    rhs       c6652               -1   c6653               -1
    rhs       c6655               -1   c6656               -1
    rhs       c6657               -1   c6658               -1
    rhs       c6660               -1   c6661               -1
    rhs       c6663               -1   c6664               -1
    rhs       c6666               -1   c6667               -1
    rhs       c6668               -1   c6669               -1
    rhs       c6670               -1   c6671               -1
    rhs       c6673               -1   c6674               -1
    rhs       c6676               -1   c6677               -1
    rhs       c6678               -1   c6679               -1
    rhs       c6680               -3   c6681               -3
    rhs       c6682               -3   c6683               -3
    rhs       c6684               -3   c6685               -3
    rhs       c6686               -2   c6687               -2
    rhs       c6688               -2   c6689               -2
    rhs       c6690               -3   c6691               -3
    rhs       c6692               -3   c6693               -3
    rhs       c6694               -3   c6695               -3
    rhs       c6696               -2   c6697               -2
    rhs       c6698               -2   c6699               -2
    rhs       c6701               -1   c6702               -1
    rhs       c6704               -1   c6705               -1
    rhs       c6707               -1   c6708               -1
    rhs       c6709               -1   c6710               -1
    rhs       c6711               -1   c6712               -1
    rhs       c6714               -1   c6715               -1
    rhs       c6717               -1   c6718               -1
    rhs       c6719               -1   c6720               -1
    rhs       c6721               -3   c6722               -3
    rhs       c6723               -3   c6724               -3
    rhs       c6725               -3   c6726               -3
    rhs       c6727               -2   c6728               -2
    rhs       c6729               -2   c6730               -2
    rhs       c6732                1   c6733                1
    rhs       c6737                1   c6738                1
    rhs       c6739                1   c6741                1
    rhs       c6742                1   c6743               -4
    rhs       c6744               -4   c6745               -4
    rhs       c6746               -4   c6747               -4
    rhs       c6748               -4   c6750               -4
    rhs       c6751               -4   c6752                1
    rhs       c6753                1   c6754               -4
    rhs       c6755               -4   c6756               -4
    rhs       c6757               -4   c6758               -4
    rhs       c6759               -4   c6761                1
BOUNDS
 UP bnd       x1                   1
 UP bnd       x2                   1
 UP bnd       x3                   1
 UP bnd       x4                   1
 UP bnd       x5                   1
 UP bnd       x6                   1
 UP bnd       x7                   1
 UP bnd       x8                   1
 UP bnd       x9                   1
 UP bnd       x10                  1
 UP bnd       x11                  1
 UP bnd       x12                  1
 UP bnd       x13                  1
 UP bnd       x14                  1
 UP bnd       x15                  1
 UP bnd       x16                  1
 UP bnd       x17                  1
 UP bnd       x18                  1
 UP bnd       x19                  1
 UP bnd       x20                  1
 UP bnd       x21                  1
 UP bnd       x22                  1
 UP bnd       x23                  1
 UP bnd       x24                  1
 UP bnd       x25                  1
 UP bnd       x26                  1
 UP bnd       x27                  1
 UP bnd       x28                  1
 UP bnd       x29                  1
 UP bnd       x30                  1
 UP bnd       x31                  1
 UP bnd       x32                  1
 UP bnd       x33                  1
 UP bnd       x34                  1
 UP bnd       x35                  1
 UP bnd       x36                  1
 UP bnd       x37                  1
 UP bnd       x38                  1
 UP bnd       x39                  1
 UP bnd       x40                  1
 UP bnd       x41                  1
 UP bnd       x42                  1
 UP bnd       x43                  1
 UP bnd       x44                  1
 UP bnd       x45                  1
 UP bnd       x46                  1
 UP bnd       x47                  1
 UP bnd       x48                  1
 UP bnd       x49                  1
 UP bnd       x50                  1
 UP bnd       x51                  1
 UP bnd       x52                  1
 UP bnd       x53                  1
 UP bnd       x54                  1
 UP bnd       x55                  1
 UP bnd       x56                  1
 UP bnd       x57                  1
 UP bnd       x58                  1
 UP bnd       x59                  1
 UP bnd       x60                  1
 UP bnd       x61                  1
 UP bnd       x62                  1
 UP bnd       x63                  1
 UP bnd       x64                  1
 UP bnd       x65                  1
 UP bnd       x66                  1
 UP bnd       x67                  1
 UP bnd       x68                  1
 UP bnd       x69                  1
 UP bnd       x70                  1
 UP bnd       x71                  1
 UP bnd       x72                  1
 UP bnd       x73                  1
 UP bnd       x74                  1
 UP bnd       x75                  1
 UP bnd       x76                  1
 UP bnd       x77                  1
 UP bnd       x78                  1
 UP bnd       x79                  1
 UP bnd       x80                  1
 UP bnd       x81                  1
 UP bnd       x82                  1
 UP bnd       x83                  1
 UP bnd       x84                  1
 UP bnd       x85                  1
 UP bnd       x86                  1
 UP bnd       x87                  1
 UP bnd       x88                  1
 UP bnd       x89                  1
 UP bnd       x90                  1
 UP bnd       x91                  1
 UP bnd       x92                  1
 UP bnd       x93                  1
 UP bnd       x94                  1
 UP bnd       x95                  1
 UP bnd       x96                  1
 UP bnd       x97                  1
 UP bnd       x98                  1
 UP bnd       x99                  1
 UP bnd       x100                 1
 UP bnd       x101                 1
 UP bnd       x102                 1
 UP bnd       x103                 1
 UP bnd       x104                 1
 UP bnd       x105                 1
 UP bnd       x106                 1
 UP bnd       x107                 1
 UP bnd       x108                 1
 UP bnd       x109                 1
 UP bnd       x110                 1
 UP bnd       x111                 1
 UP bnd       x112                 1
 UP bnd       x113                 1
 UP bnd       x114                 1
 UP bnd       x115                 1
 UP bnd       x116                 1
 UP bnd       x117                 1
 UP bnd       x118                 1
 UP bnd       x119                 1
 UP bnd       x120                 1
 UP bnd       x121                 1
 UP bnd       x122                 1
 UP bnd       x123                 1
 UP bnd       x124                 1
 UP bnd       x125                 1
 UP bnd       x126                 1
 UP bnd       x127                 1
 UP bnd       x128                 1
 UP bnd       x129                 1
 UP bnd       x130                 1
 UP bnd       x131                 1
 UP bnd       x132                 1
 UP bnd       x133                 1
 UP bnd       x134                 1
 UP bnd       x135                 1
 UP bnd       x136                 1
 UP bnd       x137                 1
 UP bnd       x138                 1
 UP bnd       x139                 1
 UP bnd       x140                 1
 UP bnd       x141                 1
 UP bnd       x142                 1
 UP bnd       x143                 1
 UP bnd       x144                 1
 UP bnd       x145                 1
 UP bnd       x146                 1
 UP bnd       x147                 1
 UP bnd       x148                 1
 UP bnd       x149                 1
 UP bnd       x150                 1
 UP bnd       x151                 1
 UP bnd       x152                 1
 UP bnd       x153                 1
 UP bnd       x154                 1
 UP bnd       x155                 1
 UP bnd       x156                 1
 UP bnd       x157                 1
 UP bnd       x158                 1
 UP bnd       x159                 1
 UP bnd       x160                 1
 UP bnd       x161                 1
 UP bnd       x162                 1
 UP bnd       x163                 1
 UP bnd       x164                 1
 UP bnd       x165                 1
 UP bnd       x166                 1
 UP bnd       x167                 1
 UP bnd       x168                 1
 UP bnd       x169                 1
 UP bnd       x170                 1
 UP bnd       x171                 1
 UP bnd       x172                 1
 UP bnd       x173                 1
 UP bnd       x174                 1
 UP bnd       x175                 1
 UP bnd       x176                 1
 UP bnd       x177                 1
 UP bnd       x178                 1
 UP bnd       x179                 1
 UP bnd       x180                 1
 UP bnd       x181                 1
 UP bnd       x182                 1
 UP bnd       x183                 1
 UP bnd       x184                 1
 UP bnd       x185                 1
 UP bnd       x186                 1
 UP bnd       x187                 1
 UP bnd       x188                 1
 UP bnd       x189                 1
 UP bnd       x190                 1
 UP bnd       x191                 1
 UP bnd       x192                 1
 UP bnd       x193                 1
 UP bnd       x194                 1
 UP bnd       x195                 1
 UP bnd       x196                 1
 UP bnd       x197                 1
 UP bnd       x198                 1
 UP bnd       x199                 1
 UP bnd       x200                 1
 UP bnd       x201                 1
 UP bnd       x202                 1
 UP bnd       x203                 1
 UP bnd       x204                 1
 UP bnd       x205                 1
 UP bnd       x206                 1
 UP bnd       x207                 1
 UP bnd       x208                 1
 UP bnd       x209                 1
 UP bnd       x210                 1
 UP bnd       x211                 1
 UP bnd       x212                 1
 UP bnd       x213                 1
 UP bnd       x214                 1
 UP bnd       x215                 1
 UP bnd       x216                 1
 UP bnd       x217                 1
 UP bnd       x218                 1
 UP bnd       x219                 1
 UP bnd       x220                 1
 UP bnd       x221                 1
 UP bnd       x222                 1
 UP bnd       x223                 1
 UP bnd       x224                 1
 UP bnd       x225                 1
 UP bnd       x226                 1
 UP bnd       x227                 1
 UP bnd       x228                 1
 UP bnd       x229                 1
 UP bnd       x230                 1
 UP bnd       x231                 1
 UP bnd       x232                 1
 UP bnd       x233                 1
 UP bnd       x234                 1
 UP bnd       x235                 1
 UP bnd       x236                 1
 UP bnd       x237                 1
 UP bnd       x238                 1
 UP bnd       x239                 1
 UP bnd       x240                 1
 UP bnd       x241                 1
 UP bnd       x242                 1
 UP bnd       x243                 1
 UP bnd       x244                 1
 UP bnd       x245                 1
 UP bnd       x246                 1
 UP bnd       x247                 1
 UP bnd       x248                 1
 UP bnd       x249                 1
 UP bnd       x250                 1
 UP bnd       x251                 1
 UP bnd       x252                 1
 UP bnd       x253                 1
 UP bnd       x254                 1
 UP bnd       x255                 1
 UP bnd       x256                 1
 UP bnd       x257                 1
 UP bnd       x258                 1
 UP bnd       x259                 1
 UP bnd       x260                 1
 UP bnd       x261                 1
 UP bnd       x262                 1
 UP bnd       x263                 1
 UP bnd       x264                 1
 UP bnd       x265                 1
 UP bnd       x266                 1
 UP bnd       x267                 1
 UP bnd       x268                 1
 UP bnd       x269                 1
 UP bnd       x270                 1
 UP bnd       x271                 1
 UP bnd       x272                 1
 UP bnd       x273                 1
 UP bnd       x274                 1
 UP bnd       x275                 1
 UP bnd       x276                 1
 UP bnd       x277                 1
 UP bnd       x278                 1
 UP bnd       x279                 1
 UP bnd       x280                 1
 UP bnd       x281                 1
 UP bnd       x282                 1
 UP bnd       x283                 1
 UP bnd       x284                 1
 UP bnd       x285                 1
 UP bnd       x286                 1
 UP bnd       x287                 1
 UP bnd       x288                 1
 UP bnd       x289                 1
 UP bnd       x290                 1
 UP bnd       x291                 1
 UP bnd       x292                 1
 UP bnd       x293                 1
 UP bnd       x294                 1
 UP bnd       x295                 1
 UP bnd       x296                 1
 UP bnd       x297                 1
 UP bnd       x298                 1
 UP bnd       x299                 1
 UP bnd       x300                 1
 UP bnd       x301                 1
 UP bnd       x302                 1
 UP bnd       x303                 1
 UP bnd       x304                 1
 UP bnd       x305                 1
 UP bnd       x306                 1
 UP bnd       x307                 1
 UP bnd       x308                 1
 UP bnd       x309                 1
 UP bnd       x310                 1
 UP bnd       x311                 1
 UP bnd       x312                 1
 UP bnd       x313                 1
 UP bnd       x314                 1
 UP bnd       x315                 1
 UP bnd       x316                 1
 UP bnd       x317                 1
 UP bnd       x318                 1
 UP bnd       x319                 1
 UP bnd       x320                 1
 UP bnd       x321                 1
 UP bnd       x322                 1
 UP bnd       x323                 1
 UP bnd       x324                 1
 UP bnd       x325                 1
 UP bnd       x326                 1
 UP bnd       x327                 1
 UP bnd       x328                 1
 UP bnd       x329                 1
 UP bnd       x330                 1
 UP bnd       x331                 1
 UP bnd       x332                 1
 UP bnd       x333                 1
 UP bnd       x334                 1
 UP bnd       x335                 1
 UP bnd       x336                 1
 UP bnd       x337                 1
 UP bnd       x338                 1
 UP bnd       x339                 1
 UP bnd       x340                 1
 UP bnd       x341                 1
 UP bnd       x342                 1
 UP bnd       x343                 1
 UP bnd       x344                 1
 UP bnd       x345                 1
 UP bnd       x346                 1
 UP bnd       x347                 1
 UP bnd       x348                 1
 UP bnd       x349                 1
 UP bnd       x350                 1
 UP bnd       x351                 1
 UP bnd       x352                 1
 UP bnd       x353                 1
 UP bnd       x354                 1
 UP bnd       x355                 1
 UP bnd       x356                 1
 UP bnd       x357                 1
 UP bnd       x358                 1
 UP bnd       x359                 1
 UP bnd       x360                 1
 UP bnd       x361                 1
 UP bnd       x362                 1
 UP bnd       x363                 1
 UP bnd       x364                 1
 UP bnd       x365                 1
 UP bnd       x366                 1
 UP bnd       x367                 1
 UP bnd       x368                 1
 UP bnd       x369                 1
 UP bnd       x370                 1
 UP bnd       x371                 1
 UP bnd       x372                 1
 UP bnd       x373                 1
 UP bnd       x374                 1
 UP bnd       x375                 1
 UP bnd       x376                 1
 UP bnd       x377                 1
 UP bnd       x378                 1
 UP bnd       x379                 1
 UP bnd       x380                 1
 UP bnd       x381                 1
 UP bnd       x382                 1
 UP bnd       x383                 1
 UP bnd       x384                 1
 UP bnd       x385                 1
 UP bnd       x386                 1
 UP bnd       x387                 1
 UP bnd       x388                 1
 UP bnd       x389                 1
 UP bnd       x390                 1
 UP bnd       x391                 1
 UP bnd       x392                 1
 UP bnd       x393                 1
 UP bnd       x394                 1
 UP bnd       x395                 1
 UP bnd       x396                 1
 UP bnd       x397                 1
 UP bnd       x398                 1
 UP bnd       x399                 1
 UP bnd       x400                 1
 UP bnd       x401                 1
 UP bnd       x402                 1
 UP bnd       x403                 1
 UP bnd       x404                 1
 UP bnd       x405                 1
 UP bnd       x406                 1
 UP bnd       x407                 1
 UP bnd       x408                 1
 UP bnd       x409                 1
 UP bnd       x410                 1
 UP bnd       x411                 1
 UP bnd       x412                 1
 UP bnd       x413                 1
 UP bnd       x414                 1
 UP bnd       x415                 1
 UP bnd       x416                 1
 UP bnd       x417                 1
 UP bnd       x418                 1
 UP bnd       x419                 1
 UP bnd       x420                 1
 UP bnd       x421                 1
 UP bnd       x422                 1
 UP bnd       x423                 1
 UP bnd       x424                 1
 UP bnd       x425                 1
 UP bnd       x426                 1
 UP bnd       x427                 1
 UP bnd       x428                 1
 UP bnd       x429                 1
 UP bnd       x430                 1
 UP bnd       x431                 1
 UP bnd       x432                 1
 UP bnd       x433                 1
 UP bnd       x434                 1
 UP bnd       x435                 1
 UP bnd       x436                 1
 UP bnd       x437                 1
 UP bnd       x438                 1
 UP bnd       x439                 1
 UP bnd       x440                 1
 UP bnd       x441                 1
 UP bnd       x442                 1
 UP bnd       x443                 1
 UP bnd       x444                 1
 UP bnd       x445                 1
 UP bnd       x446                 1
 UP bnd       x447                 1
 UP bnd       x448                 1
 UP bnd       x449                 1
 UP bnd       x450                 1
 UP bnd       x451                 1
 UP bnd       x452                 1
 UP bnd       x453                 1
 UP bnd       x454                 1
 UP bnd       x455                 1
 UP bnd       x456                 1
 UP bnd       x457                 1
 UP bnd       x458                 1
 UP bnd       x459                 1
 UP bnd       x460                 1
 UP bnd       x461                 1
 UP bnd       x462                 1
 UP bnd       x463                 1
 UP bnd       x464                 1
 UP bnd       x465                 1
 UP bnd       x466                 1
 UP bnd       x467                 1
 UP bnd       x468                 1
 UP bnd       x469                 1
 UP bnd       x470                 1
 UP bnd       x471                 1
 UP bnd       x472                 1
 UP bnd       x473                 1
 UP bnd       x474                 1
 UP bnd       x475                 1
 UP bnd       x476                 1
 UP bnd       x477                 1
 UP bnd       x478                 1
 UP bnd       x479                 1
 UP bnd       x480                 1
 UP bnd       x481                 1
 UP bnd       x482                 1
 UP bnd       x483                 1
 UP bnd       x484                 1
 UP bnd       x485                 1
 UP bnd       x486                 1
 UP bnd       x487                 1
 UP bnd       x488                 1
 UP bnd       x489                 1
 UP bnd       x490                 1
 UP bnd       x491                 1
 UP bnd       x492                 1
 UP bnd       x493                 1
 UP bnd       x494                 1
 UP bnd       x495                 1
 UP bnd       x496                 1
 UP bnd       x497                 1
 UP bnd       x498                 1
 UP bnd       x499                 1
 UP bnd       x500                 1
 UP bnd       x501                 1
 UP bnd       x502                 1
 UP bnd       x503                 1
 UP bnd       x504                 1
 UP bnd       x505                 1
 UP bnd       x506                 1
 UP bnd       x507                 1
 UP bnd       x508                 1
 UP bnd       x509                 1
 UP bnd       x510                 1
 UP bnd       x511                 1
 UP bnd       x512                 1
 UP bnd       x513                 1
 UP bnd       x514                 1
 UP bnd       x515                 1
 UP bnd       x516                 1
 UP bnd       x517                 1
 UP bnd       x518                 1
 UP bnd       x519                 1
 UP bnd       x520                 1
 UP bnd       x521                 1
 UP bnd       x522                 1
 UP bnd       x523                 1
 UP bnd       x524                 1
 UP bnd       x525                 1
 UP bnd       x526                 1
 UP bnd       x527                 1
 UP bnd       x528                 1
 UP bnd       x529                 1
 UP bnd       x530                 1
 UP bnd       x531                 1
 UP bnd       x532                 1
 UP bnd       x533                 1
 UP bnd       x534                 1
 UP bnd       x535                 1
 UP bnd       x536                 1
 UP bnd       x537                 1
 UP bnd       x538                 1
 UP bnd       x539                 1
 UP bnd       x540                 1
 UP bnd       x541                 1
 UP bnd       x542                 1
 UP bnd       x543                 1
 UP bnd       x544                 1
 UP bnd       x545                 1
 UP bnd       x546                 1
 UP bnd       x547                 1
 UP bnd       x548                 1
 UP bnd       x549                 1
 UP bnd       x550                 1
 UP bnd       x551                 1
 UP bnd       x552                 1
 UP bnd       x553                 1
 UP bnd       x554                 1
 UP bnd       x555                 1
 UP bnd       x556                 1
 UP bnd       x557                 1
 UP bnd       x558                 1
 UP bnd       x559                 1
 UP bnd       x560                 1
 UP bnd       x561                 1
 UP bnd       x562                 1
 UP bnd       x563                 1
 UP bnd       x564                 1
 UP bnd       x565                 1
 UP bnd       x566                 1
 UP bnd       x567                 1
 UP bnd       x568                 1
 UP bnd       x569                 1
 UP bnd       x570                 1
 UP bnd       x571                 1
 UP bnd       x572                 1
 UP bnd       x573                 1
 UP bnd       x574                 1
 UP bnd       x575                 1
 UP bnd       x576                 1
 UP bnd       x577                 1
 UP bnd       x578                 1
 UP bnd       x579                 1
 UP bnd       x580                 1
 UP bnd       x581                 1
 UP bnd       x582                 1
 UP bnd       x583                 1
 UP bnd       x584                 1
 UP bnd       x585                 1
 UP bnd       x586                 1
 UP bnd       x587                 1
 UP bnd       x588                 1
 UP bnd       x589                 1
 UP bnd       x590                 1
 UP bnd       x591                 1
 UP bnd       x592                 1
 UP bnd       x593                 1
 UP bnd       x594                 1
 UP bnd       x595                 1
 UP bnd       x596                 1
 UP bnd       x597                 1
 UP bnd       x598                 1
 UP bnd       x599                 1
 UP bnd       x600                 1
 UP bnd       x601                 1
 UP bnd       x602                 1
 UP bnd       x603                 1
 UP bnd       x604                 1
 UP bnd       x605                 1
 UP bnd       x606                 1
 UP bnd       x607                 1
 UP bnd       x608                 1
 UP bnd       x609                 1
 UP bnd       x610                 1
 UP bnd       x611                 1
 UP bnd       x612                 1
 UP bnd       x613                 1
 UP bnd       x614                 1
 UP bnd       x615                 1
 UP bnd       x616                 1
 UP bnd       x617                 1
 UP bnd       x618                 1
 UP bnd       x619                 1
 UP bnd       x620                 1
 UP bnd       x621                 1
 UP bnd       x622                 1
 UP bnd       x623                 1
 UP bnd       x624                 1
 UP bnd       x625                 1
 UP bnd       x626                 1
 UP bnd       x627                 1
 UP bnd       x628                 1
 UP bnd       x629                 1
 UP bnd       x630                 1
 UP bnd       x631                 1
 UP bnd       x632                 1
 UP bnd       x633                 1
 UP bnd       x634                 1
 UP bnd       x635                 1
 UP bnd       x636                 1
 UP bnd       x637                 1
 UP bnd       x638                 1
 UP bnd       x639                 1
 UP bnd       x640                 1
 UP bnd       x641                 1
 UP bnd       x642                 1
 UP bnd       x643                 1
 UP bnd       x644                 1
 UP bnd       x645                 1
 UP bnd       x646                 1
 UP bnd       x647                 1
 UP bnd       x648                 1
 UP bnd       x649                 1
 UP bnd       x650                 1
 UP bnd       x651                 1
 UP bnd       x652                 1
 UP bnd       x653                 1
 UP bnd       x654                 1
 UP bnd       x655                 1
 UP bnd       x656                 1
 UP bnd       x657                 1
 UP bnd       x658                 1
 UP bnd       x659                 1
 UP bnd       x660                 1
 UP bnd       x661                 1
 UP bnd       x662                 1
 UP bnd       x663                 1
 UP bnd       x664                 1
 UP bnd       x665                 1
 UP bnd       x666                 1
 UP bnd       x667                 1
 UP bnd       x668                 1
 UP bnd       x669                 1
 UP bnd       x670                 1
 UP bnd       x671                 1
 UP bnd       x672                 1
 UP bnd       x673                 1
 UP bnd       x674                 1
 UP bnd       x675                 1
 UP bnd       x676                 1
 UP bnd       x677                 1
 UP bnd       x678                 1
 UP bnd       x679                 1
 UP bnd       x680                 1
 UP bnd       x681                 1
 UP bnd       x682                 1
 UP bnd       x683                 1
 UP bnd       x684                 1
 UP bnd       x685                 1
 UP bnd       x686                 1
 UP bnd       x687                 1
 UP bnd       x688                 1
 UP bnd       x689                 1
 UP bnd       x690                 1
 UP bnd       x691                 1
 UP bnd       x692                 1
 UP bnd       x693                 1
 UP bnd       x694                 1
 UP bnd       x695                 1
 UP bnd       x696                 1
 UP bnd       x697                 1
 UP bnd       x698                 1
 UP bnd       x699                 1
 UP bnd       x700                 1
 UP bnd       x701                 1
 UP bnd       x702                 1
 UP bnd       x703                 1
 UP bnd       x704                 1
 UP bnd       x705                 1
 UP bnd       x706                 1
 UP bnd       x707                 1
 UP bnd       x708                 1
 UP bnd       x709                 1
 UP bnd       x710                 1
 UP bnd       x711                 1
 UP bnd       x712                 1
 UP bnd       x713                 1
 UP bnd       x714                 1
 UP bnd       x715                 1
 UP bnd       x716                 1
 UP bnd       x717                 1
 UP bnd       x718                 1
 UP bnd       x719                 1
 UP bnd       x720                 1
 UP bnd       x721                 1
 UP bnd       x722                 1
 UP bnd       x723                 1
 UP bnd       x724                 1
 UP bnd       x725                 1
 UP bnd       x726                 1
 UP bnd       x727                 1
 UP bnd       x728                 1
 UP bnd       x729                 1
 UP bnd       x730                 1
 UP bnd       x731                 1
 UP bnd       x732                 1
 UP bnd       x733                 1
 UP bnd       x734                 1
 UP bnd       x735                 1
 UP bnd       x736                 1
 UP bnd       x737                 1
 UP bnd       x738                 1
 UP bnd       x739                 1
 UP bnd       x740                 1
 UP bnd       x741                 1
 UP bnd       x742                 1
 UP bnd       x743                 1
 UP bnd       x744                 1
 UP bnd       x745                 1
 UP bnd       x746                 1
 UP bnd       x747                 1
 UP bnd       x748                 1
 UP bnd       x749                 1
 UP bnd       x750                 1
 UP bnd       x751                 1
 UP bnd       x752                 1
 UP bnd       x753                 1
 UP bnd       x754                 1
 UP bnd       x755                 1
 UP bnd       x756                 1
 UP bnd       x757                 1
 UP bnd       x758                 1
 UP bnd       x759                 1
 UP bnd       x760                 1
 UP bnd       x761                 1
 UP bnd       x762                 1
 UP bnd       x763                 1
 UP bnd       x764                 1
 UP bnd       x765                 1
 UP bnd       x766                 1
 UP bnd       x767                 1
 UP bnd       x768                 1
 UP bnd       x769                 1
 UP bnd       x770                 1
 UP bnd       x771                 1
 UP bnd       x772                 1
 UP bnd       x773                 1
 UP bnd       x774                 1
 UP bnd       x775                 1
 UP bnd       x776                 1
 UP bnd       x777                 1
 UP bnd       x778                 1
 UP bnd       x779                 1
 UP bnd       x780                 1
 UP bnd       x781                 1
 UP bnd       x782                 1
 UP bnd       x783                 1
 UP bnd       x784                 1
 UP bnd       x785                 1
 UP bnd       x786                 1
 UP bnd       x787                 1
 UP bnd       x788                 1
 UP bnd       x789                 1
 UP bnd       x790                 1
 UP bnd       x791                 1
 UP bnd       x792                 1
 UP bnd       x793                 1
 UP bnd       x794                 1
 UP bnd       x795                 1
 UP bnd       x796                 1
 UP bnd       x797                 1
 UP bnd       x798                 1
 UP bnd       x799                 1
 UP bnd       x800                 1
 UP bnd       x801                 1
 UP bnd       x802                 1
 UP bnd       x803                 1
 UP bnd       x804                 1
 UP bnd       x805                 1
 UP bnd       x806                 1
 UP bnd       x807                 1
 UP bnd       x808                 1
 UP bnd       x809                 1
 UP bnd       x810                 1
 UP bnd       x811                 1
 UP bnd       x812                 1
 UP bnd       x813                 1
 UP bnd       x814                 1
 UP bnd       x815                 1
 UP bnd       x816                 1
 UP bnd       x817                 1
 UP bnd       x818                 1
 UP bnd       x819                 1
 UP bnd       x820                 1
 UP bnd       x821                 1
 UP bnd       x822                 1
 UP bnd       x823                 1
 UP bnd       x824                 1
 UP bnd       x825                 1
 UP bnd       x826                 1
 UP bnd       x827                 1
 UP bnd       x828                 1
 UP bnd       x829                 1
 UP bnd       x830                 1
 UP bnd       x831                 1
 UP bnd       x832                 1
 UP bnd       x833                 1
 UP bnd       x834                 1
 UP bnd       x835                 1
 UP bnd       x836                 1
 UP bnd       x837                 1
 UP bnd       x838                 1
 UP bnd       x839                 1
 UP bnd       x840                 1
 UP bnd       x841                 1
 UP bnd       x842                 1
 UP bnd       x843                 1
 UP bnd       x844                 1
 UP bnd       x845                 1
 UP bnd       x846                 1
 UP bnd       x847                 1
 UP bnd       x848                 1
 UP bnd       x849                 1
 UP bnd       x850                 1
 UP bnd       x851                 1
 UP bnd       x852                 1
 UP bnd       x853                 1
 UP bnd       x854                 1
 UP bnd       x855                 1
 UP bnd       x856                 1
 UP bnd       x857                 1
 UP bnd       x858                 1
 UP bnd       x859                 1
 UP bnd       x860                 1
 UP bnd       x861                 1
 UP bnd       x862                 1
 UP bnd       x863                 1
 UP bnd       x864                 1
 UP bnd       x865                 1
 UP bnd       x866                 1
 UP bnd       x867                 1
 UP bnd       x868                 1
 UP bnd       x869                 1
 UP bnd       x870                 1
 UP bnd       x871                 1
 UP bnd       x872                 1
 UP bnd       x873                 1
 UP bnd       x874                 1
 UP bnd       x875                 1
 UP bnd       x876                 1
 UP bnd       x877                 1
 UP bnd       x878                 1
 UP bnd       x879                 1
 UP bnd       x880                 1
 UP bnd       x881                 1
 UP bnd       x882                 1
 UP bnd       x883                 1
 UP bnd       x884                 1
 UP bnd       x885                 1
 UP bnd       x886                 1
 UP bnd       x887                 1
 UP bnd       x888                 1
 UP bnd       x889                 1
 UP bnd       x890                 1
 UP bnd       x891                 1
 UP bnd       x892                 1
 UP bnd       x893                 1
 UP bnd       x894                 1
 UP bnd       x895                 1
 UP bnd       x896                 1
 UP bnd       x897                 1
 UP bnd       x898                 1
 UP bnd       x899                 1
 UP bnd       x900                 1
 UP bnd       x901                 1
 UP bnd       x902                 1
 UP bnd       x903                 1
 UP bnd       x904                 1
 UP bnd       x905                 1
 UP bnd       x906                 1
 UP bnd       x907                 1
 UP bnd       x908                 1
 UP bnd       x909                 1
 UP bnd       x910                 1
 UP bnd       x911                 1
 UP bnd       x912                 1
 UP bnd       x913                 1
 UP bnd       x914                 1
 UP bnd       x915                 1
 UP bnd       x916                 1
 UP bnd       x917                 1
 UP bnd       x918                 1
 UP bnd       x919                 1
 UP bnd       x920                 1
 UP bnd       x921                 1
 UP bnd       x922                 1
 UP bnd       x923                 1
 UP bnd       x924                 1
 UP bnd       x925                 1
 UP bnd       x926                 1
 UP bnd       x927                 1
 UP bnd       x928                 1
 UP bnd       x929                 1
 UP bnd       x930                 1
 UP bnd       x931                 1
 UP bnd       x932                 1
 UP bnd       x933                 1
 UP bnd       x934                 1
 UP bnd       x935                 1
 UP bnd       x936                 1
 UP bnd       x937                 1
 UP bnd       x938                 1
 UP bnd       x939                 1
 UP bnd       x940                 1
 UP bnd       x941                 1
 UP bnd       x942                 1
 UP bnd       x943                 1
 UP bnd       x944                 1
 UP bnd       x945                 1
 UP bnd       x946                 1
 UP bnd       x947                 1
 UP bnd       x948                 1
 UP bnd       x949                 1
 UP bnd       x950                 1
 UP bnd       x951                 1
 UP bnd       x952                 1
 UP bnd       x953                 1
 UP bnd       x954                 1
 UP bnd       x955                 1
 UP bnd       x956                 1
 UP bnd       x957                 1
 UP bnd       x958                 1
 UP bnd       x959                 1
 UP bnd       x960                 1
 UP bnd       x961                 1
 UP bnd       x962                 1
 UP bnd       x963                 1
 UP bnd       x964                 1
 UP bnd       x965                 1
 UP bnd       x966                 1
 UP bnd       x967                 1
 UP bnd       x968                 1
 UP bnd       x969                 1
 UP bnd       x970                 1
 UP bnd       x971                 1
 UP bnd       x972                 1
 UP bnd       x973                 1
 UP bnd       x974                 1
 UP bnd       x975                 1
 UP bnd       x976                 1
 UP bnd       x977                 1
 UP bnd       x978                 1
 UP bnd       x979                 1
 UP bnd       x980                 1
 UP bnd       x981                 1
 UP bnd       x982                 1
 UP bnd       x983                 1
 UP bnd       x984                 1
 UP bnd       x985                 1
 UP bnd       x986                 1
 UP bnd       x987                 1
 UP bnd       x988                 1
 UP bnd       x989                 1
 UP bnd       x990                 1
 UP bnd       x991                 1
 UP bnd       x992                 1
 UP bnd       x993                 1
 UP bnd       x994                 1
 UP bnd       x995                 1
 UP bnd       x996                 1
 UP bnd       x997                 1
 UP bnd       x998                 1
 UP bnd       x999                 1
 UP bnd       x1000                1
 UP bnd       x1001                1
 UP bnd       x1002                1
 UP bnd       x1003                1
 UP bnd       x1004                1
 UP bnd       x1005                1
 UP bnd       x1006                1
 UP bnd       x1007                1
 UP bnd       x1008                1
 UP bnd       x1009                1
 UP bnd       x1010                1
 UP bnd       x1011                1
 UP bnd       x1012                1
 UP bnd       x1013                1
 UP bnd       x1014                1
 UP bnd       x1015                1
 UP bnd       x1016                1
 UP bnd       x1017                1
 UP bnd       x1018                1
 UP bnd       x1019                1
 UP bnd       x1020                1
 UP bnd       x1021                1
 UP bnd       x1022                1
 UP bnd       x1023                1
 UP bnd       x1024                1
 UP bnd       x1025                1
 UP bnd       x1026                1
 UP bnd       x1027                1
 UP bnd       x1028                1
 UP bnd       x1029                1
 UP bnd       x1030                1
 UP bnd       x1031                1
 UP bnd       x1032                1
 UP bnd       x1033                1
 UP bnd       x1034                1
 UP bnd       x1035                1
 UP bnd       x1036                1
 UP bnd       x1037                1
 UP bnd       x1038                1
 UP bnd       x1039                1
 UP bnd       x1040                1
 UP bnd       x1041                1
 UP bnd       x1042                1
 UP bnd       x1043                1
 UP bnd       x1044                1
 UP bnd       x1045                1
 UP bnd       x1046                1
 UP bnd       x1047                1
 UP bnd       x1048                1
 UP bnd       x1049                1
 UP bnd       x1050                1
 UP bnd       x1051                1
 UP bnd       x1052                1
 UP bnd       x1053                1
 UP bnd       x1054                1
 UP bnd       x1055                1
 UP bnd       x1056                1
 UP bnd       x1057                1
 UP bnd       x1058                1
 UP bnd       x1059                1
 UP bnd       x1060                1
 UP bnd       x1061                1
 UP bnd       x1062                1
 UP bnd       x1063                1
 UP bnd       x1064                1
 UP bnd       x1065                1
 UP bnd       x1066                1
 UP bnd       x1067                1
 UP bnd       x1068                1
 UP bnd       x1069                1
 UP bnd       x1070                1
 UP bnd       x1071                1
 UP bnd       x1072                1
 UP bnd       x1073                1
 UP bnd       x1074                1
 UP bnd       x1075                1
 UP bnd       x1076                1
 UP bnd       x1077                1
 UP bnd       x1078                1
 UP bnd       x1079                1
 UP bnd       x1080                1
 UP bnd       x1081                1
 UP bnd       x1082                1
 UP bnd       x1083                1
 UP bnd       x1084                1
 UP bnd       x1085                1
 UP bnd       x1086                1
 UP bnd       x1087                1
 UP bnd       x1088                1
 UP bnd       x1089                1
 UP bnd       x1090                1
 UP bnd       x1091                1
 UP bnd       x1092                1
 UP bnd       x1093                1
 UP bnd       x1094                1
 UP bnd       x1095                1
 UP bnd       x1096                1
 UP bnd       x1097                1
 UP bnd       x1098                1
 UP bnd       x1099                1
 UP bnd       x1100                1
 UP bnd       x1101                1
 UP bnd       x1102                1
 UP bnd       x1103                1
 UP bnd       x1104                1
 UP bnd       x1105                1
 UP bnd       x1106                1
 UP bnd       x1107                1
 UP bnd       x1108                1
 UP bnd       x1109                1
 UP bnd       x1110                1
 UP bnd       x1111                1
 UP bnd       x1112                1
 UP bnd       x1113                1
 UP bnd       x1114                1
 UP bnd       x1115                1
 UP bnd       x1116                1
 UP bnd       x1117                1
 UP bnd       x1118                1
 UP bnd       x1119                1
 UP bnd       x1120                1
 UP bnd       x1121                1
 UP bnd       x1122                1
 UP bnd       x1123                1
 UP bnd       x1124                1
 UP bnd       x1125                1
 UP bnd       x1126                1
 UP bnd       x1127                1
 UP bnd       x1128                1
 UP bnd       x1129                1
 UP bnd       x1130                1
 UP bnd       x1131                1
 UP bnd       x1132                1
 UP bnd       x1133                1
 UP bnd       x1134                1
 UP bnd       x1135                1
 UP bnd       x1136                1
 UP bnd       x1137                1
 UP bnd       x1138                1
 UP bnd       x1139                1
 UP bnd       x1140                1
 UP bnd       x1141                1
 UP bnd       x1142                1
 UP bnd       x1143                1
 UP bnd       x1144                1
 UP bnd       x1145                1
 UP bnd       x1146                1
 UP bnd       x1147                1
 UP bnd       x1148                1
 UP bnd       x1149                1
 UP bnd       x1150                1
 UP bnd       x1151                1
 UP bnd       x1152                1
 UP bnd       x1153                1
 UP bnd       x1154                1
 UP bnd       x1155                1
 UP bnd       x1156                1
 UP bnd       x1157                1
 UP bnd       x1158                1
 UP bnd       x1159                1
 UP bnd       x1160                1
 UP bnd       x1161                1
 UP bnd       x1162                1
 UP bnd       x1163                1
 UP bnd       x1164                1
 UP bnd       x1165                1
 UP bnd       x1166                1
 UP bnd       x1167                1
 UP bnd       x1168                1
 UP bnd       x1169                1
 UP bnd       x1170                1
 UP bnd       x1171                1
 UP bnd       x1172                1
 UP bnd       x1173                1
 UP bnd       x1174                1
 UP bnd       x1175                1
 UP bnd       x1176                1
 UP bnd       x1177                1
 UP bnd       x1178                1
 UP bnd       x1179                1
 UP bnd       x1180                1
 UP bnd       x1181                1
 UP bnd       x1182                1
 UP bnd       x1183                1
 UP bnd       x1184                1
 UP bnd       x1185                1
 UP bnd       x1186                1
 UP bnd       x1187                1
 UP bnd       x1188                1
 UP bnd       x1189                1
 UP bnd       x1190                1
 UP bnd       x1191                1
 UP bnd       x1192                1
 UP bnd       x1193                1
 UP bnd       x1194                1
 UP bnd       x1195                1
 UP bnd       x1196                1
 UP bnd       x1197                1
 UP bnd       x1198                1
 UP bnd       x1199                1
 UP bnd       x1200                1
 UP bnd       x1201                1
 UP bnd       x1202                1
 UP bnd       x1203                1
 UP bnd       x1204                1
 UP bnd       x1205                1
 UP bnd       x1206                1
 UP bnd       x1207                1
 UP bnd       x1208                1
 UP bnd       x1209                1
 UP bnd       x1210                1
 UP bnd       x1211                1
 UP bnd       x1212                1
 UP bnd       x1213                1
 UP bnd       x1214                1
 UP bnd       x1215                1
 UP bnd       x1216                1
 UP bnd       x1217                1
 UP bnd       x1218                1
 UP bnd       x1219                1
 UP bnd       x1220                1
 UP bnd       x1221                1
 UP bnd       x1222                1
 UP bnd       x1223                1
 UP bnd       x1224                1
 UP bnd       x1225                1
 UP bnd       x1226                1
 UP bnd       x1227                1
 UP bnd       x1228                1
 UP bnd       x1229                1
 UP bnd       x1230                1
 UP bnd       x1231                1
 UP bnd       x1232                1
 UP bnd       x1233                1
 UP bnd       x1234                1
 UP bnd       x1235                1
 UP bnd       x1236                1
 UP bnd       x1237                1
 UP bnd       x1238                1
 UP bnd       x1239                1
 UP bnd       x1240                1
 UP bnd       x1241                1
 UP bnd       x1242                1
 UP bnd       x1243                1
 UP bnd       x1244                1
 UP bnd       x1245                1
 UP bnd       x1246                1
 UP bnd       x1247                1
 UP bnd       x1248                1
 UP bnd       x1249                1
 UP bnd       x1250                1
 UP bnd       x1251                1
 UP bnd       x1252                1
 UP bnd       x1253                1
 UP bnd       x1254                1
 UP bnd       x1255                1
 UP bnd       x1256                1
 UP bnd       x1257                1
 UP bnd       x1258                1
 UP bnd       x1259                1
 UP bnd       x1260                1
 UP bnd       x1261                1
 UP bnd       x1262                1
 UP bnd       x1263                1
 UP bnd       x1264                1
 UP bnd       x1265                1
 UP bnd       x1266                1
 UP bnd       x1267                1
 UP bnd       x1268                1
 UP bnd       x1269                1
 UP bnd       x1270                1
 UP bnd       x1271                1
 UP bnd       x1272                1
 UP bnd       x1273                1
 UP bnd       x1274                1
 UP bnd       x1275                1
 UP bnd       x1276                1
 UP bnd       x1277                1
 UP bnd       x1278                1
 UP bnd       x1279                1
 UP bnd       x1280                1
 UP bnd       x1281                1
 UP bnd       x1282                1
 UP bnd       x1283                1
 UP bnd       x1284                1
 UP bnd       x1285                1
 UP bnd       x1286                1
 UP bnd       x1287                1
 UP bnd       x1288                1
 UP bnd       x1289                1
 UP bnd       x1290                1
 UP bnd       x1291                1
 UP bnd       x1292                1
 UP bnd       x1293                1
 UP bnd       x1294                1
 UP bnd       x1295                1
 UP bnd       x1296                1
 UP bnd       x1297                1
 UP bnd       x1298                1
 UP bnd       x1299                1
 UP bnd       x1300                1
 UP bnd       x1301                1
 UP bnd       x1302                1
 UP bnd       x1303                1
 UP bnd       x1304                1
 UP bnd       x1305                1
 UP bnd       x1306                1
 UP bnd       x1307                1
 UP bnd       x1308                1
 UP bnd       x1309                1
 UP bnd       x1310                1
 UP bnd       x1311                1
 UP bnd       x1312                1
 UP bnd       x1313                1
 UP bnd       x1314                1
 UP bnd       x1315                1
 UP bnd       x1316                1
 UP bnd       x1317                1
 UP bnd       x1318                1
 UP bnd       x1319                1
 UP bnd       x1320                1
 UP bnd       x1321                1
 UP bnd       x1322                1
 UP bnd       x1323                1
 UP bnd       x1324                1
 UP bnd       x1325                1
 UP bnd       x1326                1
 UP bnd       x1327                1
 UP bnd       x1328                1
 UP bnd       x1329                1
 UP bnd       x1330                1
 UP bnd       x1331                1
 UP bnd       x1332                1
 UP bnd       x1333                1
 UP bnd       x1334                1
 UP bnd       x1335                1
 UP bnd       x1336                1
 UP bnd       x1337                1
 UP bnd       x1338                1
 UP bnd       x1339                1
 UP bnd       x1340                1
 UP bnd       x1341                1
 UP bnd       x1342                1
 UP bnd       x1343                1
 UP bnd       x1344                1
 UP bnd       x1345                1
 UP bnd       x1346                1
 UP bnd       x1347                1
 UP bnd       x1348                1
 UP bnd       x1349                1
 UP bnd       x1350                1
 UP bnd       x1351                1
 UP bnd       x1352                1
 UP bnd       x1353                1
 UP bnd       x1354                1
 UP bnd       x1355                1
 UP bnd       x1356                1
 UP bnd       x1357                1
 UP bnd       x1358                1
 UP bnd       x1359                1
 UP bnd       x1360                1
 UP bnd       x1361                1
 UP bnd       x1362                1
 UP bnd       x1363                1
 UP bnd       x1364                1
 UP bnd       x1365                1
 UP bnd       x1366                1
 UP bnd       x1367                1
 UP bnd       x1368                1
 UP bnd       x1369                1
 UP bnd       x1370                1
 UP bnd       x1371                1
 UP bnd       x1372                1
 UP bnd       x1373                1
 UP bnd       x1374                1
 UP bnd       x1375                1
 UP bnd       x1376                1
 UP bnd       x1377                1
 UP bnd       x1378                1
 UP bnd       x1379                1
 UP bnd       x1380                1
 UP bnd       x1381                1
 UP bnd       x1382                1
 UP bnd       x1383                1
 UP bnd       x1384                1
 UP bnd       x1385                1
 UP bnd       x1386                1
 UP bnd       x1387                1
 UP bnd       x1388                1
 UP bnd       x1389                1
 UP bnd       x1390                1
 UP bnd       x1391                1
 UP bnd       x1392                1
 UP bnd       x1393                1
 UP bnd       x1394                1
 UP bnd       x1395                1
 UP bnd       x1396                1
 UP bnd       x1397                1
 UP bnd       x1398                1
 UP bnd       x1399                1
 UP bnd       x1400                1
 UP bnd       x1401                1
 UP bnd       x1402                1
 UP bnd       x1403                1
 UP bnd       x1404                1
 UP bnd       x1405                1
 UP bnd       x1406                1
 UP bnd       x1407                1
 UP bnd       x1408                1
 UP bnd       x1409                1
 UP bnd       x1410                1
 UP bnd       x1411                1
 UP bnd       x1412                1
 UP bnd       x1413                1
 UP bnd       x1414                1
 UP bnd       x1415                1
 UP bnd       x1416                1
 UP bnd       x1417                1
 UP bnd       x1418                1
 UP bnd       x1419                1
 UP bnd       x1420                1
 UP bnd       x1421                1
 UP bnd       x1422                1
 UP bnd       x1423                1
 UP bnd       x1424                1
 UP bnd       x1425                1
 UP bnd       x1426                1
 UP bnd       x1427                1
 UP bnd       x1428                1
 UP bnd       x1429                1
 UP bnd       x1430                1
 UP bnd       x1431                1
 UP bnd       x1432                1
 UP bnd       x1433                1
 UP bnd       x1434                1
 UP bnd       x1435                1
 UP bnd       x1436                1
 UP bnd       x1437                1
 UP bnd       x1438                1
 UP bnd       x1439                1
 UP bnd       x1440                1
 UP bnd       x1441                1
 UP bnd       x1442                1
 UP bnd       x1443                1
 UP bnd       x1444                1
 UP bnd       x1445                1
 UP bnd       x1446                1
 UP bnd       x1447                1
 UP bnd       x1448                1
 UP bnd       x1449                1
 UP bnd       x1450                1
 UP bnd       x1451                1
 UP bnd       x1452                1
 UP bnd       x1453                1
 UP bnd       x1454                1
 UP bnd       x1455                1
 UP bnd       x1456                1
 UP bnd       x1457                1
 UP bnd       x1458                1
 UP bnd       x1459                1
 UP bnd       x1460                1
 UP bnd       x1461                1
 UP bnd       x1462                1
 UP bnd       x1463                1
 UP bnd       x1464                1
 UP bnd       x1465                1
 UP bnd       x1466                1
 UP bnd       x1467                1
 UP bnd       x1468                1
 UP bnd       x1469                1
 UP bnd       x1470                1
 UP bnd       x1471                1
 UP bnd       x1472                1
 UP bnd       x1473                1
 UP bnd       x1474                1
 UP bnd       x1475                1
 UP bnd       x1476                1
 UP bnd       x1477                1
 UP bnd       x1478                1
 UP bnd       x1479                1
 UP bnd       x1480                1
 UP bnd       x1481                1
 UP bnd       x1482                1
 UP bnd       x1483                1
 UP bnd       x1484                1
 UP bnd       x1485                1
 UP bnd       x1486                1
 UP bnd       x1487                1
 UP bnd       x1488                1
 UP bnd       x1489                1
 UP bnd       x1490                1
 UP bnd       x1491                1
 UP bnd       x1492                1
 UP bnd       x1493                1
 UP bnd       x1494                1
 UP bnd       x1495                1
 UP bnd       x1496                1
 UP bnd       x1497                1
 UP bnd       x1498                1
 UP bnd       x1499                1
 UP bnd       x1500                1
 UP bnd       x1501                1
 UP bnd       x1502                1
 UP bnd       x1503                1
 UP bnd       x1504                1
 UP bnd       x1505                1
 UP bnd       x1506                1
 UP bnd       x1507                1
 UP bnd       x1508                1
 UP bnd       x1509                1
 UP bnd       x1510                1
 UP bnd       x1511                1
 UP bnd       x1512                1
 UP bnd       x1513                1
 UP bnd       x1514                1
 UP bnd       x1515                1
 UP bnd       x1516                1
 UP bnd       x1517                1
 UP bnd       x1518                1
 UP bnd       x1519                1
 UP bnd       x1520                1
 UP bnd       x1521                1
 UP bnd       x1522                1
 UP bnd       x1523                1
 UP bnd       x1524                1
 UP bnd       x1525                1
 UP bnd       x1526                1
 UP bnd       x1527                1
 UP bnd       x1528                1
 UP bnd       x1529                1
 UP bnd       x1530                1
 UP bnd       x1531                1
 UP bnd       x1532                1
 UP bnd       x1533                1
 UP bnd       x1534                1
 UP bnd       x1535                1
 UP bnd       x1536                1
 UP bnd       x1537                1
 UP bnd       x1538                1
 UP bnd       x1539                1
 UP bnd       x1540                1
 UP bnd       x1541                1
 UP bnd       x1542                1
 UP bnd       x1543                1
 UP bnd       x1544                1
 UP bnd       x1545                1
 UP bnd       x1546                1
 UP bnd       x1547                1
 UP bnd       x1548                1
 UP bnd       x1549                1
 UP bnd       x1550                1
 UP bnd       x1551                1
 UP bnd       x1552                1
 UP bnd       x1553                1
 UP bnd       x1554                1
 UP bnd       x1555                1
 UP bnd       x1556                1
 UP bnd       x1557                1
 UP bnd       x1558                1
 UP bnd       x1559                1
 UP bnd       x1560                1
 UP bnd       x1561                1
 UP bnd       x1562                1
 UP bnd       x1563                1
 UP bnd       x1564                1
 UP bnd       x1565                1
 UP bnd       x1566                1
 UP bnd       x1567                1
 UP bnd       x1568                1
 UP bnd       x1569                1
 UP bnd       x1570                1
 UP bnd       x1571                1
 UP bnd       x1572                1
 UP bnd       x1573                1
 UP bnd       x1574                1
 UP bnd       x1575                1
 UP bnd       x1576                1
 UP bnd       x1577                1
 UP bnd       x1578                1
 UP bnd       x1579                1
 UP bnd       x1580                1
 UP bnd       x1581                1
 UP bnd       x1582                1
 UP bnd       x1583                1
 UP bnd       x1584                1
 UP bnd       x1585                1
 UP bnd       x1586                1
 UP bnd       x1587                1
 UP bnd       x1588                1
 UP bnd       x1589                1
 UP bnd       x1590                1
 UP bnd       x1591                1
 UP bnd       x1592                1
 UP bnd       x1593                1
 UP bnd       x1594                1
 UP bnd       x1595                1
 UP bnd       x1596                1
 UP bnd       x1597                1
 UP bnd       x1598                1
 UP bnd       x1599                1
 UP bnd       x1600                1
 UP bnd       x1601                1
 UP bnd       x1602                1
 UP bnd       x1603                1
 UP bnd       x1604                1
 UP bnd       x1605                1
 UP bnd       x1606                1
 UP bnd       x1607                1
 UP bnd       x1608                1
 UP bnd       x1609                1
 UP bnd       x1610                1
 UP bnd       x1611                1
 UP bnd       x1612                1
 UP bnd       x1613                1
 UP bnd       x1614                1
 UP bnd       x1615                1
 UP bnd       x1616                1
 UP bnd       x1617                1
 UP bnd       x1618                1
 UP bnd       x1619                1
 UP bnd       x1620                1
 UP bnd       x1621                1
 UP bnd       x1622                1
 UP bnd       x1623                1
 UP bnd       x1624                1
 UP bnd       x1625                1
 UP bnd       x1626                1
 UP bnd       x1627                1
 UP bnd       x1628                1
 UP bnd       x1629                1
 UP bnd       x1630                1
 UP bnd       x1631                1
 UP bnd       x1632                1
 UP bnd       x1633                1
 UP bnd       x1634                1
 UP bnd       x1635                1
 UP bnd       x1636                1
 UP bnd       x1637                1
 UP bnd       x1638                1
 UP bnd       x1639                1
 UP bnd       x1640                1
 UP bnd       x1641                1
 UP bnd       x1642                1
 UP bnd       x1643                1
 UP bnd       x1644                1
 UP bnd       x1645                1
 UP bnd       x1646                1
 UP bnd       x1647                1
 UP bnd       x1648                1
 UP bnd       x1649                1
 UP bnd       x1650                1
 UP bnd       x1651                1
 UP bnd       x1652                1
 UP bnd       x1653                1
 UP bnd       x1654                1
 UP bnd       x1655                1
 UP bnd       x1656                1
 UP bnd       x1657                1
 UP bnd       x1658                1
 UP bnd       x1659                1
 UP bnd       x1660                1
 UP bnd       x1661                1
 UP bnd       x1662                1
 UP bnd       x1663                1
 UP bnd       x1664                1
 UP bnd       x1665                1
 UP bnd       x1666                1
 UP bnd       x1667                1
 UP bnd       x1668                1
 UP bnd       x1669                1
 UP bnd       x1670                1
 UP bnd       x1671                1
 UP bnd       x1672                1
 UP bnd       x1673                1
 UP bnd       x1674                1
 UP bnd       x1675                1
 UP bnd       x1676                1
 UP bnd       x1677                1
 UP bnd       x1678                1
 UP bnd       x1679                1
 UP bnd       x1680                1
 UP bnd       x1681                1
 UP bnd       x1682                1
 UP bnd       x1683                1
 UP bnd       x1684                1
 UP bnd       x1685                1
 UP bnd       x1686                1
 UP bnd       x1687                1
 UP bnd       x1688                1
 UP bnd       x1689                1
 UP bnd       x1690                1
 UP bnd       x1691                1
 UP bnd       x1692                1
 UP bnd       x1693                1
 UP bnd       x1694                1
 UP bnd       x1695                1
 UP bnd       x1696                1
 UP bnd       x1697                1
 UP bnd       x1698                1
 UP bnd       x1699                1
 UP bnd       x1700                1
 UP bnd       x1701                1
 UP bnd       x1702                1
 UP bnd       x1703                1
 UP bnd       x1704                1
 UP bnd       x1705                1
 UP bnd       x1706                1
 UP bnd       x1707                1
 UP bnd       x1708                1
 UP bnd       x1709                1
 UP bnd       x1710                1
 UP bnd       x1711                1
 UP bnd       x1712                1
 UP bnd       x1713                1
 UP bnd       x1714                1
 UP bnd       x1715                1
 UP bnd       x1716                1
 UP bnd       x1717                1
 UP bnd       x1718                1
 UP bnd       x1719                1
 UP bnd       x1720                1
 UP bnd       x1721                1
 UP bnd       x1722                1
 UP bnd       x1723                1
 UP bnd       x1724                1
 UP bnd       x1725                1
 UP bnd       x1726                1
 UP bnd       x1727                1
 UP bnd       x1728                1
 UP bnd       x1729                1
 UP bnd       x1730                1
 UP bnd       x1731                1
 UP bnd       x1732                1
 UP bnd       x1733                1
 UP bnd       x1734                1
 UP bnd       x1735                1
 UP bnd       x1736                1
 UP bnd       x1737                1
 UP bnd       x1738                1
 UP bnd       x1739                1
 UP bnd       x1740                1
 UP bnd       x1741                1
 UP bnd       x1742                1
 UP bnd       x1743                1
 UP bnd       x1744                1
 UP bnd       x1745                1
 UP bnd       x1746                1
 UP bnd       x1747                1
 UP bnd       x1748                1
 UP bnd       x1749                1
 UP bnd       x1750                1
 UP bnd       x1751                1
 UP bnd       x1752                1
 UP bnd       x1753                1
 UP bnd       x1754                1
 UP bnd       x1755                1
 UP bnd       x1756                1
 UP bnd       x1757                1
 UP bnd       x1758                1
 UP bnd       x1759                1
 UP bnd       x1760                1
 UP bnd       x1761                1
 UP bnd       x1762                1
 UP bnd       x1763                1
 UP bnd       x1764                1
 UP bnd       x1765                1
 UP bnd       x1766                1
 UP bnd       x1767                1
 UP bnd       x1768                1
 UP bnd       x1769                1
 UP bnd       x1770                1
 UP bnd       x1771                1
 UP bnd       x1772                1
 UP bnd       x1773                1
 UP bnd       x1774                1
 UP bnd       x1775                1
 UP bnd       x1776                1
 UP bnd       x1777                1
 UP bnd       x1778                1
 UP bnd       x1779                1
 UP bnd       x1780                1
 UP bnd       x1781                1
 UP bnd       x1782                1
 UP bnd       x1783                1
 UP bnd       x1784                1
 UP bnd       x1785                1
 UP bnd       x1786                1
 UP bnd       x1787                1
 UP bnd       x1788                1
 UP bnd       x1789                1
 UP bnd       x1790                1
 UP bnd       x1791                1
 UP bnd       x1792                1
 UP bnd       x1793                1
 UP bnd       x1794                1
 UP bnd       x1795                1
 UP bnd       x1796                1
 UP bnd       x1797                1
 UP bnd       x1798                1
 UP bnd       x1799                1
 UP bnd       x1800                1
 UP bnd       x1801                1
 UP bnd       x1802                1
 UP bnd       x1803                1
 UP bnd       x1804                1
 UP bnd       x1805                1
 UP bnd       x1806                1
 UP bnd       x1807                1
 UP bnd       x1808                1
 UP bnd       x1809                1
 UP bnd       x1810                1
 UP bnd       x1811                1
 UP bnd       x1812                1
 UP bnd       x1813                1
 UP bnd       x1814                1
 UP bnd       x1815                1
 UP bnd       x1816                1
 UP bnd       x1817                1
 UP bnd       x1818                1
 UP bnd       x1819                1
 UP bnd       x1820                1
 UP bnd       x1821                1
 UP bnd       x1822                1
 UP bnd       x1823                1
 UP bnd       x1824                1
 UP bnd       x1825                1
 UP bnd       x1826                1
 UP bnd       x1827                1
 UP bnd       x1828                1
 UP bnd       x1829                1
 UP bnd       x1830                1
 UP bnd       x1831                1
 UP bnd       x1832                1
 UP bnd       x1833                1
 UP bnd       x1834                1
 UP bnd       x1835                1
 UP bnd       x1836                1
 UP bnd       x1837                1
 UP bnd       x1838                1
 UP bnd       x1839                1
 UP bnd       x1840                1
 UP bnd       x1841                1
 UP bnd       x1842                1
 UP bnd       x1843                1
 UP bnd       x1844                1
 UP bnd       x1845                1
 UP bnd       x1846                1
 UP bnd       x1847                1
 UP bnd       x1848                1
 UP bnd       x1849                1
 UP bnd       x1850                1
 UP bnd       x1851                1
 UP bnd       x1852                1
 UP bnd       x1853                1
 UP bnd       x1854                1
 UP bnd       x1855                1
 UP bnd       x1856                1
 UP bnd       x1857                1
 UP bnd       x1858                1
 UP bnd       x1859                1
 UP bnd       x1860                1
 UP bnd       x1861                1
 UP bnd       x1862                1
 UP bnd       x1863                1
 UP bnd       x1864                1
 UP bnd       x1865                1
 UP bnd       x1866                1
 UP bnd       x1867                1
 UP bnd       x1868                1
 UP bnd       x1869                1
 UP bnd       x1870                1
 UP bnd       x1871                1
 UP bnd       x1872                1
 UP bnd       x1873                1
 UP bnd       x1874                1
 UP bnd       x1875                1
 UP bnd       x1876                1
 UP bnd       x1877                1
 UP bnd       x1878                1
 UP bnd       x1879                1
 UP bnd       x1880                1
 UP bnd       x1881                1
 UP bnd       x1882                1
 UP bnd       x1883                1
 UP bnd       x1884                1
 UP bnd       x1885                1
 UP bnd       x1886                1
 UP bnd       x1887                1
 UP bnd       x1888                1
 UP bnd       x1889                1
 UP bnd       x1890                1
 UP bnd       x1891                1
 UP bnd       x1892                1
 UP bnd       x1893                1
 UP bnd       x1894                1
 UP bnd       x1895                1
 UP bnd       x1896                1
 UP bnd       x1897                1
 UP bnd       x1898                1
 UP bnd       x1899                1
 UP bnd       x1900                1
 UP bnd       x1901                1
 UP bnd       x1902                1
 UP bnd       x1903                1
 UP bnd       x1904                1
 UP bnd       x1905                1
 UP bnd       x1906                1
 UP bnd       x1907                1
 UP bnd       x1908                1
 UP bnd       x1909                1
 UP bnd       x1910                1
 UP bnd       x1911                1
 UP bnd       x1912                1
 UP bnd       x1913                1
 UP bnd       x1914                1
 UP bnd       x1915                1
 UP bnd       x1916                1
 UP bnd       x1917                1
 UP bnd       x1918                1
 UP bnd       x1919                1
 UP bnd       x1920                1
 UP bnd       x1921                1
 UP bnd       x1922                1
 UP bnd       x1923                1
 UP bnd       x1924                1
 UP bnd       x1925                1
 UP bnd       x1926                1
 UP bnd       x1927                1
 UP bnd       x1928                1
 UP bnd       x1929                1
 UP bnd       x1930                1
 UP bnd       x1931                1
 UP bnd       x1932                1
 UP bnd       x1933                1
 UP bnd       x1934                1
 UP bnd       x1935                1
 UP bnd       x1936                1
 UP bnd       x1937                1
 UP bnd       x1938                1
 UP bnd       x1939                1
 UP bnd       x1940                1
 UP bnd       x1941                1
 UP bnd       x1942                1
 UP bnd       x1943                1
 UP bnd       x1944                1
 UP bnd       x1945                1
 UP bnd       x1946                1
 UP bnd       x1947                1
 UP bnd       x1948                1
 UP bnd       x1949                1
 UP bnd       x1950                1
 UP bnd       x1951                1
 UP bnd       x1952                1
 UP bnd       x1953                1
 UP bnd       x1954                1
 UP bnd       x1955                1
 UP bnd       x1956                1
 UP bnd       x1957                1
 UP bnd       x1958                1
 UP bnd       x1959                1
 UP bnd       x1960                1
 UP bnd       x1961                1
 UP bnd       x1962                1
 UP bnd       x1963                1
 UP bnd       x1964                1
 UP bnd       x1965                1
 UP bnd       x1966                1
 UP bnd       x1967                1
 UP bnd       x1968                1
 UP bnd       x1969                1
 UP bnd       x1970                1
 UP bnd       x1971                1
 UP bnd       x1972                1
 UP bnd       x1973                1
 UP bnd       x1974                1
 UP bnd       x1975                1
 UP bnd       x1976                1
 UP bnd       x1977                1
 UP bnd       x1978                1
 UP bnd       x1979                1
 UP bnd       x1980                1
 UP bnd       x1981                1
 UP bnd       x1982                1
 UP bnd       x1983                1
 UP bnd       x1984                1
 UP bnd       x1985                1
 UP bnd       x1986                1
 UP bnd       x1987                1
 UP bnd       x1988                1
 UP bnd       x1989                1
 UP bnd       x1990                1
 UP bnd       x1991                1
 UP bnd       x1992                1
 UP bnd       x1993                1
 UP bnd       x1994                1
 UP bnd       x1995                1
 UP bnd       x1996                1
 UP bnd       x1997                1
 UP bnd       x1998                1
 UP bnd       x1999                1
 UP bnd       x2000                1
 UP bnd       x2001                1
 UP bnd       x2002                1
 UP bnd       x2003                1
 UP bnd       x2004                1
 UP bnd       x2005                1
 UP bnd       x2006                1
 UP bnd       x2007                1
 UP bnd       x2008                1
 UP bnd       x2009                1
 UP bnd       x2010                1
 UP bnd       x2011                1
 UP bnd       x2012                1
 UP bnd       x2013                1
 UP bnd       x2014                1
 UP bnd       x2015                1
 UP bnd       x2016                1
 UP bnd       x2017                1
 UP bnd       x2018                1
 UP bnd       x2019                1
 UP bnd       x2020                1
 UP bnd       x2021                1
 UP bnd       x2022                1
 UP bnd       x2023                1
 UP bnd       x2024                1
 UP bnd       x2025                1
 UP bnd       x2026                1
 UP bnd       x2027                1
 UP bnd       x2028                1
 UP bnd       x2029                1
 UP bnd       x2030                1
 UP bnd       x2031                1
 UP bnd       x2032                1
 UP bnd       x2033                1
 UP bnd       x2034                1
 UP bnd       x2035                1
 UP bnd       x2036                1
 UP bnd       x2037                1
 UP bnd       x2038                1
 UP bnd       x2039                1
 UP bnd       x2040                1
 UP bnd       x2041                1
 UP bnd       x2042                1
 UP bnd       x2043                1
 UP bnd       x2044                1
 UP bnd       x2045                1
 UP bnd       x2046                1
 UP bnd       x2047                1
 UP bnd       x2048                1
 UP bnd       x2049                1
 UP bnd       x2050                1
 UP bnd       x2051                1
 UP bnd       x2052                1
 UP bnd       x2053                1
 UP bnd       x2054                1
 UP bnd       x2055                1
 UP bnd       x2056                1
 UP bnd       x2057                1
 UP bnd       x2058                1
 UP bnd       x2059                1
 UP bnd       x2060                1
 UP bnd       x2061                1
 UP bnd       x2062                1
 UP bnd       x2063                1
 UP bnd       x2064                1
 UP bnd       x2065                1
 UP bnd       x2066                1
 UP bnd       x2067                1
 UP bnd       x2068                1
 UP bnd       x2069                1
 UP bnd       x2070                1
 UP bnd       x2071                1
 UP bnd       x2072                1
 UP bnd       x2073                1
 UP bnd       x2074                1
 UP bnd       x2075                1
 UP bnd       x2076                1
 UP bnd       x2077                1
 UP bnd       x2078                1
 UP bnd       x2079                1
 UP bnd       x2080                1
 UP bnd       x2081                1
 UP bnd       x2082                1
 UP bnd       x2083                1
 UP bnd       x2084                1
 UP bnd       x2085                1
 UP bnd       x2086                1
 UP bnd       x2087                1
 UP bnd       x2088                1
 UP bnd       x2089                1
 UP bnd       x2090                1
 UP bnd       x2091                1
 UP bnd       x2092                1
 UP bnd       x2093                1
 UP bnd       x2094                1
 UP bnd       x2095                1
 UP bnd       x2096                1
 UP bnd       x2097                1
 UP bnd       x2098                1
 UP bnd       x2099                1
 UP bnd       x2100                1
 UP bnd       x2101                1
 UP bnd       x2102                1
 UP bnd       x2103                1
 UP bnd       x2104                1
 UP bnd       x2105                1
 UP bnd       x2106                1
 UP bnd       x2107                1
 UP bnd       x2108                1
 UP bnd       x2109                1
 UP bnd       x2110                1
 UP bnd       x2111                1
 UP bnd       x2112                1
 UP bnd       x2113                1
 UP bnd       x2114                1
 UP bnd       x2115                1
 UP bnd       x2116                1
 UP bnd       x2117                1
 UP bnd       x2118                1
 UP bnd       x2119                1
 UP bnd       x2120                1
 UP bnd       x2121                1
 UP bnd       x2122                1
 UP bnd       x2123                1
 UP bnd       x2124                1
 UP bnd       x2125                1
 UP bnd       x2126                1
 UP bnd       x2127                1
 UP bnd       x2128                1
 UP bnd       x2129                1
 UP bnd       x2130                1
 UP bnd       x2131                1
 UP bnd       x2132                1
 UP bnd       x2133                1
 UP bnd       x2134                1
 UP bnd       x2135                1
 UP bnd       x2136                1
 UP bnd       x2137                1
 UP bnd       x2138                1
 UP bnd       x2139                1
 UP bnd       x2140                1
 UP bnd       x2141                1
 UP bnd       x2142                1
 UP bnd       x2143                1
 UP bnd       x2144                1
 UP bnd       x2145                1
 UP bnd       x2146                1
 UP bnd       x2147                1
 UP bnd       x2148                1
 UP bnd       x2149                1
 UP bnd       x2150                1
 UP bnd       x2151                1
 UP bnd       x2152                1
 UP bnd       x2153                1
 UP bnd       x2154                1
 UP bnd       x2155                1
 UP bnd       x2156                1
 UP bnd       x2157                1
 UP bnd       x2158                1
 UP bnd       x2159                1
 UP bnd       x2160                1
 UP bnd       x2161                1
 UP bnd       x2162                1
 UP bnd       x2163                1
 UP bnd       x2164                1
 UP bnd       x2165                1
 UP bnd       x2166                1
 UP bnd       x2167                1
 UP bnd       x2168                1
 UP bnd       x2169                1
 UP bnd       x2170                1
 UP bnd       x2171                1
 UP bnd       x2172                1
 UP bnd       x2173                1
 UP bnd       x2174                1
 UP bnd       x2175                1
 UP bnd       x2176                1
 UP bnd       x2177                1
 UP bnd       x2178                1
 UP bnd       x2179                1
 UP bnd       x2180                1
ENDATA
